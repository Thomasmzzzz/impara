-- =====================================================================
--  Impara — rappel de série du soir (à exécuter après push.sql)
--  Toutes les heures, on cherche les personnes pour qui il est 20 h,
--  qui ont une série en cours mais n'ont rien fait aujourd'hui (dans
--  LEUR fuseau horaire), qui ont activé les notifications et le rappel.
--  Un seul rappel par jour et par personne. Réexécutable sans risque.
-- =====================================================================
create extension if not exists pg_cron;

create table if not exists private.streak_reminders (
  user_id uuid not null,
  day     date not null,
  primary key (user_id, day)
);
alter table private.streak_reminders enable row level security;

create or replace function private.send_streak_reminders()
returns int language plpgsql security definer set search_path = '' as $$
declare r record; secret text; n int := 0;
begin
  select value into secret from private.settings where key = 'notify_secret';
  delete from private.streak_reminders where day < current_date - 7;
  for r in
    with s as (
      select us.user_id, us.summary, us.updated_at,
             case when exists (select 1 from pg_catalog.pg_timezone_names z where z.name = us.summary->>'tz')
                  then us.summary->>'tz' else 'UTC' end as tz
      from public.user_stats us
      where exists (select 1 from public.push_subscriptions p where p.user_id = us.user_id)
    ), l as (
      select user_id, summary, updated_at, (now() at time zone tz) as local_now
      from s
    )
    select user_id,
           min(local_now::date) as local_day,
           max(extract(hour from local_now))::int as hr,
           bool_or(summary->>'lastDay' = to_char(local_now::date, 'YYYY-MM-DD')) as done_today,
           max(case when summary->>'lastDay' = to_char(local_now::date - 1, 'YYYY-MM-DD')
                    then coalesce((summary->>'streakRaw')::int, (summary->>'streak')::int, 0) else 0 end) as at_risk,
           -- réglages du résumé le plus récent (la langue utilisée en dernier)
           (array_agg(coalesce((summary->>'remind')::boolean, true) order by updated_at desc))[1] as remind,
           (array_agg(coalesce((summary->>'remindHour')::int, 20) order by updated_at desc))[1] as at_hour
    from l group by user_id
  loop
    continue when r.hr <> r.at_hour or r.done_today or r.at_risk < 1 or not r.remind;
    insert into private.streak_reminders (user_id, day) values (r.user_id, r.local_day)
      on conflict do nothing;
    continue when not found;
    perform net.http_post(
      url := 'https://brfysaduoqeozqqazbaa.supabase.co/functions/v1/notify',
      body := jsonb_build_object('action', 'streak', 'user', r.user_id, 'streak', r.at_risk),
      headers := jsonb_build_object('Content-Type', 'application/json', 'x-notify-secret', secret),
      timeout_milliseconds := 5000
    );
    n := n + 1;
  end loop;
  return n;
end;
$$;
revoke execute on function private.send_streak_reminders() from public, anon, authenticated;

-- Toutes les heures, à la minute 0
select cron.unschedule(jobid) from cron.job where jobname = 'impara-streak-reminder';
select cron.schedule('impara-streak-reminder', '0 * * * *', 'select private.send_streak_reminders()');

select jobid, jobname, schedule from cron.job where jobname = 'impara-streak-reminder';
