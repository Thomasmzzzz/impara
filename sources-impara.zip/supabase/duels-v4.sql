-- =====================================================================
--  Impara — duels v4 : mort subite, « sur son terrain », revanche
--  - mode 'survival' : jusqu'à la première erreur (50 questions au plus) ;
--  - words           : liste de mots imposée (points faibles de l'adversaire) ;
--  - rematch_of      : défi lancé en revanche d'un autre (notification dédiée).
--  À exécuter après social-v3.sql. Réexécutable sans risque.
-- =====================================================================

alter table public.challenges add column if not exists words jsonb;
alter table public.challenges add column if not exists rematch_of uuid references public.challenges (id) on delete set null;

alter table public.challenges drop constraint if exists challenges_mode_check;
alter table public.challenges add constraint challenges_mode_check check (mode is null or mode in ('speed', 'precision', 'survival'));
alter table public.challenges drop constraint if exists challenges_words_check;
alter table public.challenges add constraint challenges_words_check check (
  words is null or (jsonb_typeof(words) = 'array' and jsonb_array_length(words) between 12 and 40 and pg_column_size(words) < 6000));

drop function if exists public.create_challenge(uuid, int, text, boolean);
create or replace function public.create_challenge(
  p_opponent uuid, p_n int default 10, p_mode text default 'speed', p_live boolean default false,
  p_words jsonb default null, p_rematch uuid default null)
returns uuid language plpgsql security definer set search_path = '' as $$
declare new_id uuid; m text; k int;
begin
  if not public.are_friends(auth.uid(), p_opponent) then raise exception 'not_friends'; end if;
  m := case when p_mode in ('precision', 'survival') then p_mode else 'speed' end;
  k := case when m = 'survival' then 50 else coalesce(p_n, 10) end;
  if k not in (5, 10, 15, 25, 50) then raise exception 'invalid_n'; end if;
  if p_words is not null and (jsonb_typeof(p_words) <> 'array' or jsonb_array_length(p_words) not between 12 and 40) then
    raise exception 'invalid_words';
  end if;
  -- Une revanche cite forcément un défi entre les deux mêmes joueurs
  if p_rematch is not null and not exists (
    select 1 from public.challenges c where c.id = p_rematch
      and ((c.challenger = auth.uid() and c.opponent = p_opponent) or (c.challenger = p_opponent and c.opponent = auth.uid()))) then
    raise exception 'invalid_rematch';
  end if;
  insert into public.challenges (challenger, opponent, n, mode, live, words, rematch_of)
  values (auth.uid(), p_opponent, k, m, coalesce(p_live, false), p_words, p_rematch)
  returning id into new_id;
  return new_id;
end;
$$;
revoke execute on function public.create_challenge(uuid, int, text, boolean, jsonb, uuid) from public, anon;
grant execute on function public.create_challenge(uuid, int, text, boolean, jsonb, uuid) to authenticated;

select column_name from information_schema.columns where table_name = 'challenges' and column_name in ('words', 'rematch_of');
