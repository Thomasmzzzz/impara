-- =====================================================================
--  Impara — schéma de la base Supabase
--  À coller dans Supabase → SQL Editor → New query → Run
-- =====================================================================

-- Une ligne par compte et par langue étudiée (it, zh, …)
create table if not exists public.progress (
  user_id    uuid        not null references auth.users (id) on delete cascade,
  lang       text        not null check (char_length(lang) between 2 and 8),
  state      jsonb       not null check (pg_column_size(state) < 512000), -- garde-fou de taille
  updated_at timestamptz not null default now(),
  primary key (user_id, lang)
);

-- Sécurité ligne par ligne : chacun ne voit et ne modifie QUE sa progression
alter table public.progress enable row level security;

drop policy if exists "lire sa progression"      on public.progress;
drop policy if exists "créer sa progression"     on public.progress;
drop policy if exists "modifier sa progression"  on public.progress;
drop policy if exists "supprimer sa progression" on public.progress;

create policy "lire sa progression" on public.progress
  for select to authenticated using ((select auth.uid()) = user_id);

create policy "créer sa progression" on public.progress
  for insert to authenticated with check ((select auth.uid()) = user_id);

create policy "modifier sa progression" on public.progress
  for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

create policy "supprimer sa progression" on public.progress
  for delete to authenticated using ((select auth.uid()) = user_id);

-- Aucun accès pour les visiteurs non connectés
revoke all on public.progress from anon;
grant select, insert, update, delete on public.progress to authenticated;
