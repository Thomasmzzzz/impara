-- =====================================================================
--  Impara — messages v2 : réponses citées, réactions, cartes « mot du carnet »
--  À exécuter une fois dans l'éditeur SQL de Supabase (idempotent).
-- =====================================================================

alter table public.messages add column if not exists reply_to  bigint references public.messages (id) on delete set null;
alter table public.messages add column if not exists kind      text   not null default 'text';
alter table public.messages add column if not exists meta      jsonb;
alter table public.messages add column if not exists reactions jsonb  not null default '{}'::jsonb;

do $$ begin
  alter table public.messages add constraint messages_kind_ok check (kind in ('text', 'word'));
exception when duplicate_object then null; end $$;
do $$ begin
  alter table public.messages add constraint messages_meta_size check (meta is null or pg_column_size(meta) < 1000);
exception when duplicate_object then null; end $$;

-- La réponse doit citer un message de la même conversation
create or replace function public.same_conversation(p_msg bigint, p_a uuid, p_b uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.messages m where m.id = p_msg
    and ((m.sender = p_a and m.recipient = p_b) or (m.sender = p_b and m.recipient = p_a)));
$$;

drop policy if exists "écrire à un ami" on public.messages;
create policy "écrire à un ami" on public.messages for insert to authenticated
  with check (
    (select auth.uid()) = sender and read_at is null and public.are_friends(sender, recipient)
    and reactions = '{}'::jsonb
    and (reply_to is null or public.same_conversation(reply_to, sender, recipient))
  );

-- Réagir à un message (ou retirer sa réaction avec p_emoji = null)
create or replace function public.react_message(p_id bigint, p_emoji text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare r jsonb;
begin
  if p_emoji is not null and p_emoji not in ('❤️', '😂', '👏', '😮', '🔥') then
    raise exception 'bad_emoji';
  end if;
  update public.messages
     set reactions = case when p_emoji is null then reactions - (select auth.uid())::text
                          else reactions || jsonb_build_object((select auth.uid())::text, p_emoji) end
   where id = p_id and (select auth.uid()) in (sender, recipient)
  returning reactions into r;
  return r;
end;
$$;

revoke execute on function public.same_conversation(bigint, uuid, uuid), public.react_message(bigint, text) from public, anon;
grant execute on function public.same_conversation(bigint, uuid, uuid), public.react_message(bigint, text) to authenticated;

select column_name from information_schema.columns where table_schema = 'public' and table_name = 'messages' order by ordinal_position;
