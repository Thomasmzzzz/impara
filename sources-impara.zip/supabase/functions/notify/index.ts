// =====================================================================
//  Fonction serveur « notify » (Supabase Edge Function)
//  - { action: "vapid" } : renvoie la clé publique des notifications
//    (les clés sont créées automatiquement au premier appel) ;
//  - appel des déclencheurs SQL (avec le secret partagé) : envoie la
//    notification au bon destinataire (message, ami, défi).
//  Déploiement : sans vérification JWT (les déclencheurs n'ont pas de
//  session) ; la sécurité repose sur le secret généré dans la base.
// =====================================================================
import webpush from "npm:web-push@3.6.7";
import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const SITE = "https://thomasmzzzz.github.io/impara/";
// Clé serveur : ancienne « service_role » ou nouvelle clé secrète (sb_secret_…)
function serverKey(): string {
  const legacy = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (legacy) return legacy;
  const raw = Deno.env.get("SUPABASE_SECRET_KEYS") ?? "";
  try { const v = JSON.parse(raw); return typeof v === "string" ? v : Object.values(v)[0] as string; } catch { return raw; }
}
const sb = createClient(Deno.env.get("SUPABASE_URL")!, serverKey(), {
  auth: { persistSession: false, autoRefreshToken: false },
});
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });

async function setting(k: string): Promise<string | null> {
  const { data } = await sb.rpc("notify_get_setting", { k });
  return data ?? null;
}

let vapid: { publicKey: string; privateKey: string } | null = null;
async function getVapid() {
  if (vapid) return vapid;
  let raw = await setting("vapid");
  if (!raw) {
    const keys = webpush.generateVAPIDKeys();
    await sb.rpc("notify_set_setting", { k: "vapid", v: JSON.stringify(keys) });
    raw = await setting("vapid"); // relu : si deux appels simultanés, une seule paire est gardée
  }
  vapid = JSON.parse(raw!);
  webpush.setVapidDetails("https://thomasmzzzz.github.io", vapid!.publicKey, vapid!.privateKey);
  return vapid!;
}

type Profile = { username: string; pseudo: string | null } | null;
async function profile(id: string): Promise<Profile> {
  const { data } = await sb.from("profiles").select("username, pseudo").eq("id", id).maybeSingle();
  return data;
}
const name = (p: Profile) => p?.pseudo || p?.username || "Un ami";

async function sendTo(userId: string, payload: Record<string, unknown>) {
  const { data: subs } = await sb.from("push_subscriptions").select("*").eq("user_id", userId);
  await Promise.all((subs ?? []).map(async (s) => {
    try {
      await webpush.sendNotification(
        { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
        JSON.stringify(payload),
        { TTL: 86400 },
      );
    } catch (e) {
      const code = (e as { statusCode?: number }).statusCode;
      if (code === 404 || code === 410) await sb.from("push_subscriptions").delete().eq("endpoint", s.endpoint);
      else console.error("push error", code, String(e));
    }
  }));
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const body = await req.json().catch(() => ({}));

  if (body.action === "vapid") return json({ publicKey: (await getVapid()).publicKey });

  const secret = await setting("notify_secret");
  if (!secret || req.headers.get("x-notify-secret") !== secret) return json({ error: "forbidden" }, 403);
  await getVapid();

  const { table, op, id, old } = body;
  if (!["messages", "friendships", "challenges"].includes(table)) return json({ ok: true });
  const { data: row } = await sb.from(table).select("*").eq("id", id).maybeSingle();
  if (!row) return json({ ok: true });

  if (table === "messages" && op === "INSERT") {
    const p = await profile(row.sender);
    await sendTo(row.recipient, { title: `💬 ${name(p)}`, body: String(row.body).slice(0, 140), url: `${SITE}#ami-${p?.username ?? ""}`, tag: `msg-${row.sender}` });
  } else if (table === "friendships") {
    if (op === "INSERT" && row.status === "pending") {
      const p = await profile(row.requester);
      await sendTo(row.addressee, { title: "👥 Nouvelle demande d'ami", body: `${name(p)} (@${p?.username}) veut devenir votre ami.`, url: `${SITE}#amis`, tag: "friend" });
    } else if (op === "UPDATE" && old?.status === "pending" && row.status === "accepted") {
      const p = await profile(row.addressee);
      await sendTo(row.requester, { title: "🎉 Demande acceptée", body: `${name(p)} a accepté votre demande d'ami.`, url: `${SITE}#ami-${p?.username ?? ""}`, tag: "friend" });
    }
  } else if (table === "challenges") {
    const url = `${SITE}#defi-${row.id}`;
    if (op === "INSERT") {
      const p = await profile(row.challenger);
      await sendTo(row.opponent, { title: "⚔️ Nouveau défi !", body: `${name(p)} vous défie sur ${row.n} questions.`, url: `${SITE}#amis`, tag: `defi-${row.id}` });
    } else if (op === "UPDATE" && old) {
      if (old.status === "pending" && row.status === "accepted") {
        const p = await profile(row.opponent);
        await sendTo(row.challenger, { title: "⚔️ Défi accepté", body: `${name(p)} a accepté votre défi : à vous de jouer !`, url, tag: `defi-${row.id}` });
      } else if (old.status === "pending" && row.status === "declined") {
        const p = await profile(row.opponent);
        await sendTo(row.challenger, { title: "Défi refusé", body: `${name(p)} a refusé votre défi.`, url: `${SITE}#amis`, tag: `defi-${row.id}` });
      } else if (row.status === "accepted") {
        const justPlayed = old.challenger_score == null && row.challenger_score != null ? row.challenger
          : old.opponent_score == null && row.opponent_score != null ? row.opponent : null;
        if (justPlayed) {
          const other = justPlayed === row.challenger ? row.opponent : row.challenger;
          const p = await profile(justPlayed);
          const both = row.challenger_score != null && row.opponent_score != null;
          await sendTo(other, both
            ? { title: "🏁 Résultat du défi", body: `${name(p)} a joué : découvrez qui a gagné !`, url, tag: `defi-${row.id}` }
            : { title: "⏱️ À vous de jouer", body: `${name(p)} a terminé le défi. Saurez-vous faire mieux ?`, url, tag: `defi-${row.id}` });
        }
      }
    }
  }
  return json({ ok: true });
});
