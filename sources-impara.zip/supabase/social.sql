-- =====================================================================
--  Impara — espace social : noms d'utilisateur, amis, messages, défis
--  À exécuter APRÈS schema.sql (Supabase → SQL Editor → Run).
--  Réexécutable sans risque.
--
--  Sécurité :
--  - un profil (nom d'utilisateur, pseudo, avatar) est visible des
--    personnes connectées, pour pouvoir chercher un ami ;
--  - la progression (user_stats) n'est visible QUE de soi et de ses amis ;
--  - les messages ne sont visibles que de l'expéditeur et du destinataire,
--    et on ne peut écrire qu'à un ami ;
--  - toutes les actions sensibles (demandes d'ami, défis, scores) passent
--    par des fonctions qui vérifient qui a le droit de faire quoi.
-- =====================================================================

-- ---------------------------------------------------------------- Profils
create table if not exists public.profiles (
  id         uuid primary key references auth.users (id) on delete cascade,
  username   text not null unique check (username ~ '^[a-z0-9_]{3,20}$'),
  pseudo     text check (char_length(pseudo) <= 40),
  avatar     text check (char_length(avatar) <= 16),
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

drop policy if exists "profils visibles"   on public.profiles;
drop policy if exists "créer son profil"    on public.profiles;
drop policy if exists "modifier son profil" on public.profiles;
create policy "profils visibles"   on public.profiles for select to authenticated using (true);
create policy "créer son profil"    on public.profiles for insert to authenticated with check ((select auth.uid()) = id);
create policy "modifier son profil" on public.profiles for update to authenticated
  using ((select auth.uid()) = id) with check ((select auth.uid()) = id);

-- ------------------------------------------------------------------- Amis
create table if not exists public.friendships (
  id         bigint generated always as identity primary key,
  requester  uuid not null references public.profiles (id) on delete cascade,
  addressee  uuid not null references public.profiles (id) on delete cascade,
  status     text not null default 'pending' check (status in ('pending', 'accepted')),
  created_at timestamptz not null default now(),
  check (requester <> addressee)
);
create unique index if not exists friendships_pair
  on public.friendships (least(requester, addressee), greatest(requester, addressee));
create index if not exists friendships_addressee on public.friendships (addressee);
alter table public.friendships enable row level security;

drop policy if exists "voir ses amitiés"     on public.friendships;
drop policy if exists "supprimer une amitié" on public.friendships;
create policy "voir ses amitiés" on public.friendships for select to authenticated
  using ((select auth.uid()) in (requester, addressee));
-- Refuser une demande, l'annuler ou retirer un ami
create policy "supprimer une amitié" on public.friendships for delete to authenticated
  using ((select auth.uid()) in (requester, addressee));

create or replace function public.are_friends(a uuid, b uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.friendships f
    where f.status = 'accepted'
      and ((f.requester = a and f.addressee = b) or (f.requester = b and f.addressee = a))
  );
$$;

-- Envoie une demande (ou accepte directement si l'autre nous l'a déjà demandée)
create or replace function public.send_friend_request(p_username text)
returns text language plpgsql security definer set search_path = '' as $$
declare
  me uuid := auth.uid();
  target uuid;
  existing public.friendships;
begin
  if me is null then raise exception 'not_authenticated'; end if;
  if not exists (select 1 from public.profiles where id = me) then return 'no_profile'; end if;
  select id into target from public.profiles where username = lower(trim(p_username));
  if target is null then return 'not_found'; end if;
  if target = me then return 'self'; end if;
  select * into existing from public.friendships
   where least(requester, addressee) = least(me, target) and greatest(requester, addressee) = greatest(me, target);
  if found then
    if existing.status = 'accepted' then return 'already_friends'; end if;
    if existing.addressee = me then
      update public.friendships set status = 'accepted' where id = existing.id;
      return 'accepted';
    end if;
    return 'already_sent';
  end if;
  insert into public.friendships (requester, addressee) values (me, target);
  return 'sent';
end;
$$;

create or replace function public.accept_friend_request(p_id bigint)
returns void language plpgsql security definer set search_path = '' as $$
begin
  update public.friendships set status = 'accepted'
   where id = p_id and addressee = auth.uid() and status = 'pending';
  if not found then raise exception 'request_not_found'; end if;
end;
$$;

-- ----------------------------------------------- Progression (pour les amis)
create table if not exists public.user_stats (
  user_id    uuid not null references public.profiles (id) on delete cascade,
  lang       text not null check (char_length(lang) between 2 and 8),
  summary    jsonb not null check (pg_column_size(summary) < 8000),
  updated_at timestamptz not null default now(),
  primary key (user_id, lang)
);
alter table public.user_stats enable row level security;

drop policy if exists "voir stats amis"   on public.user_stats;
drop policy if exists "créer ses stats"   on public.user_stats;
drop policy if exists "modifier ses stats" on public.user_stats;
create policy "voir stats amis" on public.user_stats for select to authenticated
  using ((select auth.uid()) = user_id or public.are_friends((select auth.uid()), user_id));
create policy "créer ses stats" on public.user_stats for insert to authenticated
  with check ((select auth.uid()) = user_id);
create policy "modifier ses stats" on public.user_stats for update to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

-- --------------------------------------------------------------- Messages
create table if not exists public.messages (
  id         bigint generated always as identity primary key,
  sender     uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  recipient  uuid not null references public.profiles (id) on delete cascade,
  body       text not null check (char_length(trim(body)) between 1 and 1000),
  created_at timestamptz not null default now(),
  read_at    timestamptz
);
create index if not exists messages_pair   on public.messages (sender, recipient, created_at desc);
create index if not exists messages_unread on public.messages (recipient) where read_at is null;
alter table public.messages enable row level security;

drop policy if exists "voir ses messages"     on public.messages;
drop policy if exists "écrire à un ami"       on public.messages;
create policy "voir ses messages" on public.messages for select to authenticated
  using ((select auth.uid()) in (sender, recipient));
create policy "écrire à un ami" on public.messages for insert to authenticated
  with check ((select auth.uid()) = sender and read_at is null and public.are_friends(sender, recipient));

create or replace function public.mark_messages_read(p_friend uuid)
returns void language sql security definer set search_path = '' as $$
  update public.messages set read_at = now()
   where recipient = auth.uid() and sender = p_friend and read_at is null;
$$;

-- ------------------------------------------------------------------ Défis
create table if not exists public.challenges (
  id               uuid primary key default gen_random_uuid(),
  challenger       uuid not null references public.profiles (id) on delete cascade,
  opponent         uuid not null references public.profiles (id) on delete cascade,
  status           text not null default 'pending' check (status in ('pending', 'accepted', 'declined', 'cancelled')),
  n                int  not null default 10 check (n between 5 and 20),
  challenger_lang  text, challenger_score int, challenger_total int, challenger_ms int,
  opponent_lang    text, opponent_score   int, opponent_total   int, opponent_ms   int,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  check (challenger <> opponent)
);
create index if not exists challenges_challenger on public.challenges (challenger, created_at desc);
create index if not exists challenges_opponent   on public.challenges (opponent, created_at desc);
alter table public.challenges enable row level security;

drop policy if exists "voir ses défis" on public.challenges;
create policy "voir ses défis" on public.challenges for select to authenticated
  using ((select auth.uid()) in (challenger, opponent));

create or replace function public.create_challenge(p_opponent uuid, p_n int default 10)
returns uuid language plpgsql security definer set search_path = '' as $$
declare new_id uuid;
begin
  if not public.are_friends(auth.uid(), p_opponent) then raise exception 'not_friends'; end if;
  insert into public.challenges (challenger, opponent, n)
  values (auth.uid(), p_opponent, greatest(5, least(20, coalesce(p_n, 10))))
  returning id into new_id;
  return new_id;
end;
$$;

-- L'adversaire accepte ou refuse ; le lanceur peut annuler tant que ce n'est pas accepté
create or replace function public.respond_challenge(p_id uuid, p_accept boolean)
returns void language plpgsql security definer set search_path = '' as $$
begin
  update public.challenges
     set status = case when p_accept then 'accepted' else 'declined' end, updated_at = now()
   where id = p_id and opponent = auth.uid() and status = 'pending';
  if not found then raise exception 'challenge_not_found'; end if;
end;
$$;

create or replace function public.cancel_challenge(p_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  update public.challenges set status = 'cancelled', updated_at = now()
   where id = p_id and challenger = auth.uid() and status = 'pending';
  if not found then raise exception 'challenge_not_found'; end if;
end;
$$;

-- Enregistre son score, une seule fois, quand le défi est accepté
create or replace function public.submit_challenge(p_id uuid, p_lang text, p_score int, p_total int, p_ms int)
returns void language plpgsql security definer set search_path = '' as $$
declare c public.challenges;
begin
  select * into c from public.challenges where id = p_id for update;
  if not found or c.status <> 'accepted' then raise exception 'challenge_not_playable'; end if;
  if p_total < 1 or p_total > c.n or p_score < 0 or p_score > p_total or p_ms < 0 then raise exception 'invalid_score'; end if;
  if char_length(coalesce(p_lang, '')) not between 2 and 8 then raise exception 'invalid_lang'; end if;
  if c.challenger = auth.uid() and c.challenger_score is null then
    update public.challenges set challenger_lang = p_lang, challenger_score = p_score, challenger_total = p_total,
           challenger_ms = p_ms, updated_at = now() where id = p_id;
  elsif c.opponent = auth.uid() and c.opponent_score is null then
    update public.challenges set opponent_lang = p_lang, opponent_score = p_score, opponent_total = p_total,
           opponent_ms = p_ms, updated_at = now() where id = p_id;
  else
    raise exception 'already_played';
  end if;
end;
$$;

-- ------------------------------------------------------ Droits d'accès
revoke all on public.profiles, public.friendships, public.user_stats, public.messages, public.challenges from anon;
grant select, insert, update on public.profiles   to authenticated;
grant select, delete         on public.friendships to authenticated;
grant select, insert, update on public.user_stats to authenticated;
grant select, insert         on public.messages   to authenticated;
grant select                 on public.challenges to authenticated;

revoke execute on function public.are_friends(uuid, uuid), public.send_friend_request(text),
  public.accept_friend_request(bigint), public.mark_messages_read(uuid), public.create_challenge(uuid, int),
  public.respond_challenge(uuid, boolean), public.cancel_challenge(uuid),
  public.submit_challenge(uuid, text, int, int, int) from public, anon;
grant execute on function public.are_friends(uuid, uuid), public.send_friend_request(text),
  public.accept_friend_request(bigint), public.mark_messages_read(uuid), public.create_challenge(uuid, int),
  public.respond_challenge(uuid, boolean), public.cancel_challenge(uuid),
  public.submit_challenge(uuid, text, int, int, int) to authenticated;

-- -------------------------------------------- Temps réel (messages instantanés)
do $$
declare t text;
begin
  foreach t in array array['messages', 'challenges', 'friendships'] loop
    if not exists (select 1 from pg_publication_tables
                   where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t) then
      execute format('alter publication supabase_realtime add table public.%I', t);
    end if;
  end loop;
end $$;
