"""Génère js/data/zh-keys.js : la décomposition des caractères du cours en « clés ».
CHARS : caractère -> [composants, index du composant qui donne le son (-1 si aucun), histoire]
COMPS : composant -> [pinyin, sens en français]
Dépendances : pip install hanzipy pypinyin"""
import json, logging, re, unicodedata
logging.disable(logging.INFO)
from hanzipy.decomposer import HanziDecomposer
from pypinyin import pinyin

ROOT = "/home/claude/impara/impara-comptes/"
D = HanziDecomposer()
GLOSS = json.load(open(ROOT + "tools/radicaux-fr.json", encoding="utf8"))
STORY = json.load(open(ROOT + "tools/histoires-cles.json", encoding="utf8"))
src = "".join(open(ROOT + "js/data/" + f, encoding="utf8").read() for f in ["zh.js", "zh-hsk1-plus.js", "zh-hsk2-plus.js", "zh-hsk3-plus.js", "stories-zh.js", "dialogues-zh.js"])
HAN = lambda c: "一" <= c <= "鿿"
chars = sorted({c for c in src if HAN(c)})

# Sens des caractères seuls dans le cours : [« 好 », « hǎo », « bien »]
course = {}
for m in re.finditer(r'\["([^"\]]+)",\s*"([^"]*)",\s*"([^"]+)"\]', src):
    w, py, fr = m.groups()
    if len(w) == 1 and HAN(w) and w not in course:
        course[w] = re.split(r" — | ; |, | / ", fr)[0].strip()[:28]

def toneless(s):
    return re.sub(r"[̀-̄̌]", "", unicodedata.normalize("NFD", s)).replace("ü", "v")

VARIANTS = set("亻氵讠扌忄纟艹饣钅辶宀阝刂⺮灬⻊犭礻衤疒冫冖亠彳廴攵罒覀⺈⺊⺀⺌⺍")  # formes de clés qui ne se lisent pas seules
def read(c):
    if not HAN(c) or c in VARIANTS: return ""
    rs = pinyin(c, heteronym=True)[0]
    tone = [r for r in rs if re.search("[āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ]", r)]
    r = (tone or rs)[0]
    return "" if r == c else r

out_chars, comps = {}, {}
for c in chars:
    parts = [x for x in D.decompose(c)["once"] if x != c and "glyph" not in x]
    if len(parts) < 2 and c not in STORY: continue
    me = toneless(read(c))
    phon = -1
    for i, x in enumerate(parts):
        if read(x) and toneless(read(x)) == me and len(parts) == 2: phon = i
    for x in parts:
        if x not in comps: comps[x] = [read(x), course.get(x) or GLOSS.get(x, "")]
    out_chars[c] = [parts, phon, STORY.get(c, "")]

out = "/* Généré par tools/gen-keys.py (hanzipy + pypinyin) : clés des caractères du cours. */\n"
out += "export const CHARS = " + json.dumps(out_chars, ensure_ascii=False, separators=(",", ":")) + ";\n"
out += "export const COMPS = " + json.dumps(comps, ensure_ascii=False, separators=(",", ":")) + ";\n"
out += "export const MEAN = " + json.dumps(course, ensure_ascii=False, separators=(",", ":")) + ";\n"
open(ROOT + "js/data/zh-keys.js", "w", encoding="utf8").write(out)
phon = sum(1 for v in out_chars.values() if v[1] >= 0)
nogl = [k for k, v in comps.items() if not v[1]]
print(len(out_chars), "caractères ;", phon, "avec composant phonétique ;", len(comps), "composants ;", len(nogl), "sans sens :", "".join(nogl)[:80], ";", len(out.encode()), "octets")
for k in "好妈您请问饭们":
    print(k, out_chars.get(k), [comps[x] for x in out_chars.get(k, [[]])[0]])
