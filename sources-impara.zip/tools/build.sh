set -e
# Construction du site : JS découpé en morceaux (chargés à la demande), CSS intégrée
cd /home/claude/impara/impara-comptes
D=/home/claude/impara/dist
find $D -maxdepth 1 -name "*.js" ! -name "sw.js" -delete
rm -f $D/app.js $D/style.min.css $D/meta.json
esbuild js/app.js --bundle --splitting --format=esm --external:'https://*' --minify \
  --outdir=$D --entry-names='app-[hash]' --chunk-names='c-[hash]' --asset-names='a-[hash]' \
  --metafile=/tmp/impara-meta.json --log-level=warning
esbuild css/style.css --minify --outfile=/tmp/impara-style.min.css --log-level=warning
python3 - <<'PY'
import json, os
D='/home/claude/impara/dist'
meta=json.load(open('/tmp/impara-meta.json'))
outs=meta['outputs']
name=lambda p: os.path.basename(p)
entry=[k for k,v in outs.items() if v.get('entryPoint')=='js/app.js'][0]
def static_deps(k, seen=None):
    seen=seen if seen is not None else set()
    for imp in outs[k].get('imports',[]):
        if imp['kind']=='import-statement' and imp['path'] not in seen:
            seen.add(imp['path']); static_deps(imp['path'], seen)
    return seen
by_entry={v.get('entryPoint'):k for k,v in outs.items() if v.get('entryPoint')}
def bundle(eps):
    s=set()
    for e in eps:
        k=by_entry.get(e)
        if k: s.add(k); s|=static_deps(k)
    return s
base=static_deps(entry)
lang={'it':bundle(['js/data/it.js','js/data/stories-it.js'])-base-{entry},
      'zh':bundle(['js/data/zh.js','js/data/stories-zh.js','js/data/zh-pinyin.js'])-base-{entry}}
pre=''.join(f'<link rel="modulepreload" href="{name(p)}">' for p in sorted(base))
langjs=json.dumps({l:sorted(name(p) for p in v) for l,v in lang.items()})
html=open('index.html',encoding='utf-8').read()
css=open('/tmp/impara-style.min.css',encoding='utf-8').read()
html=html.replace('<link rel="stylesheet" href="css/style.css">','<style>\n'+css+'\n</style>')
html=html.replace('<script type="module" src="js/app.js"></script>',
  '<script>(function(){var m='+langjs+',l=document.documentElement.getAttribute("data-lang")||"it";(m[l]||[]).forEach(function(f){var k=document.createElement("link");k.rel="modulepreload";k.href=f;document.head.appendChild(k);});})();</script>\n'
  +pre+'\n<script type="module" src="'+name(entry)+'"></script>')
open(D+'/index.html','w',encoding='utf-8').write(html)
tot=lambda ks: sum(outs[k]['bytes'] for k in ks)
print('index.html', os.path.getsize(D+'/index.html'), '| entrée+commun', tot(base|{entry}), '| it', tot(lang['it']), '| zh', tot(lang['zh']), '| total js', tot([k for k in outs if k.endswith('.js')]), '| fichiers', len([k for k in outs if k.endswith('.js')]))
PY
