import { pinyin } from "pinyin-pro";
import fs from "fs";
const src = fs.readFileSync("/home/claude/impara/impara-comptes/js/data/zh.js", "utf8");
const { LEVELS } = await import("/home/claude/impara/impara-comptes/js/data/zh.js");
// Pinyin des auteurs (vocabulaire + exemples), syllabe par syllabe quand c'est alignable
const author = {};
const SYL = /([bpmfdtnlgkhjqxrzcsyw]|zh|ch|sh)?[aeiouüāáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ]+(ng|n|r)?/gi;
const add = ([zh, py]) => {
  if (!py || !/^[㐀-鿿]+$/.test(zh)) return;
  const syl = pinyin(zh, { type: "array" }).length === zh.length ? null : null;
  author[zh] = py;
};
LEVELS.forEach((l) => l.lessons.forEach((les) => {
  (les.vocab || []).forEach((x) => x.length === 3 && add(x));
  (les.sections || []).forEach((s) => (s.examples || []).forEach((x) => x.length === 3 && add([x[0].replace(/[。！？，]/g, ""), x[1]])));
}));
const runs = [...new Set(src.match(/[㐀-鿿]+/g))];
const map = {};
for (const r of runs) {
  const arr = pinyin(r, { type: "array", toneSandhi: false });
  map[r] = arr.join(" ");
}
// Corrections : quand le mot existe dans le vocabulaire, on prend la lecture contextuelle de pinyin-pro
// mais on garde les tons neutres de l'auteur s'il a le même nombre de syllabes (ex. 谢谢 xiè xie)
const norm = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
let fixed = 0;
for (const [zh, py] of Object.entries(author)) {
  const mine = map[zh]?.split(" ");
  if (!mine) continue;
  const flat = py.replace(/[^a-zA-Zāáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜü]/g, "");
  // découpe le pinyin de l'auteur en suivant les syllabes de pinyin-pro (même lettres, tons différents)
  let i = 0; const out = [];
  for (const s of mine) { const n = norm(s).length; out.push(flat.slice(i, i + n)); i += n; }
  if (i === flat.length && out.every((x, k) => norm(x) === norm(mine[k]))) { const v = out.join(" ").toLowerCase(); if (v !== map[zh]) { map[zh] = v; fixed++; } }
}
Object.assign(map, { "了": "le", "着": "zhe", "得": "de", "过": "guo", "吗": "ma", "呢": "ne", "吧": "ba" });
fs.writeFileSync("/home/claude/impara/impara-comptes/js/data/zh-pinyin.js",
  "/* Généré automatiquement (pinyin-pro + pinyin du cours) : lecture de chaque suite de caractères du cours. */\nexport default " + JSON.stringify(map) + ";\n");
console.log("runs", runs.length, "fixed", fixed, "size", fs.statSync("/home/claude/impara/impara-comptes/js/data/zh-pinyin.js").size);
for (const k of ["她很漂亮", "他没来了", "你吃", "北京烤鸭吗", "我没有车", "谢谢", "不客气", "一个", "三十八", "好", "了", "我有", "个朋友"]) console.log(k, "→", map[k]);
