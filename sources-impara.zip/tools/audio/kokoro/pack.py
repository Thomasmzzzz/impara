import json,os,sys
lang=sys.argv[1]; HERE="/tmp/claude-0/kok"
src=open("/home/claude/impara/impara-comptes/tools/audio/generer-audio.py").read().replace("import edge_tts","edge_tts=None")
ns={"__name__":"g","__file__":HERE+"/x.py"}; exec(compile(src,"g","exec"),ns); ns["HERE"]=HERE; ns["PACK_MAX"]=9*1024*1024
items=json.load(open(f"/home/claude/impara/impara-comptes/tools/audio/texts-{lang}.json"))["items"]
ns["pack"](lang,items,f"{HERE}/clips/{lang}",{"it":"Kokoro if_sara","zh":"Kokoro zf_xiaoxiao"}[lang])
