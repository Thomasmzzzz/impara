import json, os, sys
voice, d = sys.argv[1], sys.argv[2]
src=f'/tmp/claude-0/kok/clips-short-t/{voice}'; folder=f'/home/claude/impara/dist/audio/{d}'
ix=json.load(open(f'{folder}/index.json'))
items=json.load(open('/tmp/claude-0/kok/it-short-all.json'))
PACK_MAX=9*1024*1024; base=len(ix['packs']); buf=bytearray(); n=0; new=[]; cnt=0
def flush():
    global buf,n
    name=f's1-p{n}.bin'; open(f'{folder}/{name}','wb').write(buf); new.append(name); buf=bytearray(); n+=1
for it in items:
    p=f'{src}/{it["id"]}.mp3'
    if not os.path.exists(p): continue
    data=open(p,'rb').read()
    if len(buf)+len(data)>PACK_MAX and buf: flush()
    ix['clips'][it['id']]=[base+n,len(buf),len(data)]; buf+=data; cnt+=1
if buf: flush()
ix['packs']+=new
json.dump(ix,open(f'{folder}/index.json','w'),separators=(',',':'))
print(d,cnt,'clips remplacés',new,ix['packs'])
