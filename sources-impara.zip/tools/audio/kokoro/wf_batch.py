import sys, json, os, time, numpy as np, lameenc
sys.path.insert(0,'/tmp/claude-0/kok'); from wordfix import *
items=json.load(open('/tmp/claude-0/kok/it-short-all.json'))
BIAS={'fin':-0.05,'début':0.0,'seul':0.1}
def mp3(s):
    s=np.concatenate([np.zeros(int(SR*0.05)), s, np.zeros(int(SR*0.15))]).astype(np.float32)
    e=lameenc.Encoder(); e.set_bit_rate(40); e.set_in_sample_rate(SR); e.set_channels(1); e.set_quality(2)
    return e.encode((np.clip(s,-1,1)*32767).astype(np.int16).tobytes())+e.flush()
def trim_start(a):
    e=np.sqrt(np.convolve(a*a,np.ones(240)/240,'same')); i=np.nonzero(e>e.max()*0.02)[0]
    return a[max(0,i[0]-600):i[-1]+2400] if len(i) else a
for voice in sys.argv[1:]:
    out=f'/tmp/claude-0/kok/clips-short/{voice}'; os.makedirs(out,exist_ok=True)
    log=open(f'{out}.jsonl','a'); t0=time.time(); n=0
    for it in items:
        p=f'{out}/{it["id"]}.mp3'
        if os.path.exists(p): continue
        try:
            ph=K.tokenizer.phonemize(it['t'],'it')
            vs=variants(ph,voice)
            best=min(vs,key=lambda v:v[2]+BIAS[v[0]])
            a=best[1] if best[0]!='seul' else trim_start(best[1])
            open(p+'.part','wb').write(mp3(a)); os.replace(p+'.part',p)
            log.write(json.dumps({'id':it['id'],'t':it['t'],'choix':best[0],'scores':{v[0]:round(v[2],3) for v in vs}},ensure_ascii=False)+'\n'); log.flush()
        except Exception as ex:
            print('FAIL',it['t'],ex,flush=True)
        n+=1
        if n%50==0: print(voice,n,round(time.time()-t0),'s',flush=True)
    print('DONE',voice,flush=True)
