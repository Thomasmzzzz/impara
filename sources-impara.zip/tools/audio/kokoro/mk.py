import onnx
from onnx import helper, TensorProto
src='kokoro-v1.0.onnx'
DUR='/encoder/Clip_output_0'; F0='/encoder/F0_proj/Conv_output_0'
onnx.utils.extract_model(src,'enc.onnx',['tokens','style','speed'],[DUR,F0])
m=onnx.load(src)
for n in m.graph.node:
    for i,x in enumerate(n.input):
        if x==F0: n.input[i]='f0_in'
m.graph.input.append(helper.make_tensor_value_info('f0_in',TensorProto.FLOAT,[1,1,'T']))
onnx.save(m,'full_f0.onnx')
print('ok')
