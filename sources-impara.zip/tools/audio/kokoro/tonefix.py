"""Kokoro (v1.0) Mandarin with corrected tones.

The model predicts an F0 curve (/encoder/F0_proj) before the vocoder.
We read it (enc.onnx), replace the pitch of each syllable with a proper
Mandarin tone contour (Chao scale, sandhi, neutral tones), then
synthesize with full_f0.onnx where that curve is an input.
"""
import re, numpy as np, onnxruntime as ort
from kokoro_onnx import Kokoro
from misaki import zh as mzh

K = Kokoro("/tmp/claude-0/kok/kokoro-v1.0.onnx", "/tmp/claude-0/kok/voices-v1.0.bin")
so = ort.SessionOptions(); so.intra_op_num_threads = 2
ENC = ort.InferenceSession("/tmp/claude-0/kok/enc.onnx", so)
FULL = ort.InferenceSession("/tmp/claude-0/kok/full_f0.onnx", so)
G = mzh.ZHG2P()

TONE = {"→": 1, "↗": 2, "↓": 3, "↘": 4}
VOW = "aeiouɤəɛɨɚyʊ"
GLIDE = "jwɥ"
SYL = re.compile(
    r"(?P<ini>(?:[ptkʦꭧʨ]ʰ?|[mnflxsʂɕʐ])?)(?P<gl>[jwɥ]?)(?P<nuc>[aeiouɤəɛɨɚyʊ]+)(?P<tone>[→↗↓↘]?)(?P<coda>ŋ|n(?![aeiouɤəɛɨɚyʊjwɥ])|)"
)


def phonemes(text):
    r = G(text)
    return r[0] if isinstance(r, tuple) else r


def syllables(ph):
    """[(start_char, nucleus_start, end_char, tone)] ; tone 5 = neutral"""
    out = []
    for m in SYL.finditer(ph):
        t = TONE.get(m.group("tone"), 5)
        out.append([m.start(), m.start("gl") if m.group("gl") else m.start("nuc"), m.end(), t])
    return out


def sandhi(syls, ph):
    t = [s[3] for s in syls]
    # groupes séparés par espace / ponctuation : le 3-3 ne traverse pas une pause
    for i in range(len(t) - 1):
        gap = ph[syls[i][2]:syls[i + 1][0]]
        if any(c in gap for c in ",.?!;:，。？！、"):
            continue
        if t[i] == 3 and t[i + 1] == 3:
            t[i] = 2
    for i, s in enumerate(syls):
        s[3] = t[i]
    return syls


# Chao levels -> semitones above the speaker's floor
def lv(x, span):
    return (x - 1) / 4 * span


def contour(tone, prev, final, n, span):
    """n points (semitones above floor) for one syllable rhyme"""
    x = np.linspace(0, 1, max(n, 2))
    if tone == 1:
        y = np.full_like(x, lv(5, span) - 0.3)
    elif tone == 2:
        a, b = lv(2.7, span), lv(5, span) + 0.6
        xx = np.clip((x - 0.25) / 0.75, 0, 1)
        y = np.where(x < 0.25, a - 0.4 * np.sin(np.clip(x / 0.25, 0, 1) * np.pi / 2), a - 0.4 + (b + 0.4 - a) * xx ** 1.2)
    elif tone == 3:
        lo = lv(1, span) - 0.5
        if final:
            y = np.where(x < 0.55, lv(2.2, span) + (lo - lv(2.2, span)) * np.sin(x / 0.55 * np.pi / 2), lo + (lv(3.6, span) - lo) * ((x - 0.55) / 0.45) ** 1.5)
        else:
            y = lv(2.2, span) + (lo - lv(2.2, span)) * np.sin(np.minimum(x / 0.8, 1) * np.pi / 2)
    elif tone == 4:
        a, b = lv(5, span) + 0.5, lv(1.3 if final else 2.2, span)
        y = np.where(x < 0.12, a, a + (b - a) * ((x - 0.12) / 0.88) ** 0.9)
    else:  # neutre : hauteur selon le ton précédent, court
        lvl = {1: 2, 2: 3, 3: 4, 4: 1.3, 5: 2}.get(prev, 2)
        y = np.full_like(x, lv(lvl, span)) - x * 0.5
    return y[:n] if n >= 2 else y[:1]


def smooth(v, k):
    if k < 2:
        return v
    w = np.hanning(k * 2 + 1); w /= w.sum()
    p = np.pad(v, k, mode="edge")
    return np.convolve(p, w, mode="valid")


def synth(text, voice, speed=0.9, span=None, ph=None):
    ph = ph or phonemes(text)
    voc = K.tokenizer.vocab
    keep = [i for i, c in enumerate(ph) if c in voc]          # char index of each token
    tokens = [voc[ph[i]] for i in keep]
    style = np.asarray(K._style_for(K.voices[voice], len(tokens)), dtype=np.float32)
    feeds = {"tokens": np.array([[0, *tokens, 0]], dtype=np.int64), "style": style, "speed": np.array([speed], dtype=np.float32)}
    dur, f0 = ENC.run(None, feeds)
    dur = np.asarray(dur).ravel().astype(int)                # per token incl. pads
    f0 = np.asarray(f0, dtype=np.float32).copy()             # [1,1,T]
    T = f0.shape[-1]
    fpd = T / max(1, dur.sum())                              # f0 frames per duration unit
    starts = np.concatenate([[0], np.cumsum(dur)])           # in duration units
    char_to_tok = {c: j + 1 for j, c in enumerate(keep)}     # +1 : pad

    def frame_of_char(ci, end=False):
        # first token at/after ci (or last before, for end)
        rng = range(ci, len(ph)) if not end else range(ci - 1, -1, -1)
        for c in rng:
            if c in char_to_tok:
                j = char_to_tok[c]
                return int(round((starts[j + 1] if end else starts[j]) * fpd))
        return 0 if not end else T

    orig = f0[0, 0]
    voiced = orig > 40
    if voiced.sum() < 3:
        return K.create(ph, voice=voice, speed=speed, is_phonemes=True)[0]
    lf = np.log2(np.where(voiced, orig, 1))
    floor = np.percentile(lf[voiced], 8)
    top = np.percentile(lf[voiced], 92)
    if span is None:
        span = float(np.clip((top - floor) * 12 + 2.5, 8, 11))   # semitones between Chao 1 and 5
    floor_hz = 2 ** floor

    syls = sandhi(syllables(ph), ph)
    target = np.full(T, np.nan)
    prev = 5
    n_s = len(syls)
    for k, (s0, nuc, e, t) in enumerate(syls):
        A = 0 if k == 0 else frame_of_char(s0)
        B = T if k == n_s - 1 else frame_of_char(syls[k + 1][0])
        vi = np.nonzero(voiced[A:B])[0]
        if len(vi) < 2:
            prev = t; continue
        a, b = A + vi[0], A + vi[-1] + 1
        if b - a < 2:
            prev = t; continue
        nxt_gap = ph[e:syls[k + 1][0]] if k + 1 < n_s else "."
        final = k + 1 == n_s or any(c in nxt_gap for c in ",.?!;:，。？！、")
        y = contour(t, prev, final, b - a, span)
        # déclinaison : la voix baisse doucement le long de la phrase
        decl = -1.2 * (k / max(1, n_s - 1))
        target[a:b] = y + decl
        prev = t
    # interpolation entre syllabes (consonnes voisées, transitions)
    idx = np.arange(T)
    ok = ~np.isnan(target)
    if ok.sum() < 2:
        return K.create(ph, voice=voice, speed=speed, is_phonemes=True)[0]
    tgt = np.interp(idx, idx[ok], target[ok])
    tgt = smooth(tgt, 3)
    # micro-variations d'origine (naturel) : résidu autour de la courbe lissée
    resid = np.where(voiced, (lf - np.log2(np.maximum(smooth(np.where(voiced, orig, np.median(orig[voiced])), 6), 1))) * 12, 0)
    new = floor_hz * 2 ** ((tgt + 0.4 * np.clip(resid, -1, 1)) / 12)
    out = np.where(voiced, new, orig).astype(np.float32)
    feeds["f0_in"] = out[None, None, :]
    audio = FULL.run(None, feeds)[0]
    return np.asarray(audio).ravel()
