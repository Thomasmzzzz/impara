// Liste toutes les phrases que l'appli peut faire lire, pour les enregistrer.
// Usage : node tools/audio/export-texts.mjs   →   tools/audio/texts-it.json, texts-zh.json
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { speechText, clipId, SPEAK_FILTER } from "../../js/core/speechkey.js";
import { allSpoken } from "../../js/core/numwords.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const DATA = path.join(here, "../../js/data/");
const tri = (x) => (x.length === 3 ? x : [x[0], "", x[1]]);
const HAN = /[㐀-鿿]/;

for (const lang of ["it", "zh"]) {
  const out = new Map();
  const add = (raw) => { const t = speechText(raw, SPEAK_FILTER[lang]); if (t && !out.has(clipId(t))) out.set(clipId(t), t); };
  const cur = await import(path.join(DATA, lang === "zh" ? "zh.js" : "it.js"));
  const stories = (await import(path.join(DATA, `stories-${lang}.js`))).default;
  const dialogues = (await import(path.join(DATA, `dialogues-${lang}.js`))).default;
  for (const L of cur.LEVELS) {
    for (const l of L.lessons) {
      (l.vocab || []).map(tri).forEach(([w]) => { add(w); String(w).split(/\s*\/\s*/).forEach(add); });
      (l.sections || []).flatMap((s) => s.examples || []).map(tri).forEach(([w]) => { add(w); String(w).split(/\s+—\s+/).forEach(add); });
      [...(l.quiz || [])].forEach((q) => { (q.pairs || []).forEach(([a]) => add(a)); if (q.say) add(q.say); });
    }
    (L.exam || []).forEach((q) => { (q.pairs || []).forEach(([a]) => add(a)); if (q.say) add(q.say); });
  }
  stories.forEach((s) => s.lines.forEach((l) => l.t && add(l.t)));
  dialogues.forEach((d) => d.turns.forEach((t) => { if (t.npc) add(t.npc); (t.choices || []).forEach((c) => add(c.t)); }));
  allSpoken(lang).forEach(add);
  add(lang === "zh" ? "你好" : "Ciao");
  add(lang === "zh" ? "你好！我们今天一起学习中文。" : "Ciao! Come stai? Oggi impariamo l'italiano insieme.");
  if (lang === "zh") {
    // Chaque caractère seul (exercice des tons, mots cliquables) + caractères de comparaison des tons
    const src = fs.readdirSync(DATA).filter((f) => /^(zh|stories-zh|dialogues-zh)/.test(f) && !/pinyin|keys|tones/.test(f)).map((f) => fs.readFileSync(path.join(DATA, f), "utf8")).join("");
    [...new Set([...src].filter((c) => HAN.test(c)))].forEach(add);
    const { REF } = await import(path.join(DATA, "zh-tones.js"));
    Object.values(REF).forEach((row) => row.forEach((chars) => [...chars].slice(0, 2).forEach(add)));
    ["妈", "麻", "马", "骂"].forEach(add);
  }
  const items = [...out].map(([id, t]) => ({ id, t }));
  fs.writeFileSync(path.join(here, `texts-${lang}.json`), JSON.stringify({ lang, items }, null, 0));
  console.log(lang, items.length, "phrases,", items.reduce((n, x) => n + x.t.length, 0), "caractères");
}
