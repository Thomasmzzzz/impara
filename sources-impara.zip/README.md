# Impara — Apprendre l'italien ou le mandarin de A1 à C2

Prototype de site d'apprentissage gamifié, en **HTML5 / CSS3 / JavaScript vanilla (modules ES)**, sans dépendance ni étape de build.

## Lancer le projet

Les modules ES doivent être servis en HTTP (pas en `file://`) :

```bash
cd impara
python3 -m http.server 8000      # ou : npx serve .
# puis ouvrir http://localhost:8000
```

## Architecture

```
impara/
├── index.html               # Coquille : en-tête, <main id="app">, barre d'onglets mobile
├── css/
│   └── style.css            # Tokens (couleurs, rayons), composants, vues, responsive
└── js/
    ├── app.js               # Point d'entrée : routeur par ancre, en-tête, délégation d'événements
    ├── data/
    │   ├── curriculum.js    # Façade : charge le contenu de la langue active
    │   ├── it.js            # Italien : 6 paliers, 22 leçons, quiz, examens
    │   └── zh.js            # Mandarin : 6 paliers (repères HSK), 22 leçons, caractères + pinyin
    ├── config.js            # Clés Supabase (vides = mode local)
    ├── core/
    │   ├── cloud.js         # Comptes + synchronisation (connexion, fusion, envoi)
    │   ├── lang.js          # Registre des langues : thème, voix, clavier, textes, drapeaux
    │   ├── storage.js       # État + persistance localStorage (repli mémoire), import/export
    │   ├── progress.js      # Règles métier : déblocage, %, XP, série, cahier d'erreurs
    │   ├── quiz-engine.js   # Moteur de quiz générique (QCM, trous, association, traduction)
    │   └── ui.js            # Utilitaires : échappement, toasts, modale, audio, anneau SVG
    └── views/
        ├── parcours.js      # Accueil : carte des niveaux (chemin sinueux)
        ├── lecon.js         # Mini-leçon : sections, tableaux, exemples audio, astuce, vocabulaire
        ├── quiz.js          # Quiz de leçon, examen de palier, révision + écran de résultats
        ├── dashboard.js     # Tableau de bord : %, objectif du jour, stats, paliers, historique
        ├── carnet.js        # Carnet de vocabulaire : recherche, filtres, flashcards
        ├── erreurs.js       # Cahier d'erreurs
        ├── profil.js        # Onboarding + profil (avatar, pseudo, objectif, sauvegarde)
        └── compte.js        # Connexion, inscription, mot de passe oublié, état de synchro
supabase/
└── schema.sql               # Table `progress` + règles de sécurité (RLS)
GUIDE-MISE-EN-LIGNE.md       # Pas à pas : Supabase + GitHub Pages
```

### Routes

| Ancre              | Vue                                  |
|--------------------|--------------------------------------|
| `#parcours`        | Carte des niveaux (accueil)          |
| `#lecon-<id>`      | Leçon (ex. `#lecon-a1-numeri`)       |
| `#quiz-<id>`       | Quiz de fin de leçon                 |
| `#examen-<niveau>` | Examen de palier (ex. `#examen-B1`)  |
| `#revision`        | Révision des erreurs                 |
| `#tableau`, `#carnet`, `#erreurs`, `#profil` | Espace personnel |
| `#compte`          | Connexion / compte en ligne          |

Une route verrouillée redirige vers le parcours avec un message.

## Comptes et synchronisation

Chaque personne peut créer un compte (e-mail + mot de passe) et retrouver sa progression sur tous ses appareils. Mise en place : **voir `GUIDE-MISE-EN-LIGNE.md`**.

- Tant que `js/config.js` est vide, le site reste en **mode local** (aucune différence visible).
- Fonctionnement « local d'abord » : la copie du navigateur reste la copie de travail (site instantané, utilisable hors ligne) ; les changements partent vers Supabase toutes les ~1,5 s.
- Connexion sur un nouvel appareil, retour sur l'onglet ou retour du réseau : la copie du serveur est récupérée et **fusionnée** (`mergeStates` dans `cloud.js` : meilleurs scores, union du vocabulaire et de l'historique, XP maximum).
- La progression faite en invité est rattachée au compte lors de l'inscription ; à la déconnexion, la copie locale est effacée (ordinateur partagé).
- Sécurité : la clé publique Supabase est faite pour être visible ; les règles RLS de `schema.sql` garantissent que chacun ne lit et ne modifie que ses propres lignes.

## Changer de langue

Cliquez sur le **drapeau en haut à gauche** (ou choisissez la langue sur l'écran d'accueil) :

| Langue   | Marque | Sauvegarde (`localStorage`) | Clavier | Voix |
|----------|--------|-----------------------------|---------|------|
| Italien  | Impara | `impara.state.v1`           | accents à è é ì ò ù | `it-IT` |
| Mandarin | Xuéxí  | `xuexi.state.v1`            | tons ā á ǎ à + ü (placement automatique) | `zh-CN` (caractères seulement) |

- Le choix est mémorisé (`impara.lang`, avec repli sur `window.name`) et l'application se recharge dans la nouvelle langue.
- Chaque langue garde **sa propre progression**, son carnet et son cahier d'erreurs ; le profil (pseudo, avatar, objectif) est repris automatiquement.
- Le thème change aussi : vert/rouge italien, ou rouge/or/jade pour le mandarin (`body.lang-zh` dans le CSS).

### Ajouter une langue
1. Créez `js/data/es.js` sur le modèle de `it.js` (vocabulaire `[mot, fr]` ou `[mot, prononciation, fr]`).
2. Ajoutez une entrée `es` dans `LANGS` (`js/core/lang.js`) : textes, voix, clavier, drapeau SVG.
3. Ajoutez `es: () => import("./es.js")` dans `js/data/curriculum.js`.

## Règles pédagogiques (modifiables dans `progress.js`)

- Leçons débloquées **une par une** dans chaque palier.
- Leçon validée à **60 %** → ses mots rejoignent le carnet.
- Examen de palier débloqué quand toutes les leçons sont validées ; réussi à **80 %**, il ouvre le palier suivant.
- Chaque erreur va dans le **cahier d'erreurs** ; elle en sort après **2 bonnes réponses consécutives**. La révision propose d'abord les questions les plus souvent ratées.
- **10 XP** par bonne réponse, +20 XP pour une validation ; série de jours et objectif quotidien.
- Saisie libre tolérante : casse, ponctuation et apostrophes ignorées ; accents oubliés acceptés avec un avertissement.

## Modèle de données sauvegardé (une clé par langue)

```js
{
  version: 1,
  profile:  { pseudo, avatar, dailyGoal, createdAt },
  settings: { tts },
  lessons:  { "a1-numeri": { best, total, passed, attempts, date } },
  exams:    { "A1": { best, total, passed, attempts, date } },
  vocab:    { "grazie": { zh /* mot étudié */, py /* pinyin, mandarin seulement */, fr, levelId, lessonId, added } },
  errors:   { "a1-numeri:2": { ref, count, streak, lastAnswer, lastWrong } },
  mastered, xp, streak: { count, last }, daily: { date, xp }, history: [...]
}
```

Les questions ne sont jamais copiées dans la sauvegarde : on stocke une **référence** (`idLeçon:index`).

## Ajouter du contenu

Dans `js/data/it.js` (ou `zh.js`), ajoutez une leçon au tableau `lessons` d'un palier :

```js
{
  id: "a2-famiglia", module: "vocab", title: "La famille", emoji: "👨‍👩‍👧",
  intro: "…",
  sections: [{ title: "…", text: "…", table: { cols, rows }, examples: [["la madre", "la mère"]] }],
  mnemo: "…",
  vocab: [["la madre", "la mère"]],
  quiz: [ mcq(...), fill(...), match(...), tr(...) ],
}
```

La carte, la progression, le carnet et le cahier d'erreurs s'adaptent automatiquement.

## Évolutions possibles

- Connexion avec Google (Supabase → Authentication → Providers), classement entre amis.
- **React** : chaque fichier de `views/` correspond à un composant ; `core/` se réutilise tel quel (hooks autour de `subscribe`).
- Répétition espacée (SM-2) dans le carnet, exercices d'écoute, reconnaissance vocale.

## Sources et mise à jour

Le site publié sur GitHub Pages se compose de `index.html` (CSS intégrée), du point
d'entrée `app-XXXX.js` et de morceaux `c-XXXX.js` chargés à la demande (chaque langue ne
télécharge que son propre contenu ; les autres pages arrivent en arrière-plan), avec
`manifest.json`, `sw.js` et les icônes. Les noms en XXXX changent à chaque version : on peut
les garder en cache sans risque. Les sources complètes sont dans `sources-impara.zip` :
https://thomasmzzzz.github.io/impara/sources-impara.zip

Construction : `esbuild js/app.js --bundle --splitting --format=esm --minify
--entry-names=app-[hash] --chunk-names=c-[hash]`, puis la CSS est insérée dans
`index.html` avec les préchargements (modulepreload) de la langue active.
