/* =====================================================================
   Vue « Prononciation » (#prononciation)
   Vous lisez le mot à voix haute ; la reconnaissance vocale du
   navigateur (Chrome, Android, Safari iPhone) dit ce qu'elle a entendu.
   En mandarin, on compare aussi le pinyin (avec les tons) de ce qui a
   été reconnu : un homophone exact compte comme juste, un ton
   différent est signalé.
   ===================================================================== */

import { L, code } from "../core/lang.js";
import { esc, shuffle, speak, ring, celebrate } from "../core/ui.js";
import * as P from "../core/progress.js";
import { wordPool } from "./entrainement.js";
import MAP from "../data/zh-pinyin.js";

const SR = typeof window !== "undefined" && (window.SpeechRecognition || window.webkitSpeechRecognition);
export const canRecognize = () => !!SR;
const isZh = () => code === "zh";
const HAN = /[㐀-鿿]/g;
const N = 10;

/* -------------------------- Comparaison ---------------------------- */
const stripAcc = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "");
const norm = (s) => stripAcc(String(s).toLowerCase()).replace(/['’]/g, " ").replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();

function lev(a, b) {
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++)
    d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
}
const sim = (a, b) => (a || b ? 1 - lev(a, b) / Math.max(a.length, b.length) : 1);

// Pinyin des caractères reconnus : bibliothèque complète si le réseau le permet, sinon le dictionnaire du cours
let PP = null;
const loadPinyin = () => (PP ||= import("https://cdn.jsdelivr.net/npm/pinyin-pro@3.26.0/+esm").then((m) => m.pinyin).catch(() => null));
async function pyOf(text) {
  const chars = (text.match(HAN) || []).join("");
  if (!chars) return [];
  const fn = await loadPinyin();
  if (fn) return fn(chars, { type: "array" });
  return [...chars].map((c) => MAP[c] || "?");
}
const toneless = (s) => stripAcc(s).replace(/ü/g, "v").toLowerCase();

/** Note un essai : { level: "perfect" | "good" | "tone" | "miss", heard, note } */
async function grade(word, alts) {
  if (!isZh()) {
    const target = norm(word.zh).replace(/^(il|lo|la|l|i|gli|le|un|una|uno) /, "");
    let best = { s: 0, heard: alts[0] || "" };
    for (const a of alts) {
      const h = norm(a);
      const s = h.includes(target) ? 1 : Math.max(sim(h, target), sim(h, norm(word.zh)));
      if (s > best.s) best = { s, heard: a };
    }
    if (best.s >= 0.95) return { level: "perfect", heard: best.heard };
    if (best.s >= 0.75) return { level: "good", heard: best.heard, note: "Presque parfait : écoutez le modèle et comparez." };
    return { level: "miss", heard: best.heard };
  }
  const target = (word.zh.match(HAN) || []).join("");
  const want = (word.py ? word.py.toLowerCase().replace(/['’]/g, " ").split(/\s+/).join("") : (await pyOf(target)).join(""));
  let best = { level: "miss", heard: alts[0] || "" };
  for (const a of alts) {
    const chars = (a.match(HAN) || []).join("");
    if (chars.includes(target)) return { level: "perfect", heard: a };
    const got = (await pyOf(chars)).join("");
    if (!got) continue;
    if (got.includes(want)) return { level: "good", heard: a, note: `Homophone reconnu (${got}) : la prononciation et les tons sont bons.` };
    if (toneless(got).includes(toneless(want)) && best.level === "miss") best = { level: "tone", heard: a, note: `J'ai entendu « ${got} » : les sons sont bons, mais attention aux tons (« ${word.py} »).` };
  }
  return best;
}

/* ------------------------------ Vue -------------------------------- */
export function renderPrononciation(app) {
  if (!SR) {
    app.innerHTML = `<a class="back-link" href="#entrainement">← Entraînement</a>
    <section class="card empty-state"><p class="big-emoji">🎤</p><h1 class="h3">Reconnaissance vocale indisponible</h1>
      <p class="muted">Ce navigateur ne sait pas reconnaître la voix. Utilisez <b>Chrome</b> (ordinateur ou Android) ou <b>Safari</b> sur iPhone.</p></section>`;
    return true;
  }
  const pool = wordPool().filter((w) => w.zh.length <= (isZh() ? 6 : 24));
  if (pool.length < 3) return false;
  const words = shuffle(pool).slice(0, N);
  let i = 0, score = 0, tries = 0, rec = null, listening = false, scored = false;

  document.body.classList.add("focus-mode");
  app.innerHTML = `
  <section class="pron">
    <div class="story-top">
      <button class="btn ghost small" data-quit aria-label="Quitter">✕</button>
      <div class="progress"><span class="story-bar"></span></div>
    </div>
    <p class="eyebrow">Prononciation · lisez à voix haute</p>
    <div class="card pron-card">
      <p class="pron-word"></p><p class="pron-py py"></p><p class="pron-fr muted"></p>
      <div class="btn-row center"><button class="btn ghost small" data-model>🔊 Modèle</button><button class="btn ghost small" data-slow>🐢 Lentement</button></div>
    </div>
    <button class="mic" data-mic aria-label="Appuyez puis parlez"><span>🎤</span></button>
    <p class="pron-hint muted small">Appuyez sur le micro, puis dites le mot.</p>
    <div class="pron-res" aria-live="polite"></div>
    <div class="story-foot"><button class="btn ghost" data-skip>Passer</button><button class="btn primary" data-next hidden>Suivant →</button></div>
  </section>`;

  const $ = (s) => app.querySelector(s);
  const quit = () => { try { rec?.abort(); } catch {} document.body.classList.remove("focus-mode"); location.hash = "entrainement"; };
  $("[data-quit]").onclick = quit;

  function show() {
    const w = words[i];
    tries = 0; scored = false;
    $(".story-bar").style.width = `${Math.round((i / words.length) * 100)}%`;
    $(".pron-word").innerHTML = `<span class="${isZh() ? "zh" : ""}">${esc(w.zh)}</span>`;
    $(".pron-py").textContent = w.py || "";
    $(".pron-fr").textContent = w.fr;
    $(".pron-res").innerHTML = "";
    $("[data-next]").hidden = true; $("[data-skip]").hidden = false;
    $(".pron-hint").textContent = "Appuyez sur le micro, puis dites le mot.";
  }

  function result(r) {
    const w = words[i];
    tries++;
    const ok = r.level === "perfect" || r.level === "good";
    if (ok && !scored) { score++; scored = true; }
    const head = { perfect: "✓ Parfait !", good: "✓ Bien !", tone: "≈ Presque !", miss: "✗ Pas encore" }[r.level];
    $(".pron-res").innerHTML = `<div class="pron-out ${ok ? "ok" : "ko"}"><b>${head}</b>
      ${r.heard ? `<p class="small">J'ai entendu : « <span class="${isZh() ? "zh" : ""}">${esc(r.heard)}</span> »</p>` : ""}
      ${r.note ? `<p class="small">${esc(r.note)}</p>` : ""}
      ${!ok && tries < 3 ? `<p class="small muted">Écoutez le modèle 🔊 et réessayez (${3 - tries} essai${3 - tries > 1 ? "s" : ""}).</p>` : ""}</div>`;
    if (ok || tries >= 3) { $("[data-next]").hidden = false; $("[data-skip]").hidden = true; if (!ok) speak(w.zh, { force: true }); }
  }

  function listen() {
    if (listening) { try { rec.stop(); } catch {} return; }
    speechSynthesis?.cancel?.();
    rec = new SR();
    rec.lang = L.speech; rec.interimResults = false; rec.maxAlternatives = 5; rec.continuous = false;
    let got = false;
    rec.onresult = async (e) => {
      got = true;
      const alts = [...e.results[0]].map((a) => a.transcript.trim()).filter(Boolean);
      result(await grade(words[i], alts));
    };
    rec.onerror = (e) => {
      got = true;
      const msg = {
        "not-allowed": "Micro refusé : autorisez le micro pour ce site dans les réglages du navigateur.",
        "service-not-allowed": "La reconnaissance vocale est bloquée ici. Sur iPhone, essayez dans Safari plutôt que dans l'application installée.",
        "no-speech": "Je n'ai rien entendu. Rapprochez-vous du micro et réessayez.",
        network: "La reconnaissance vocale a besoin d'Internet.",
        "audio-capture": "Aucun micro détecté.",
      }[e.error] || "La reconnaissance vocale a échoué, réessayez.";
      $(".pron-res").innerHTML = `<p class="small muted">${esc(msg)}</p>`;
    };
    rec.onend = () => {
      listening = false; $("[data-mic]").classList.remove("on");
      $(".pron-hint").textContent = "Appuyez sur le micro, puis dites le mot.";
      if (!got) $(".pron-res").innerHTML = `<p class="small muted">Je n'ai rien entendu. Réessayez.</p>`;
    };
    try {
      rec.start(); listening = true; $("[data-mic]").classList.add("on");
      $(".pron-hint").textContent = "J'écoute… parlez maintenant";
      $(".pron-res").innerHTML = "";
    } catch { listening = false; }
  }

  function finish() {
    document.body.classList.remove("focus-mode");
    const r = P.recordPractice({ label: "Prononciation", score, total: words.length });
    const pct = Math.round(r.ratio * 100);
    app.innerHTML = `
    <section class="results ${pct >= 60 ? "ok" : "ko"}">
      ${ring(pct, 150, 12)}
      <h1>${pct === 100 ? "Prononciation parfaite ! 🎉" : pct >= 60 ? "Bien prononcé !" : "Continuez, ça viendra !"}</h1>
      <p class="lead">${score} / ${words.length} mots bien prononcés</p>
      <div class="result-chips"><span class="chip">⚡ +${r.xpGained} XP</span></div>
      <div class="result-actions">
        <a class="btn primary big" href="#prononciation" data-reload>Recommencer</a>
        <a class="btn ghost" href="#entrainement">Autres exercices</a>
      </div>
    </section>`;
    if (pct === 100) celebrate();
  }

  $("[data-mic]").onclick = listen;
  $("[data-model]").onclick = () => speak(words[i].zh, { force: true });
  $("[data-slow]").onclick = () => speak(words[i].zh, { force: true, slow: true });
  const advance = () => { try { rec?.abort(); } catch {} i++; if (i >= words.length) finish(); else show(); };
  $("[data-next]").onclick = advance;
  $("[data-skip]").onclick = advance;
  show();
  if (isZh()) loadPinyin();
  return true;
}
