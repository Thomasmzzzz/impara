/* =====================================================================
   Vue « Séance du jour » (#seance)
   Une séance d'environ 10 minutes construite automatiquement, à suivre
   sans rien choisir :
     1. Échauffement : mots à réviser (répétition espacée) + erreurs récentes
     2. La prochaine étape du parcours (leçon, test de mi-palier ou examen)
     3. Écoute : quelques mots à reconnaître à l'oral
   Le plan est figé pour la journée (state.seance) ; chaque étape est
   cochée au fur et à mesure, et la séance terminée rapporte un bonus.
   ===================================================================== */

import { state, commit } from "../core/storage.js";
import { code } from "../core/lang.js";
import { esc, shuffle, celebrate, ring } from "../core/ui.js";
import { runQuiz } from "../core/quiz-engine.js";
import * as P from "../core/progress.js";
import { getQuestion, lvlLabel } from "../data/curriculum.js";
import { dueWords, grade } from "../core/srs.js";
import { mascot, line } from "../core/mascot.js";
import { wordPool, listeningQuestions } from "./entrainement.js";

const BONUS = 30;
const N_SRS = 6, N_ERR = 5, N_LISTEN = 5;
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };
const isToday = (iso) => !!iso && today() === (() => { const d = new Date(iso); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; })();

/* ------------------------------ Plan -------------------------------- */
const vocabDue = () => dueWords(Object.values(state.vocab || {}));
const errorRefs = () => Object.values(state.errors || {}).sort((a, b) => b.lastWrong - a.lastWrong).map((e) => e.ref).filter((r) => getQuestion(r));

function stepTitle(next) {
  if (!next) return null;
  if (next.kind === "lesson") return { ref: `lesson:${next.lesson.id}`, href: `lecon-${next.lesson.id}`, title: next.lesson.title, icon: next.lesson.emoji || "📘", sub: `Nouvelle leçon · ${lvlLabel(next.level)}`, lv: next.level.id };
  if (next.kind === "checkpoint") return { ref: `checkpoint:${next.level.id}`, href: `mipalier-${next.level.id}`, title: `Test de mi-palier ${lvlLabel(next.level)}`, icon: "🛡️", sub: `${P.CHECKPOINT_N} questions · 90 % requis` };
  return { ref: `exam:${next.level.id}`, href: `examen-${next.level.id}`, title: `Examen ${lvlLabel(next.level)}`, icon: "🎓", sub: "Sans faute requis" };
}

/** Plan du jour : créé à la première ouverture, puis conservé */
export function todaysPlan() {
  if (state.seance?.date === today()) return state.seance;
  const steps = [];
  const srs = Math.min(N_SRS, vocabDue().length), err = Math.min(N_ERR, errorRefs().length);
  if (srs + err > 0) steps.push({ id: "warmup", icon: "🔁", title: "Échauffement", sub: [srs && `${srs} mot${srs > 1 ? "s" : ""} à réviser`, err && `${err} erreur${err > 1 ? "s" : ""} à corriger`].filter(Boolean).join(" · "), done: false });
  const st = stepTitle(P.nextStep());
  if (st) steps.push({ id: "path", ...st, done: false });
  if (wordPool().length >= 4) steps.push({ id: "listen", icon: "🎧", title: "Écoute", sub: `${N_LISTEN} mots à reconnaître à l'oral`, done: false });
  const plan = { date: today(), steps, finished: false, bonus: false };
  commit((s) => { s.seance = plan; }, { touch: false });
  return state.seance;
}

/** La séance attend-elle le résultat de cette étape du parcours ? (bouton « Continuer la séance ») */
export function seanceWaits(kind, id) {
  const p = state.seance;
  if (!p || p.date !== today() || p.finished) return false;
  const s = p.steps.find((x) => x.id === "path");
  return !!s && !s.done && s.ref === `${kind}:${id}`;
}

/** Étape du parcours faite aujourd'hui ? (on regarde la date de la dernière tentative) */
function pathAttempted(ref) {
  const [kind, id] = ref.split(":");
  const rec = kind === "lesson" ? state.lessons[id] : kind === "exam" ? state.exams[id] : state.checkpoints?.[id];
  return !!rec && isToday(rec.date);
}

function mark(id) {
  commit((s) => { const st = s.seance?.steps.find((x) => x.id === id); if (st) st.done = true; });
}

/** Résumé pour la page d'accueil : { started, done, total, finished } */
export function seanceStatus() {
  const p = state.seance?.date === today() ? state.seance : null;
  if (!p) return { started: false, done: 0, total: 0, finished: false };
  return { started: p.steps.some((s) => s.done), done: p.steps.filter((s) => s.done).length, total: p.steps.length, finished: !!p.finished };
}

/* ------------------------------ Vue --------------------------------- */
export function renderSeance(app) {
  const plan = todaysPlan();
  // L'étape du parcours se coche dès qu'elle a été tentée aujourd'hui
  const path = plan.steps.find((s) => s.id === "path");
  if (path && !path.done && pathAttempted(path.ref)) mark("path");
  const steps = state.seance.steps;
  const next = steps.find((s) => !s.done);

  if (!steps.length) {
    app.innerHTML = `<section class="card empty-state"><p class="big-emoji">🗺️</p><h1 class="h3">Rien à préparer pour l'instant</h1>
      <p class="muted">Commencez par la première leçon du parcours : la séance du jour se construira avec vos mots et vos erreurs.</p>
      <a class="btn primary" href="#parcours">Aller au parcours</a></section>`;
    return true;
  }
  if (!next) return finish(app);

  const doneN = steps.filter((s) => s.done).length;
  const mins = steps.filter((s) => !s.done).reduce((n, s) => n + (s.id === "path" ? 6 : s.id === "warmup" ? 3 : 2), 0);
  app.innerHTML = `
  <section class="seance">
    <a class="back-link" href="#parcours">← Parcours</a>
    <header class="se-head">
      <span class="se-mascot">${mascot(doneN ? "happy" : "idle", { size: 92 })}</span>
      <div><p class="eyebrow">Séance du jour · ≈ ${Math.max(2, mins)} min${doneN ? " restantes" : ""}</p>
        <h1>${doneN ? "On continue !" : "Prêt pour ta séance ?"}</h1>
        <p class="muted">${doneN ? `${doneN} étape${doneN > 1 ? "s" : ""} sur ${steps.length} terminée${doneN > 1 ? "s" : ""}.` : "Tout est préparé : il suffit de suivre les étapes."} Bonus de <b>+${BONUS} XP</b> à la fin.</p></div>
    </header>
    <ol class="se-steps">
      ${steps.map((s, k) => `<li class="se-step ${s.done ? "done" : s === next ? "current" : ""}">
        <span class="se-ico">${s.done ? "✓" : esc(s.icon)}</span>
        <span class="se-txt"><b class="${code === "zh" ? "zh-mix" : ""}">${k + 1}. ${esc(s.title)}</b><small>${esc(s.sub || "")}</small></span>
        ${s === next ? `<span class="se-now">Maintenant</span>` : ""}
      </li>`).join("")}
    </ol>
    <button class="btn primary big se-go" data-go>${doneN ? "Continuer" : "Commencer"} : ${esc(next.title)} →</button>
    ${next.id !== "path" ? `<button class="btn ghost small se-skip" data-skip>Passer cette étape</button>` : ""}
  </section>`;

  app.querySelector("[data-go]").onclick = () => run(app, next);
  const sk = app.querySelector("[data-skip]");
  if (sk) sk.onclick = () => { mark(next.id); renderSeance(app); };
  return true;
}

function run(app, step) {
  if (step.id === "path") { location.hash = step.href; return; }
  const questions = step.id === "warmup" ? warmupQuestions() : listeningQuestions(N_LISTEN);
  if (!questions.length) { mark(step.id); renderSeance(app); return; }
  const words = new Map(Object.values(state.vocab || {}).map((w) => [w.zh, w]));
  document.body.classList.add("focus-mode");
  runQuiz(app, {
    title: step.id === "warmup" ? "Séance du jour · échauffement" : "Séance du jour · écoute",
    questions,
    xpPerAnswer: step.id === "warmup" ? P.XP_PER_CORRECT : 5,
    onAnswer: ({ index, correct }) => {
      // Mot du carnet : la réponse fait avancer (ou reculer) sa carte de révision
      const ref = questions[index]?.ref || "";
      if (ref.startsWith("srs:gen:")) { const w = words.get(ref.slice(8)); if (w) grade(w, correct ? "good" : "again"); }
    },
    onQuit: () => { document.body.classList.remove("focus-mode"); location.hash = "parcours"; },
    onFinish: (results) => {
      document.body.classList.remove("focus-mode");
      if (step.id === "warmup") P.recordQuiz({ kind: "review", id: "seance", label: "Séance du jour · échauffement", results });
      else { const score = results.filter((r) => r.correct).length; P.recordPractice({ label: "Séance du jour · écoute", score, total: results.length, xpPer: 5 }); }
      mark(step.id);
      renderSeance(app);
      app.classList.remove("page-in"); void app.offsetWidth; app.classList.add("page-in");
      scrollTo({ top: 0 });
    },
  });
}

/** Échauffement : mots dus du carnet (sens ↔ mot) + dernières erreurs */
function warmupQuestions() {
  const all = Object.values(state.vocab || {});
  const label = (w) => (w.py ? `${w.zh} · ${w.py}` : w.zh);
  const srs = shuffle(vocabDue()).slice(0, N_SRS).map((w, i) => {
    const others = shuffle(all.filter((x) => x.zh !== w.zh && x.fr !== w.fr)).slice(0, 3);
    if (others.length < 2) return null;
    const opts = shuffle([w, ...others]), reverse = i % 2 === 1;
    return {
      ref: `srs:gen:${w.zh}`,
      q: reverse
        ? { type: "mcq", q: `Comment dit-on « ${w.fr} » ?`, options: opts.map(label), answer: opts.indexOf(w) }
        : { type: "mcq", q: `Que signifie « ${label(w)} » ?`, options: opts.map((x) => x.fr), answer: opts.indexOf(w) },
    };
  }).filter(Boolean);
  const errs = errorRefs().slice(0, N_ERR).map((ref) => ({ ref, q: getQuestion(ref) }));
  return shuffle([...srs, ...errs]);
}

function finish(app) {
  let gained = 0;
  if (!state.seance.bonus) {
    gained = P.recordPractice({ label: "", score: 1, total: 0, xpPer: BONUS }).xpGained;
    commit((s) => { s.seance.bonus = true; s.seance.finished = true; s.seance.end = Date.now(); });
    setTimeout(() => celebrate(), 250);
  }
  const steps = state.seance.steps;
  app.innerHTML = `
  <section class="results ok seance-done">
    <div class="res-hero happy"><span class="res-mascot">${mascot("cheer", { size: 132 })}</span><span class="m-bubble res-bubble">${esc(line("win"))}</span></div>
    <h1>Séance du jour terminée ! 🎉</h1>
    <p class="lead">${steps.length} étape${steps.length > 1 ? "s" : ""} bouclée${steps.length > 1 ? "s" : ""}${gained ? ` · bonus <b>+${gained} XP</b>` : ""}</p>
    <ul class="se-recap">${steps.map((s) => `<li>✓ ${esc(s.title)}</li>`).join("")}</ul>
    <div class="res-tiles">
      <div class="rt t-streak"><small>Série</small><b>${P.streakCount()} j</b><span>🔥</span></div>
      <div class="rt t-xp"><small>XP aujourd'hui</small><b>${P.dailyXp()}</b><span>⚡</span></div>
    </div>
    <p class="muted small">Une nouvelle séance sera prête demain. Envie de continuer ? Tout le parcours et l'entraînement restent ouverts.</p>
    <div class="result-actions">
      <a class="btn primary big" href="#parcours">Retour au parcours</a>
      <a class="btn ghost" href="#entrainement">Entraînement libre</a>
    </div>
  </section>`;
  return true;
}

/* Raccourci : ring de progression pour l'accueil */
export const seanceRing = (st) => ring(st.total ? Math.round((st.done / st.total) * 100) : 0, 46, 5, st.finished ? "✓" : `${st.done}/${st.total}`);
