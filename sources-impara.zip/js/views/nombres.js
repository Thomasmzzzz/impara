/* =====================================================================
   Vue « Nombres, heure, dates, prix » (#nombres)
   Des questions générées à l'infini (séries de 15) : écouter un nombre et
   le reconnaître ou l'écrire en chiffres, ou trouver comment se dit
   « 15:30 », « 3,50 € », « le 8 mars »… Les mauvaises réponses proposées
   sont les pièges classiques (13/30, 16/60, 十四/四十, 一刻/三刻…).
   ===================================================================== */

import { code } from "../core/lang.js";
import { esc, shuffle, ring, celebrate } from "../core/ui.js";
import { runQuiz, mistakesHtml } from "../core/quiz-engine.js";
import * as P from "../core/progress.js";
import { levelWantsPinyin } from "../core/pinyin.js";
import { xpChip } from "./entrainement.js";

const zh = () => code === "zh";
const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
const pickOne = (arr) => arr[Math.floor(Math.random() * arr.length)];
const MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
import { DAYS } from "../core/numwords.js";

import { itNum, zhNum, zhPy, D, sayNum, sayTime, sayDate, sayPrice, BIG, MINUTES, CENTS } from "../core/numwords.js";

/* ------------------------------ Générateurs -------------------------- */
// Chaque élément : { say (texte lu), py, show (forme écrite, en chiffres), ok (réponses acceptées à l'écrit), alt () → variante piège }
function numberItem(max) {
  const n = max <= 100 ? rnd(0, 100) : pickOne([rnd(11, 99), rnd(0, 100), pickOne(BIG)]);
  return mkNum(n, max);
}
function mkNum(n, max) {
  const say = sayNum(code, n);
  return { kind: "num", n, say, py: zh() ? zhPy(say) : "", show: String(n), ok: [String(n), n.toLocaleString("fr-FR")],
    traps: () => {
      const s = String(n), t = new Set();
      if (n >= 13 && n <= 19) t.add((n % 10) * 10);                              // 13 ↔ 30
      if (n % 10 === 0 && n >= 30 && n <= 90) t.add(10 + n / 10);                // 30 ↔ 13
      if (s.length === 2 && s[0] !== s[1]) t.add(+(s[1] + s[0]));                // 14 ↔ 41
      t.add(n + 1); t.add(Math.max(0, n - 1)); t.add(n + 10); t.add(Math.max(0, n - 10));
      if (n >= 100) { t.add(n + 100); t.add(Math.max(0, n - 100)); }
      t.delete(n);
      return [...t].filter((x) => x >= 0 && x <= Math.max(max, 100)).map((x) => mkNum(x, max));
    } };
}
function timeItem(h = rnd(1, 12), m = pickOne(MINUTES)) {
  const nh = (h % 12) + 1, mm = String(m).padStart(2, "0");
  const say = sayTime(code, h, m);
  const show = `${h}:${mm}`;
  return { kind: "time", say, py: zh() ? zhPy(say) : "", show, ok: [show, `${h}h${mm}`, `${h + 12}:${mm}`, `${h + 12}h${mm}`, `${String(h).padStart(2, "0")}:${mm}`, ...(m === 0 ? [`${h}h`, `${h + 12}h`] : [])],
    traps: () => [timeItem(h, m === 15 ? 45 : m === 45 ? 15 : m === 30 ? 0 : 30), timeItem(nh, m), timeItem(h === 1 ? 12 : h - 1, m), timeItem(h, (m + 10) % 60 - ((m + 10) % 60) % 5)].filter((x) => x.show !== show) };
}
function dateItem(mo = rnd(0, 11), d = rnd(1, DAYS[mo])) {
  const say = sayDate(code, mo, d);
  const show = `${d === 1 ? "1er" : d} ${MOIS[mo]}`, dd = String(d).padStart(2, "0"), mm = String(mo + 1).padStart(2, "0");
  return { kind: "date", say, py: zh() ? zhPy(say) : "", show, ok: [`${d}/${mo + 1}`, `${dd}/${mm}`, `${d} ${MOIS[mo]}`, `${dd}/${mo + 1}`, `${d}/${mm}`, ...(d === 1 ? [`1er ${MOIS[mo]}`] : [])],
    traps: () => [
      dateItem(mo, d === DAYS[mo] ? d - 1 : d + 1),
      d <= 12 && d - 1 !== mo ? dateItem(d - 1, Math.min(mo + 1, DAYS[d - 1])) : dateItem((mo + 1) % 12, Math.min(d, DAYS[(mo + 1) % 12])), // jour ↔ mois
      dateItem((mo + 11) % 12, Math.min(d, DAYS[(mo + 11) % 12])),
      d >= 10 && d % 10 && +(String(d)[1] + String(d)[0]) <= DAYS[mo] ? dateItem(mo, +(String(d)[1] + String(d)[0])) : dateItem(mo, Math.max(1, d - 10)),
    ].filter((x) => x.show !== show) };
}
function priceItem(e = rnd(1, 99), c = pickOne([0, ...CENTS])) {
  const say = sayPrice(code, e, c);
  const show = zh() ? (c ? `${e},${c / 10}0 ¥` : `${e} ¥`) : (c ? `${e},${String(c).padStart(2, "0")} €` : `${e} €`);
  const base = c ? `${e},${String(c).padStart(2, "0")}` : `${e}`;
  return { kind: "price", say, py: zh() ? zhPy(say) : "", show, ok: [base, base.replace(",", "."), `${base}€`, `${base}¥`, ...(c ? [`${e},${c / 10}`, `${e}.${c / 10}`] : [`${e},00`, `${e}.00`])],
    traps: () => [priceItem(e, c === 50 ? 20 : 50), priceItem(e + 1, c), priceItem(Math.max(1, e - 10), c), e >= 13 && e <= 19 ? priceItem((e % 10) * 10, c) : priceItem(e + 10, c)].filter((x) => x.show !== show) };
}

const KINDS = {
  num: ["🔢", "Nombres", () => numberItem(P.currentLevel().id === "A1" ? 100 : 9999)],
  time: ["🕒", "L'heure", () => timeItem()],
  date: ["📅", "Les dates", () => dateItem()],
  price: ["💶", "Les prix", () => priceItem()],
};
const LABEL = { num: "ce nombre", time: "cette heure", date: "cette date", price: "ce prix" };
const HINT = { num: "en chiffres", time: "ex. 3:15", date: "ex. 8/3", price: zh() ? "ex. 3,50" : "ex. 3,50" };

/** Une question, de l'un des trois types : écouter et choisir, écouter et écrire, lire et choisir */
function question(kind, i) {
  const it = KINDS[kind][2]();
  const traps = shuffle(it.traps()).filter((x, k, a) => a.findIndex((y) => y.show === x.show) === k).slice(0, 3);
  const pyOn = zh() && levelWantsPinyin(P.currentLevel().id);
  const reveal = `${it.say}${it.py ? ` (${it.py})` : ""} = ${it.show}`;
  const type = pickOne(traps.length >= 3 ? ["hear", "hear", "write", "read"] : ["write"]);
  if (type === "hear") {
    const o = shuffle([it, ...traps]);
    return { ref: `nombres:gen:${i}`, q: { type: "listen", say: it.say, q: `Quel${kind === "date" || kind === "time" ? "le" : ""} ${LABEL[kind].split(" ")[1]} entendez-vous ?`, options: o.map((x) => x.show), answer: o.indexOf(it), reveal } };
  }
  if (type === "write") {
    return { ref: `nombres:gen:${i}`, q: { type: "listen", write: true, say: it.say, q: `Écrivez ${LABEL[kind]} (${HINT[kind]})`, answer: it.ok, reveal } };
  }
  const o = shuffle([it, ...traps]);
  return { ref: `nombres:gen:${i}`, q: { type: "mcq", q: `Comment dit-on « ${it.show} » ?`, options: o.map((x) => x.say), answer: o.indexOf(it), explain: reveal, _py: pyOn } };
}

/* ------------------------------- Vue --------------------------------- */
let chosen = "all", streakTotal = 0;
const ROUND = 15;

export function renderNombres(app, opts = {}) {
  if (opts.go) return play(app);
  app.innerHTML = `
  <a class="back-link" href="#entrainement">← Entraînement</a>
  <header class="page-head"><p class="eyebrow">Sans fin</p><h1>🔢 Nombres, heure, prix</h1>
    <p class="muted">Ce qui bloque le plus à l'oral : écoutez, reconnaissez, écrivez. Des questions nouvelles à chaque série, autant que vous voulez.</p></header>
  <section class="card nb-pick">
    <p class="set-label">Que voulez-vous travailler ?</p>
    <div class="nb-grid">
      <button class="nb-k ${chosen === "all" ? "on" : ""}" data-k="all"><span>🎲</span><b>Tout mélangé</b></button>
      ${Object.entries(KINDS).map(([k, [e, l]]) => `<button class="nb-k ${chosen === k ? "on" : ""}" data-k="${k}"><span>${e}</span><b>${l}</b></button>`).join("")}
    </div>
    <p class="nb-ex muted small">${zh() ? "Exemples : 十四 / 四十 · 三点一刻 · 五月八号 · 三块五" : "Exemples : tredici / trenta · sono le tre e un quarto · l'otto marzo · tre euro e cinquanta"}</p>
    <button class="btn primary big" data-go>C'est parti : ${ROUND} questions</button>
  </section>`;
  app.querySelectorAll("[data-k]").forEach((b) => (b.onclick = () => { chosen = b.dataset.k; app.querySelectorAll("[data-k]").forEach((x) => x.classList.toggle("on", x === b)); }));
  app.querySelector("[data-go]").onclick = () => play(app);
  return true;
}

function play(app) {
  const kinds = chosen === "all" ? Object.keys(KINDS) : [chosen];
  const questions = Array.from({ length: ROUND }, (_, i) => question(kinds[i % kinds.length], i));
  document.body.classList.add("focus-mode");
  runQuiz(app, {
    title: chosen === "all" ? "Nombres, heure, dates, prix" : KINDS[chosen][1],
    questions: shuffle(questions),
    onQuit: () => { document.body.classList.remove("focus-mode"); location.hash = "entrainement"; },
    onFinish: (results) => {
      document.body.classList.remove("focus-mode");
      const score = results.filter((r) => r.correct).length;
      streakTotal += score;
      const r = P.recordPractice({ label: "Nombres", score, total: results.length, key: "nombres" });
      const pct = Math.round(r.ratio * 100);
      app.innerHTML = `
      <section class="results ${pct >= 60 ? "ok" : "ko"}">
        ${ring(pct, 150, 12)}
        <h1>${pct === 100 ? "Sans faute ! 🎉" : pct >= 60 ? "Bien joué !" : "Continuez, ça viendra !"}</h1>
        <p class="lead">${score} / ${results.length} bonnes réponses${streakTotal > score ? ` · ${streakTotal} depuis le début` : ""}</p>
        <div class="result-chips">${xpChip(r)}</div>
        ${mistakesHtml(results)}
        <div class="result-actions">
          <button class="btn primary big" data-more>Encore ${ROUND} questions →</button>
          <a class="btn ghost" href="#nombres" data-reload>Changer de thème</a>
        </div>
      </section>`;
      app.querySelector("[data-more]").onclick = () => play(app);
      if (pct === 100) celebrate();
    },
  });
  return true;
}
