/* =====================================================================
   Vue « Test de niveau » (#test-niveau)
   Questions de plus en plus difficiles, palier par palier : 8 questions
   par palier (examen + quiz des leçons). 6/8 → on passe au palier
   suivant ; sinon le test s'arrête. À la fin, on propose de valider les
   paliers réussis (leçons, test de mi-palier, examen) pour commencer au
   bon endroit. Rien n'est jamais retiré : une progression déjà plus
   avancée est conservée.
   ===================================================================== */

import { LEVELS, lvlLabel } from "../data/curriculum.js";
import { state, commit } from "../core/storage.js";
import * as P from "../core/progress.js";
import { runQuiz } from "../core/quiz-engine.js";
import { esc, shuffle, celebrate, toast } from "../core/ui.js";
import { L } from "../core/lang.js";

export const PER_LEVEL = 8;
export const PASS_N = 6;

/** Tire des questions du palier : la moitié dans l'examen, le reste dans les quiz des leçons */
function pick(level) {
  const exam = shuffle(level.exam.map((q, i) => ({ ref: `exam-${level.id}:${i}`, q })));
  const per = shuffle(level.lessons).map((l) => shuffle(l.quiz.map((q, i) => ({ ref: `${l.id}:${i}`, q })).filter((x) => x.q.type !== "match")));
  const out = exam.slice(0, PER_LEVEL / 2);
  for (let k = 0; out.length < PER_LEVEL && per.some((a) => a.length); k++) { const a = per[k % per.length]; if (a.length) out.push(a.pop()); }
  for (const x of exam.slice(PER_LEVEL / 2)) { if (out.length >= PER_LEVEL) break; out.push(x); }
  return shuffle(out);
}

/** Nombre de paliers déjà validés (examens réussis à la suite) */
const passedLevels = () => { let n = 0; while (n < LEVELS.length && P.isExamPassed(LEVELS[n].id)) n++; return n; };

export function renderTestNiveau(app) {
  const done = passedLevels();
  const prev = state.placement;
  app.innerHTML = `
  <a class="back-link" href="#parcours">← Parcours</a>
  <section class="card blanc-intro">
    <p class="eyebrow">Test de niveau</p>
    <h1>🧭 Où commencer ?</h1>
    <p class="lead">Quelques questions par palier, de plus en plus difficiles, pour vous placer directement au bon niveau ${esc(L.label === "Mandarin" ? "HSK" : "CECRL")}.</p>
    <ul class="defi-rules">
      <li>📈 ${PER_LEVEL} questions par palier, du plus facile (${esc(lvlLabel(LEVELS[0]))}) au plus difficile (${esc(lvlLabel(LEVELS[LEVELS.length - 1]))})</li>
      <li>✅ ${PASS_N}/${PER_LEVEL} pour passer au palier suivant ; le test s'arrête dès qu'un palier est trop difficile</li>
      <li>🎯 À la fin, les paliers réussis sont validés : vous commencez au bon endroit</li>
      <li>🤷 Vous ne savez pas ? Répondez au hasard plutôt que de chercher : le test sera plus juste</li>
    </ul>
    ${done ? `<p class="muted small">Vous avez déjà validé ${done} palier${done > 1 ? "s" : ""} : votre progression actuelle sera toujours conservée.</p>` : ""}
    ${prev ? `<p class="muted small">Dernier test : ${esc(prev.label)}.</p>` : ""}
    <button class="btn primary big" data-go>Commencer le test</button>
    <a class="btn ghost" href="#parcours">Je préfère commencer au début</a>
  </section>`;
  app.querySelector("[data-go]").onclick = () => run(app, 0, []);
  return true;
}

function run(app, li, scores) {
  const level = LEVELS[li];
  document.body.classList.add("focus-mode");
  runQuiz(app, {
    title: `Test de niveau · palier ${lvlLabel(level)}`,
    questions: pick(level),
    countText: (i, n) => `${lvlLabel(level)} · ${i + 1}/${n}`,
    onQuit: () => { document.body.classList.remove("focus-mode"); location.hash = "parcours"; },
    onFinish: (results) => {
      document.body.classList.remove("focus-mode");
      const score = results.filter((r) => r.correct).length;
      const all = [...scores, { id: level.id, score, total: results.length }];
      const ok = score >= PASS_N;
      if (ok && li + 1 < LEVELS.length) return between(app, li, all);
      finish(app, all.filter((s) => s.score >= PASS_N).length, all);
    },
  });
}

/** Écran entre deux paliers */
function between(app, li, scores) {
  const s = scores[scores.length - 1], next = LEVELS[li + 1];
  app.innerHTML = `
  <section class="results ok">
    <p class="eyebrow">Test de niveau</p>
    <h1>Palier ${esc(lvlLabel(LEVELS[li]))} réussi ✓</h1>
    <p class="lead">${s.score} / ${s.total} bonnes réponses</p>
    <div class="pl-steps">${steps(scores)}</div>
    <div class="result-actions">
      <button class="btn primary big" data-next>Continuer : palier ${esc(lvlLabel(next))} →</button>
      <button class="btn ghost" data-stop>M'arrêter ici</button>
    </div>
  </section>`;
  app.querySelector("[data-next]").onclick = () => run(app, li + 1, scores);
  app.querySelector("[data-stop]").onclick = () => finish(app, scores.filter((x) => x.score >= PASS_N).length, scores);
}

const steps = (scores) => LEVELS.map((l, i) => {
  const s = scores[i];
  const cls = !s ? "todo" : s.score >= PASS_N ? "ok" : "ko";
  return `<span class="pl-step ${cls}" title="${s ? `${s.score}/${s.total}` : ""}">${esc(lvlLabel(l))}${s ? `<small>${s.score}/${s.total}</small>` : ""}</span>`;
}).join("");

function finish(app, n, scores) {
  const already = passedLevels();
  const start = LEVELS[Math.min(n, LEVELS.length - 1)];
  const label = n === 0 ? "débutant" : n >= LEVELS.length ? `${lvlLabel(LEVELS[LEVELS.length - 1])} validé` : `niveau ${lvlLabel(LEVELS[n - 1])}`;
  commit((s) => { s.placement = { n, label, date: Date.now(), scores }; });
  const gain = n > already;
  app.innerHTML = `
  <section class="results ${n ? "ok" : ""}">
    <p class="eyebrow">Résultat du test</p>
    <h1>${n === 0 ? "On commence par les bases 🌱" : n >= LEVELS.length ? "Impressionnant ! 🏆" : `Votre niveau : ${esc(lvlLabel(LEVELS[n - 1]))} 🎯`}</h1>
    <div class="pl-steps">${steps(scores)}</div>
    <p class="lead">${n === 0 ? `Le palier ${esc(lvlLabel(LEVELS[0]))} est fait pour vous : vous progresserez vite.`
      : n >= LEVELS.length ? "Vous avez réussi tous les paliers."
      : `Nous vous conseillons de commencer au palier <b>${esc(lvlLabel(start))}</b>.`}</p>
    ${gain ? `<p class="muted">Les leçons et examens des paliers ${esc(LEVELS.slice(already, n).map(lvlLabel).join(", "))} seront marqués comme réussis. Vous pourrez toujours y revenir.</p>`
      : n ? `<p class="muted">Votre progression actuelle va déjà jusque-là : rien à changer.</p>` : ""}
    <div class="result-actions">
      ${gain ? `<button class="btn primary big" data-apply>Commencer au palier ${esc(lvlLabel(start))} →</button>
        <a class="btn ghost" href="#parcours">Non merci, je garde mon parcours</a>`
      : `<a class="btn primary big" href="#parcours">Aller au parcours →</a>`}
      <a class="btn ghost" href="#test-niveau" data-reload>Refaire le test</a>
    </div>
  </section>`;
  if (n) celebrate();
  app.querySelector("[data-apply]")?.addEventListener("click", () => {
    applyPlacement(n);
    toast(`Paliers validés : vous commencez en ${lvlLabel(start)} ✓`, "ok");
    location.hash = "parcours";
  });
}

/** Valide les n premiers paliers (sans jamais retirer une progression existante) */
export function applyPlacement(n) {
  const date = new Date().toISOString();
  commit((s) => {
    s.checkpoints ||= {};
    // Les étapes validées par le test ne sont pas publiées une à une dans le fil des amis
    const fs = { ...(s.feedSent || {}) }, now = Date.now();
    LEVELS.slice(0, n).forEach((lvl) => {
      lvl.lessons.forEach((l) => {
        if (s.lessons[l.id]?.passed) return;
        const total = P.LESSON_QUIZ_N;
        fs[`lesson-${l.id}`] ||= now;
        s.lessons[l.id] = { best: Math.ceil(total * P.PASS_LESSON), total, attempts: s.lessons[l.id]?.attempts || 0, passed: true, date, placed: true };
      });
      if (!s.checkpoints[P.ckKey(lvl.id)]?.passed) s.checkpoints[P.ckKey(lvl.id)] = { best: P.CHECKPOINT_N, total: P.CHECKPOINT_N, attempts: 0, passed: true, date, placed: true };
      fs[`exam-${lvl.id}`] ||= now;
      if (!s.exams[lvl.id]?.passed) s.exams[lvl.id] = { best: P.EXAM_N, total: P.EXAM_N, attempts: s.exams[lvl.id]?.attempts || 0, passed: true, date, placed: true };
    });
    s.feedSent = fs;
  });
}
