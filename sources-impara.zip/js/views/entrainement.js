/* =====================================================================
   Vue « Entraînement » — exercices libres à partir du vocabulaire
   - #entrainement        : choix de l'exercice
   - #ecoute              : compréhension orale (les deux langues)
   - #tons                : reconnaître le ton d'une syllabe (mandarin)
   - #trace               : ordre des traits et écriture au doigt (mandarin)
   Les questions sont générées à partir du carnet ; s'il est trop petit,
   on complète avec le vocabulaire des leçons déjà débloquées.
   ===================================================================== */

import { state } from "../core/storage.js";
import { L, code } from "../core/lang.js";
import { esc, shuffle, ring, celebrate, toast, speak, tri, splitDialog } from "../core/ui.js";
import { keysFor } from "../core/words.js";
import { loadWriter } from "../core/hanzi.js";
import { orderQuestions } from "../core/order.js";
import { runQuiz, mistakesHtml } from "../core/quiz-engine.js";
import * as P from "../core/progress.js";
import { ALL_LESSONS } from "../data/curriculum.js";
import { srsStats } from "../core/srs.js";
import { icon } from "../core/icons.js";
import { storyCount } from "./histoires.js";
import { sentencePool } from "./dictee.js";

const isZh = () => code === "zh";
const HAN = /[㐀-鿿]/;

/* ------------------------- Réservoir de mots ------------------------ */
export function wordPool(min = 8) {
  const seen = new Map();
  Object.values(state.vocab).forEach((w) => seen.set(w.zh, { zh: w.zh, py: w.py || "", fr: w.fr, learned: true }));
  if (seen.size < min) {
    ALL_LESSONS.filter((l) => P.isLessonUnlocked(l)).forEach((l) => {
      [...(l.vocab || []).map(tri), ...(l.sections || []).flatMap((s) => s.examples || []).flatMap(splitDialog)].forEach(([zh, py, fr]) => {
        if (!seen.has(zh) && zh.length <= 12) seen.set(zh, { zh, py, fr: String(fr).split(" — ")[0], learned: false });
      });
    });
  }
  return [...seen.values()];
}

/* ------------------------------ Tons -------------------------------- */
const TONE_MARKS = ["āēīōūǖ", "áéíóúǘ", "ǎěǐǒǔǚ", "àèìòùǜ"];
const toneOf = (syl) => { for (let t = 0; t < 4; t++) if ([...syl].some((c) => TONE_MARKS[t].includes(c.toLowerCase()))) return t + 1; return 0; };

/** Syllabes isolées : caractère seul, ou mot dont le pinyin est séparé syllabe par syllabe */
function syllablePool() {
  const out = new Map();
  const add = (ch, syl) => { const t = toneOf(syl); if (t && HAN.test(ch) && !out.has(ch)) out.set(ch, { ch, syl, tone: t }); };
  const words = wordPool(999);
  words.forEach(({ zh, py }) => {
    if (!py) return;
    const chars = [...zh].filter((c) => HAN.test(c));
    const syls = py.trim().split(/\s+/);
    if (chars.length === 1 && syls.length === 1) add(chars[0], syls[0]);
    else if (chars.length === syls.length && chars.length === [...zh].length) chars.forEach((c, i) => add(c, syls[i]));
  });
  return [...out.values()];
}

/* ------------------------- Génération des quiz ---------------------- */
export function listeningQuestions(n = 10) {
  const pool = wordPool();
  if (pool.length < 4) return [];
  const label = (w) => (w.py ? `${w.zh} · ${w.py}` : w.zh);
  return shuffle(pool).slice(0, n).map((w, i) => {
    const others = shuffle(pool.filter((x) => x.zh !== w.zh && x.fr !== w.fr));
    const meaning = i % 2 === 1;
    const opts = shuffle([w, ...others.slice(0, 3)]);
    return {
      ref: `listen:${w.zh}`,
      q: {
        type: "listen", say: w.zh,
        q: meaning ? "Que signifie le mot entendu ?" : "Quel mot avez-vous entendu ?",
        options: opts.map((x) => (meaning ? x.fr : label(x))), answer: opts.indexOf(w),
        reveal: `${w.zh}${w.py ? " (" + w.py + ")" : ""} — ${w.fr}`,
      },
    };
  });
}

/**
 * Exercice des tons : uniquement des caractères que la voix lit seuls comme
 * dans le cours (lecture par défaut = lecture du cours), avec, pour chaque
 * ton, un autre caractère courant à écouter pour comparer.
 */
async function toneQuestions(n = 10) {
  const { REF, READ } = await import("../data/zh-tones.js");
  const strip = (s) => s.normalize("NFD").replace(/[\u0300-\u0304\u030c]/g, "").normalize("NFC").replace(/u\u0308|v/g, "ü");
  const pool = syllablePool().filter((s) => READ[s.ch] === s.syl);
  if (pool.length < 4) return [];
  const picks = [];
  while (picks.length < n) picks.push(...shuffle(pool));
  return picks.slice(0, n).map((s) => {
    const syl = strip(s.syl);
    // Pour chaque ton, un caractère à écouter pour comparer : sur la même syllabe si possible
    // (un autre que celui à deviner), sinon le modèle classique 妈 麻 马 骂 (mā má mǎ mà)
    const MODEL = [["妈", "mā"], ["麻", "má"], ["马", "mǎ"], ["骂", "mà"]];
    const row = REF[syl] || ["", "", "", ""];
    const cmp = row.map((chars, i) => {
      const c = [...chars].find((x) => x !== s.ch) || (chars.includes(s.ch) ? s.ch : "");
      return c ? [c, ""] : MODEL[i];
    });
    return {
      ref: `tone:${s.ch}`,
      q: { type: "tone", say: s.ch, syl, cmp, q: "Quel ton entendez-vous ?", answer: s.tone - 1, reveal: `${s.ch} ${s.syl}`, explain: `${s.ch} se lit ${s.syl}` },
    };
  });
}

/* ============================== Hub ================================ */
export function renderEntrainement(app) {
  const words = wordPool().length, syl = isZh() ? syllablePool().length : 0;
  const errors = Object.keys(state.errors).length;
  const srs = srsStats(Object.values(state.vocab));
  const vocab = Object.keys(state.vocab).length;
  const st = storyCount();
  const dict = sentencePool().length;

  // Carte du haut : la meilleure chose à faire maintenant
  const hero = errors ? { href: "revision", title: "Travaille tes points faibles", sub: `${Math.min(10, errors)} question${errors > 1 ? "s" : ""} ratée${errors > 1 ? "s" : ""} à corriger`, xp: Math.min(10, errors) * 10, icon: "target" }
    : srs.todo ? { href: "reviser", title: "Révision du jour", sub: `${srs.todo} mot${srs.todo > 1 ? "s" : ""} à revoir en flashcards`, xp: srs.todo * 2, icon: "calendar" }
    : words >= 4 && !P.practiceReadyAt("ecoute") ? { href: "ecoute", title: "Entraîne ton oreille", sub: "10 mots à reconnaître à l'écoute", xp: 50, icon: "headphones" }
    : words >= 3 && !P.practiceReadyAt("prononciation") ? { href: "prononciation", title: "Travaille ta prononciation", sub: "10 mots à dire à voix haute", xp: 50, icon: "mic" }
    : words >= 4 ? { href: "ecoute", title: "Entraînement libre", sub: "XP du jour déjà gagnés : tu peux continuer pour progresser", xp: 0, icon: "train" }
    : { href: "parcours", title: "Commence ton parcours", sub: "Termine une leçon pour débloquer l'entraînement", xp: 0, icon: "map" };

  const row = (href, title, ico, cls, { badge = 0, sub = "", ok = true } = {}) => `
    <a class="tr-row ${ok ? "" : "disabled"}" ${ok ? `href="#${href}"` : `aria-disabled="true"`}>
      <span class="tr-txt"><b>${title}</b>${sub ? `<small>${sub}</small>` : ""}</span>
      <span class="tr-ico ${cls}">${icon(ico, { size: 28, stroke: 2.2 })}</span>
      ${badge ? `<em class="tr-badge">${badge > 30 ? "30+" : badge}</em>` : ""}
    </a>`;

  app.innerHTML = `
  <section class="tr-hero">
    <div class="tr-hero-txt">
      <p class="tr-hero-kicker">${hero.title}</p>
      <p class="tr-hero-sub">${hero.sub}</p>
      <a class="tr-hero-btn" href="#${hero.href}">COMMENCER${hero.xp ? ` +${hero.xp} XP` : ""}</a>
    </div>
    <span class="tr-hero-ico" aria-hidden="true">${icon(hero.icon, { size: 84, stroke: 1.8 })}</span>
  </section>

  <h2 class="tr-h2">Exercices</h2>
  <div class="tr-list">
    ${row("histoires", "Histoires", "story", "c-orange", { sub: st.open ? `Dialogues à lire et écouter · ${st.done}/${st.total} lues` : "Se débloquent au fil des leçons", ok: st.open > 0, badge: st.open - st.done })}
    ${row("dialogues", "Dialogues", "chat", "c-blue", { sub: cool("dialogue", "Choisissez la bonne réplique, comme en vrai"), ok: words >= 3 })}
    ${row("nombres", "Nombres, heure, prix", "hash", "c-orange", { sub: cool("nombres", "Sans fin : écouter, reconnaître, écrire"), ok: words >= 1 })}
    ${row("prononciation", "Prononciation", "mic", "c-red", { sub: cool("prononciation", isZh() ? "Parlez, je vérifie les sons et les tons" : "Parlez, je vérifie ce que j'entends"), ok: words >= 3 })}
    ${row("ecoute", "Écoute", "headphones", "c-blue", { sub: cool("ecoute", "Reconnaître les mots à l'oral"), ok: words >= 4 })}
    ${row("ecoutes", "Écoute longue", "headphones", "c-purple", { sub: storyCount().open ? "Une histoire entière, sans le texte, puis des questions" : "Se débloque avec les histoires", ok: storyCount().open > 0 })}
    ${row("repeter", "Répéter des phrases", "repeat", "c-green", { sub: dict >= 3 ? cool("repeter", "Écoutez une phrase, répétez-la à voix haute") : "Se débloque après quelques leçons", ok: dict >= 3 })}
    ${row("ordre", "Ordre des mots", "puzzle", "c-sky", { sub: dict >= 3 ? cool("ordre", "Reconstruisez des phrases mot par mot") : "Se débloque après quelques leçons", ok: dict >= 3 })}
    ${row("dictee", "Dictée", "keyboard", "c-purple", { sub: dict >= 3 ? cool("dictee", isZh() ? "Écoutez une phrase, écrivez le pinyin ou les caractères" : "Écoutez une phrase à vitesse réelle et écrivez-la") : "Se débloque après quelques leçons", ok: dict >= 3 })}
    ${isZh() ? row("tons", "Les tons", "wave", "c-green", { sub: cool("tons", "1er, 2e, 3e ou 4e ton ?"), ok: syl >= 4 }) : ""}
    ${!isZh() ? row("conjugaison", "Conjugaison chrono", "timer", "c-orange", { sub: cool("conjugaison", "60 secondes pour conjuguer vos verbes"), ok: P.isLessonDone("a1-presente-are") }) : ""}
    ${isZh() ? row("trace", "Tracé des caractères", "pen", "c-purple", { sub: "L'ordre des traits, au doigt", ok: words >= 1 }) : ""}
    ${isZh() ? row("ecriture", "Écrire de mémoire", "brush", "c-orange", { sub: words >= 3 ? cool("ecriture", "Le sens et le pinyin : tracez le caractère, sans modèle") : "Se débloque après quelques leçons", ok: words >= 3 }) : ""}
  </div>

  <h2 class="tr-h2">Mes collections</h2>
  <div class="tr-list">
    ${row("erreurs", "Erreurs", "redo", "c-orange", { badge: errors, sub: errors ? "Cahier des questions ratées" : "Aucune erreur en attente" })}
    ${row("reviser", "Mots", "layers", "c-sky", { badge: srs.todo, sub: vocab ? `${vocab} mot${vocab > 1 ? "s" : ""} · flashcards et révision du jour` : "Votre carnet de vocabulaire" })}
    ${row("carnet", "Carnet", "notebook", "c-yellow", { sub: "Tous vos mots, avec recherche" })}
    ${row("fiches", "Fiches de grammaire", "clipboard", "c-green", { sub: "Toutes les explications, rangées par thème" })}
  </div>`;
}

/** Pastille de résultat : XP gagnés, ou rappel du délai de 24 h */
export const xpChip = (r) => (r.capped ? `<span class="chip muted-chip">⏳ XP déjà gagnés aujourd'hui</span>` : `<span class="chip">⚡ +${r.xpGained} XP</span>`);
/** Sous-titre d'un exercice dans le hub : signale l'attente avant de nouveaux XP */
const cool = (key, sub) => { const at = P.practiceReadyAt(key); return at ? `${sub} · ✓ XP dans ${P.waitLabel(at)}` : sub; };

/* ======================= Écoute et tons (quiz) ===================== */
export function renderEcoute(app) { return practiceQuiz(app, { title: "Écoute", questions: listeningQuestions(), again: "ecoute" }); }
export async function renderTons(app) {
  if (!isZh()) return false;
  const questions = await toneQuestions();
  if (location.hash !== "#tons") return true; // page quittée pendant le chargement
  return practiceQuiz(app, { title: "Les tons", questions, again: "tons" });
}

function practiceQuiz(app, { title, questions, again }) {
  if (!questions.length) return false;
  if (!state.settings.tts) toast("Le son est coupé dans votre profil : il est quand même joué pour cet exercice.");
  document.body.classList.add("focus-mode");
  runQuiz(app, {
    title, questions,
    onQuit: () => { document.body.classList.remove("focus-mode"); location.hash = "entrainement"; },
    onFinish: (results) => {
      document.body.classList.remove("focus-mode");
      const score = results.filter((r) => r.correct).length;
      const r = P.recordPractice({ label: title, score, total: results.length, key: again });
      const pct = Math.round(r.ratio * 100);
      app.innerHTML = `
      <section class="results ${pct >= 60 ? "ok" : "ko"}">
        ${ring(pct, 150, 12)}
        <h1>${pct === 100 ? "Sans faute ! 🎉" : pct >= 60 ? "Bien joué !" : "Continuez, ça viendra !"}</h1>
        <p class="lead">${score} / ${results.length} bonnes réponses</p>
        <div class="result-chips">${xpChip(r)}</div>
        ${r.capped ? `<p class="muted small">Cet exercice a déjà rapporté des XP dans les dernières 24 h. Vous pouvez le refaire pour vous entraîner : les XP reviennent dans <b>${P.waitLabel(r.readyAt)}</b>.</p>` : ""}
        ${mistakesHtml(results)}
        <div class="result-actions">
          <a class="btn primary big" href="#${again}" data-reload>Recommencer</a>
          <a class="btn ghost" href="#entrainement">Autres exercices</a>
        </div>
      </section>`;
      if (pct === 100) celebrate();
    },
  });
  return true;
}

/* ========================= Ordre des mots ========================== */
export function renderOrdre(app) {
  const questions = orderQuestions(sentencePool().map((x) => ({ ...x, levelId: P.currentLevel().id })), 10, "ordre");
  if (questions.length < 3) return false;
  return practiceQuiz(app, { title: "Ordre des mots", questions, again: "ordre" });
}

/* ============================== Tracé ============================== */


export function renderTrace(app, start) {
  if (!isZh()) return false;
  const words = wordPool();
  const chars = [];
  words.forEach((w) => [...w.zh].forEach((c) => { if (HAN.test(c) && !chars.some((x) => x.ch === c)) chars.push({ ch: c, w }); }));
  if (!chars.length) return false;
  let idx = Math.max(0, chars.findIndex((c) => c.ch === start));
  let writer = null, mode = "view";

  app.innerHTML = `
  <a class="back-link" href="#entrainement">← Entraînement</a>
  <section class="card trace-card">
    <div class="trace-head">
      <div><p class="eyebrow">Tracé des caractères</p><h1 class="trace-title"></h1><p class="trace-info muted"></p></div>
      <button class="speak" data-say aria-label="Écouter">🔊</button>
    </div>
    <div class="trace-box"><div class="trace-writer" aria-label="Zone de tracé"></div><p class="trace-msg" aria-live="polite"></p></div>
    <div class="btn-row trace-actions">
      <button class="btn ghost" data-anim>▶️ Voir l'ordre des traits</button>
      <button class="btn primary" data-quiz>✍️ À moi d'écrire</button>
      <button class="btn ghost" data-outline>👁️ Contour</button>
    </div>
    <div class="trace-keys" data-keys></div>
    <div class="flash-nav"><button class="btn ghost" data-prev>← Précédent</button><span class="trace-pos"></span><button class="btn ghost" data-next>Suivant →</button></div>
    <details class="trace-list"><summary>Choisir un caractère (${chars.length})</summary>
      <div class="trace-chips">${chars.map((c, i) => `<button class="chip-btn zh" data-pick="${i}">${esc(c.ch)}</button>`).join("")}</div></details>
  </section>`;

  const $ = (s) => app.querySelector(s);
  const size = () => Math.min(300, $(".trace-box").clientWidth - 8);
  let outline = true;

  async function show() {
    const c = chars[idx];
    $(".trace-title").innerHTML = `<span class="zh">${esc(c.ch)}</span>`;
    $(".trace-info").textContent = `${c.w.zh}${c.w.py ? " · " + c.w.py : ""} — ${c.w.fr}`;
    $(".trace-pos").textContent = `${idx + 1} / ${chars.length}`;
    $(".trace-msg").textContent = "";
    mode = "view";
    keysFor(c.ch).then((h) => { if (chars[idx] === c) $("[data-keys]").innerHTML = h; });
    const box = $(".trace-writer");
    box.innerHTML = `<p class="muted small">Chargement…</p>`;
    try {
      const HanziWriter = await loadWriter();
      if (chars[idx] !== c) return;
      box.innerHTML = "";
      const s = size();
      box.style.width = box.style.height = s + "px";
      writer = HanziWriter.create(box, c.ch, {
        width: s, height: s, padding: 10, showOutline: outline, strokeColor: getComputedStyle(document.documentElement).getPropertyValue("--ink").trim() || "#1d2733",
        radicalColor: "#c23b32", outlineColor: getComputedStyle(document.documentElement).getPropertyValue("--line").trim() || "#e7e1d5", drawingColor: "#c23b32", highlightColor: "#e8b04b",
        strokeAnimationSpeed: 1, delayBetweenStrokes: 250, showCharacter: true,
        onLoadCharDataError: () => { box.innerHTML = `<p class="muted small">Tracé indisponible pour « ${esc(c.ch)} ».</p>`; writer = null; },
      });
    } catch {
      box.innerHTML = `<p class="muted small">Connexion nécessaire pour charger le tracé.</p>`; writer = null;
    }
  }

  $("[data-anim]").onclick = () => { if (!writer) return; mode = "view"; $(".trace-msg").textContent = ""; writer.showCharacter(); writer.animateCharacter(); };
  $("[data-quiz]").onclick = () => {
    if (!writer) return;
    mode = "quiz";
    $(".trace-msg").textContent = "Tracez les traits dans l'ordre. Après 3 erreurs sur un trait, un indice apparaît.";
    writer.quiz({
      showHintAfterMisses: 3,
      onComplete: ({ totalMistakes }) => {
        const ok = totalMistakes <= 2;
        $(".trace-msg").textContent = ok ? `✓ Bravo ! ${totalMistakes ? totalMistakes + " petite(s) erreur(s)." : "Parfait, sans erreur."} +5 XP` : `Terminé avec ${totalMistakes} erreurs. Réessayez pour gagner des XP.`;
        const r = ok ? P.recordPractice({ label: `Tracé ${chars[idx].ch}`, score: 1, total: 0, key: `trace:${chars[idx].ch}` }) : null;
        if (r?.capped) $(".trace-msg").textContent = `✓ Bravo ! Déjà tracé aujourd'hui : XP de nouveau dans ${P.waitLabel(r.readyAt)}.`;
        speak(chars[idx].ch);
      },
    });
  };
  $("[data-outline]").onclick = () => { outline = !outline; if (writer) outline ? writer.showOutline() : writer.hideOutline(); };
  $("[data-say]").onclick = () => speak(chars[idx].ch);
  $("[data-prev]").onclick = () => { idx = (idx - 1 + chars.length) % chars.length; show(); };
  $("[data-next]").onclick = () => { idx = (idx + 1) % chars.length; show(); };
  app.querySelectorAll("[data-pick]").forEach((b) => (b.onclick = () => { idx = +b.dataset.pick; $(".trace-list").open = false; show(); }));
  show();
  return true;
}

/* ======================= Écrire de mémoire (mandarin) =======================
   10 caractères déjà vus : on voit le sens et le pinyin, on trace le caractère
   au doigt sans modèle ; chaque trait est corrigé. Réussi si ≤ 2 erreurs. */
export function renderEcriture(app) {
  if (!isZh()) return false;
  const seen = new Set(), pool = [];
  shuffle(wordPool()).forEach((w) => [...w.zh].forEach((c) => { if (HAN.test(c) && !seen.has(c)) { seen.add(c); pool.push({ ch: c, w }); } }));
  const items = pool.slice(0, 10);
  if (items.length < 3) return false;
  const res = [];
  let i = 0, writer = null;
  app.innerHTML = `
  <section class="quiz ew">
    <header class="quiz-top"><button class="icon-btn quiz-quit" aria-label="Quitter">✕</button><div class="bar"><span></span></div><span class="quiz-count"></span></header>
    <p class="quiz-title">Écrire de mémoire</p>
    <div class="quiz-card ew-card">
      <p class="q-label">Tracez le caractère</p>
      <h2 class="q-text ew-q"></h2>
      <div class="trace-box"><div class="trace-writer ew-writer"></div><p class="trace-msg ew-msg" aria-live="polite"></p></div>
      <div class="btn-row"><button class="btn ghost small" data-say>🔊 Écouter</button><button class="btn ghost small" data-hint>💡 Indice</button></div>
    </div>
    <footer class="quiz-foot"><button class="btn primary big quiz-action" disabled>Continuer</button></footer>
  </section>`;
  document.body.classList.add("focus-mode");
  const $ = (s) => app.querySelector(s);
  $(".quiz-quit").onclick = () => { document.body.classList.remove("focus-mode"); location.hash = "entrainement"; };
  $("[data-say]").onclick = () => speak(items[i].ch, { force: true });
  $("[data-hint]").onclick = () => { if (writer) { writer.showOutline(); res[i] && (res[i].hint = true); } };
  $(".quiz-action").onclick = () => { if (++i < items.length) show(); else finish(); };
  async function show() {
    const it = items[i], word = it.w;
    $(".bar span").style.width = `${(i / items.length) * 100}%`;
    $(".quiz-count").textContent = `${i + 1} / ${items.length}`;
    const hint = word.zh.length > 1 ? `dans « ${word.zh.replace(it.ch, "＿")} »` : "";
    $(".ew-q").innerHTML = `<b>${esc(word.fr)}</b><span class="ew-py">${esc(word.py || "")}</span>${hint ? `<small>${esc(hint)}</small>` : ""}`;
    $(".ew-msg").textContent = "Tracez les traits dans l'ordre. Après 3 erreurs sur un trait, il s'affiche.";
    $(".quiz-action").disabled = true;
    res[i] = { ch: it.ch, w: word, mistakes: 0, done: false };
    const box = $(".ew-writer"); box.innerHTML = "";
    try {
      const HanziWriter = await loadWriter();
      const s = Math.min(280, box.parentElement.clientWidth - 8);
      box.style.width = box.style.height = s + "px";
      writer = HanziWriter.create(box, it.ch, {
        width: s, height: s, padding: 10, showOutline: false, showCharacter: false,
        strokeColor: getComputedStyle(document.documentElement).getPropertyValue("--ink").trim() || "#1d2733",
        outlineColor: getComputedStyle(document.documentElement).getPropertyValue("--line").trim() || "#e7e1d5",
        drawingColor: "#c23b32", highlightColor: "#e8b04b",
        onLoadCharDataError: () => { res[i].skip = true; $(".ew-msg").textContent = "Tracé indisponible pour ce caractère."; $(".quiz-action").disabled = false; },
      });
      writer.quiz({
        showHintAfterMisses: 3,
        onMistake: () => { res[i].mistakes++; },
        onComplete: ({ totalMistakes }) => {
          res[i].mistakes = totalMistakes; res[i].done = true;
          const ok = totalMistakes <= 2;
          $(".ew-msg").textContent = ok ? (totalMistakes ? `✓ Bien ! ${totalMistakes} petite(s) erreur(s).` : "✓ Parfait, sans erreur !") : `${totalMistakes} erreurs : on le revoit à la fin.`;
          $(".ew-card").classList.toggle("is-ok", ok);
          speak(it.ch, { force: true });
          $(".quiz-action").disabled = false; $(".quiz-action").textContent = i === items.length - 1 ? "Voir mes résultats" : "Continuer";
        },
      });
    } catch { $(".ew-msg").textContent = "Connexion nécessaire pour charger les tracés."; res[i].skip = true; $(".quiz-action").disabled = false; }
  }
  function finish() {
    document.body.classList.remove("focus-mode");
    const done = res.filter((r) => !r.skip), good = done.filter((r) => r.done && r.mistakes <= 2 && !r.hint).length;
    const r = P.recordPractice({ label: "Écrire de mémoire", score: good, total: done.length, key: "ecriture" });
    const pct = done.length ? Math.round((good / done.length) * 100) : 0;
    const bad = done.filter((x) => !(x.done && x.mistakes <= 2 && !x.hint));
    app.innerHTML = `
    <section class="results ${pct >= 60 ? "ok" : "ko"}">
      ${ring(pct, 150, 12)}
      <h1>${pct === 100 ? "Sans faute ! 🎉" : pct >= 60 ? "Bien joué !" : "Continuez, ça viendra !"}</h1>
      <p class="lead">${good} / ${done.length} caractères bien écrits</p>
      <div class="result-chips">${xpChip(r)}</div>
      ${bad.length ? `<div class="card ew-review"><h2 class="h3">À retravailler</h2><div class="trace-chips">${bad.map((x) => `<a class="chip-btn zh" href="#trace-${encodeURIComponent(x.ch)}">${esc(x.ch)}</a>`).join("")}</div><p class="muted small">Touchez un caractère pour revoir l'ordre de ses traits.</p></div>` : ""}
      <div class="result-actions"><a class="btn primary big" href="#ecriture" data-reload>Recommencer</a><a class="btn ghost" href="#entrainement">Autres exercices</a></div>
    </section>`;
    if (pct === 100) celebrate();
  }
  show();
  return true;
}
