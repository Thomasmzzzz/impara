/* =====================================================================
   Vue « Entraînement » — exercices libres à partir du vocabulaire
   - #entrainement        : choix de l'exercice
   - #ecoute              : compréhension orale (les deux langues)
   - #tons                : reconnaître le ton d'une syllabe (mandarin)
   - #trace               : ordre des traits et écriture au doigt (mandarin)
   Les questions sont générées à partir du carnet ; s'il est trop petit,
   on complète avec le vocabulaire des leçons déjà débloquées.
   ===================================================================== */

import { state } from "../core/storage.js";
import { L, code } from "../core/lang.js";
import { esc, shuffle, ring, celebrate, toast, speak, tri } from "../core/ui.js";
import { runQuiz } from "../core/quiz-engine.js";
import * as P from "../core/progress.js";
import { ALL_LESSONS } from "../data/curriculum.js";
import { srsStats } from "../core/srs.js";

const isZh = () => code === "zh";
const HAN = /[㐀-鿿]/;

/* ------------------------- Réservoir de mots ------------------------ */
function wordPool(min = 8) {
  const seen = new Map();
  Object.values(state.vocab).forEach((w) => seen.set(w.zh, { zh: w.zh, py: w.py || "", fr: w.fr, learned: true }));
  if (seen.size < min) {
    ALL_LESSONS.filter((l) => P.isLessonUnlocked(l)).forEach((l) => {
      [...(l.vocab || []), ...(l.sections || []).flatMap((s) => s.examples || [])].map(tri).forEach(([zh, py, fr]) => {
        if (!seen.has(zh) && zh.length <= 12) seen.set(zh, { zh, py, fr: String(fr).split(" — ")[0], learned: false });
      });
    });
  }
  return [...seen.values()];
}

/* ------------------------------ Tons -------------------------------- */
const TONE_MARKS = ["āēīōūǖ", "áéíóúǘ", "ǎěǐǒǔǚ", "àèìòùǜ"];
const toneOf = (syl) => { for (let t = 0; t < 4; t++) if ([...syl].some((c) => TONE_MARKS[t].includes(c.toLowerCase()))) return t + 1; return 0; };
const TONE_LABELS = ["1er ton — ā (haut et plat)", "2e ton — á (montant)", "3e ton — ǎ (descend puis remonte)", "4e ton — à (descendant)"];

/** Syllabes isolées : caractère seul, ou mot dont le pinyin est séparé syllabe par syllabe */
function syllablePool() {
  const out = new Map();
  const add = (ch, syl) => { const t = toneOf(syl); if (t && HAN.test(ch) && !out.has(ch)) out.set(ch, { ch, syl, tone: t }); };
  const words = wordPool(999);
  words.forEach(({ zh, py }) => {
    if (!py) return;
    const chars = [...zh].filter((c) => HAN.test(c));
    const syls = py.trim().split(/\s+/);
    if (chars.length === 1 && syls.length === 1) add(chars[0], syls[0]);
    else if (chars.length === syls.length && chars.length === [...zh].length) chars.forEach((c, i) => add(c, syls[i]));
  });
  return [...out.values()];
}

/* ------------------------- Génération des quiz ---------------------- */
function listeningQuestions(n = 10) {
  const pool = wordPool();
  if (pool.length < 4) return [];
  const label = (w) => (w.py ? `${w.zh} · ${w.py}` : w.zh);
  return shuffle(pool).slice(0, n).map((w, i) => {
    const others = shuffle(pool.filter((x) => x.zh !== w.zh && x.fr !== w.fr));
    const meaning = i % 2 === 1;
    const opts = shuffle([w, ...others.slice(0, 3)]);
    return {
      ref: `listen:${w.zh}`,
      q: {
        type: "listen", say: w.zh,
        q: meaning ? "Que signifie le mot entendu ?" : "Quel mot avez-vous entendu ?",
        options: opts.map((x) => (meaning ? x.fr : label(x))), answer: opts.indexOf(w),
        reveal: `${w.zh}${w.py ? " (" + w.py + ")" : ""} — ${w.fr}`,
      },
    };
  });
}

function toneQuestions(n = 10) {
  const pool = syllablePool();
  if (pool.length < 4) return [];
  const picks = [];
  while (picks.length < n) picks.push(...shuffle(pool));
  return picks.slice(0, n).map((s) => ({
    ref: `tone:${s.ch}`,
    q: { type: "listen", say: s.ch, q: "Quel ton entendez-vous ?", options: TONE_LABELS, answer: s.tone - 1, reveal: `${s.ch} ${s.syl}` },
  }));
}

/* ============================== Hub ================================ */
export function renderEntrainement(app) {
  const words = wordPool().length, syl = isZh() ? syllablePool().length : 0;
  const errors = Object.keys(state.errors).length;
  const srs = srsStats(Object.values(state.vocab));
  const vocab = Object.keys(state.vocab).length;

  // Carte du haut : la meilleure chose à faire maintenant
  const hero = errors ? { href: "revision", title: "Travaille tes points faibles", sub: `${Math.min(10, errors)} question${errors > 1 ? "s" : ""} ratée${errors > 1 ? "s" : ""} à corriger`, xp: Math.min(10, errors) * 10, icon: "🎯" }
    : srs.todo ? { href: "reviser", title: "Révision du jour", sub: `${srs.todo} mot${srs.todo > 1 ? "s" : ""} à revoir en flashcards`, xp: srs.todo * 2, icon: "📅" }
    : words >= 4 ? { href: "ecoute", title: "Entraîne ton oreille", sub: "10 mots à reconnaître à l'écoute", xp: 50, icon: "🎧" }
    : { href: "parcours", title: "Commence ton parcours", sub: "Termine une leçon pour débloquer l'entraînement", xp: 0, icon: "🗺️" };

  const row = (href, title, icon, cls, { badge = 0, sub = "", ok = true } = {}) => `
    <a class="tr-row ${ok ? "" : "disabled"}" ${ok ? `href="#${href}"` : `aria-disabled="true"`}>
      <span class="tr-txt"><b>${title}</b>${sub ? `<small>${sub}</small>` : ""}</span>
      <span class="tr-ico ${cls}">${icon}</span>
      ${badge ? `<em class="tr-badge">${badge > 30 ? "30+" : badge}</em>` : ""}
    </a>`;

  app.innerHTML = `
  <section class="tr-hero">
    <div class="tr-hero-txt">
      <p class="tr-hero-kicker">${hero.title}</p>
      <p class="tr-hero-sub">${hero.sub}</p>
      <a class="tr-hero-btn" href="#${hero.href}">COMMENCER${hero.xp ? ` +${hero.xp} XP` : ""}</a>
    </div>
    <span class="tr-hero-ico" aria-hidden="true">${hero.icon}</span>
  </section>

  <h2 class="tr-h2">Exercices</h2>
  <div class="tr-list">
    ${row("ecoute", "Écoute", "🎧", "c-blue", { sub: "Reconnaître les mots à l'oral", ok: words >= 4 })}
    ${isZh() ? row("tons", "Les tons", "🎵", "c-green", { sub: "1er, 2e, 3e ou 4e ton ?", ok: syl >= 4 }) : ""}
    ${isZh() ? row("trace", "Tracé des caractères", "✍️", "c-purple", { sub: "L'ordre des traits, au doigt", ok: words >= 1 }) : ""}
  </div>

  <h2 class="tr-h2">Mes collections</h2>
  <div class="tr-list">
    ${row("erreurs", "Erreurs", "🔁", "c-orange", { badge: errors, sub: errors ? "Cahier des questions ratées" : "Aucune erreur en attente" })}
    ${row("reviser", "Mots", "🃏", "c-sky", { badge: srs.todo, sub: vocab ? `${vocab} mot${vocab > 1 ? "s" : ""} · flashcards et révision du jour` : "Votre carnet de vocabulaire" })}
    ${row("carnet", "Carnet", "📒", "c-yellow", { sub: "Tous vos mots, avec recherche" })}
  </div>`;
}

/* ======================= Écoute et tons (quiz) ===================== */
export function renderEcoute(app) { return practiceQuiz(app, { title: "Écoute", questions: listeningQuestions(), again: "ecoute" }); }
export function renderTons(app) { if (!isZh()) return false; return practiceQuiz(app, { title: "Les tons", questions: toneQuestions(), again: "tons" }); }

function practiceQuiz(app, { title, questions, again }) {
  if (!questions.length) return false;
  if (!state.settings.tts) toast("Le son est coupé dans votre profil : il est quand même joué pour cet exercice.");
  document.body.classList.add("focus-mode");
  runQuiz(app, {
    title, questions,
    onQuit: () => { document.body.classList.remove("focus-mode"); location.hash = "entrainement"; },
    onFinish: (results) => {
      document.body.classList.remove("focus-mode");
      const score = results.filter((r) => r.correct).length;
      const r = P.recordPractice({ label: title, score, total: results.length });
      const pct = Math.round(r.ratio * 100);
      app.innerHTML = `
      <section class="results ${pct >= 60 ? "ok" : "ko"}">
        ${ring(pct, 150, 12)}
        <h1>${pct === 100 ? "Sans faute ! 🎉" : pct >= 60 ? "Bien joué !" : "Continuez, ça viendra !"}</h1>
        <p class="lead">${score} / ${results.length} bonnes réponses</p>
        <div class="result-chips"><span class="chip">⚡ +${r.xpGained} XP</span></div>
        <div class="result-actions">
          <a class="btn primary big" href="#${again}" data-reload>Recommencer</a>
          <a class="btn ghost" href="#entrainement">Autres exercices</a>
        </div>
      </section>`;
      if (pct === 100) celebrate();
    },
  });
  return true;
}

/* ============================== Tracé ============================== */
let HW = null;
const loadWriter = () => (HW ||= import("https://cdn.jsdelivr.net/npm/hanzi-writer@3.5.0/+esm").then((m) => m.default || m.HanziWriter));

export function renderTrace(app, start) {
  if (!isZh()) return false;
  const words = wordPool();
  const chars = [];
  words.forEach((w) => [...w.zh].forEach((c) => { if (HAN.test(c) && !chars.some((x) => x.ch === c)) chars.push({ ch: c, w }); }));
  if (!chars.length) return false;
  let idx = Math.max(0, chars.findIndex((c) => c.ch === start));
  let writer = null, mode = "view";

  app.innerHTML = `
  <a class="back-link" href="#entrainement">← Entraînement</a>
  <section class="card trace-card">
    <div class="trace-head">
      <div><p class="eyebrow">Tracé des caractères</p><h1 class="trace-title"></h1><p class="trace-info muted"></p></div>
      <button class="speak" data-say aria-label="Écouter">🔊</button>
    </div>
    <div class="trace-box"><div class="trace-writer" aria-label="Zone de tracé"></div><p class="trace-msg" aria-live="polite"></p></div>
    <div class="btn-row trace-actions">
      <button class="btn ghost" data-anim>▶️ Voir l'ordre des traits</button>
      <button class="btn primary" data-quiz>✍️ À moi d'écrire</button>
      <button class="btn ghost" data-outline>👁️ Contour</button>
    </div>
    <div class="flash-nav"><button class="btn ghost" data-prev>← Précédent</button><span class="trace-pos"></span><button class="btn ghost" data-next>Suivant →</button></div>
    <details class="trace-list"><summary>Choisir un caractère (${chars.length})</summary>
      <div class="trace-chips">${chars.map((c, i) => `<button class="chip-btn zh" data-pick="${i}">${esc(c.ch)}</button>`).join("")}</div></details>
  </section>`;

  const $ = (s) => app.querySelector(s);
  const size = () => Math.min(300, $(".trace-box").clientWidth - 8);
  let outline = true;

  async function show() {
    const c = chars[idx];
    $(".trace-title").innerHTML = `<span class="zh">${esc(c.ch)}</span>`;
    $(".trace-info").textContent = `${c.w.zh}${c.w.py ? " · " + c.w.py : ""} — ${c.w.fr}`;
    $(".trace-pos").textContent = `${idx + 1} / ${chars.length}`;
    $(".trace-msg").textContent = "";
    mode = "view";
    const box = $(".trace-writer");
    box.innerHTML = `<p class="muted small">Chargement…</p>`;
    try {
      const HanziWriter = await loadWriter();
      if (chars[idx] !== c) return;
      box.innerHTML = "";
      const s = size();
      box.style.width = box.style.height = s + "px";
      writer = HanziWriter.create(box, c.ch, {
        width: s, height: s, padding: 10, showOutline: outline, strokeColor: "#1d2733",
        radicalColor: "#c23b32", outlineColor: "#e7e1d5", drawingColor: "#c23b32", highlightColor: "#e8b04b",
        strokeAnimationSpeed: 1, delayBetweenStrokes: 250, showCharacter: true,
        onLoadCharDataError: () => { box.innerHTML = `<p class="muted small">Tracé indisponible pour « ${esc(c.ch)} ».</p>`; writer = null; },
      });
    } catch {
      box.innerHTML = `<p class="muted small">Connexion nécessaire pour charger le tracé.</p>`; writer = null;
    }
  }

  $("[data-anim]").onclick = () => { if (!writer) return; mode = "view"; $(".trace-msg").textContent = ""; writer.showCharacter(); writer.animateCharacter(); };
  $("[data-quiz]").onclick = () => {
    if (!writer) return;
    mode = "quiz";
    $(".trace-msg").textContent = "Tracez les traits dans l'ordre. Après 3 erreurs sur un trait, un indice apparaît.";
    writer.quiz({
      showHintAfterMisses: 3,
      onComplete: ({ totalMistakes }) => {
        const ok = totalMistakes <= 2;
        $(".trace-msg").textContent = ok ? `✓ Bravo ! ${totalMistakes ? totalMistakes + " petite(s) erreur(s)." : "Parfait, sans erreur."} +5 XP` : `Terminé avec ${totalMistakes} erreurs. Réessayez pour gagner des XP.`;
        if (ok) P.recordPractice({ label: `Tracé ${chars[idx].ch}`, score: 1, total: 0 });
        speak(chars[idx].ch);
      },
    });
  };
  $("[data-outline]").onclick = () => { outline = !outline; if (writer) outline ? writer.showOutline() : writer.hideOutline(); };
  $("[data-say]").onclick = () => speak(chars[idx].ch);
  $("[data-prev]").onclick = () => { idx = (idx - 1 + chars.length) % chars.length; show(); };
  $("[data-next]").onclick = () => { idx = (idx + 1) % chars.length; show(); };
  app.querySelectorAll("[data-pick]").forEach((b) => (b.onclick = () => { idx = +b.dataset.pick; $(".trace-list").open = false; show(); }));
  show();
  return true;
}
