/* =====================================================================
   Vue « Parcours » — carte des paliers A1 → C2 (accueil)
   ===================================================================== */

import { LEVELS, MODULES, lvlLabel, lvlBadge } from "../data/curriculum.js";
import { srsStats } from "../core/srs.js";
const srsTodo = () => srsStats(Object.values(state.vocab)).todo;
import { state } from "../core/storage.js";
import * as P from "../core/progress.js";
import { esc } from "../core/ui.js";
import { pyText } from "../core/pinyin.js";
import { L } from "../core/lang.js";

// Décalage horizontal des nœuds pour dessiner un chemin sinueux
const OFFSETS = [0, 56, 84, 56, 0, -56, -84, -56];

export function renderParcours(app) {
  bindPops();
  const g = P.globalProgress();
  const next = P.nextStep();
  const pseudo = esc(state.profile?.pseudo || "");

  app.innerHTML = `
    <section class="hero">
      <div>
        <p class="eyebrow">${L.hello} ${pseudo} 👋</p>
        <h1>Votre route vers<br><em>${L.heroEm}</em></h1>
        <p class="muted">${g.done} étapes sur ${g.total} validées · niveau actuel <b>${lvlLabel(P.currentLevel())}</b></p>
        ${next
          ? `<a class="btn primary big" href="#${P.stepHref(next)}">
               ${next.kind === "lesson" ? `Continuer : ${pyText(next.lesson.levelId, next.lesson.title)}` : next.kind === "checkpoint" ? `Test de mi-palier ${lvlLabel(next.level)}` : `Passer l'examen ${lvlLabel(next.level)}`} →</a>`
          : `<p class="badge-done">🏆 Parcours terminé — ${L.done}</p>`}
        <div class="hero-links">${srsTodo() ? `<a class="btn ghost small" href="#reviser">📅 ${srsTodo()} mot${srsTodo() > 1 ? "s" : ""} à réviser</a>` : ""}
          <a class="btn ghost small" href="#entrainement">🎯 Entraînement</a>
          <a class="btn ghost small" href="#blanc-${P.currentLevel().id}">📝 Examen blanc ${lvlLabel(P.currentLevel())}</a></div>
      </div>
      <div class="hero-meter" aria-label="Progression globale ${g.pct} %">
        <div class="meter-track"><span style="width:${g.pct}%"></span></div>
        <div class="meter-labels">${LEVELS.map((l, i) => `<span class="${P.isLevelUnlocked(i) ? "on" : ""}">${lvlLabel(l)}</span>`).join("")}</div>
      </div>
    </section>

    <div class="path">
      ${LEVELS.map((lvl, li) => levelBlock(lvl, li)).join("")}
    </div>`;
}

function levelBlock(lvl, li) {
  const unlocked = P.isLevelUnlocked(li);
  const prog = P.levelProgress(li);
  const examOpen = P.isExamUnlocked(li);
  const examDone = P.isExamPassed(lvl.id);
  const examOffset = OFFSETS[lvl.lessons.length % OFFSETS.length];

  return `
  <section class="level ${unlocked ? "" : "locked"}" style="--lvl:${lvl.color}" id="palier-${lvl.id}">
    <header class="level-head">
      <div class="level-badge">${lvlBadge(lvl)}</div>
      <div class="level-info">
        <p class="eyebrow">${lvl.emoji} Palier ${lvlLabel(lvl)} · ${lvl.name}${lvl.hsk && !lvl.label ? ` · repère ${lvl.hsk}` : ""}</p>
        <h2>${pyText(lvl.id, lvl.title)}</h2>
        <p class="muted small">${pyText(lvl.id, lvl.desc)}</p>
      </div>
      <div class="level-prog">
        ${unlocked ? `<span>${prog.pct}%</span><div class="mini-bar"><i style="width:${prog.pct}%"></i></div>` : `<span class="lock">🔒</span>`}
      </div>
    </header>
    ${unlocked ? "" : `<p class="level-locked-msg">Réussissez l'examen ${lvlLabel(LEVELS[li - 1])} pour débloquer ce palier.</p>`}
    <ol class="nodes">
      ${lvl.lessons.map((lesson, i) => (i === P.checkpointIndex(lvl) ? checkpointNode(lvl, li, unlocked) : "") + node(lesson, OFFSETS[i % OFFSETS.length])).join("")}
      <li class="node-wrap" style="--x:${examOffset}px">
        <a class="node exam ${examDone ? "done" : examOpen ? "open" : "locked"}"
           ${examOpen ? `href="#examen-${lvl.id}"` : `aria-disabled="true"`}
           ${examOpen ? popData({ title: `Examen ${lvlLabel(lvl)}`, sub: `${lvl.exam.length} questions · sans faute requis`, note: examDone ? `Validé avec ${state.exams[lvl.id].best}/${state.exams[lvl.id].total}` : "Entraînez-vous d'abord avec un examen blanc", cta: examDone ? "Repasser l'examen" : "Passer l'examen", href: `#examen-${lvl.id}`, alt: "Examen blanc", altHref: `#blanc-${lvl.id}` }) : ""}
           aria-label="Examen de fin de palier ${lvlLabel(lvl)}${examDone ? ", validé" : examOpen ? "" : ", verrouillé"}">
          <span class="node-icon">${examDone ? "🏆" : examOpen ? "🎓" : "🔒"}</span>
        </a>
        <span class="node-label"><b>Examen ${lvlLabel(lvl)}</b><small>${examDone ? `Validé · ${state.exams[lvl.id].best}/${state.exams[lvl.id].total}` : "Sans faute (100 %) requis"}</small>
          ${unlocked ? `<a class="blanc-link" href="#blanc-${lvl.id}">📝 Examen blanc${state.blanc?.[lvl.id] ? ` · ${state.blanc[lvl.id].best}/${state.blanc[lvl.id].total}` : ""}</a>` : ""}</span>
      </li>
    </ol>
  </section>`;
}

function checkpointNode(lvl, li, unlocked) {
  const done = P.isCheckpointPassed(lvl), open = P.isCheckpointUnlocked(li), rec = state.checkpoints?.[lvl.id];
  return `<li class="node-wrap cp-wrap">
    <a class="node checkpoint ${done ? "done" : open ? "open" : "locked"}" ${open ? `href="#mipalier-${lvl.id}"` : `aria-disabled="true"`}
       ${open ? popData({ title: `Test de mi-palier ${lvlLabel(lvl)}`, sub: `${P.CHECKPOINT_N} questions sur la 1re moitié du palier · 9/10 requis`, note: done && rec ? `Validé avec ${rec.best}/${rec.total}` : "", cta: done ? "Refaire le test" : "Commencer le test", href: `#mipalier-${lvl.id}` }) : ""}
       aria-label="Test de mi-palier ${lvlLabel(lvl)}${done ? ", validé" : open ? "" : ", verrouillé"}">
      <span class="node-icon">${done ? "✅" : open ? "🛡️" : "🔒"}</span></a>
    <span class="node-label"><b>Test de mi-palier</b><small>${done ? (rec ? `Validé · ${rec.best}/${rec.total}` : "Validé") : `${P.CHECKPOINT_N} questions · 90 % requis`}</small></span>
  </li>`;
}

/** Attributs data-* décrivant la bulle « Commencer » d'un nœud */
function popData(o) {
  return Object.entries(o).filter(([, v]) => v != null && v !== "").map(([k, v]) => `data-pop-${k}="${esc(v)}"`).join(" ");
}

/* --------- Bulle d'un nœud : un clic l'ouvre, le bouton lance le cours --------- */
function closePop() { document.querySelectorAll(".node-pop").forEach((x) => x.remove()); document.querySelectorAll(".node.popped").forEach((x) => x.classList.remove("popped")); }
function openPop(nodeEl) {
  const d = nodeEl.dataset, wrap = nodeEl.closest(".node-wrap");
  closePop();
  nodeEl.classList.add("popped");
  const title = d.popLv ? pyText(d.popLv, d.popTitle) : esc(d.popTitle);
  wrap.insertAdjacentHTML("beforeend", `<div class="node-pop ${nodeEl.classList.contains("perfect") ? "perfect" : nodeEl.classList.contains("done") ? "done" : ""}" role="dialog">
    <b class="np-title">${title}</b>
    ${d.popSub ? `<small class="np-sub">${esc(d.popSub)}</small>` : ""}
    ${d.popNote ? `<small class="np-note">${esc(d.popNote)}</small>` : ""}
    <a class="np-cta" href="${esc(d.popHref)}">${esc(d.popCta)}</a>
    ${d.popAlt ? `<a class="np-alt" href="${esc(d.popAltHref)}">${esc(d.popAlt)}</a>` : ""}
  </div>`);
  const pop = wrap.querySelector(".node-pop");
  requestAnimationFrame(() => pop.classList.add("in"));
  pop.querySelector(".np-cta").focus({ preventScroll: true });
  const r = pop.getBoundingClientRect();
  if (r.bottom > innerHeight - 80) scrollBy({ top: r.bottom - innerHeight + 100, behavior: "smooth" });
}
let popBound = false;
function bindPops() {
  if (popBound) return; popBound = true;
  document.addEventListener("click", (e) => {
    const n = e.target.closest(".nodes a.node[data-pop-href]");
    if (n) {
      e.preventDefault(); e.stopPropagation();
      if (n.classList.contains("popped")) closePop(); else openPop(n);
      return;
    }
    if (!e.target.closest(".node-pop")) closePop();
  }, true);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closePop(); });
  window.addEventListener("hashchange", closePop);
}

function node(lesson, x) {
  const done = P.isLessonDone(lesson.id);
  const open = P.isLessonUnlocked(lesson);
  const rec = state.lessons[lesson.id];
  const stars = rec ? P.starsFor(rec.best / rec.total) : 0;
  const mod = MODULES[lesson.module];
  const isCurrent = open && !done;

  const perfect = done && stars === 3;
  const lvl = LEVELS[lesson.levelIndex];
  const pop = open ? popData({
    title: lesson.title, lv: lesson.levelId,
    sub: done ? `${"★".repeat(stars)}${"☆".repeat(3 - stars)} · meilleur score ${rec.best}/${rec.total}` : `Leçon ${lesson.index + 1}/${lvl.lessons.length} · ${mod.icon} ${mod.label}`,
    note: done && !perfect ? "Refaites le quiz sans faute pour obtenir les 3 étoiles 👑" : perfect ? "Leçon maîtrisée à la perfection 👑" : "",
    cta: done ? "Revoir la leçon" : "Commencer", href: `#lecon-${lesson.id}`,
    alt: done ? (perfect ? "Refaire le quiz" : "Viser les 3 étoiles") : "", altHref: `#quiz-${lesson.id}`,
  }) : "";
  return `
  <li class="node-wrap" style="--x:${x}px">
    <a class="node ${done ? "done" : open ? "open" : "locked"} ${perfect ? "perfect" : ""} ${isCurrent ? "current" : ""}"
       ${open ? `href="#lecon-${lesson.id}"` : `aria-disabled="true"`} ${pop}
       aria-label="${esc(lesson.title)}${perfect ? ", 3 étoiles" : done ? ", terminée" : open ? "" : ", verrouillée"}">
      <span class="node-icon">${open ? lesson.emoji : "🔒"}</span>
      ${perfect ? `<span class="node-crown" aria-hidden="true">👑</span>` : ""}
      ${isCurrent ? `<span class="node-start">Commencer</span>` : ""}
    </a>
    <span class="node-label">
      <b>${pyText(lesson.levelId, lesson.title)}</b>
      <small>${mod.icon} ${mod.label}${done ? ` · ${"★".repeat(stars)}${"☆".repeat(3 - stars)}` : ""}</small>
    </span>
  </li>`;
}
