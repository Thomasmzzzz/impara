/* =====================================================================
   Vue « Parcours » — carte des paliers A1 → C2 (accueil)
   ===================================================================== */

import { LEVELS, MODULES, lvlLabel, lvlBadge } from "../data/curriculum.js";
import { srsStats } from "../core/srs.js";
const srsTodo = () => srsStats(Object.values(state.vocab)).todo;
import { state } from "../core/storage.js";
import * as P from "../core/progress.js";
import { esc } from "../core/ui.js";
import { pyText } from "../core/pinyin.js";
import { L } from "../core/lang.js";

// Décalage horizontal des nœuds pour dessiner un chemin sinueux
const OFFSETS = [0, 56, 84, 56, 0, -56, -84, -56];

export function renderParcours(app) {
  const g = P.globalProgress();
  const next = P.nextStep();
  const pseudo = esc(state.profile?.pseudo || "");

  app.innerHTML = `
    <section class="hero">
      <div>
        <p class="eyebrow">${L.hello} ${pseudo} 👋</p>
        <h1>Votre route vers<br><em>${L.heroEm}</em></h1>
        <p class="muted">${g.done} étapes sur ${g.total} validées · niveau actuel <b>${lvlLabel(P.currentLevel())}</b></p>
        ${next
          ? `<a class="btn primary big" href="#${P.stepHref(next)}">
               ${next.kind === "lesson" ? `Continuer : ${pyText(next.lesson.levelId, next.lesson.title)}` : next.kind === "checkpoint" ? `Test de mi-palier ${lvlLabel(next.level)}` : `Passer l'examen ${lvlLabel(next.level)}`} →</a>`
          : `<p class="badge-done">🏆 Parcours terminé — ${L.done}</p>`}
        <div class="hero-links">${srsTodo() ? `<a class="btn ghost small" href="#reviser">📅 ${srsTodo()} mot${srsTodo() > 1 ? "s" : ""} à réviser</a>` : ""}
          <a class="btn ghost small" href="#entrainement">🎯 Entraînement</a>
          <a class="btn ghost small" href="#blanc-${P.currentLevel().id}">📝 Examen blanc ${lvlLabel(P.currentLevel())}</a></div>
      </div>
      <div class="hero-meter" aria-label="Progression globale ${g.pct} %">
        <div class="meter-track"><span style="width:${g.pct}%"></span></div>
        <div class="meter-labels">${LEVELS.map((l, i) => `<span class="${P.isLevelUnlocked(i) ? "on" : ""}">${lvlLabel(l)}</span>`).join("")}</div>
      </div>
    </section>

    <div class="path">
      ${LEVELS.map((lvl, li) => levelBlock(lvl, li)).join("")}
    </div>`;
}

function levelBlock(lvl, li) {
  const unlocked = P.isLevelUnlocked(li);
  const prog = P.levelProgress(li);
  const examOpen = P.isExamUnlocked(li);
  const examDone = P.isExamPassed(lvl.id);
  const examOffset = OFFSETS[lvl.lessons.length % OFFSETS.length];

  return `
  <section class="level ${unlocked ? "" : "locked"}" style="--lvl:${lvl.color}" id="palier-${lvl.id}">
    <header class="level-head">
      <div class="level-badge">${lvlBadge(lvl)}</div>
      <div class="level-info">
        <p class="eyebrow">${lvl.emoji} Palier ${lvlLabel(lvl)} · ${lvl.name}${lvl.hsk && !lvl.label ? ` · repère ${lvl.hsk}` : ""}</p>
        <h2>${pyText(lvl.id, lvl.title)}</h2>
        <p class="muted small">${pyText(lvl.id, lvl.desc)}</p>
      </div>
      <div class="level-prog">
        ${unlocked ? `<span>${prog.pct}%</span><div class="mini-bar"><i style="width:${prog.pct}%"></i></div>` : `<span class="lock">🔒</span>`}
      </div>
    </header>
    ${unlocked ? "" : `<p class="level-locked-msg">Réussissez l'examen ${lvlLabel(LEVELS[li - 1])} pour débloquer ce palier.</p>`}
    <ol class="nodes">
      ${lvl.lessons.map((lesson, i) => (i === P.checkpointIndex(lvl) ? checkpointNode(lvl, li, unlocked) : "") + node(lesson, OFFSETS[i % OFFSETS.length])).join("")}
      <li class="node-wrap" style="--x:${examOffset}px">
        <a class="node exam ${examDone ? "done" : examOpen ? "open" : "locked"}"
           ${examOpen ? `href="#examen-${lvl.id}"` : `aria-disabled="true"`}
           aria-label="Examen de fin de palier ${lvlLabel(lvl)}${examDone ? ", validé" : examOpen ? "" : ", verrouillé"}">
          <span class="node-icon">${examDone ? "🏆" : examOpen ? "🎓" : "🔒"}</span>
        </a>
        <span class="node-label"><b>Examen ${lvlLabel(lvl)}</b><small>${examDone ? `Validé · ${state.exams[lvl.id].best}/${state.exams[lvl.id].total}` : "Sans faute (100 %) requis"}</small>
          ${unlocked ? `<a class="blanc-link" href="#blanc-${lvl.id}">📝 Examen blanc${state.blanc?.[lvl.id] ? ` · ${state.blanc[lvl.id].best}/${state.blanc[lvl.id].total}` : ""}</a>` : ""}</span>
      </li>
    </ol>
  </section>`;
}

function checkpointNode(lvl, li, unlocked) {
  const done = P.isCheckpointPassed(lvl), open = P.isCheckpointUnlocked(li), rec = state.checkpoints?.[lvl.id];
  return `<li class="node-wrap cp-wrap">
    <a class="node checkpoint ${done ? "done" : open ? "open" : "locked"}" ${open ? `href="#mipalier-${lvl.id}"` : `aria-disabled="true"`}
       aria-label="Test de mi-palier ${lvlLabel(lvl)}${done ? ", validé" : open ? "" : ", verrouillé"}">
      <span class="node-icon">${done ? "✅" : open ? "🛡️" : "🔒"}</span></a>
    <span class="node-label"><b>Test de mi-palier</b><small>${done ? (rec ? `Validé · ${rec.best}/${rec.total}` : "Validé") : `${P.CHECKPOINT_N} questions · 90 % requis`}</small></span>
  </li>`;
}

function node(lesson, x) {
  const done = P.isLessonDone(lesson.id);
  const open = P.isLessonUnlocked(lesson);
  const rec = state.lessons[lesson.id];
  const stars = rec ? P.starsFor(rec.best / rec.total) : 0;
  const mod = MODULES[lesson.module];
  const isCurrent = open && !done;

  return `
  <li class="node-wrap" style="--x:${x}px">
    <a class="node ${done ? "done" : open ? "open" : "locked"} ${isCurrent ? "current" : ""}"
       ${open ? `href="#lecon-${lesson.id}"` : `aria-disabled="true"`}
       aria-label="${esc(lesson.title)}${done ? ", terminée" : open ? "" : ", verrouillée"}">
      <span class="node-icon">${open ? lesson.emoji : "🔒"}</span>
      ${isCurrent ? `<span class="node-start">Commencer</span>` : ""}
    </a>
    <span class="node-label">
      <b>${pyText(lesson.levelId, lesson.title)}</b>
      <small>${mod.icon} ${mod.label}${done ? ` · ${"★".repeat(stars)}${"☆".repeat(3 - stars)}` : ""}</small>
    </span>
  </li>`;
}
