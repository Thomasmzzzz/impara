/* =====================================================================
   Vue « Parcours » — carte des paliers A1 → C2 (accueil)
   ===================================================================== */

import { LEVELS, MODULES, lvlLabel, lvlBadge } from "../data/curriculum.js";
import { srsStats } from "../core/srs.js";
const srsTodo = () => srsStats(Object.values(state.vocab)).todo;
import { state } from "../core/storage.js";
import * as P from "../core/progress.js";
import { esc } from "../core/ui.js";
import { pyText } from "../core/pinyin.js";
import { L, code } from "../core/lang.js";
import { mascot, mascotName, line } from "../core/mascot.js";

/* Décor de chaque palier : une ville ou un paysage du pays */
const SCENES = {
  it: {
    A1: ["Roma", "🏛️", ["#ffd9a8", "#fff1db"], "#c8794a"], A2: ["Venezia", "🛶", ["#bfe3f2", "#eef8fb"], "#4f97b3"],
    B1: ["Firenze", "⛪", ["#ffd2b5", "#fff0e4"], "#b8673c"], B2: ["Milano", "🏙️", ["#d6dcf5", "#f3f5fc"], "#6f79a8"],
    C1: ["Napoli", "🌋", ["#ffc9c0", "#ffeeea"], "#a4504a"], C2: ["Sicilia", "🏝️", ["#b8ecdf", "#ecfbf6"], "#3c9a83"],
  },
  zh: {
    A1: ["北京 Pékin", "🏯", ["#ffd0c7", "#fff0ec"], "#b8453a"], A2: ["上海 Shanghai", "🌆", ["#d9d2f7", "#f4f1fd"], "#6c5bb3"],
    B1: ["长城 La Grande Muraille", "⛰️", ["#cfe8c8", "#f0f9ee"], "#5c8f4f"], B2: ["西安 Xi'an", "🏮", ["#ffd8a6", "#fff3e0"], "#b9772d"],
    C1: ["桂林 Guilin", "🏞️", ["#bfe6e0", "#ecf8f6"], "#3f8f84"], C2: ["香港 Hong Kong", "🌃", ["#c9d3ec", "#eef1f9"], "#4a5b8f"],
  },
};
function scene(lvl) {
  const sc = SCENES[code]?.[lvl.id];
  if (!sc) return "";
  const [place, icon, [sky1, sky2], ground] = sc;
  return `<div class="level-scene" style="--sky1:${sky1};--sky2:${sky2};--ground:${ground}" aria-hidden="true">
    <span class="sc-cloud c1">☁️</span><span class="sc-cloud c2">☁️</span>
    <svg class="sc-hills" viewBox="0 0 400 60" preserveAspectRatio="none"><path d="M0,42 C60,18 110,22 160,36 C210,50 250,20 310,26 C350,30 380,40 400,34 L400,60 L0,60 Z" fill="var(--ground)" opacity=".35"/>
      <path d="M0,52 C70,38 120,46 190,50 C260,54 320,38 400,46 L400,60 L0,60 Z" fill="var(--ground)" opacity=".6"/></svg>
    <span class="sc-icon">${icon}</span>
    <span class="sc-place">📍 ${place}</span>
  </div>`;
}

// Décalage horizontal des nœuds pour dessiner un chemin sinueux
const OFFSETS = [0, 56, 84, 56, 0, -56, -84, -56];

export function renderParcours(app) {
  bindPops();
  const g = P.globalProgress();
  const next = P.nextStep();
  const pseudo = esc(state.profile?.pseudo || "");

  app.innerHTML = `
    <section class="hero">
      <div class="hero-main">
        <button class="hero-mascot" type="button" aria-label="${mascotName()}">${mascot("idle", { size: 86 })}<span class="m-bubble">${esc(line(P.streakCount() ? "welcome" : "welcome"))}</span></button>
        <p class="eyebrow">${L.hello} ${pseudo} 👋</p>
        ${next
          ? `<a class="btn primary big" href="#${P.stepHref(next)}">
               ${next.kind === "lesson" ? `Continuer : ${pyText(next.lesson.levelId, next.lesson.title)}` : next.kind === "checkpoint" ? `Test de mi-palier ${lvlLabel(next.level)}` : `Passer l'examen ${lvlLabel(next.level)}`} →</a>`
          : `<p class="badge-done">🏆 Parcours terminé — ${L.done}</p>`}
        ${srsTodo() ? `<div class="hero-links"><a class="btn ghost small" href="#reviser">📅 ${srsTodo()} mot${srsTodo() > 1 ? "s" : ""} à réviser</a></div>` : ""}
      </div>
      <div class="hero-meter" aria-label="Progression globale ${g.pct} %">
        <div class="meter-track"><span style="width:${g.pct}%"></span></div>
        <div class="meter-labels">${LEVELS.map((l, i) => `<span class="${P.isLevelUnlocked(i) ? "on" : ""}">${lvlLabel(l)}</span>`).join("")}</div>
      </div>
    </section>

    <div class="path">
      ${LEVELS.map((lvl, li) => levelBlock(lvl, li)).join("")}
    </div>`;
  drawPaths(app);
  // La mascotte réagit quand on la touche
  const mb = app.querySelector(".hero-mascot");
  mb?.addEventListener("click", () => {
    mb.innerHTML = `${mascot(Math.random() < .5 ? "cheer" : "happy", { size: 86 })}<span class="m-bubble">${esc(line(Math.random() < .5 ? "good" : "welcome"))}</span>`;
    mb.classList.remove("hop"); void mb.offsetWidth; mb.classList.add("hop");
  });
  const redraw = () => drawPaths(app);
  addEventListener("resize", redraw);
  document.fonts?.ready.then(redraw);
  app._cleanup = () => removeEventListener("resize", redraw);
}

/* ----------- Chemin dessiné entre les nœuds (coloré quand c'est fait) ----------- */
function drawPaths(app) {
  app.querySelectorAll("ol.nodes").forEach((ol) => {
    ol.querySelector(":scope > svg.trail")?.remove();
    const nodes = [...ol.querySelectorAll(":scope > .node-wrap > .node")];
    if (nodes.length < 2) return;
    const box = ol.getBoundingClientRect();
    if (!box.width) return;
    const pts = nodes.map((n) => { const r = n.getBoundingClientRect(); return { x: r.left - box.left + r.width / 2, y: r.top - box.top + r.height / 2, done: n.classList.contains("done") }; });
    let segs = "";
    for (let k = 0; k < pts.length - 1; k++) {
      const a = pts[k], b = pts[k + 1], dy = b.y - a.y;
      const d = `M${a.x.toFixed(1)},${a.y.toFixed(1)} C${a.x.toFixed(1)},${(a.y + dy * .55).toFixed(1)} ${b.x.toFixed(1)},${(b.y - dy * .55).toFixed(1)} ${b.x.toFixed(1)},${b.y.toFixed(1)}`;
      const lit = a.done && (b.done || !nodes[k + 1].classList.contains("locked"));
      segs += `<path class="${lit ? "lit" : "dim"}" d="${d}"/>`;
    }
    ol.insertAdjacentHTML("afterbegin", `<svg class="trail" aria-hidden="true" width="${box.width}" height="${box.height}" viewBox="0 0 ${box.width.toFixed(1)} ${box.height.toFixed(1)}">${segs}</svg>`);
  });
}

function levelBlock(lvl, li) {
  const unlocked = P.isLevelUnlocked(li);
  const prog = P.levelProgress(li);
  const examOpen = P.isExamUnlocked(li);
  const examDone = P.isExamPassed(lvl.id);
  const examOffset = OFFSETS[lvl.lessons.length % OFFSETS.length];

  return `
  <section class="level ${unlocked ? "" : "locked"}" style="--lvl:${lvl.color}" id="palier-${lvl.id}">
    ${scene(lvl)}
    <header class="level-head">
      <div class="level-badge">${lvlBadge(lvl)}</div>
      <div class="level-info">
        <p class="eyebrow">${lvl.emoji} Palier ${lvlLabel(lvl)} · ${lvl.name}${lvl.hsk && !lvl.label ? ` · repère ${lvl.hsk}` : ""}</p>
        <h2>${pyText(lvl.id, lvl.title)}</h2>
        <p class="muted small">${pyText(lvl.id, lvl.desc)}</p>
      </div>
      <div class="level-prog">
        ${unlocked ? `<span>${prog.pct}%</span><div class="mini-bar"><i style="width:${prog.pct}%"></i></div>` : `<span class="lock">🔒</span>`}
      </div>
    </header>
    ${unlocked ? "" : `<p class="level-locked-msg">Réussissez l'examen ${lvlLabel(LEVELS[li - 1])} pour débloquer ce palier.</p>`}
    <ol class="nodes">
      ${lvl.lessons.map((lesson, i) => (i === P.checkpointIndex(lvl) ? checkpointNode(lvl, li, unlocked) : "") + node(lesson, OFFSETS[i % OFFSETS.length])).join("")}
      <li class="node-wrap" style="--x:${examOffset}px">
        <a class="node exam ${examDone ? "done" : examOpen ? "open" : "locked"}"
           ${examOpen ? `href="#examen-${lvl.id}"` : `aria-disabled="true"`}
           ${examOpen ? popData({ title: `Examen ${lvlLabel(lvl)}`, sub: `${lvl.exam.length} questions · sans faute requis`, note: examDone ? `Validé avec ${state.exams[lvl.id].best}/${state.exams[lvl.id].total}` : "Entraînez-vous d'abord avec un examen blanc", cta: examDone ? "Repasser l'examen" : "Passer l'examen", href: `#examen-${lvl.id}`, alt: "Examen blanc", altHref: `#blanc-${lvl.id}` })
             : popData({ title: `Examen ${lvlLabel(lvl)}`, locked: "1", sub: `${lvl.exam.length} questions · sans faute (100 %) requis`, note: "🔒 Terminez toutes les leçons du palier pour passer l'examen.", alt: unlocked ? "S'entraîner avec un examen blanc" : "", altHref: `#blanc-${lvl.id}` })}
           aria-label="Examen de fin de palier ${lvlLabel(lvl)}${examDone ? ", validé" : examOpen ? "" : ", verrouillé"}">
          <span class="node-icon">${examDone ? "🏆" : examOpen ? "🎓" : "🔒"}</span>
        </a>
        ${unlocked ? `<a class="blanc-link" href="#blanc-${lvl.id}">📝 Examen blanc${state.blanc?.[lvl.id] ? ` · ${state.blanc[lvl.id].best}/${state.blanc[lvl.id].total}` : ""}</a>` : ""}
      </li>
    </ol>
  </section>`;
}

function checkpointNode(lvl, li, unlocked) {
  const done = P.isCheckpointPassed(lvl), open = P.isCheckpointUnlocked(li), rec = state.checkpoints?.[lvl.id];
  return `<li class="node-wrap cp-wrap">
    <a class="node checkpoint ${done ? "done" : open ? "open" : "locked"}" ${open ? `href="#mipalier-${lvl.id}"` : `aria-disabled="true"`}
       ${open ? popData({ title: `Test de mi-palier ${lvlLabel(lvl)}`, sub: `${P.CHECKPOINT_N} questions sur la 1re moitié du palier · 9/10 requis`, note: done && rec ? `Validé avec ${rec.best}/${rec.total}` : "", cta: done ? "Refaire le test" : "Commencer le test", href: `#mipalier-${lvl.id}` })
         : popData({ title: `Test de mi-palier ${lvlLabel(lvl)}`, locked: "1", sub: `${P.CHECKPOINT_N} questions · 90 % requis`, note: "🔒 Terminez d'abord les leçons de la 1re moitié du palier." })}
       aria-label="Test de mi-palier ${lvlLabel(lvl)}${done ? ", validé" : open ? "" : ", verrouillé"}">
      <span class="node-icon">${done ? "✅" : open ? "🛡️" : "🔒"}</span></a>
  </li>`;
}

/** Attributs data-* décrivant la bulle « Commencer » d'un nœud */
function popData(o) {
  return Object.entries(o).filter(([, v]) => v != null && v !== "").map(([k, v]) => `data-pop-${k}="${esc(v)}"`).join(" ");
}

/* --------- Bulle d'un nœud : un clic l'ouvre, le bouton lance le cours --------- */
function closePop() {
  document.querySelectorAll(".node-pop").forEach((x) => { x.closest(".node-wrap")?.classList.remove("has-pop"); x.remove(); });
  document.querySelectorAll(".node.popped").forEach((x) => x.classList.remove("popped"));
}
function openPop(nodeEl) {
  const d = nodeEl.dataset, wrap = nodeEl.closest(".node-wrap");
  closePop();
  nodeEl.classList.add("popped");
  wrap.classList.add("has-pop"); // la bulle passe au-dessus des nœuds suivants
  const title = d.popLv ? pyText(d.popLv, d.popTitle) : esc(d.popTitle);
  wrap.insertAdjacentHTML("beforeend", `<div class="node-pop ${d.popLocked ? "locked" : nodeEl.classList.contains("perfect") ? "perfect" : nodeEl.classList.contains("done") ? "done" : ""}" role="dialog">
    <b class="np-title">${title}</b>
    ${d.popSub ? `<small class="np-sub">${esc(d.popSub)}</small>` : ""}
    ${d.popNote ? `<small class="np-note">${esc(d.popNote)}</small>` : ""}
    ${d.popCta ? `<a class="np-cta" href="${esc(d.popHref)}">${esc(d.popCta)}</a>` : `<span class="np-cta np-locked">🔒 Verrouillé</span>`}
    ${d.popAlt ? `<a class="np-alt" href="${esc(d.popAlthref)}">${esc(d.popAlt)}</a>` : ""}
  </div>`);
  const pop = wrap.querySelector(".node-pop");
  requestAnimationFrame(() => pop.classList.add("in"));
  pop.querySelector("a.np-cta, a.np-alt")?.focus({ preventScroll: true });
  const r = pop.getBoundingClientRect();
  if (r.bottom > innerHeight - 80) scrollBy({ top: r.bottom - innerHeight + 100, behavior: "smooth" });
}
let popBound = false;
function bindPops() {
  if (popBound) return; popBound = true;
  document.addEventListener("click", (e) => {
    const n = e.target.closest(".nodes a.node[data-pop-title]");
    if (n) {
      e.preventDefault(); e.stopPropagation();
      if (n.classList.contains("popped")) closePop(); else openPop(n);
      return;
    }
    if (!e.target.closest(".node-pop")) closePop();
  }, true);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closePop(); });
  window.addEventListener("hashchange", closePop);
}

function node(lesson, x) {
  const done = P.isLessonDone(lesson.id);
  const open = P.isLessonUnlocked(lesson);
  const rec = state.lessons[lesson.id];
  const stars = P.lessonStars(rec);
  const mod = MODULES[lesson.module];
  const isCurrent = open && !done;

  const perfect = done && stars === 3;
  const lvl = LEVELS[lesson.levelIndex];
  const pop = !open ? popData({
    title: lesson.title, lv: lesson.levelId, locked: "1",
    sub: `Leçon ${lesson.index + 1}/${lvl.lessons.length} · ${mod.icon} ${mod.label}`,
    note: "🔒 Terminez les étapes précédentes pour débloquer cette leçon.",
  }) : popData({
    title: lesson.title, lv: lesson.levelId,
    sub: done ? `${"★".repeat(stars)}${"☆".repeat(3 - stars)} · meilleur score ${rec.best}/${rec.total}` : `Leçon ${lesson.index + 1}/${lvl.lessons.length} · ${mod.icon} ${mod.label}`,
    note: done && !perfect ? "Refaites le quiz sans faute pour obtenir les 3 étoiles 👑" : perfect ? "Leçon maîtrisée à la perfection 👑" : "",
    cta: done ? "Revoir la leçon" : "Commencer", href: `#lecon-${lesson.id}`,
    alt: done ? (perfect ? "Refaire le quiz" : "Viser les 3 étoiles") : "", altHref: `#quiz-${lesson.id}`,
  });
  return `
  <li class="node-wrap" style="--x:${x}px">
    <a class="node ${done ? "done" : open ? "open" : "locked"} ${perfect ? "perfect" : ""} ${isCurrent ? "current" : ""}"
       ${open ? `href="#lecon-${lesson.id}"` : `aria-disabled="true"`} ${pop}
       aria-label="${esc(lesson.title)}${perfect ? ", 3 étoiles" : done ? ", terminée" : open ? "" : ", verrouillée"}">
      <span class="node-icon">${open ? lesson.emoji : "🔒"}</span>
      ${perfect ? `<span class="node-crown" aria-hidden="true">👑</span>` : ""}
      ${isCurrent ? `<span class="node-start">Commencer</span>` : ""}
    </a>
    ${done ? `<span class="node-stars" aria-hidden="true">${"★".repeat(stars)}${"☆".repeat(3 - stars)}</span>` : ""}
  </li>`;
}
