/* =====================================================================
   Vue « Profil » + écran d'accueil (onboarding)
   ===================================================================== */

import { state, commit, replaceState, exportState, defaultState, isPersistent } from "../core/storage.js";
import { esc, AVATARS, toast, modal, speak, VOICE_SPEEDS } from "../core/ui.js";
import { L, LANGS, code, flagSVG, setLang } from "../core/lang.js";
import { isConfigured, cloudInfo } from "../core/cloud.js";
import * as PWA from "../core/pwa.js";

const GOALS = [[20, "Détente"], [50, "Régulier"], [100, "Intensif"]];

/* ------------------------- Onboarding ------------------------------ */
export function renderOnboarding(app, onDone) {
  let avatar = AVATARS[0], goal = 50;
  app.innerHTML = `
  <section class="onboard">
    <div class="lang-pick" role="group" aria-label="Langue à apprendre">
      ${Object.values(LANGS).map((l) => `<button type="button" class="lang-chip ${l.code === code ? "on" : ""}" data-lang="${l.code}">
        <span class="flag">${flagSVG(l.code)}</span>${l.label}</button>`).join("")}
    </div>
    <p class="eyebrow">${L.onboardEyebrow}</p>
    <h1>${L.onboardTitle}<br><em>de zéro à la maîtrise.</em></h1>
    <p class="lead">${L.onboardLead}</p>
    <form class="card onboard-form">
      <label class="field"><span>Votre pseudo</span>
        <input name="pseudo" required maxlength="20" placeholder="${L.namePh}" autocomplete="nickname"></label>
      <fieldset class="field"><legend>Choisissez un avatar</legend>
        <div class="avatar-grid">${AVATARS.map((a, i) => `<button type="button" class="avatar-opt ${i === 0 ? "on" : ""}" data-a="${a}" aria-label="Avatar ${a}">${a}</button>`).join("")}</div>
      </fieldset>
      <fieldset class="field"><legend>Objectif quotidien</legend>
        <div class="seg wide">${GOALS.map(([v, l]) => `<button type="button" data-g="${v}" class="${v === goal ? "on" : ""}">${l}<small>${v} XP/jour</small></button>`).join("")}</div>
      </fieldset>
      <button class="btn primary big" type="submit">${L.start}</button>
      ${isConfigured() ? `<p class="small center">Déjà un compte ? <a href="#compte">Se connecter</a></p>` : ""}
    </form>
  </section>`;

  app.querySelectorAll("[data-lang]").forEach((b) => (b.onclick = () => setLang(b.dataset.lang)));
  const form = app.querySelector("form");
  form.querySelectorAll("[data-a]").forEach((b) => (b.onclick = () => {
    avatar = b.dataset.a; form.querySelectorAll("[data-a]").forEach((x) => x.classList.toggle("on", x === b));
  }));
  form.querySelectorAll("[data-g]").forEach((b) => (b.onclick = () => {
    goal = +b.dataset.g; form.querySelectorAll("[data-g]").forEach((x) => x.classList.toggle("on", x === b));
  }));
  form.onsubmit = (e) => {
    e.preventDefault();
    const pseudo = form.pseudo.value.trim();
    if (!pseudo) return form.pseudo.focus();
    commit((s) => { s.profile = { pseudo, avatar, dailyGoal: goal, createdAt: Date.now() }; });
    onDone();
  };
  setTimeout(() => form.pseudo.focus(), 50);
}

/* ---------------------------- Profil ------------------------------- */
export function renderProfil(app) {
  const p = state.profile;
  app.innerHTML = `
  <header class="page-head">
    <p class="eyebrow">Profil</p>
    <h1><span class="big-avatar">${esc(p.avatar)}</span> ${esc(p.pseudo)}</h1>
    <p class="muted">Vous apprenez : <b>${L.label}</b> · membre depuis le ${new Date(p.createdAt).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}</p>
  </header>

  <div class="profile-grid">
    <form class="card profile-form">
      <h2 class="h3">Mes informations</h2>
      <label class="field"><span>Pseudo</span><input name="pseudo" maxlength="20" value="${esc(p.pseudo)}" required></label>
      <fieldset class="field"><legend>Avatar</legend>
        <div class="avatar-grid">${AVATARS.map((a) => `<button type="button" class="avatar-opt ${a === p.avatar ? "on" : ""}" data-a="${a}">${a}</button>`).join("")}</div>
      </fieldset>
      <fieldset class="field"><legend>Objectif quotidien</legend>
        <div class="seg wide">${GOALS.map(([v, l]) => `<button type="button" data-g="${v}" class="${v === p.dailyGoal ? "on" : ""}">${l}<small>${v} XP</small></button>`).join("")}</div>
      </fieldset>
      <label class="switch"><input type="checkbox" name="tts" ${state.settings.tts ? "checked" : ""}><span></span> ${L.tts}</label>
      <fieldset class="field"><legend>Vitesse de la voix</legend>
        <div class="seg wide">${VOICE_SPEEDS.map(([v, l]) => `<button type="button" data-v="${v}" class="${v === (state.settings.voiceSpeed || 1) ? "on" : ""}">${l}</button>`).join("")}</div>
        <p class="small muted">Le bouton 🐢 à côté de chaque 🔊 lit encore plus lentement.</p>
      </fieldset>
      <button class="btn primary" type="submit">Enregistrer</button>
    </form>

    <section class="card">
      ${isConfigured() ? `
      <h2 class="h3">☁️ Compte en ligne</h2>
      <p class="small muted">${cloudInfo().user
        ? `Connecté avec <b>${esc(cloudInfo().user.email)}</b> : votre progression est sauvegardée en ligne et synchronisée sur vos appareils.`
        : "Créez un compte gratuit pour retrouver votre progression sur tous vos appareils."}</p>
      <a class="btn ${cloudInfo().user ? "ghost" : "primary"}" href="#compte">${cloudInfo().user ? "Gérer mon compte" : "Se connecter / créer un compte"}</a>
      <hr>` : ""}
      <h2 class="h3">📲 Application et notifications</h2>
      <div data-zone="app"><p class="small muted">…</p></div>
      <hr>
      <h2 class="h3">💾 Sauvegarde</h2>
      <p class="small muted">${isPersistent()
        ? "Votre progression est enregistrée automatiquement dans ce navigateur."
        : "⚠️ Le stockage local est indisponible ici : la progression sera perdue en fermant la page. Exportez-la pour la conserver."}
        Pour la transférer sur un autre appareil, copiez le code ci-dessous puis importez-le là-bas.</p>
      <div class="btn-row">
        <button class="btn ghost" data-export>📋 Copier ma sauvegarde</button>
        <label class="btn ghost file-btn">📂 Importer un fichier<input type="file" accept=".json,application/json" hidden></label>
      </div>
      <details class="paste">
        <summary>Coller une sauvegarde</summary>
        <textarea rows="4" placeholder='{"version":1, …}'></textarea>
        <button class="btn ghost small" data-import-text>Importer le texte</button>
      </details>
      <hr>
      <h2 class="h3">Zone sensible</h2>
      <button class="btn danger" data-reset>Réinitialiser ma progression</button>
    </section>
  </div>`;

  paintApp(app);
  const offPwa = PWA.onPwa(() => paintApp(app));
  app._cleanup = offPwa;

  const form = app.querySelector(".profile-form");
  let avatar = p.avatar, goal = p.dailyGoal, voice = state.settings.voiceSpeed || 1;
  form.querySelectorAll("[data-a]").forEach((b) => (b.onclick = () => { avatar = b.dataset.a; form.querySelectorAll("[data-a]").forEach((x) => x.classList.toggle("on", x === b)); }));
  form.querySelectorAll("[data-g]").forEach((b) => (b.onclick = () => { goal = +b.dataset.g; form.querySelectorAll("[data-g]").forEach((x) => x.classList.toggle("on", x === b)); }));
  form.querySelectorAll("[data-v]").forEach((b) => (b.onclick = () => {
    voice = +b.dataset.v; form.querySelectorAll("[data-v]").forEach((x) => x.classList.toggle("on", x === b));
    // Aperçu immédiat de la vitesse choisie
    const prev = state.settings.voiceSpeed; state.settings.voiceSpeed = voice; speak(L.hello); state.settings.voiceSpeed = prev;
  }));
  form.onsubmit = (e) => {
    e.preventDefault();
    const pseudo = form.pseudo.value.trim() || p.pseudo;
    commit((s) => { s.profile = { ...s.profile, pseudo, avatar, dailyGoal: goal }; s.settings.tts = form.tts.checked; s.settings.voiceSpeed = voice; });
    toast("Profil enregistré ✓", "ok");
    renderProfil(app);
  };

  app.querySelector("[data-export]").onclick = async () => {
    try { await navigator.clipboard.writeText(exportState()); toast("Sauvegarde copiée dans le presse-papiers ✓", "ok"); }
    catch {
      modal({ title: "Votre sauvegarde", body: `<p class="small muted">Copiez ce texte manuellement :</p><textarea class="export-box" rows="8" readonly>${esc(exportState())}</textarea>` });
      setTimeout(() => document.querySelector(".export-box")?.select(), 50);
    }
  };

  const doImport = (text) => {
    try {
      const data = JSON.parse(text);
      if (!data || typeof data !== "object" || !("lessons" in data)) throw new Error();
      replaceState(data); toast("Sauvegarde importée ✓", "ok"); location.hash = "tableau";
    } catch { toast("Fichier de sauvegarde invalide", "error"); }
  };
  app.querySelector("input[type=file]").onchange = (e) => {
    const f = e.target.files[0]; if (!f) return;
    const r = new FileReader(); r.onload = () => doImport(r.result); r.readAsText(f);
  };
  app.querySelector("[data-import-text]").onclick = () => doImport(app.querySelector(".paste textarea").value);

  app.querySelector("[data-reset]").onclick = async () => {
    const v = await modal({
      title: "Tout réinitialiser ?",
      body: "<p>Votre progression, votre carnet et votre cahier d'erreurs seront effacés. Cette action est irréversible.</p>",
      actions: [{ label: "Annuler", value: "no", kind: "ghost" }, { label: "Oui, tout effacer", value: "yes", kind: "danger" }],
    });
    if (v === "yes") { replaceState(defaultState()); location.hash = "parcours"; window.dispatchEvent(new HashChangeEvent("hashchange")); }
  };
}

/* ------------------- Application installable + notifications ------------------- */
async function paintApp(app) {
  const zone = app.querySelector('[data-zone="app"]');
  if (!zone) return;
  let install;
  if (PWA.isStandalone()) install = `<p class="small hint-ok">✓ Vous utilisez l'application installée.</p>`;
  else if (PWA.canPrompt()) install = `<p class="small muted">Ajoutez Impara à votre écran d'accueil : plein écran, accès direct, et les leçons marchent même sans réseau.</p>
      <button class="btn primary" data-install>📲 Installer l'application</button>`;
  else if (PWA.isIOS()) install = `<p class="small muted">Sur iPhone : ouvrez ce site dans <b>Safari</b>, touchez <b>Partager</b> <span aria-hidden="true">⎋</span> puis <b>« Sur l'écran d'accueil »</b>.</p>`;
  else install = `<p class="small muted">Pour installer l'application : menu du navigateur (⋮) → <b>« Installer l'application »</b> ou <b>« Ajouter à l'écran d'accueil »</b>.</p>`;

  const st = await PWA.pushState();
  const push = {
    unsupported: `<p class="small muted">🔕 Les notifications ne sont pas disponibles sur ce navigateur.</p>`,
    "needs-install": `<p class="small muted">🔔 Sur iPhone, installez d'abord l'application (ci-dessus) puis activez les notifications depuis l'application.</p>`,
    "needs-login": `<p class="small muted">🔔 Connectez-vous pour recevoir une notification quand un ami vous écrit ou vous défie.</p>`,
    denied: `<p class="small muted">🔕 Notifications bloquées : autorisez-les dans les réglages du navigateur pour ce site.</p>`,
    on: `<p class="small hint-ok">🔔 Notifications activées sur cet appareil.</p><button class="btn ghost small" data-push-off>Désactiver</button>`,
    off: `<p class="small muted">🔔 Soyez prévenu quand un ami vous écrit, vous ajoute ou vous lance un défi, même site fermé.</p>
      <button class="btn primary" data-push-on>🔔 Activer les notifications</button>`,
  }[st];
  zone.innerHTML = install + `<div class="push-zone">${push}</div>`;
  zone.querySelector("[data-install]")?.addEventListener("click", async () => { if (await PWA.promptInstall()) toast("Application installée ✓", "ok"); });
  zone.querySelector("[data-push-on]")?.addEventListener("click", async (e) => {
    e.target.disabled = true; e.target.textContent = "Activation…";
    try { await PWA.enablePush(); toast("Notifications activées 🔔", "ok"); } catch (err) { toast(err.message, "warn"); }
    paintApp(app);
  });
  zone.querySelector("[data-push-off]")?.addEventListener("click", async () => { await PWA.disablePush(); toast("Notifications désactivées"); paintApp(app); });
}
