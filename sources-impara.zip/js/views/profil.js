/* =====================================================================
   Vue « Profil » + écran d'accueil (onboarding)
   ===================================================================== */

import { state, commit } from "../core/storage.js";
import { esc, AVATARS, toast, modal } from "../core/ui.js";
import { L, LANGS, code, flagSVG, setLang } from "../core/lang.js";
import { isConfigured } from "../core/cloud.js";
import * as So from "../core/social.js";
import * as P from "../core/progress.js";
import { lvlLabel } from "../data/curriculum.js";
import qrcode from "qrcode-generator";

export const GOALS = [[20, "Détente"], [50, "Régulier"], [100, "Intensif"]];

/* ------------------------- Onboarding ------------------------------ */
export function renderOnboarding(app, onDone) {
  let avatar = AVATARS[0], goal = 50;
  app.innerHTML = `
  <section class="onboard">
    <div class="lang-pick" role="group" aria-label="Langue à apprendre">
      ${Object.values(LANGS).map((l) => `<button type="button" class="lang-chip ${l.code === code ? "on" : ""}" data-lang="${l.code}">
        <span class="flag">${flagSVG(l.code)}</span>${l.label}</button>`).join("")}
    </div>
    <p class="eyebrow">${L.onboardEyebrow}</p>
    <h1>${L.onboardTitle}<br><em>de zéro à la maîtrise.</em></h1>
    <p class="lead">${L.onboardLead}</p>
    <form class="card onboard-form">
      <label class="field"><span>Votre pseudo</span>
        <input name="pseudo" required maxlength="20" placeholder="${L.namePh}" autocomplete="nickname"></label>
      <fieldset class="field"><legend>Choisissez un avatar</legend>
        <div class="avatar-grid">${AVATARS.map((a, i) => `<button type="button" class="avatar-opt ${i === 0 ? "on" : ""}" data-a="${a}" aria-label="Avatar ${a}">${a}</button>`).join("")}</div>
      </fieldset>
      <fieldset class="field"><legend>Objectif quotidien</legend>
        <div class="seg wide">${GOALS.map(([v, l]) => `<button type="button" data-g="${v}" class="${v === goal ? "on" : ""}">${l}<small>${v} XP/jour</small></button>`).join("")}</div>
      </fieldset>
      <button class="btn primary big" type="submit">${L.start}</button>
      ${isConfigured() ? `<p class="small center">Déjà un compte ? <a href="#compte">Se connecter</a></p>` : ""}
    </form>
  </section>`;

  app.querySelectorAll("[data-lang]").forEach((b) => (b.onclick = () => setLang(b.dataset.lang)));
  const form = app.querySelector("form");
  form.querySelectorAll("[data-a]").forEach((b) => (b.onclick = () => {
    avatar = b.dataset.a; form.querySelectorAll("[data-a]").forEach((x) => x.classList.toggle("on", x === b));
  }));
  form.querySelectorAll("[data-g]").forEach((b) => (b.onclick = () => {
    goal = +b.dataset.g; form.querySelectorAll("[data-g]").forEach((x) => x.classList.toggle("on", x === b));
  }));
  form.onsubmit = (e) => {
    e.preventDefault();
    const pseudo = form.pseudo.value.trim();
    if (!pseudo) return form.pseudo.focus();
    commit((s) => { s.profile = { pseudo, avatar, dailyGoal: goal, createdAt: Date.now() }; });
    onDone();
  };
  setTimeout(() => form.pseudo.focus(), 50);
}

/* ---------------------------- Profil ------------------------------- */
export const BANNER_COLORS = ["#cfe6ff", "#d7f2e3", "#ffe3c7", "#ffd6d6", "#e8dcff", "#fff1b8", "#c9f0f0", "#f3d9ec", "#2b3a4a", "#1e8e5a"];
const EXTRA_AVATARS = ["🦊", "🐼", "🐱", "🐯", "🦁", "🐸", "🦉", "🐙", "🐉", "🐧", "🐨", "🦄", "🐝", "🦋", "🐢", "🐬", "🌵", "🍕", "🥟", "🍵", "🎧", "🎸", "⚽", "🏀", "🎮", "📚", "🚀", "🌸", "🌋", "🏯", "🛵", "🎭"];
const allAvatars = () => [...new Set([...Object.values(LANGS).flatMap((l) => l.avatars), ...EXTRA_AVATARS])];

/** Langues commencées (progression dans ce navigateur ou en ligne) */
function startedLangs() {
  const online = So.statsOf(So.social().me?.id || "") || {};
  return Object.values(LANGS).filter((l) => {
    if (l.code === code || online[l.code]) return true;
    try { const s = JSON.parse(localStorage.getItem(l.storageKey) || "null"); return !!(s && (s.xp || Object.keys(s.lessons || {}).length)); } catch { return false; }
  });
}

const textOn = (hex) => { const n = parseInt(hex.slice(1), 16); return ((n >> 16) * 299 + ((n >> 8) & 255) * 587 + (n & 255) * 114) / 1000 > 150 ? "#1d2733" : "#ffffff"; };

export function renderProfil(app) {
  const p = state.profile;
  const color = p.color || BANNER_COLORS[0];
  const S = So.social();
  const logged = So.isAvailable();
  const me = S.me;
  const fr = logged ? So.friends() : [];
  const following = fr.length + (logged ? So.outgoing().length : 0);
  const followers = fr.length + (logged ? So.incoming().length : 0);
  const won = logged ? So.allChallenges().filter((c) => c.outcome === "win").length : 0;
  const g = P.globalProgress(), lvl = P.currentLevel();
  const since = new Date(p.createdAt || Date.now()).getFullYear();

  app.innerHTML = `
  <div class="pf">
    <section class="pf-banner" style="--banner:${color};--banner-ink:${textOn(color)}">
      <a class="pf-icon" href="#parcours" aria-label="Fermer">✕</a>
      <h1 class="pf-title">${esc(p.pseudo)}</h1>
      <div class="pf-icons">
        <a class="pf-icon" href="#personnaliser" aria-label="Personnaliser mon profil" title="Personnaliser">🎨</a>
        <a class="pf-icon" href="#reglages" aria-label="Réglages" title="Réglages">⚙️</a>
      </div>
      <a class="pf-avatar" href="#personnaliser" title="Personnaliser">${esc(p.avatar)}</a>
    </section>

    <section class="pf-body">
      <p class="pf-handle">${me ? `@${esc(me.username)}` : logged ? `<a href="#amis">Choisir mon nom d'utilisateur</a>` : "Profil local"} · depuis ${since}</p>
      <div class="pf-stats">
        <div class="pf-stat"><div class="pf-flags">${startedLangs().map((l) => `<button class="pf-flag ${l.code === code ? "on" : ""}" data-lang="${l.code}" title="${esc(l.label)}">${flagSVG(l.code)}</button>`).join("")}</div><span>Cours</span></div>
        <button class="pf-stat" data-list="following" ${logged ? "" : "disabled"}><b>${following}</b><span>Abonnements</span></button>
        <button class="pf-stat" data-list="followers" ${logged ? "" : "disabled"}><b>${followers}</b><span>Abonnés</span></button>
      </div>
      <div class="pf-actions">
        <a class="btn ghost pf-add" href="${logged ? "#amis" : "#compte"}">👤＋ ${logged ? "AJOUTER DES AMIS" : "SE CONNECTER POUR AJOUTER DES AMIS"}</a>
        ${me ? `<button class="btn ghost pf-qr" data-qr aria-label="Mon QR code d'invitation" title="QR code d'invitation">▦</button>` : ""}
      </div>

      <h2 class="pf-h2">Statistiques</h2>
      <div class="pf-grid">
        <div class="pf-card"><span>🔥</span><b>${P.streakCount()}</b><small>Série de jours</small></div>
        <div class="pf-card"><span>⚡</span><b>${state.xp}</b><small>XP en ${esc(L.label.toLowerCase())}</small></div>
        <div class="pf-card"><span>🏅</span><b>${esc(lvlLabel(lvl))}</b><small>Niveau actuel</small></div>
        <div class="pf-card"><span>📈</span><b>${g.pct} %</b><small>du parcours</small></div>
        <div class="pf-card"><span>📒</span><b>${Object.keys(state.vocab).length}</b><small>Mots appris</small></div>
        <div class="pf-card"><span>🏆</span><b>${won}</b><small>Défis gagnés</small></div>
      </div>

      ${logged ? `<h2 class="pf-h2">Amis <a class="pf-more" href="#amis">Voir tout</a></h2>
      ${fr.length ? `<ul class="pf-friends">${fr.slice(0, 6).map((f) => `<li><a href="#ami-${esc(f.username)}"><span class="s-avatar" style="background:${esc(f.color || "var(--paper-2)")}">${esc(f.avatar || "👤")}</span><b>${esc(f.pseudo || f.username)}</b><small>@${esc(f.username)}</small></a></li>`).join("")}</ul>`
        : `<p class="muted small">Pas encore d'amis. Partagez votre QR code ou votre nom d'utilisateur !</p>`}` : ""}
    </section>
  </div>`;

  app.querySelectorAll("[data-lang]").forEach((b) => (b.onclick = () => { if (b.dataset.lang !== code) setLang(b.dataset.lang); }));
  app.querySelectorAll("[data-list]").forEach((b) => (b.onclick = () => showList(b.dataset.list)));
  app.querySelector("[data-qr]")?.addEventListener("click", () => showQr(me.username));
  if (logged && !S.ready) So.refresh().then(() => location.hash === "#profil" && renderProfil(app)).catch(() => {});
  const off = So.onSocial(() => { if (location.hash === "#profil" && !document.querySelector(".modal")) renderProfil(app); });
  app._cleanup = off;
}

function showList(kind) {
  const fr = So.friends();
  const extra = kind === "following" ? So.outgoing().map((r) => ({ ...r.to, pending: "Demande envoyée" }))
    : So.incoming().map((r) => ({ ...r.from, pending: "Veut vous ajouter", reqId: r.id }));
  const people = [...extra, ...fr];
  const row = (p) => `<li class="s-row"><span class="s-avatar sm" style="background:${esc(p.color || "var(--paper-2)")}">${esc(p.avatar || "👤")}</span>
      <div class="s-row-txt"><b>${esc(p.pseudo || p.username)}</b><span class="s-handle">@${esc(p.username)}${p.pending ? ` · ${p.pending}` : " · ami"}</span></div>
      ${p.reqId ? `<button class="btn primary small" data-acc="${p.reqId}">Accepter</button>` : p.pending ? "" : `<a class="btn ghost small" href="#ami-${esc(p.username)}" data-close-modal>Voir</a>`}</li>`;
  modal({
    title: kind === "following" ? "Abonnements" : "Abonnés",
    body: people.length ? `<ul class="s-list pf-list">${people.map(row).join("")}</ul>` : `<p class="muted">Personne pour l'instant.</p>`,
    actions: [{ label: "Fermer", value: "ok", kind: "ghost" }],
  });
  document.querySelectorAll("[data-acc]").forEach((b) => (b.onclick = async () => {
    b.disabled = true;
    try { await So.acceptFriend(+b.dataset.acc); toast("🎉 Nouvel ami !", "ok"); b.replaceWith(Object.assign(document.createElement("span"), { className: "chip", textContent: "Ami ✓" })); }
    catch (e) { toast(So.socialError(e), "warn"); b.disabled = false; }
  }));
  document.querySelectorAll("[data-close-modal]").forEach((a) => a.addEventListener("click", () => (document.querySelector("#modal-root").innerHTML = "")));
}

function showQr(username) {
  const url = `${location.origin}${location.pathname}#ajout-${encodeURIComponent(username)}`;
  const qr = qrcode(0, "M"); qr.addData(url); qr.make();
  modal({
    title: "Mon QR code d'invitation",
    body: `<div class="qr-box">${qr.createSvgTag({ cellSize: 6, margin: 2, scalable: true })}</div>
      <p class="small muted center">Votre ami scanne ce code avec l'appareil photo de son téléphone : il arrive sur Impara et peut vous ajouter en un clic.</p>
      <p class="qr-link">@${esc(username)}</p>`,
    actions: [{ label: "Fermer", value: "close", kind: "ghost" }, { label: navigator.share ? "📤 Partager le lien" : "📋 Copier le lien", value: "share", kind: "primary" }],
  }).then(async (v) => {
    if (v !== "share") return;
    try {
      if (navigator.share) await navigator.share({ title: "Impara", text: `Ajoute-moi sur Impara : @${username}`, url });
      else { await navigator.clipboard.writeText(url); toast("Lien copié ✓", "ok"); }
    } catch {}
  });
}

/* ------------------------- Personnaliser ---------------------------- */
export function renderPersonnaliser(app) {
  const p = state.profile;
  let avatar = p.avatar, color = p.color || BANNER_COLORS[0];
  app.innerHTML = `
  <div class="pf">
    <section class="pf-banner small-banner" style="--banner:${color};--banner-ink:${textOn(color)}">
      <a class="pf-icon" href="#profil" aria-label="Retour au profil">✕</a>
      <h1 class="pf-title">Personnaliser</h1>
      <span></span>
      <span class="pf-avatar">${esc(avatar)}</span>
    </section>
    <form class="pf-body pf-edit">
      <label class="field"><span>Pseudo</span><input name="pseudo" maxlength="20" value="${esc(p.pseudo)}" required></label>
      <fieldset class="field"><legend>Avatar</legend>
        <div class="avatar-grid">${allAvatars().map((a) => `<button type="button" class="avatar-opt ${a === avatar ? "on" : ""}" data-a="${a}" aria-label="Avatar ${a}">${a}</button>`).join("")}</div>
      </fieldset>
      <fieldset class="field"><legend>Couleur de fond</legend>
        <div class="color-grid">${BANNER_COLORS.map((c) => `<button type="button" class="color-opt ${c === color ? "on" : ""}" data-c="${c}" style="background:${c}" aria-label="Couleur ${c}"></button>`).join("")}</div>
      </fieldset>
      <p class="small muted">Vos amis voient votre avatar, votre pseudo et votre couleur.</p>
      <button class="btn primary big" type="submit">Enregistrer</button>
    </form>
  </div>`;
  const banner = app.querySelector(".pf-banner"), big = app.querySelector(".pf-avatar"), form = app.querySelector("form");
  form.querySelectorAll("[data-a]").forEach((b) => (b.onclick = () => {
    avatar = b.dataset.a; big.textContent = avatar;
    form.querySelectorAll("[data-a]").forEach((x) => x.classList.toggle("on", x === b));
  }));
  form.querySelectorAll("[data-c]").forEach((b) => (b.onclick = () => {
    color = b.dataset.c; banner.style.setProperty("--banner", color); banner.style.setProperty("--banner-ink", textOn(color));
    form.querySelectorAll("[data-c]").forEach((x) => x.classList.toggle("on", x === b));
  }));
  form.onsubmit = (e) => {
    e.preventDefault();
    const pseudo = form.pseudo.value.trim() || p.pseudo;
    commit((s) => { s.profile = { ...s.profile, pseudo, avatar, color }; });
    toast("Profil mis à jour ✓", "ok");
    location.hash = "profil";
  };
}
