/* =====================================================================
   Vue « Profil » + écran d'accueil (onboarding)
   ===================================================================== */

import { state, commit } from "../core/storage.js";
import { esc, AVATARS, toast } from "../core/ui.js";
import { L, LANGS, code, flagSVG, setLang } from "../core/lang.js";
import { isConfigured } from "../core/cloud.js";

export const GOALS = [[20, "Détente"], [50, "Régulier"], [100, "Intensif"]];

/* ------------------------- Onboarding ------------------------------ */
export function renderOnboarding(app, onDone) {
  let avatar = AVATARS[0], goal = 50;
  app.innerHTML = `
  <section class="onboard">
    <div class="lang-pick" role="group" aria-label="Langue à apprendre">
      ${Object.values(LANGS).map((l) => `<button type="button" class="lang-chip ${l.code === code ? "on" : ""}" data-lang="${l.code}">
        <span class="flag">${flagSVG(l.code)}</span>${l.label}</button>`).join("")}
    </div>
    <p class="eyebrow">${L.onboardEyebrow}</p>
    <h1>${L.onboardTitle}<br><em>de zéro à la maîtrise.</em></h1>
    <p class="lead">${L.onboardLead}</p>
    <form class="card onboard-form">
      <label class="field"><span>Votre pseudo</span>
        <input name="pseudo" required maxlength="20" placeholder="${L.namePh}" autocomplete="nickname"></label>
      <fieldset class="field"><legend>Choisissez un avatar</legend>
        <div class="avatar-grid">${AVATARS.map((a, i) => `<button type="button" class="avatar-opt ${i === 0 ? "on" : ""}" data-a="${a}" aria-label="Avatar ${a}">${a}</button>`).join("")}</div>
      </fieldset>
      <fieldset class="field"><legend>Objectif quotidien</legend>
        <div class="seg wide">${GOALS.map(([v, l]) => `<button type="button" data-g="${v}" class="${v === goal ? "on" : ""}">${l}<small>${v} XP/jour</small></button>`).join("")}</div>
      </fieldset>
      <button class="btn primary big" type="submit">${L.start}</button>
      ${isConfigured() ? `<p class="small center">Déjà un compte ? <a href="#compte">Se connecter</a></p>` : ""}
    </form>
  </section>`;

  app.querySelectorAll("[data-lang]").forEach((b) => (b.onclick = () => setLang(b.dataset.lang)));
  const form = app.querySelector("form");
  form.querySelectorAll("[data-a]").forEach((b) => (b.onclick = () => {
    avatar = b.dataset.a; form.querySelectorAll("[data-a]").forEach((x) => x.classList.toggle("on", x === b));
  }));
  form.querySelectorAll("[data-g]").forEach((b) => (b.onclick = () => {
    goal = +b.dataset.g; form.querySelectorAll("[data-g]").forEach((x) => x.classList.toggle("on", x === b));
  }));
  form.onsubmit = (e) => {
    e.preventDefault();
    const pseudo = form.pseudo.value.trim();
    if (!pseudo) return form.pseudo.focus();
    commit((s) => { s.profile = { pseudo, avatar, dailyGoal: goal, createdAt: Date.now() }; });
    onDone();
  };
  setTimeout(() => form.pseudo.focus(), 50);
}

/* ---------------------------- Profil ------------------------------- */
export function renderProfil(app) {
  const p = state.profile;
  app.innerHTML = `
  <header class="page-head">
    <p class="eyebrow">Profil</p>
    <h1><span class="big-avatar">${esc(p.avatar)}</span> ${esc(p.pseudo)}</h1>
    <p class="muted">Vous apprenez : <b>${L.label}</b> · membre depuis le ${new Date(p.createdAt).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}</p>
  </header>

  <div class="profile-grid">
    <form class="card profile-form">
      <h2 class="h3">Mes informations</h2>
      <label class="field"><span>Pseudo</span><input name="pseudo" maxlength="20" value="${esc(p.pseudo)}" required></label>
      <fieldset class="field"><legend>Avatar</legend>
        <div class="avatar-grid">${AVATARS.map((a) => `<button type="button" class="avatar-opt ${a === p.avatar ? "on" : ""}" data-a="${a}">${a}</button>`).join("")}</div>
      </fieldset>
      <button class="btn primary" type="submit">Enregistrer</button>
    </form>

    <section class="card settings-teaser">
      <h2 class="h3">⚙️ Réglages</h2>
      <p class="small muted">Compte et synchronisation, langue, son et vitesse de la voix${code === "zh" ? ", pinyin" : ""}, objectif quotidien, application, notifications et sauvegarde.</p>
      <a class="btn ghost" href="#reglages">Ouvrir les réglages →</a>
    </section>
  </div>`;

  const form = app.querySelector(".profile-form");
  let avatar = p.avatar;
  form.querySelectorAll("[data-a]").forEach((b) => (b.onclick = () => { avatar = b.dataset.a; form.querySelectorAll("[data-a]").forEach((x) => x.classList.toggle("on", x === b)); }));
  form.onsubmit = (e) => {
    e.preventDefault();
    const pseudo = form.pseudo.value.trim() || p.pseudo;
    commit((s) => { s.profile = { ...s.profile, pseudo, avatar }; });
    toast("Profil enregistré ✓", "ok");
    renderProfil(app);
  };
}
