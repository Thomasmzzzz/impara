/* =====================================================================
   Vue « Histoires » — courts dialogues à lire et à écouter
   - #histoires        : liste (débloquées après une leçon)
   - #histoire-<id>    : l'histoire, ligne par ligne, avec questions
   ===================================================================== */

import { state, commit } from "../core/storage.js";
import { code } from "../core/lang.js";
import { esc, speak, celebrate, ring } from "../core/ui.js";
import * as P from "../core/progress.js";
import { getLesson, lvlLabel } from "../data/curriculum.js";
import { levelWantsPinyin } from "../core/pinyin.js";
import { STORIES } from "../data/stories.js";
import { wordsHtml } from "../core/words.js";

const MALE = new Set(["王明", "张伟", "老板", "爸爸", "哥哥", "弟弟", "爷爷", "Marco", "Luca", "Paolo", "Giorgio"]);
const FEMALE = new Set(["Léa", "小美", "姐姐", "妹妹", "妈妈", "奶奶", "服务员", "Giulia", "Sofia", "Anna"]);

const list = () => STORIES[code] || [];
const unlocked = (s) => P.isLessonDone(s.after);
const COLORS = ["#3b82c4", "#c2410c", "#7c3aed", "#0f766e", "#be185d"];

export const storyCount = () => ({ total: list().length, open: list().filter(unlocked).length, done: list().filter((s) => state.stories?.[s.id]?.done).length });

/* =============================== Liste ============================== */
export function renderHistoires(app) {
  app.innerHTML = `
  <a class="back-link" href="#entrainement">← Entraînement</a>
  <header class="page-head"><p class="eyebrow">Lire et écouter</p><h1>📖 Histoires</h1>
    <p class="muted">De courts dialogues avec les mots de vos leçons. Touchez une phrase pour voir sa traduction.</p></header>
  <div class="story-list">
    ${list().map((s) => {
      const ok = unlocked(s), rec = state.stories?.[s.id];
      const lesson = getLesson(s.after);
      return `<a class="story-item ${ok ? "" : "locked"}" ${ok ? `href="#histoire-${s.id}"` : `aria-disabled="true"`}>
        <span class="story-emoji">${ok ? s.emoji : "🔒"}</span>
        <span class="story-txt"><b class="${code === "zh" ? "zh" : ""}">${esc(s.title)} <em class="story-lvl">${esc(lvlLabel(s.level || "A1"))}</em></b>
          ${s.titlePy ? `<small class="py">${esc(s.titlePy)}</small>` : ""}
          <small>${ok ? esc(s.intro) : `Se débloque après la leçon « ${esc(lesson?.title || s.after)} »`}</small></span>
        ${rec?.done ? `<span class="story-done" title="Terminée">${rec.best}/${rec.total} ✓${P.practiceReadyAt(`story:${s.id}`) ? `<small>XP dans ${P.waitLabel(P.practiceReadyAt(`story:${s.id}`))}</small>` : ""}</span>` : ""}
      </a>`;
    }).join("")}
  </div>`;
  return true;
}

/* ============================== Histoire ============================ */
export function renderHistoire(app, id) {
  const story = list().find((s) => s.id === id);
  if (!story || !unlocked(story)) return false;
  const showPy = code === "zh" && levelWantsPinyin(story.level || "A1");
  const people = [...new Set(story.lines.map((l) => l.who).filter(Boolean))];
  const color = (who) => COLORS[people.indexOf(who) % COLORS.length];
  // Voix des personnages (mandarin : Xiaoxiao / Yunxi) ; le narrateur garde la voix choisie
  const voiceOf = (who) => (!who ? null : MALE.has(who) ? "m" : FEMALE.has(who) ? "f" : people.indexOf(who) % 2 ? "alt" : null);
  const totalQ = story.lines.filter((l) => l.q).length;
  let step = 0, score = 0, waiting = false;

  document.body.classList.add("focus-mode");
  app.innerHTML = `
  <section class="story">
    <div class="story-top">
      <button class="btn ghost small" data-quit aria-label="Quitter">✕</button>
      <div class="progress"><span class="story-bar"></span></div>
    </div>
    <header class="story-head"><span class="story-big">${story.emoji}</span>
      <h1 class="${code === "zh" ? "zh" : ""}">${esc(story.title)}</h1>${story.titlePy ? `<p class="py">${esc(story.titlePy)}</p>` : ""}
      <p class="muted small">${esc(story.intro)}</p></header>
    <div class="story-lines" aria-live="polite"></div>
    <div class="story-foot"><button class="btn primary big" data-next>Commencer</button></div>
  </section>`;

  const box = app.querySelector(".story-lines"), next = app.querySelector("[data-next]");
  const bar = app.querySelector(".story-bar");
  const quit = () => { document.body.classList.remove("focus-mode"); location.hash = "histoires"; };
  app.querySelector("[data-quit]").onclick = quit;

  function lineHtml(l) {
    const zh = code === "zh";
    const body = `<p class="sl-t ${zh ? "zh" : ""}">${wordsHtml(l.t)}</p>
      ${l.py ? `<p class="sl-py ${showPy ? "" : "hidden"}">${esc(l.py)}</p>` : ""}
      <p class="sl-fr hidden">${esc(l.fr)}</p>`;
    if (!l.who) return `<div class="sl narr" tabindex="0"><div class="sl-body">${body}</div><button class="speak" data-say aria-label="Réécouter">🔊</button></div>`;
    return `<div class="sl talk" tabindex="0" style="--who:${color(l.who)}">
      <span class="sl-who">${esc(l.who)}</span>
      <div class="sl-bubble">${body}</div><button class="speak" data-say aria-label="Réécouter">🔊</button></div>`;
  }

  function addLine(l) {
    const div = document.createElement("div");
    div.innerHTML = lineHtml(l);
    const el = div.firstElementChild;
    box.appendChild(el);
    const voice = voiceOf(l.who);
    el.querySelector("[data-say]").onclick = (e) => { e.stopPropagation(); speak(l.t, { force: true, voice }); };
    el.onclick = () => { el.querySelector(".sl-fr").classList.toggle("hidden"); el.querySelector(".sl-py")?.classList.remove("hidden"); };
    speak(l.t, { force: true, voice });
    el.scrollIntoView({ behavior: "smooth", block: "end" });
  }

  function addQuestion(l) {
    waiting = true;
    next.disabled = true; next.textContent = "Choisissez une réponse";
    const order = l.options.map((_, i) => i).sort(() => Math.random() - 0.5);
    const div = document.createElement("div");
    div.className = "sl-q card";
    div.innerHTML = `<p class="eyebrow">Question</p><p class="sl-qt">${esc(l.q)}</p>
      <div class="options">${order.map((i) => `<button class="option" data-i="${i}"><span>${esc(l.options[i])}</span></button>`).join("")}</div>`;
    box.appendChild(div);
    div.scrollIntoView({ behavior: "smooth", block: "end" });
    div.querySelectorAll("[data-i]").forEach((b) => (b.onclick = () => {
      const i = +b.dataset.i, ok = i === l.answer;
      if (ok) score++;
      div.querySelectorAll("[data-i]").forEach((x) => {
        x.disabled = true;
        if (+x.dataset.i === l.answer) x.classList.add("correct");
        else if (x === b) x.classList.add("wrong");
      });
      div.insertAdjacentHTML("beforeend", `<p class="sl-res ${ok ? "ok" : "ko"}">${ok ? "✓ Bonne réponse !" : "✗ Pas tout à fait."}</p>`);
      waiting = false;
      next.disabled = false; next.textContent = "Continuer";
      next.focus();
    }));
  }

  function finish() {
    const rec = state.stories?.[story.id];
    const first = !rec?.done;
    const r = P.recordPractice({ label: `Histoire · ${story.title}`, score, total: totalQ, xpPer: 10, key: `story:${story.id}` });
    let bonus = 0;
    if (first) { bonus = 20; P.recordPractice({ label: "", score: 1, total: 0, xpPer: bonus }); }
    commit((s) => { s.stories = { ...(s.stories || {}), [story.id]: { done: true, best: Math.max(rec?.best || 0, score), total: totalQ, date: Date.now() } }; });
    document.body.classList.remove("focus-mode");
    const pct = totalQ ? Math.round((score / totalQ) * 100) : 100;
    const nextStory = list().find((s) => unlocked(s) && !state.stories?.[s.id]?.done);
    app.innerHTML = `
    <section class="results ${pct >= 60 ? "ok" : "ko"}">
      ${ring(pct, 150, 12)}
      <h1>${pct === 100 ? "Tout compris ! 🎉" : pct >= 60 ? "Histoire terminée !" : "Histoire terminée"}</h1>
      <p class="lead">${score} / ${totalQ} questions de compréhension</p>
      <div class="result-chips">${r.capped && !bonus ? `<span class="chip muted-chip">⏳ XP déjà gagnés aujourd'hui</span>` : `<span class="chip">⚡ +${r.xpGained + bonus} XP</span>`}${bonus ? `<span class="chip">📖 Nouvelle histoire lue</span>` : ""}</div>
      <div class="result-actions">
        ${nextStory ? `<a class="btn primary big" href="#histoire-${nextStory.id}">Histoire suivante →</a>` : `<a class="btn primary big" href="#histoires">Toutes les histoires</a>`}
        <a class="btn ghost" href="#histoire-${story.id}" data-reload>Relire</a>
      </div>
    </section>`;
    if (pct === 100) celebrate();
  }

  next.onclick = () => {
    if (waiting) return;
    if (step >= story.lines.length) return finish();
    const l = story.lines[step++];
    bar.style.width = `${Math.round((step / story.lines.length) * 100)}%`;
    if (l.q) addQuestion(l);
    else { addLine(l); next.textContent = step >= story.lines.length ? "Terminer" : "Continuer"; }
  };
  return true;
}
