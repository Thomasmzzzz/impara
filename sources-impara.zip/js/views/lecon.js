/* =====================================================================
   Vue « Leçon » — contenu pédagogique d'une mini-leçon
   ===================================================================== */

import { getLesson, getLevel, MODULES, lvlLabel, lvlBadge } from "../data/curriculum.js";
import { state } from "../core/storage.js";
import { isLessonUnlocked, starsFor } from "../core/progress.js";
import { esc, speakBtn, tri } from "../core/ui.js";
import { L } from "../core/lang.js";

export function renderLecon(app, id) {
  const lesson = getLesson(id);
  if (!lesson || !isLessonUnlocked(lesson)) return false; // le routeur redirige
  const level = getLevel(lesson.levelId);
  const mod = MODULES[lesson.module];
  const rec = state.lessons[id];
  const lessons = level.lessons;

  app.innerHTML = `
  <article class="lesson" style="--lvl:${level.color}">
    <a class="back" href="#parcours">← Parcours</a>
    <header class="lesson-head">
      <div class="lesson-emoji">${lesson.emoji}</div>
      <div>
        <p class="eyebrow">${lvlLabel(level)}${level.hsk && !level.label ? ` (${level.hsk})` : ""} · ${mod.icon} ${mod.label} · Leçon ${lesson.index + 1}/${lessons.length}</p>
        <h1>${esc(lesson.title)}</h1>
        <p class="lead">${lesson.intro}</p>
        ${rec ? `<p class="small muted">Meilleur score : ${rec.best}/${rec.total} ${"★".repeat(starsFor(rec.best / rec.total))}</p>` : ""}
      </div>
    </header>

    <nav class="lesson-steps" aria-label="Sections">
      ${lesson.sections.map((s, i) => `<a href="#s${i}" data-scroll="s${i}">${i + 1}. ${esc(s.title)}</a>`).join("")}
    </nav>

    ${lesson.sections.map((s, i) => section(s, i)).join("")}

    <aside class="mnemo">
      <span class="mnemo-icon">🧠</span>
      <div><p class="eyebrow">Astuce mnémotechnique</p><p>${lesson.mnemo}</p></div>
    </aside>

    <section class="card">
      <h2 class="h3">📒 Mots de la leçon</h2>
      <p class="small muted">Ils rejoindront votre carnet de vocabulaire dès que vous réussirez le quiz.</p>
      <ul class="vocab-grid">
        ${lesson.vocab.map(tri).map(([w, py, fr]) => `<li class="${py ? "has-py" : ""}">${speakBtn(w)}<span class="it ${L.wordClass}">${esc(w)}</span>${py ? `<span class="py">${esc(py)}</span>` : ""}<span class="fr">${esc(fr)}</span></li>`).join("")}
      </ul>
    </section>

    <div class="lesson-cta">
      <p>${lesson.quiz.length} questions · 60 % pour valider</p>
      <a class="btn primary big" href="#quiz-${lesson.id}">Je suis prêt·e : quiz →</a>
    </div>
  </article>`;
  return true;
}

function section(s, i) {
  return `
  <section class="card lesson-section" id="s${i}">
    <h2 class="h3"><span class="num">${i + 1}</span>${esc(s.title)}</h2>
    ${s.text ? `<p>${s.text}</p>` : ""}
    ${s.table ? table(s.table) : ""}
    ${s.examples ? `<ul class="examples">${s.examples
      .map(tri).map(([w, py, fr]) => `<li>${speakBtn(w)}<div><span class="it ${L.wordClass}">${esc(w)}</span>${py ? `<span class="py">${esc(py)}</span>` : ""}<span class="fr">${esc(fr)}</span></div></li>`)
      .join("")}</ul>` : ""}
  </section>`;
}

function table({ cols, rows }) {
  const hasHead = cols.some((c) => c);
  return `<div class="table-wrap"><table>
    ${hasHead ? `<thead><tr>${cols.map((c) => `<th>${esc(c)}</th>`).join("")}</tr></thead>` : ""}
    <tbody>${rows.map((r) => `<tr>${r.map((c, k) => `<td class="${k === 0 && hasHead ? "first" : ""}">${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody>
  </table></div>`;
}
