/* =====================================================================
   Vue « Réglages » (roue ⚙️ en haut à droite)
   Tout ce qui se règle au même endroit ; chaque choix est enregistré
   immédiatement.
   ===================================================================== */

import { state, commit, replaceState, exportState, defaultState, isPersistent } from "../core/storage.js";
import { esc, toast, modal, speak, VOICE_SPEEDS, listVoices, setVoice, currentVoice, onVoices } from "../core/ui.js";
import { L, LANGS, code, flagSVG, setLang } from "../core/lang.js";
import * as C from "../core/cloud.js";
import * as PWA from "../core/pwa.js";
import { PINYIN_MODES } from "../core/pinyin.js";
import { GOALS } from "./profil.js";
import { getTheme, setTheme, getLangTheme, setLangTheme } from "../core/theme.js";
import { sfx, haptic } from "../core/fx.js";

const SYNC = {
  off: ["⚪", "Mode local"], guest: ["⚪", "Non connecté"], syncing: ["🔄", "Synchronisation…"],
  synced: ["✅", "Synchronisé"], offline: ["📴", "Hors ligne : les changements partiront au retour du réseau"],
  error: ["⚠️", "Problème de synchronisation"],
};

const seg = (name, items, current) => `<div class="seg wide" role="group">${items.map(([v, l, small]) =>
  `<button type="button" data-${name}="${v}" class="${String(v) === String(current) ? "on" : ""}">${l}${small ? `<small>${small}</small>` : ""}</button>`).join("")}</div>`;

const saved = () => toast("Réglage enregistré ✓", "ok");

export function renderReglages(app) {
  const p = state.profile;
  app.innerHTML = `
  <header class="page-head"><p class="eyebrow">Réglages</p><h1>⚙️ Réglages</h1>
    <p class="muted">Chaque modification est enregistrée immédiatement.</p></header>
  <div class="settings-grid">
    <div class="settings-col">
      <section class="card set-card" id="set-compte"><h2 class="h3">👤 Compte</h2><div data-zone="account"></div></section>

      <section class="card set-card"><h2 class="h3">🌍 Langue apprise</h2>
        <div class="lang-pick">${Object.values(LANGS).map((l) => `<button type="button" class="lang-chip ${l.code === code ? "on" : ""}" data-lang="${l.code}">
          <span class="flag">${flagSVG(l.code)}</span>${l.label}</button>`).join("")}</div>
        <p class="small muted">Chaque langue garde sa propre progression ; votre profil est commun.</p>
      </section>

      <section class="card set-card"><h2 class="h3">🌗 Apparence</h2>
        <div class="theme-pick">${[["auto", "Automatique", "t-auto"], ["light", "Clair", "t-light"], ["dark", "Sombre", "t-dark"]].map(([v, l, c]) =>
          `<button type="button" class="theme-opt ${getTheme() === v ? "on" : ""}" data-theme-opt="${v}"><i class="${c}"></i>${l}</button>`).join("")}</div>
        <p class="small muted">« Automatique » suit le réglage clair / sombre de votre téléphone ou ordinateur.</p>
        <label class="switch"><input type="checkbox" data-lang-theme ${getLangTheme() ? "checked" : ""}><span></span> 🎨 Thème de la langue (vert‑blanc‑rouge pour l'italien, rouge et or pour le mandarin)</label>
        <p class="small muted">Désactivé par défaut : l'application garde l'apparence classique, identique pour les deux langues. Activez‑le pour changer d'univers avec la langue.</p>
      </section>

      <section class="card set-card"><h2 class="h3">🎯 Objectif quotidien</h2>
        ${seg("goal", GOALS.map(([v, l]) => [v, l, `${v} XP/jour`]), p.dailyGoal)}
      </section>

      <section class="card set-card"><h2 class="h3">🔊 Son et prononciation</h2>
        <label class="switch"><input type="checkbox" data-tts ${state.settings.tts ? "checked" : ""}><span></span> ${L.tts}</label>
        <p class="set-label">Vitesse de la voix</p>
        ${seg("voice", VOICE_SPEEDS, state.settings.voiceSpeed || 1)}
        <p class="small muted">Touchez une vitesse pour l'écouter. Le bouton 🐢 à côté de chaque 🔊 lit encore plus lentement.</p>
        <p class="set-label">Voix</p>
        <div data-zone="voices"></div>
        <label class="switch"><input type="checkbox" data-sfx ${state.settings.sfx !== false ? "checked" : ""}><span></span> 🎵 Effets sonores (bonne réponse, erreur, victoire)</label>
        <label class="switch"><input type="checkbox" data-haptics ${state.settings.haptics !== false ? "checked" : ""}><span></span> 📳 Vibrations (Android)</label>
      </section>

      ${code === "zh" ? `<section class="card set-card"><h2 class="h3">🀄 Pinyin dans les quiz</h2>
        ${seg("pyq", PINYIN_MODES, state.settings.pinyinQuiz || "auto")}
        <p class="small muted">Le pinyin s'affiche au-dessus des caractères dans les leçons et les quiz. Par défaut : HSK 1 et HSK 2.</p>
      </section>` : ""}
    </div>

    <div class="settings-col">
      <section class="card set-card"><h2 class="h3">📲 Application et notifications</h2><div data-zone="app"><p class="small muted">…</p></div></section>

      <section class="card set-card"><h2 class="h3">💾 Sauvegarde</h2>
        <p class="small muted">${isPersistent()
          ? "Votre progression est enregistrée automatiquement dans ce navigateur" + (C.cloudInfo().user ? " et en ligne." : ".")
          : "⚠️ Le stockage local est indisponible ici : la progression sera perdue en fermant la page. Exportez-la pour la conserver."}
          Vous pouvez aussi en garder une copie ou la transférer à la main.</p>
        <div class="btn-row">
          <button class="btn ghost small" data-export>📋 Copier ma sauvegarde</button>
          <label class="btn ghost small file-btn">📂 Importer un fichier<input type="file" accept=".json,application/json" hidden></label>
        </div>
        <details class="paste"><summary>Coller une sauvegarde</summary>
          <textarea rows="4" placeholder='{"version":1, …}'></textarea>
          <button class="btn ghost small" data-import-text>Importer le texte</button></details>
      </section>

      <section class="card set-card danger-zone"><h2 class="h3">⚠️ Zone sensible</h2>
        <p class="small muted">Efface la progression en ${esc(L.label.toLowerCase())} : leçons, carnet et cahier d'erreurs.</p>
        <button class="btn danger small" data-reset>Réinitialiser ma progression</button>
      </section>

      <section class="card set-card"><h2 class="h3">ℹ️ À propos</h2>
        <p class="small muted">Impara · italien &amp; mandarin. Code source : <a href="sources-impara.zip">sources-impara.zip</a>.</p>
      </section>
    </div>
  </div>`;

  const $ = (s) => app.querySelector(s);
  paintAccount(app);
  paintApp(app);
  paintVoices(app);
  const offVoices = onVoices(() => paintVoices(app));
  const offCloud = C.onCloud(() => paintAccount(app));
  const offPwa = PWA.onPwa(() => paintApp(app));
  app._cleanup = () => { offCloud(); offPwa(); offVoices(); };

  // Choix enregistrés immédiatement
  const pick = (name, apply) => app.querySelectorAll(`[data-${name}]`).forEach((b) => (b.onclick = () => {
    app.querySelectorAll(`[data-${name}]`).forEach((x) => x.classList.toggle("on", x === b));
    apply(b.dataset[name]); saved();
  }));
  app.querySelectorAll("[data-theme-opt]").forEach((b) => (b.onclick = () => {
    app.querySelectorAll("[data-theme-opt]").forEach((x) => x.classList.toggle("on", x === b));
    setTheme(b.dataset.themeOpt); saved();
  }));
  pick("goal", (v) => commit((s) => { s.profile = { ...s.profile, dailyGoal: +v }; }));
  pick("voice", (v) => { commit((s) => { s.settings.voiceSpeed = +v; }); speak(L.hello, { force: true }); });
  pick("pyq", (v) => commit((s) => { s.settings.pinyinQuiz = v; }));
  $("[data-lang-theme]").onchange = (e) => { setLangTheme(e.target.checked); saved(); };
  $("[data-sfx]").onchange = (e) => { commit((s) => { s.settings.sfx = e.target.checked; }); if (e.target.checked) sfx("good"); saved(); };
  $("[data-haptics]").onchange = (e) => { commit((s) => { s.settings.haptics = e.target.checked; }); if (e.target.checked) haptic(40); saved(); };
  $("[data-tts]").onchange = (e) => { commit((s) => { s.settings.tts = e.target.checked; }); saved(); };
  app.querySelectorAll("[data-lang]").forEach((b) => (b.onclick = () => { if (b.dataset.lang !== code) setLang(b.dataset.lang); }));

  // Sauvegarde
  $("[data-export]").onclick = async () => {
    try { await navigator.clipboard.writeText(exportState()); toast("Sauvegarde copiée dans le presse-papiers ✓", "ok"); }
    catch {
      modal({ title: "Votre sauvegarde", body: `<p class="small muted">Copiez ce texte manuellement :</p><textarea class="export-box" rows="8" readonly>${esc(exportState())}</textarea>` });
      setTimeout(() => document.querySelector(".export-box")?.select(), 50);
    }
  };
  const doImport = (text) => {
    try {
      const data = JSON.parse(text);
      if (!data || typeof data !== "object" || !("lessons" in data)) throw new Error();
      replaceState(data); toast("Sauvegarde importée ✓", "ok"); location.hash = "tableau";
    } catch { toast("Fichier de sauvegarde invalide", "error"); }
  };
  $("input[type=file]").onchange = (e) => { const f = e.target.files[0]; if (!f) return; const r = new FileReader(); r.onload = () => doImport(r.result); r.readAsText(f); };
  $("[data-import-text]").onclick = () => doImport($(".paste textarea").value);
  $("[data-reset]").onclick = async () => {
    const v = await modal({
      title: "Tout réinitialiser ?",
      body: `<p>Votre progression en ${esc(L.label.toLowerCase())}, votre carnet et votre cahier d'erreurs seront effacés. Cette action est irréversible.</p>`,
      actions: [{ label: "Annuler", value: "no", kind: "ghost" }, { label: "Oui, tout effacer", value: "yes", kind: "danger" }],
    });
    if (v === "yes") { replaceState(defaultState()); location.hash = "parcours"; window.dispatchEvent(new HashChangeEvent("hashchange")); }
  };
}

/* ------------------------------ Compte ------------------------------ */
function paintAccount(app) {
  const zone = app.querySelector('[data-zone="account"]');
  if (!zone) return;
  const p = state.profile, i = C.cloudInfo();
  const who = `<div class="acc-row"><span class="acc-avatar">${esc(p.avatar)}</span>
      <div><b>${esc(p.pseudo)}</b><p class="muted small">${i.user ? esc(i.user.email) : "Pas de compte en ligne"}</p></div>
      <a class="btn ghost small acc-edit" href="#profil">Modifier</a></div>`;
  if (!C.isConfigured()) { zone.innerHTML = who + `<p class="small muted">Mode local : la progression reste dans ce navigateur.</p>`; return; }
  if (!i.user) {
    zone.innerHTML = who + `<p class="small muted">Créez un compte gratuit pour retrouver votre progression sur tous vos appareils et ajouter des amis.</p>
      <a class="btn primary" href="#compte">☁️ Se connecter / créer un compte</a>`;
    return;
  }
  const [icon, label] = SYNC[i.status] || SYNC.synced;
  zone.innerHTML = who + `
    <div class="sync-box sync-${i.status}"><span class="sync-icon">${icon}</span>
      <div><b>${label}</b><p class="small muted">${i.lastSync ? `Dernière synchronisation : ${new Date(i.lastSync).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}` : ""}${i.message ? ` · ${esc(i.message)}` : ""}</p></div></div>
    <div class="btn-row">
      <button class="btn ghost small" data-sync>🔄 Synchroniser</button>
      <a class="btn ghost small" href="#amis">👥 Mes amis</a>
      <button class="btn ghost small danger-txt" data-logout>Se déconnecter</button>
    </div>`;
  zone.querySelector("[data-sync]").onclick = async () => {
    await C.syncNow();
    const ok = C.cloudInfo().status === "synced";
    toast(ok ? "Synchronisé ✓" : C.cloudInfo().message, ok ? "ok" : "warn");
  };
  zone.querySelector("[data-logout]").onclick = async () => {
    const v = await modal({
      title: "Se déconnecter ?",
      body: "<p>Votre progression est sauvegardée en ligne. Elle sera retirée de cet appareil et vous la retrouverez en vous reconnectant.</p>",
      actions: [{ label: "Annuler", value: "no" }, { label: "Se déconnecter", value: "yes", kind: "danger" }],
    });
    if (v === "yes") { await C.signOut(); toast("Déconnecté", "ok"); location.hash = "parcours"; window.dispatchEvent(new HashChangeEvent("hashchange")); }
  };
}

/* ------------------- Application installable + notifications ------------------- */
/* ------------------------------ Voix ------------------------------ */
const SAMPLE = { it: "Ciao! Come stai? Oggi impariamo l'italiano insieme.", zh: "你好！我们今天一起学习中文。" };
function voiceHelp() {
  const ua = navigator.userAgent || "";
  const lang = code === "zh" ? "Chinois (Chine continentale)" : "Italien";
  if (/iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1))
    return `Sur iPhone, Apple ne donne pas accès aux sites web (ni aux applis installées depuis Safari) aux voix « améliorées » ou « Premium » téléchargées dans les Réglages : seules les voix de base apparaissent ici. Pour une voix vraiment naturelle sur iPhone, il faudrait des enregistrements audio intégrés à l'appli.`;
  if (/Macintosh/.test(ua))
    return `Sur Mac : <b>Réglages Système › Accessibilité › Contenu énoncé › Voix du système › Gérer les voix</b>, puis téléchargez une voix ${lang.toLowerCase()} « Premium » ou « améliorée ». Dans Chrome, les voix « Google » sont aussi correctes.`;
  if (/Android/.test(ua))
    return `Sur Android : dans les paramètres, cherchez <b>« Synthèse vocale »</b>, choisissez le moteur <b>Google</b> et installez les données vocales ${code === "zh" ? "chinoises" : "italiennes"} (voix de haute qualité).`;
  if (/Edg\//.test(ua)) return "Dans Edge, les voix marquées « Natural » / « Online » sont les plus réalistes : choisissez‑en une ci‑dessus.";
  return "Les voix les plus naturelles sont dans <b>Microsoft Edge</b> (voix « Natural ») et <b>Safari</b> sur iPhone ou Mac (voix « Premium »). Dans Chrome, préférez les voix « Google ».";
}
function paintVoices(app) {
  const z = app.querySelector('[data-zone="voices"]');
  if (!z) return;
  const list = listVoices(), chosen = state.settings.voiceName?.[code] || "", cur = currentVoice();
  const best = list[0];
  z.innerHTML = list.length ? `
    <div class="voice-row">
      <select data-voice-pick aria-label="Voix">
        <option value="" ${!chosen ? "selected" : ""}>Automatique${best ? ` — ${esc(best.name)}` : ""}</option>
        ${list.map((x) => `<option value="${esc(x.name)}" ${chosen === x.name ? "selected" : ""}>${esc(x.name)} · ${esc(x.tag)}${x.lang && x.lang.toLowerCase().replace("_", "-") !== L.speech.toLowerCase() ? ` (${esc(x.lang)})` : ""}</option>`).join("")}
      </select>
      <button class="btn ghost small" data-voice-test>▶️ Écouter</button>
    </div>
    <p class="small muted">${list.length} voix ${code === "zh" ? "mandarin" : "italienne"}${list.length > 1 ? "s" : ""} sur cet appareil${cur ? ` · utilisée : <b>${esc(cur.name)}</b>` : ""}. Les voix « Naturelle », « Premium » ou « Améliorée » sonnent beaucoup plus humain.</p>
    <details class="voice-help"><summary>La voix sonne robotique ?</summary><p class="small">${voiceHelp()}</p></details>`
    : `<p class="small muted">Aucune voix ${code === "zh" ? "mandarin" : "italienne"} trouvée pour l'instant sur cet appareil.</p><p class="small">${voiceHelp()}</p>`;
  z.querySelector("[data-voice-pick]")?.addEventListener("change", (e) => { setVoice(e.target.value); speak(SAMPLE[code] || L.hello, { force: true }); toast("Voix enregistrée ✓", "ok"); });
  z.querySelector("[data-voice-test]")?.addEventListener("click", () => speak(SAMPLE[code] || L.hello, { force: true }));
}

async function paintApp(app) {
  const zone = app.querySelector('[data-zone="app"]');
  if (!zone) return;
  let install;
  if (PWA.isStandalone()) install = `<p class="small hint-ok">✓ Vous utilisez l'application installée.</p>`;
  else if (PWA.canPrompt()) install = `<p class="small muted">Ajoutez Impara à votre écran d'accueil : plein écran, accès direct, et les leçons marchent même sans réseau.</p>
      <button class="btn primary small" data-install>📲 Installer l'application</button>`;
  else if (PWA.isIOS()) install = `<p class="small muted">Sur iPhone : ouvrez ce site dans <b>Safari</b>, touchez <b>Partager</b> puis <b>« Sur l'écran d'accueil »</b>.</p>`;
  else install = `<p class="small muted">Pour installer l'application : menu du navigateur (⋮) → <b>« Installer l'application »</b> ou <b>« Ajouter à l'écran d'accueil »</b>.</p>`;

  const st = await PWA.pushState();
  const push = {
    unsupported: `<p class="small muted">🔕 Les notifications ne sont pas disponibles sur ce navigateur.</p>`,
    "needs-install": `<p class="small muted">🔔 Sur iPhone, installez d'abord l'application, puis activez les notifications depuis l'application.</p>`,
    "needs-login": `<p class="small muted">🔔 Connectez-vous pour être prévenu quand un ami vous écrit ou vous défie.</p>`,
    denied: `<p class="small muted">🔕 Notifications bloquées : autorisez-les dans les réglages du navigateur pour ce site.</p>`,
    on: `<p class="small hint-ok">🔔 Notifications activées sur cet appareil.</p>
      <label class="switch"><input type="checkbox" data-remind ${state.settings.streakReminder !== false ? "checked" : ""}><span></span> 🔥 Rappel de série à 20 h si je n'ai rien fait de la journée</label>
      <button class="btn ghost small" data-push-off>Désactiver</button>`,
    off: `<p class="small muted">🔔 Soyez prévenu quand un ami vous écrit, vous ajoute ou vous lance un défi, même site fermé.</p>
      <button class="btn primary small" data-push-on>🔔 Activer les notifications</button>`,
  }[st];
  zone.innerHTML = install + `<div class="push-zone">${push}</div>`;
  zone.querySelector("[data-install]")?.addEventListener("click", async () => { if (await PWA.promptInstall()) toast("Application installée ✓", "ok"); });
  zone.querySelector("[data-push-on]")?.addEventListener("click", async (e) => {
    e.target.disabled = true; e.target.textContent = "Activation…";
    try { await PWA.enablePush(); toast("Notifications activées 🔔", "ok"); } catch (err) { toast(err.message, "warn"); }
    paintApp(app);
  });
  zone.querySelector("[data-remind]")?.addEventListener("change", (e) => { commit((s) => { s.settings.streakReminder = e.target.checked; }); saved(); });
  zone.querySelector("[data-push-off]")?.addEventListener("click", async () => { await PWA.disablePush(); toast("Notifications désactivées"); paintApp(app); });
}
