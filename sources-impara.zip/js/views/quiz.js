/* =====================================================================
   Vue « Quiz » — quiz de leçon, examen de palier et révision d'erreurs
   ===================================================================== */

import { getLesson, getLevel, getQuestion, LEVELS, lvlLabel, lvlBadge } from "../data/curriculum.js";
import { state } from "../core/storage.js";
import * as P from "../core/progress.js";
import { runQuiz } from "../core/quiz-engine.js";
import { esc, celebrate, shuffle, ring } from "../core/ui.js";
import { L } from "../core/lang.js";
import { buildLessonQuestions } from "../core/challenge-gen.js";

/** Quiz de fin de leçon */
export function renderQuiz(app, id) {
  const lesson = getLesson(id);
  if (!lesson || !P.isLessonUnlocked(lesson)) return false;
  start(app, {
    kind: "lesson", id, label: lesson.title,
    title: `Quiz · ${lesson.title}`,
    questions: lessonQuestions(lesson),
    back: `#lecon-${id}`,
  });
  return true;
}

/**
 * Questions d'une leçon : la première fois, celles du cours (ordre mélangé) ;
 * ensuite, environ 40 % sont remplacées par des questions générées sur les
 * mots de la leçon, avec des formulations différentes à chaque essai.
 */
function lessonQuestions(lesson) {
  const base = shuffle(lesson.quiz.map((q, i) => ({ ref: `${lesson.id}:${i}`, q })));
  if (!state.lessons[lesson.id]?.attempts) return base;
  const swap = Math.max(2, Math.round(base.length * 0.4));
  const gen = buildLessonQuestions(lesson, swap);
  const kept = base.slice(0, base.length - gen.length);
  return shuffle([...kept, ...gen]);
}

/** Examen de fin de palier */
export function renderExamen(app, levelId) {
  const level = getLevel(levelId);
  const li = LEVELS.indexOf(level);
  if (!level || !P.isExamUnlocked(li)) return false;
  start(app, {
    kind: "exam", id: levelId, label: `Examen ${lvlLabel(levelId)}`,
    title: `Examen de fin de palier ${lvlLabel(levelId)}`,
    questions: level.exam.map((q, i) => ({ ref: `exam-${levelId}:${i}`, q })),
    back: "#parcours",
  });
  return true;
}

/** Révision intelligente : les erreurs les plus fréquentes d'abord */
export function renderRevision(app) {
  const errs = Object.values(state.errors)
    .sort((a, b) => b.count - a.count || a.lastWrong - b.lastWrong)
    .slice(0, 10)
    .map((e) => ({ ref: e.ref, q: getQuestion(e.ref) }))
    .filter((x) => x.q);
  if (!errs.length) { location.hash = "erreurs"; return true; }
  start(app, { kind: "review", id: "review", label: "Révision des erreurs", title: "Révision de vos erreurs", questions: shuffle(errs), back: "#erreurs" });
  return true;
}

function start(app, cfg) {
  document.body.classList.add("focus-mode"); // masque la navigation pendant le quiz
  runQuiz(app, {
    title: cfg.title,
    questions: cfg.questions,
    onQuit: () => { document.body.classList.remove("focus-mode"); location.hash = cfg.back.slice(1); },
    onFinish: (results) => {
      document.body.classList.remove("focus-mode");
      const sum = P.recordQuiz({ kind: cfg.kind, id: cfg.id, label: cfg.label, results });
      showResults(app, cfg, sum);
    },
  });
}

function showResults(app, cfg, s) {
  const pct = Math.round(s.ratio * 100);
  const next = P.nextStep();
  let headline, msg, primary;

  if (cfg.kind === "review") {
    headline = pct === 100 ? "Sans faute ! 💪" : "Révision terminée";
    msg = s.mastered ? `${s.mastered} notion(s) maîtrisée(s) et retirée(s) du cahier d'erreurs.` : "Une erreur disparaît du cahier après 2 bonnes réponses d'affilée.";
    primary = Object.keys(state.errors).length ? `<a class="btn primary big" href="#revision" data-reload>Nouvelle révision</a>` : `<a class="btn primary big" href="#parcours">Retour au parcours</a>`;
  } else if (s.passed) {
    headline = cfg.kind === "exam" ? `Palier ${lvlLabel(cfg.id)} validé ! 🎓` : L.resultHeads[s.stars - 1] || L.resultHeads[0];
    msg = cfg.kind === "exam"
      ? (LEVELS[LEVELS.findIndex((l) => l.id === cfg.id) + 1] ? `Le palier ${lvlLabel(LEVELS[LEVELS.findIndex((l) => l.id === cfg.id) + 1])} est maintenant débloqué.` : L.finished)
      : s.newWords ? `${s.newWords} nouveaux mots ajoutés à votre carnet.` : "Leçon validée.";
    primary = next
      ? `<a class="btn primary big" href="#${next.kind === "lesson" ? "lecon-" + next.lesson.id : "examen-" + next.level.id}">${next.kind === "lesson" ? "Leçon suivante" : `Examen ${lvlLabel(next.level)}`} →</a>`
      : `<a class="btn primary big" href="#tableau">Voir mon tableau de bord</a>`;
  } else {
    headline = L.almost;
    msg = `Il faut ${Math.round(s.passMark * 100)} % pour valider. Relisez la leçon, vos erreurs sont dans le cahier.`;
    primary = `<a class="btn primary big" href="#${cfg.kind === "exam" ? "examen-" + cfg.id : "quiz-" + cfg.id}" data-reload>Réessayer</a>`;
  }

  app.innerHTML = `
  <section class="results ${s.passed ? "ok" : "ko"}">
    ${ring(pct, 150, 12)}
    ${cfg.kind !== "review" ? `<div class="stars" aria-label="${s.stars} étoiles sur 3">${[1, 2, 3].map((n) => `<span class="${n <= s.stars ? "on" : ""}">★</span>`).join("")}</div>` : ""}
    <h1>${headline}</h1>
    <p class="lead">${s.score} / ${s.total} bonnes réponses</p>
    <p class="muted">${esc(msg)}</p>
    <div class="result-chips">
      <span class="chip">⚡ +${s.xpGained} XP</span>
      ${s.newWords ? `<span class="chip">📒 +${s.newWords} mots</span>` : ""}
      ${s.total - s.score ? `<span class="chip warn">🔁 ${s.total - s.score} à revoir</span>` : ""}
    </div>
    <div class="result-actions">
      ${primary}
      <a class="btn ghost" href="${cfg.back}">${cfg.kind === "lesson" ? "Relire la leçon" : "Retour"}</a>
    </div>
  </section>`;

  if (s.passed && (s.firstPass || s.ratio === 1)) celebrate();
}
