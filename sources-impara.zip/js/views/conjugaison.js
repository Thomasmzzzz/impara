/* =====================================================================
   Vue « Conjugaison » (#conjugaison, italien) : 60 secondes pour conjuguer
   un maximum de verbes déjà vus (verbe + temps + personne). Les temps se
   débloquent avec les leçons correspondantes.
   ===================================================================== */
import { state, commit } from "../core/storage.js";
import { code } from "../core/lang.js";
import { esc, shuffle, ring, celebrate, speak } from "../core/ui.js";
import { checkText, accentBar } from "../core/quiz-engine.js";
import * as P from "../core/progress.js";
import { PERSONS, TENSES, conjugate } from "../core/conjug-it.js";
import { sfx, haptic } from "../core/fx.js";
import { xpChip } from "./entrainement.js";

const DURATION = 60;
const BASICS = ["essere", "avere", "parlare", "mangiare", "prendere", "dormire", "capire", "fare", "andare"];
let chosen = null;

/** Verbes du carnet que l'on sait conjuguer */
function verbs() {
  const out = new Set();
  Object.keys(state.vocab || {}).forEach((w) => String(w).split(/\s*\/\s*/).forEach((v) => { v = v.trim(); if (/^[a-zàèéìòù]+(are|ere|ire|arsi|ersi|irsi)$/.test(v) && conjugate(v, "presente", 0)) out.add(v); }));
  return [...out];
}
const unlocked = () => Object.keys(TENSES).filter((t) => P.isLessonDone(TENSES[t].lesson));

export function renderConjugaison(app) {
  if (code !== "it") return false;
  const vs = verbs(), open = unlocked();
  if (!chosen || !chosen.every((t) => open.includes(t))) chosen = open.slice();
  const best = state.conjBest || {};
  const ready = vs.length >= 3 && open.length;
  app.innerHTML = `
  <a class="back-link" href="#entrainement">← Entraînement</a>
  <section class="card cj-intro">
    <p class="eyebrow">Conjugaison</p>
    <h1>⏱️ ${DURATION} secondes chrono</h1>
    <p class="lead">Un verbe, un temps, une personne : écrivez la bonne forme le plus vite possible.</p>
    ${ready ? `
    <p class="cj-label">Temps</p>
    <div class="chips cj-tenses">${Object.entries(TENSES).map(([t, x]) => `<button type="button" class="chip-btn ${chosen.includes(t) ? "on" : ""}" data-t="${t}" ${open.includes(t) ? "" : "disabled title=\"Se débloque avec la leçon correspondante\""}>${open.includes(t) ? "" : "🔒 "}${esc(x.label)}</button>`).join("")}</div>
    <p class="muted small">${vs.length} verbes de votre carnet · record : <b>${best.all || 0}</b></p>
    <button class="btn primary big" data-go>Commencer</button>`
    : `<p class="muted">Terminez d'abord les leçons sur le présent : les verbes appris arriveront ici.</p><a class="btn primary" href="#parcours">Continuer le parcours</a>`}
  </section>`;
  if (!ready) return true;
  app.querySelectorAll("[data-t]").forEach((b) => (b.onclick = () => {
    const t = b.dataset.t;
    chosen = chosen.includes(t) ? (chosen.length > 1 ? chosen.filter((x) => x !== t) : chosen) : [...chosen, t];
    app.querySelectorAll("[data-t]").forEach((x) => x.classList.toggle("on", chosen.includes(x.dataset.t)));
  }));
  app.querySelector("[data-go]").onclick = () => play(app, vs.length >= 3 ? vs : [...new Set([...vs, ...BASICS])], chosen.slice());
  return true;
}

function play(app, vs, tenses) {
  document.body.classList.add("focus-mode");
  const log = [];
  let cur = null, score = 0, combo = 0, t0 = performance.now(), timer = null, lock = false, last = "";
  app.innerHTML = `
  <section class="quiz cj">
    <header class="quiz-top"><button class="icon-btn quiz-quit" aria-label="Quitter">✕</button><div class="bar cj-time"><span></span></div><span class="quiz-count cj-score">0</span></header>
    <div class="quiz-card cj-card">
      <p class="q-label cj-tense"></p>
      <h2 class="cj-prompt"><span class="cj-person"></span><span class="cj-verb"></span></h2>
      <input class="tr-input cj-input" autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="Forme conjuguée" enterkeyhint="go">
      <p class="cj-fb" aria-live="polite"></p>
    </div>
    <footer class="quiz-foot"><button class="btn primary big quiz-action">Valider</button></footer>
  </section>`;
  const $ = (s) => app.querySelector(s), input = $(".cj-input");
  $(".cj-card").appendChild(accentBar(input));
  const end = () => { clearInterval(timer); document.body.classList.remove("focus-mode"); finish(app, log, score, tenses); };
  $(".quiz-quit").onclick = () => { clearInterval(timer); document.body.classList.remove("focus-mode"); location.hash = "entrainement"; };
  function next() {
    let c = null;
    for (let k = 0; k < 40 && !c; k++) {
      const v = vs[Math.floor(Math.random() * vs.length)], t = tenses[Math.floor(Math.random() * tenses.length)], p = Math.floor(Math.random() * 6);
      const r = conjugate(v, t, p);
      if (r && `${v}${t}${p}` !== last) c = { v, t, p, ...r };
    }
    cur = c; last = `${c.v}${c.t}${c.p}`;
    $(".cj-tense").textContent = TENSES[c.t].label;
    $(".cj-person").textContent = (c.t === "congiuntivo" ? "che " : "") + PERSONS[c.p];
    $(".cj-verb").textContent = c.v;
    $(".cj-fb").textContent = ""; $(".cj-card").classList.remove("ok", "ko");
    input.value = ""; input.disabled = false; lock = false; input.focus();
  }
  function check() {
    if (lock || !cur) return;
    const given = input.value.trim();
    if (!given) return;
    const res = checkText(given, cur.answers);
    log.push({ ...cur, given, correct: res.correct });
    if (res.correct) {
      score++; combo++; sfx(combo >= 3 && combo % 3 === 0 ? "combo" : "good"); haptic(15);
      $(".cj-score").textContent = score; $(".cj-card").classList.add("ok");
      $(".cj-fb").textContent = res.note ? `✓ ${cur.show}` : `✓ ${combo >= 3 ? `${combo} d'affilée !` : ""}`;
      lock = true; setTimeout(next, res.note ? 700 : 260);
    } else {
      combo = 0; sfx("bad"); haptic([30, 30]);
      $(".cj-card").classList.add("ko"); $(".cj-fb").innerHTML = `✗ <b>${esc(cur.show)}</b>`;
      lock = true; input.disabled = true; setTimeout(next, 1400);
    }
  }
  $(".quiz-action").onclick = check;
  input.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); check(); } });
  app._cleanup = () => clearInterval(timer);   // on quitte la page : le chrono s'arrête
  timer = setInterval(() => {
    if (!$(".cj-time")) return clearInterval(timer);
    const left = Math.max(0, DURATION - (performance.now() - t0) / 1000);
    $(".cj-time span").style.width = `${(left / DURATION) * 100}%`;
    $(".cj-time").classList.toggle("hurry", left < 10);
    if (left <= 0) end();
  }, 100);
  next();
}

function finish(app, log, score, tenses) {
  const total = log.length;
  const r = P.recordPractice({ label: "Conjugaison", score, total, key: "conjugaison" });
  const prev = state.conjBest?.all || 0, record = score > prev;
  if (record) commit((s) => { s.conjBest = { ...(s.conjBest || {}), all: score }; });
  const pct = total ? Math.round((score / total) * 100) : 0;
  const wrong = log.filter((x) => !x.correct);
  app.innerHTML = `
  <section class="results ${pct >= 60 ? "ok" : "ko"}">
    ${ring(pct, 150, 12)}
    <h1>${record && score ? "Nouveau record ! 🏆" : score >= 10 ? "Rapide !" : "Bien joué !"}</h1>
    <p class="lead">${score} bonne${score > 1 ? "s" : ""} réponse${score > 1 ? "s" : ""} en ${DURATION} s · ${total} essai${total > 1 ? "s" : ""}</p>
    <div class="result-chips">${xpChip(r)}<span class="chip">🏆 Record : ${Math.max(prev, score)}</span></div>
    ${wrong.length ? `<details class="mistakes card" open><summary><b>Vos erreurs</b><span class="mk-n">${wrong.length}</span></summary><ol class="mk-list">${wrong.map((x) => `
      <li class="mk"><p class="mk-q"><small>${esc(TENSES[x.t].label)}</small>${esc((x.t === "congiuntivo" ? "che " : "") + PERSONS[x.p])} · ${esc(x.v)}</p>
        <p class="mk-a no"><span>Votre réponse</span><s>${esc(x.given)}</s></p>
        <p class="mk-a yes"><span>Bonne réponse</span><b>${esc(x.show)}</b><button type="button" class="speak mk-say" data-speak="${esc(x.show.replace(/o\/a$|i\/e$/, (m) => m[0]))}" aria-label="Écouter">🔊</button></p></li>`).join("")}</ol></details>` : ""}
    <div class="result-actions"><a class="btn primary big" href="#conjugaison" data-reload>Rejouer</a><a class="btn ghost" href="#entrainement">Autres exercices</a></div>
  </section>`;
  if (record && score) celebrate();
}
