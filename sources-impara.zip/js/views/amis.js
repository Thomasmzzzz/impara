/* =====================================================================
   Vues sociales
   - #amis          : nom d'utilisateur, ajout d'amis, demandes, défis
   - #ami-<pseudo>  : progression comparée, défis et messages avec un ami
   - #defi-<id>     : jouer un défi
   ===================================================================== */

import { state } from "../core/storage.js";
import { L, LANGS, code, flagSVG } from "../core/lang.js";
import { esc, toast, modal, shuffle, ring, celebrate } from "../core/ui.js";
import { runQuiz } from "../core/quiz-engine.js";
import * as P from "../core/progress.js";
import { ALL_LESSONS, LEVELS } from "../data/curriculum.js";
import { isConfigured } from "../core/cloud.js";
import * as So from "../core/social.js";
import * as PWA from "../core/pwa.js";

/* ------------------------------ Outils ----------------------------- */
const who = (p) => esc(p?.pseudo || p?.username || "Ami");
const av = (p, cls = "") => `<span class="s-avatar ${cls}">${esc(p?.avatar || "👤")}</span>`;
const handle = (p) => (p?.username ? `<span class="s-handle">@${esc(p.username)}</span>` : "");
const stillHere = (hash) => location.hash === hash;

function when(ts) {
  const d = new Date(ts), now = new Date();
  const hm = d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  if (d.toDateString() === now.toDateString()) return hm;
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return `hier ${hm}`;
  return `${d.toLocaleDateString("fr-FR", { day: "numeric", month: "short" })} ${hm}`;
}
const secs = (ms) => (ms < 60000 ? `${Math.round(ms / 1000)} s` : `${Math.floor(ms / 60000)} min ${String(Math.round((ms % 60000) / 1000)).padStart(2, "0")}`);

/** Écrans communs : pas de serveur / pas connecté / chargement */
function gate(app, title) {
  if (!isConfigured()) {
    app.innerHTML = `<header class="page-head"><p class="eyebrow">Amis</p><h1>👥 ${title}</h1></header>
      <section class="card"><p>L'espace amis nécessite les comptes en ligne, qui ne sont pas activés sur ce site.</p></section>`;
    return true;
  }
  if (!So.isAvailable()) {
    app.innerHTML = `<header class="page-head"><p class="eyebrow">Amis</p><h1>👥 ${title}</h1>
      <p class="muted">Ajoutez vos amis, suivez leurs progrès, discutez et lancez-vous des défis.</p></header>
      <section class="card account-card"><p>Connectez-vous pour accéder à l'espace amis.</p>
      <a class="btn primary" href="#compte">☁️ Se connecter ou créer un compte</a></section>`;
    return true;
  }
  return false;
}
const loading = (app) => (app.innerHTML = `<p class="muted s-loading">Chargement…</p>`);
/** Charge les données sociales puis affiche ; en cas d'échec, message + bouton Réessayer */
function loadThen(app, render) {
  const hash = location.hash;
  loading(app);
  So.refresh().then(() => { if (stillHere(hash) && So.social().ready) render(); })
    .catch((e) => {
      if (!stillHere(hash)) return;
      app.innerHTML = `<section class="card account-card"><p class="form-msg error">${esc(So.socialError(e))}</p>
        <button class="btn primary" data-retry>Réessayer</button></section>`;
      app.querySelector("[data-retry]").onclick = () => loadThen(app, render);
    });
}

/* ---------------------------- Cartes défi -------------------------- */
function challengeCard(c, { showFriend = true } = {}) {
  const f = c.friend;
  const langs = (r) => (r?.lang ? `<span class="flag mini">${flagSVG(r.lang)}</span>` : "");
  let status = "", actions = "", cls = "";
  switch (c.stage) {
    case "to_accept":
      status = `<b>${who(f)}</b> vous défie sur ${c.n} questions`; cls = "todo";
      actions = `<button class="btn primary small" data-ch-accept="${c.id}">Accepter</button><button class="btn ghost small" data-ch-decline="${c.id}">Refuser</button>`;
      break;
    case "waiting_accept":
      status = `En attente de la réponse de <b>${who(f)}</b>`;
      actions = `<button class="btn ghost small" data-ch-cancel="${c.id}">Annuler</button>`;
      break;
    case "to_play":
      status = c.theirs ? `<b>${who(f)}</b> a joué : à vous !` : `Défi accepté : à vous de jouer !`; cls = "todo";
      actions = `<a class="btn primary small" href="#defi-${c.id}">⚔️ Jouer</a>`;
      break;
    case "waiting_play":
      status = `Votre score : <b>${c.mine.score}/${c.mine.total}</b> ${langs(c.mine)} · en attente de ${who(f)}`;
      break;
    case "done": {
      const t = { win: ["🏆 Victoire", "win"], lose: ["Défaite", "lose"], draw: ["🤝 Égalité", "draw"] }[c.outcome];
      cls = t[1];
      status = `<b class="s-outcome">${t[0]}</b> · vous ${c.mine.score}/${c.mine.total} ${langs(c.mine)} <small>(${secs(c.mine.ms)})</small>
        — ${who(f)} ${c.theirs.score}/${c.theirs.total} ${langs(c.theirs)} <small>(${secs(c.theirs.ms)})</small>`;
      break;
    }
    case "declined": status = `${c.iAmChallenger ? `${who(f)} a refusé` : "Vous avez refusé"} le défi`; cls = "off"; break;
    case "cancelled": status = "Défi annulé"; cls = "off"; break;
  }
  return `<li class="s-challenge ${cls}">
    ${showFriend ? av(f, "sm") : `<span class="s-ch-icon">⚔️</span>`}
    <div class="s-ch-body"><p>${status}</p><small class="muted">${c.n} questions · ${when(c.created_at)}</small></div>
    ${actions ? `<div class="s-ch-actions">${actions}</div>` : ""}
  </li>`;
}

/** Boutons d'action des défis (délégation) */
function bindChallengeActions(root) {
  root.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-ch-accept],[data-ch-decline],[data-ch-cancel]");
    if (!b) return;
    b.disabled = true;
    try {
      if (b.dataset.chAccept) { await So.respondChallenge(b.dataset.chAccept, true); toast("Défi accepté ⚔️", "ok");
        if (location.hash === `#defi-${b.dataset.chAccept}`) window.dispatchEvent(new HashChangeEvent("hashchange"));
        else location.hash = `defi-${b.dataset.chAccept}`; }
      else if (b.dataset.chDecline) { await So.respondChallenge(b.dataset.chDecline, false); toast("Défi refusé"); }
      else { await So.cancelChallenge(b.dataset.chCancel); toast("Défi annulé"); }
    } catch (err) { toast(err.message, "warn"); b.disabled = false; }
  });
}

async function askChallenge(friend) {
  const v = await modal({
    title: `⚔️ Défier ${who(friend)}`,
    body: `<p>Chacun répond à des questions de <b>sa propre langue</b>, tirées des leçons qu'il a débloquées.
      Le meilleur score gagne ; à égalité, le plus rapide.</p><p class="muted small">${who(friend)} doit d'abord accepter le défi.</p>`,
    actions: [{ label: "Annuler", value: "" }, { label: "5 questions", value: "5" }, { label: "10 questions", value: "10", kind: "primary" }, { label: "15 questions", value: "15" }],
  });
  if (!v) return;
  try { await So.createChallenge(friend.id, +v); toast(`Défi envoyé à ${friend.pseudo || friend.username} ⚔️`, "ok"); }
  catch (e) { toast(e.message, "warn"); }
}

/* ============================== #amis ============================== */
export function renderAmis(app) {
  if (gate(app, "Amis")) return;
  const S = So.social();
  if (!S.ready) { loadThen(app, () => renderAmis(app)); return; }
  if (!S.me) return renderUsername(app);

  app.innerHTML = `<div class="s-page">
  <header class="page-head s-head">
    <div><p class="eyebrow">Amis</p><h1>👥 Mes amis</h1>
    <p class="muted">Votre nom d'utilisateur : <b class="s-me">@${esc(S.me.username)}</b> <button class="link-btn" data-copy>Copier</button></p></div>
  </header>
  <div class="s-grid">
    <div class="s-col">
      <form class="card s-add" autocomplete="off">
        <h2 class="h3">➕ Ajouter un ami</h2>
        <div class="s-add-row"><span class="s-at">@</span>
          <input name="u" required maxlength="21" placeholder="nom d'utilisateur de votre ami" aria-label="Nom d'utilisateur de l'ami" autocapitalize="none" spellcheck="false">
          <button class="btn primary" type="submit">Envoyer</button></div>
        <p class="form-msg" role="alert"></p>
        <p class="muted small">Votre ami verra votre demande et pourra l'accepter. Une fois amis, vous voyez la progression l'un de l'autre.</p>
      </form>
      <div data-zone="push"></div>
      <div data-zone="requests"></div>
      <div data-zone="todo"></div>
      <section class="card"><h2 class="h3">Mes amis</h2><div data-zone="friends"></div></section>
    </div>
    <div class="s-col">
      <section class="card"><h2 class="h3">🏆 Classement de la semaine</h2><div data-zone="board"></div></section>
      <section class="card"><h2 class="h3">⚔️ Défis</h2><div data-zone="challenges"></div></section>
      <div data-zone="sent"></div>
    </div>
  </div></div>`;
  const page = app.firstElementChild;

  const paint = () => {
    const z = (n) => app.querySelector(`[data-zone="${n}"]`);
    const inc = So.incoming();
    z("requests").innerHTML = inc.length ? `<section class="card s-highlight"><h2 class="h3">📬 Demandes reçues</h2><ul class="s-list">
      ${inc.map((r) => `<li class="s-row">${av(r.from)}<div class="s-row-txt"><b>${who(r.from)}</b>${handle(r.from)}</div>
        <div class="s-row-actions"><button class="btn primary small" data-accept="${r.id}">Accepter</button><button class="btn ghost small" data-remove="${r.id}">Refuser</button></div></li>`).join("")}
      </ul></section>` : "";

    const all = So.allChallenges();
    const todo = all.filter((c) => c.stage === "to_accept" || c.stage === "to_play");
    z("todo").innerHTML = todo.length ? `<section class="card s-highlight"><h2 class="h3">🔔 À faire</h2><ul class="s-ch-list">${todo.map((c) => challengeCard(c)).join("")}</ul></section>` : "";

    const fr = So.friends();
    z("friends").innerHTML = fr.length ? `<ul class="s-list">${fr.map((f) => {
      const st = So.statsOf(f.id), n = S.unread[f.id] || 0;
      const chips = Object.keys(LANGS).filter((c) => st[c]).map((c) => `<span class="s-lang-chip"><span class="flag mini">${flagSVG(c)}</span>${esc(st[c].level)} · ${st[c].pct}%</span>`).join("");
      return `<li><a class="s-row s-friend" href="#ami-${esc(f.username)}">${av(f)}
        <div class="s-row-txt"><b>${who(f)}</b>${handle(f)}<div class="s-chips">${chips || `<small class="muted">Pas encore de progression</small>`}</div></div>
        ${n ? `<span class="s-unread" title="${n} message(s) non lu(s)">💬 ${n}</span>` : ""}<span class="s-go">›</span></a></li>`;
    }).join("")}</ul>` : `<p class="muted">Vous n'avez pas encore d'amis ici. Envoyez votre nom d'utilisateur <b>@${esc(S.me.username)}</b> à vos amis, ou ajoutez le leur ci-contre.</p>`;

    const rest = all.filter((c) => !todo.includes(c)).slice(0, 12);
    z("challenges").innerHTML = rest.length ? `<ul class="s-ch-list">${rest.map((c) => challengeCard(c)).join("")}</ul>`
      : `<p class="muted small">${fr.length ? "Ouvrez la fiche d'un ami pour le défier." : "Ajoutez un ami pour lancer votre premier défi."}</p>`;

    const board = So.leaderboard();
    const medal = ["🥇", "🥈", "🥉"];
    z("board").innerHTML = board.length > 1 ? `<ol class="s-board">${board.map((p, i) => `
        <li class="${p.isMe ? "me" : ""}"><span class="s-rank">${p.xp ? medal[i] || i + 1 : "–"}</span>${av(p, "sm")}
          <span class="s-board-name">${p.isMe ? "Vous" : who(p)}<small>${p.allXp} XP au total</small></span><b>${p.xp} XP</b></li>`).join("")}</ol>
        <p class="muted small">XP gagnés cette semaine (depuis lundi 0 h), toutes langues confondues. Mis à jour en direct dès qu'un ami gagne des XP.</p>`
      : `<p class="muted small">Ajoutez des amis pour comparer vos XP de la semaine.</p>`;

    const out = So.outgoing();
    z("sent").innerHTML = out.length ? `<section class="card"><h2 class="h3">📤 Demandes envoyées</h2><ul class="s-list">
      ${out.map((r) => `<li class="s-row">${av(r.to)}<div class="s-row-txt"><b>${who(r.to)}</b>${handle(r.to)}<small class="muted">En attente</small></div>
        <div class="s-row-actions"><button class="btn ghost small" data-remove="${r.id}">Annuler</button></div></li>`).join("")}</ul></section>` : "";
  };
  paint();

  // Invitation à activer les notifications (si possible et pas encore fait)
  PWA.pushState().then((st) => {
    const zone = page.querySelector('[data-zone="push"]');
    if (!zone || (st !== "off" && st !== "needs-install")) return;
    let hidden = false; try { hidden = localStorage.getItem("impara.pushHint") === "no"; } catch {}
    if (hidden) return;
    zone.innerHTML = `<section class="card s-push-hint"><p>🔔 <b>Soyez prévenu</b> quand un ami vous écrit ou vous lance un défi.</p>
      <div class="btn-row">${st === "off" ? `<button class="btn primary small" data-push-on>Activer les notifications</button>` : `<a class="btn ghost small" href="#profil">Installer l'application d'abord</a>`}
      <button class="btn ghost small" data-push-no>Plus tard</button></div></section>`;
    zone.querySelector("[data-push-no]").onclick = () => { try { localStorage.setItem("impara.pushHint", "no"); } catch {} zone.innerHTML = ""; };
    zone.querySelector("[data-push-on]")?.addEventListener("click", async (e) => {
      e.target.disabled = true;
      try { await PWA.enablePush(); toast("Notifications activées 🔔", "ok"); zone.innerHTML = ""; }
      catch (err) { toast(err.message, "warn"); e.target.disabled = false; }
    });
  });

  const form = app.querySelector(".s-add"), msg = form.querySelector(".form-msg");
  form.onsubmit = async (e) => {
    e.preventDefault();
    const btn = form.querySelector("button"); btn.disabled = true; msg.className = "form-msg"; msg.textContent = "";
    try {
      const r = await So.addFriend(form.u.value);
      msg.className = "form-msg ok";
      msg.textContent = r === "accepted" ? "🎉 Vous êtes maintenant amis !" : "✓ Demande envoyée.";
      form.u.value = "";
    } catch (err) { msg.className = "form-msg error"; msg.textContent = err.message; }
    btn.disabled = false;
  };
  app.querySelector("[data-copy]").onclick = async () => {
    try { await navigator.clipboard.writeText(S.me.username); toast("Nom d'utilisateur copié ✓", "ok"); }
    catch { toast(`Votre nom : @${S.me.username}`); }
  };
  page.addEventListener("click", async (e) => {
    const a = e.target.closest("[data-accept]"), r = e.target.closest("[data-remove]");
    if (!a && !r) return;
    (a || r).disabled = true;
    try {
      if (a) { await So.acceptFriend(+a.dataset.accept); toast("🎉 Nouvel ami !", "ok"); }
      else { await So.removeFriendship(+r.dataset.remove); }
    } catch (err) { toast(So.socialError(err), "warn"); (a || r).disabled = false; }
  });
  bindChallengeActions(page);
  const off = So.onSocial(() => paint());
  app._cleanup = off;
}

/* ------------------------- Choix du nom d'utilisateur --------------- */
function renderUsername(app) {
  const suggestion = (state.profile?.pseudo || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9_]/g, "").slice(0, 20);
  app.innerHTML = `
  <header class="page-head"><p class="eyebrow">Amis</p><h1>👥 Choisissez votre nom d'utilisateur</h1>
    <p class="muted">C'est grâce à lui que vos amis pourront vous ajouter. Il est unique et visible des autres utilisateurs.</p></header>
  <form class="card account-card auth-form" data-form="username" autocomplete="off">
    <label class="field"><span>Nom d'utilisateur</span>
      <div class="s-add-row"><span class="s-at">@</span><input name="u" required minlength="3" maxlength="20" value="${esc(suggestion.length >= 3 ? suggestion : "")}" placeholder="ex. thomas_92" autocapitalize="none" spellcheck="false"></div></label>
    <p class="muted small">3 à 20 caractères : lettres minuscules, chiffres et « _ ». Pas d'espace ni d'accent.</p>
    <p class="form-msg" role="alert"></p>
    <button class="btn primary big" type="submit">Valider</button>
  </form>`;
  const form = app.querySelector("form"), msg = form.querySelector(".form-msg");
  form.u.oninput = () => { const v = form.u.value.toLowerCase().replace(/\s/g, "_"); if (v !== form.u.value) form.u.value = v; };
  form.onsubmit = async (e) => {
    e.preventDefault();
    const btn = form.querySelector("button[type=submit]"); btn.disabled = true; msg.className = "form-msg"; msg.textContent = "";
    try { await So.createProfile(form.u.value); toast("Nom d'utilisateur enregistré ✓", "ok"); renderAmis(app); }
    catch (err) { msg.className = "form-msg error"; msg.textContent = err.message; btn.disabled = false; }
  };
  setTimeout(() => form.u.focus(), 50);
}

/* =========================== #ami-<nom> ============================ */
export function renderAmi(app, username) {
  if (gate(app, "Amis")) return;
  const S = So.social();
  const hash = location.hash;
  if (!S.ready) { loadThen(app, () => renderAmi(app, username)); return; }
  if (!S.me) { location.hash = "amis"; return; }
  const f = So.friendByUsername(username);
  if (!f) {
    app.innerHTML = `<section class="card account-card"><p>@${esc(username)} ne fait pas (ou plus) partie de vos amis.</p><a class="btn ghost" href="#amis">← Mes amis</a></section>`;
    return;
  }

  app.innerHTML = `<div class="s-page">
  <a class="back-link" href="#amis">← Mes amis</a>
  <header class="s-friend-head card">
    ${av(f, "xl")}
    <div class="s-friend-id"><h1>${who(f)}</h1>${handle(f)}<p class="muted small">Amis depuis le ${new Date(f.since).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}</p></div>
    <div class="s-friend-actions"><button class="btn primary" data-challenge>⚔️ Lancer un défi</button>
      <button class="link-btn danger-txt" data-unfriend>Retirer des amis</button></div>
  </header>
  <div class="s-grid">
    <div class="s-col">
      <section class="card"><h2 class="h3">📈 Progression</h2><div data-zone="compare"></div></section>
      <section class="card"><h2 class="h3">⚔️ Défis entre vous</h2><div data-zone="challenges"></div></section>
    </div>
    <section class="card s-chat">
      <h2 class="h3">💬 Messages</h2>
      <div class="s-msgs" aria-live="polite"><p class="muted small">Chargement…</p></div>
      <form class="s-send" autocomplete="off">
        <textarea name="m" rows="1" maxlength="1000" placeholder="Écrire à ${who(f)}…" aria-label="Message"></textarea>
        <button class="btn primary" type="submit" aria-label="Envoyer">➤</button>
      </form>
    </section>
  </div></div>`;
  const page = app.firstElementChild;

  const z = (n) => app.querySelector(`[data-zone="${n}"]`);
  const paint = () => {
    const theirs = So.statsOf(f.id); let mine = So.statsOf(S.me.id);
    // Ma progression dans la langue active : la copie locale est la plus à jour
    mine = { ...mine, [code]: So.mySummary() };
    const langs = Object.keys(LANGS).filter((c) => theirs[c] || mine[c]?.level);
    z("compare").innerHTML = langs.length ? langs.map((c) => {
      const t = theirs[c], m = mine[c]?.level ? mine[c] : null;
      const col = (s, label) => s ? `<div class="s-cmp-col"><p class="s-cmp-who">${label}</p>
          <p class="s-cmp-lvl">${esc(s.level)} <small>${esc(s.levelName || "")}</small></p>
          <div class="s-bar"><span style="width:${s.pct}%"></span></div>
          <p class="small muted">${s.pct} % du parcours · ⚡ ${s.xp} XP · 🔥 ${s.streak} j · 📒 ${s.words} mots</p></div>`
        : `<div class="s-cmp-col"><p class="s-cmp-who">${label}</p><p class="muted small">Pas encore commencé</p></div>`;
      return `<div class="s-cmp"><p class="s-cmp-lang"><span class="flag mini">${flagSVG(c)}</span>${esc(LANGS[c].label)}</p>
        <div class="s-cmp-cols">${col(t, who(f))}${col(m, "Vous")}</div></div>`;
    }).join("") : `<p class="muted">${who(f)} n'a pas encore commencé de parcours.</p>`;

    const chs = So.challengesWith(f.id);
    z("challenges").innerHTML = chs.length ? `<ul class="s-ch-list">${chs.slice(0, 15).map((c) => challengeCard(c, { showFriend: false })).join("")}</ul>`
      : `<p class="muted small">Aucun défi pour l'instant. Lancez le premier !</p>`;
  };
  paint();

  // ---- Messages
  const box = app.querySelector(".s-msgs");
  const shown = new Set();
  const bubble = (m) => `<div class="s-msg ${m.sender === S.me.id ? "me" : "them"}" data-id="${m.id}"><p>${esc(m.body)}</p><time>${when(m.created_at)}</time></div>`;
  const add = (list, { initial = false } = {}) => {
    const fresh = list.filter((m) => !shown.has(m.id));
    if (initial) box.innerHTML = "";
    fresh.forEach((m) => shown.add(m.id));
    if (!fresh.length && initial) box.innerHTML = `<p class="muted small s-empty">Aucun message. Dites bonjour à ${who(f)} 👋</p>`;
    if (!fresh.length) return;
    box.querySelector(".s-empty")?.remove();
    box.insertAdjacentHTML("beforeend", fresh.map(bubble).join(""));
    box.scrollTop = box.scrollHeight;
  };
  So.loadMessages(f.id).then((list) => { if (stillHere(hash)) { add(list, { initial: true }); So.markRead(f.id); } })
    .catch((e) => (box.innerHTML = `<p class="form-msg error">${esc(So.socialError(e))}</p>`));

  const form = app.querySelector(".s-send"), ta = form.m;
  const grow = () => { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 140) + "px"; };
  ta.oninput = grow;
  ta.onkeydown = (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); } };
  form.onsubmit = async (e) => {
    e.preventDefault();
    const text = ta.value.trim();
    if (!text) return;
    ta.value = ""; grow();
    try { const m = await So.sendMessage(f.id, text); if (m) add([m]); }
    catch (err) { ta.value = text; toast(err.message, "warn"); }
  };
  // Filet de sécurité : si le temps réel ne passe pas, on recharge régulièrement
  const poll = setInterval(() => {
    if (document.visibilityState === "visible") So.loadMessages(f.id, 30).then((l) => { if (stillHere(hash)) { add(l); So.markRead(f.id); } }).catch(() => {});
  }, 12000);

  app.querySelector("[data-challenge]").onclick = () => askChallenge(f);
  app.querySelector("[data-unfriend]").onclick = async () => {
    const v = await modal({ title: `Retirer ${who(f)} ?`, body: "<p>Vous ne verrez plus sa progression et ne pourrez plus vous écrire. Vous pourrez le réinviter plus tard.</p>",
      actions: [{ label: "Annuler", value: "" }, { label: "Retirer", value: "yes", kind: "danger" }] });
    if (v !== "yes") return;
    try { await So.removeFriendship(f.friendshipId); toast("Ami retiré"); location.hash = "amis"; } catch (e) { toast(So.socialError(e), "warn"); }
  };
  bindChallengeActions(page);

  const off = So.onSocial((what, m) => {
    if (what === "message") { if (m.sender === f.id) { add([m]); So.markRead(f.id); } return; }
    if (what === "unread") return;
    if (!So.friendByUsername(username)) { location.hash = "amis"; return; }
    paint();
  });
  app._cleanup = () => { off(); clearInterval(poll); };
}

/* =========================== #defi-<id> ============================ */
/** Questions du défi : tirées des leçons débloquées dans la langue active */
function pickQuestions(n) {
  const pool = [];
  ALL_LESSONS.filter((l) => P.isLessonUnlocked(l)).forEach((l) => l.quiz.forEach((q, i) => pool.push({ ref: `${l.id}:${i}`, q })));
  LEVELS.forEach((lvl) => { if (P.isExamPassed(lvl.id)) lvl.exam.forEach((q, i) => pool.push({ ref: `exam-${lvl.id}:${i}`, q })); });
  return shuffle(pool).slice(0, n);
}

export function renderDefi(app, id) {
  if (gate(app, "Défi")) return;
  const hash = location.hash;
  loading(app);
  So.getChallenge(id).then((c) => {
    if (!stillHere(hash)) return;
    if (!c) { app.innerHTML = `<section class="card account-card"><p>Ce défi est introuvable.</p><a class="btn ghost" href="#amis">← Amis</a></section>`; return; }
    if (c.stage !== "to_play") return showDefi(app, c);
    const qs = pickQuestions(c.n);
    app.innerHTML = `
    <a class="back-link" href="#amis">← Amis</a>
    <section class="card s-defi-intro">
      <p class="eyebrow">Défi</p>
      <div class="s-vs">${av(So.social().me, "xl")}<span class="s-vs-x">VS</span>${av(c.friend, "xl")}</div>
      <h1>⚔️ Vous contre ${who(c.friend)}</h1>
      <p class="lead">${qs.length} questions de <b>${esc(L.label.toLowerCase())}</b> <span class="flag mini">${flagSVG(code)}</span>, tirées des leçons que vous avez débloquées.</p>
      <p class="muted">Le meilleur score gagne ; à égalité, le plus rapide. Une seule tentative : le chrono démarre quand vous cliquez.</p>
      <p class="muted small">Vous apprenez aussi une autre langue ? Changez de langue en haut de la page avant de commencer.</p>
      ${c.theirs ? `<p class="chip">${who(c.friend)} a déjà joué : à vous de faire mieux !</p>` : ""}
      <button class="btn primary big" data-go>C'est parti !</button>
    </section>`;
    app.querySelector("[data-go]").onclick = () => play(app, c, qs);
  }).catch((e) => { app.innerHTML = `<section class="card"><p class="form-msg error">${esc(So.socialError(e))}</p></section>`; });
}

function play(app, c, questions) {
  document.body.classList.add("focus-mode");
  const t0 = performance.now();
  runQuiz(app, {
    title: `Défi contre ${c.friend?.pseudo || c.friend?.username || "un ami"}`,
    questions,
    onQuit: async () => {
      document.body.classList.remove("focus-mode");
      location.hash = "amis";
    },
    onFinish: async (results) => {
      document.body.classList.remove("focus-mode");
      const ms = performance.now() - t0;
      const score = results.filter((r) => r.correct).length;
      app.innerHTML = `<p class="muted s-loading">Envoi de votre score…</p>`;
      try {
        await So.submitChallenge(c.id, { score, total: results.length, ms });
        const v = await So.getChallenge(c.id);
        showDefi(app, v, true);
      } catch (e) {
        app.innerHTML = `<section class="card account-card"><p class="form-msg error">${esc(e.message)}</p>
          <p>Votre score : ${score}/${results.length}</p><a class="btn ghost" href="#amis">← Amis</a></section>`;
      }
    },
  });
}

function showDefi(app, c, justPlayed = false) {
  const f = c.friend;
  const line = (r, label, p) => r ? `<div class="s-res-col">${av(p, "lg")}<p class="s-res-who">${label}</p>
      ${ring(Math.round((r.score / r.total) * 100), 96, 9)}<p><b>${r.score}/${r.total}</b> <span class="flag mini">${flagSVG(r.lang)}</span></p><p class="muted small">⏱ ${secs(r.ms)}</p></div>`
    : `<div class="s-res-col">${av(p, "lg")}<p class="s-res-who">${label}</p><p class="muted">${c.stage === "to_accept" || c.stage === "waiting_accept" ? "—" : "Pas encore joué"}</p></div>`;
  const head = {
    done: { win: "🏆 Victoire !", lose: `${who(f)} l'emporte`, draw: "🤝 Égalité parfaite" }[c.outcome],
    waiting_play: "Score envoyé ✓",
    to_accept: `${who(f)} vous défie`,
    waiting_accept: `En attente de ${who(f)}`,
    declined: "Défi refusé",
    cancelled: "Défi annulé",
  }[c.stage] || "Défi";
  const sub = {
    waiting_play: `Le résultat s'affichera quand ${who(f)} aura joué.`,
    done: c.outcome === "win" ? "Bien joué ! Prêt pour la revanche ?" : c.outcome === "lose" ? "La revanche vous attend !" : "Même score, même temps : impressionnant.",
  }[c.stage] || "";
  app.innerHTML = `<div class="s-page">
  <a class="back-link" href="#ami-${esc(f?.username || "")}">← ${who(f)}</a>
  <section class="card s-defi-res ${c.outcome || ""}">
    <p class="eyebrow">Défi · ${c.n} questions</p>
    <h1>${head}</h1>${sub ? `<p class="muted">${sub}</p>` : ""}
    <div class="s-res">${line(c.mine, "Vous", So.social().me)}<span class="s-vs-x">VS</span>${line(c.theirs, who(f), f)}</div>
    <div class="result-actions">
      ${c.stage === "to_accept" ? `<button class="btn primary big" data-ch-accept="${c.id}">Accepter le défi</button>` : ""}
      ${c.stage === "done" && f ? `<button class="btn primary big" data-rematch>⚔️ Revanche</button>` : ""}
      <a class="btn ghost" href="#ami-${esc(f?.username || "")}">💬 Voir ${who(f)}</a>
    </div>
  </section></div>`;
  if (justPlayed && c.outcome === "win") celebrate();
  app.querySelector("[data-rematch]")?.addEventListener("click", () => askChallenge(f));
  bindChallengeActions(app.firstElementChild);
  const off = So.onSocial((what) => {
    if (what !== "all") return;
    const fresh = So.allChallenges().find((x) => x.id === c.id);
    if (fresh && fresh.stage !== c.stage) { off(); showDefi(app, fresh, fresh.stage === "done" && justPlayed); }
  });
  app._cleanup = off;
}
