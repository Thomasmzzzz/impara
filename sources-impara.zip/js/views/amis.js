/* =====================================================================
   Vues sociales
   - #amis          : nom d'utilisateur, ajout d'amis, demandes, défis
   - #ami-<pseudo>  : progression comparée, défis et messages avec un ami
   - #defi-<id>     : jouer un défi
   ===================================================================== */

import { state } from "../core/storage.js";
import { L, LANGS, code, flagSVG } from "../core/lang.js";
import { esc, toast, modal, shuffle, ring, celebrate } from "../core/ui.js";
import { runQuiz } from "../core/quiz-engine.js";
import * as P from "../core/progress.js";
import { ALL_LESSONS, LEVELS } from "../data/curriculum.js";
import { isConfigured } from "../core/cloud.js";
import * as So from "../core/social.js";
import * as PWA from "../core/pwa.js";
import * as CG from "../core/challenge-gen.js";

/* ------------------------------ Outils ----------------------------- */
const who = (p) => esc(p?.pseudo || p?.username || "Ami");
const av = (p, cls = "") => `<span class="s-avatar ${cls}"${p?.color ? ` style="background:${esc(p.color)}"` : ""}>${esc(p?.avatar || "👤")}</span>`;
const handle = (p) => (p?.username ? `<span class="s-handle">@${esc(p.username)}</span>` : "");
const stillHere = (hash) => location.hash === hash;

function when(ts) {
  const d = new Date(ts), now = new Date();
  const hm = d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  if (d.toDateString() === now.toDateString()) return hm;
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return `hier ${hm}`;
  return `${d.toLocaleDateString("fr-FR", { day: "numeric", month: "short" })} ${hm}`;
}
const secs = (ms) => (ms < 60000 ? `${Math.round(ms / 1000)} s` : `${Math.floor(ms / 60000)} min ${String(Math.round((ms % 60000) / 1000)).padStart(2, "0")}`);

/** Écrans communs : pas de serveur / pas connecté / chargement */
function gate(app, title) {
  if (!isConfigured()) {
    app.innerHTML = `<header class="page-head"><p class="eyebrow">Amis</p><h1>👥 ${title}</h1></header>
      <section class="card"><p>L'espace amis nécessite les comptes en ligne, qui ne sont pas activés sur ce site.</p></section>`;
    return true;
  }
  if (!So.isAvailable()) {
    app.innerHTML = `<header class="page-head"><p class="eyebrow">Amis</p><h1>👥 ${title}</h1>
      <p class="muted">Ajoutez vos amis, suivez leurs progrès, discutez et lancez-vous des défis.</p></header>
      <section class="card account-card"><p>Connectez-vous pour accéder à l'espace amis.</p>
      <a class="btn primary" href="#compte">☁️ Se connecter ou créer un compte</a></section>`;
    return true;
  }
  return false;
}
const skelRows = (n = 4) => Array.from({ length: n }, () => `<div class="skel-row"><span class="skel skel-av"></span><span class="skel-lines"><span class="skel skel-l1"></span><span class="skel skel-l2"></span></span></div>`).join("");
const loading = (app) => (app.innerHTML = `<div class="s-page skel-page" aria-busy="true" aria-label="Chargement"><span class="skel skel-title"></span><section class="card">${skelRows(5)}</section></div>`);
/** Charge les données sociales puis affiche ; en cas d'échec, message + bouton Réessayer */
function loadThen(app, render) {
  const hash = location.hash;
  loading(app);
  So.refresh().then(() => { if (stillHere(hash) && So.social().ready) { app._cleanup?.(); app._cleanup = null; render(); } })
    .catch((e) => {
      if (!stillHere(hash)) return;
      app.innerHTML = `<section class="card account-card"><p class="form-msg error">${esc(So.socialError(e))}</p>
        <button class="btn primary" data-retry>Réessayer</button></section>`;
      app.querySelector("[data-retry]").onclick = () => loadThen(app, render);
    });
}

/* ---------------------------- Cartes défi -------------------------- */
const OUT = { win: ["🏆", "Victoire", "win"], lose: ["😤", "Défaite", "lose"], draw: ["🤝", "Égalité", "draw"] };
function challengeCard(c, { showFriend = true } = {}) {
  const f = c.friend;
  const langs = (r) => (r?.lang ? `<span class="flag mini">${flagSVG(r.lang)}</span>` : "");
  let status = "", actions = "", cls = "", score = "";
  switch (c.stage) {
    case "to_accept":
      status = c.live ? `⚡ <b>${who(f)}</b> vous défie en direct !` : `<b>${who(f)}</b> vous défie !`; cls = "todo";
      actions = `<button class="btn primary small" data-ch-accept="${c.id}">Accepter</button><button class="btn ghost small" data-ch-decline="${c.id}">Refuser</button>`;
      break;
    case "waiting_accept":
      status = `Défi envoyé à <b>${who(f)}</b>`; cls = "wait";
      actions = `${c.live ? `<a class="btn primary small" href="#defi-${c.id}">⚡ Salle</a>` : ""}<button class="btn ghost small" data-ch-cancel="${c.id}">Annuler</button>`;
      break;
    case "to_play":
      status = c.theirs ? `<b>${who(f)}</b> a fait ${c.theirs.score}/${c.theirs.total} : à vous !` : `À vous de jouer contre <b>${who(f)}</b>`; cls = "todo";
      actions = `<a class="btn primary small" href="#defi-${c.id}">⚔️ Jouer</a>`;
      break;
    case "waiting_play":
      status = `En attente de <b>${who(f)}</b>`; cls = "wait";
      score = `<span class="ch-score">${c.mine.score}/${c.mine.total}</span>`;
      break;
    case "done": {
      const [ico, label, k] = OUT[c.outcome]; cls = k;
      status = `<b class="s-outcome">${ico} ${label}</b> contre ${who(f)}`;
      score = `<span class="ch-score">${c.mine.score}<i>–</i>${c.theirs.score}</span>`;
      break;
    }
    case "declined": status = `${c.iAmChallenger ? `${who(f)} a refusé` : "Vous avez refusé"} le défi`; cls = "off"; break;
    case "cancelled": status = "Défi annulé"; cls = "off"; break;
  }
  const link = ["done", "waiting_play", "to_play", "to_accept"].includes(c.stage) ? `href="#defi-${c.id}"` : "";
  return `<li class="s-challenge ${cls}">
    ${link ? `<a class="ch-link" ${link} aria-label="Voir le défi"></a>` : ""}
    ${showFriend ? av(f, "sm") : `<span class="s-ch-icon">⚔️</span>`}
    <div class="s-ch-body"><p>${status}</p><small class="muted">${c.n} questions · ${modeLabel(c.mode)}${c.live ? " · ⚡ En direct" : ""} · ${when(c.created_at)}${c.mine?.lang ? " · " + langs(c.mine) : ""}</small></div>
    ${score}
    ${actions ? `<div class="s-ch-actions">${actions}</div>` : ""}
  </li>`;
}

/** Boutons d'action des défis (délégation) */
function bindChallengeActions(root) {
  root.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-ch-accept],[data-ch-decline],[data-ch-cancel]");
    if (!b) return;
    e.preventDefault();
    b.disabled = true;
    try {
      const chN = So.allChallenges().find((x) => x.id === b.dataset.chAccept)?.n || 5;
      if (b.dataset.chAccept && !CG.canChallenge(chN)) { b.disabled = false; return notEnoughWords(`Pas assez de mots pour ${chN} questions`, chN); }
      if (b.dataset.chAccept) { await So.respondChallenge(b.dataset.chAccept, true); toast("Défi accepté ⚔️", "ok");
        if (location.hash === `#defi-${b.dataset.chAccept}`) window.dispatchEvent(new HashChangeEvent("hashchange"));
        else location.hash = `defi-${b.dataset.chAccept}`; }
      else if (b.dataset.chDecline) { await So.respondChallenge(b.dataset.chDecline, false); toast("Défi refusé"); }
      else { await So.cancelChallenge(b.dataset.chCancel); toast("Défi annulé"); }
    } catch (err) { toast(err.message, "warn"); b.disabled = false; }
  });
}

const MODES = {
  speed: ["⏱️ Vitesse", "Le temps compte : 100 pts par bonne réponse, −3 pts par seconde"],
  precision: ["🎯 Précision", "Seules les bonnes réponses comptent, prenez votre temps"],
};
const modeLabel = (m) => (MODES[m] ? MODES[m][0] : "⏱️ Classique");

/** Tailles possibles pour un adversaire : il faut assez de mots des DEUX côtés */
function sizeState(n, friend) {
  const mine = CG.learnedWords().length, need = CG.wordsNeeded(n);
  if (mine < need) return { ok: false, why: `Il vous faut ${need} mots` };
  if (!friend) return { ok: true };
  const theirs = So.friendWords(friend.id);
  if (theirs == null) return n <= 15 ? { ok: true } : { ok: false, why: `Progression de ${who(friend)} inconnue` };
  if (theirs < need) return { ok: false, why: `${who(friend)} : ${theirs} mots` };
  return { ok: true };
}
function paintSizes() {
  const fr = So.friends();
  const friend = pendingPick.fixed || fr.find((f) => f.id === pendingPick.friend) || null;
  let firstOk = null;
  document.querySelectorAll("[data-ns] [data-n]").forEach((b) => {
    const st = sizeState(+b.dataset.n, friend);
    b.disabled = !st.ok;
    b.querySelector("small").textContent = st.ok ? b.dataset.t : `🔒 ${st.why}`;
    if (st.ok && firstOk == null) firstOk = +b.dataset.n;
  });
  // Taille choisie devenue impossible (autre ami) : on se replie sur la plus grande possible
  const cur = document.querySelector(`[data-ns] [data-n="${pendingPick.n}"]`);
  if (cur?.disabled) {
    const ok = [...document.querySelectorAll("[data-ns] [data-n]:not(:disabled)")].pop();
    pendingPick.n = ok ? +ok.dataset.n : null;
  }
  document.querySelectorAll("[data-ns] [data-n]").forEach((x) => x.classList.toggle("on", +x.dataset.n === pendingPick.n));
}

/** Lancer un défi : ami, nombre de questions et mode */
async function askChallenge(friend = null) {
  if (!CG.canChallenge(5)) return notEnoughWords("Pas encore assez de mots pour défier", 5);
  const fr = So.friends();
  if (!friend && !fr.length) { toast("Ajoutez d'abord un ami depuis votre profil", "warn"); return; }
  let target = friend || (fr.length === 1 ? fr[0] : null);
  Object.assign(pendingPick, { friend: target?.id || null, fixed: friend, n: 10, mode: pendingPick.mode || "speed" });
  if (!sizeState(10, target).ok) pendingPick.n = 5;
  const rec = (f) => { const r = So.record(f.id); return r.total ? `${r.win}V · ${r.lose}D${r.draw ? ` · ${r.draw}N` : ""}` : "Premier duel"; };
  const v = await modal({
    title: friend ? `⚔️ Défier ${who(friend)}` : "⚔️ Nouveau défi",
    body: `${friend ? "" : `<p class="set-label">Adversaire</p><div class="pick-friends">${fr.map((f) => `<button type="button" class="pick-friend ${target?.id === f.id ? "on" : ""}" data-f="${f.id}">${av(f, "sm")}<b>${who(f)}</b><small>${rec(f)}</small></button>`).join("")}</div>`}
      <p class="set-label">Nombre de questions</p>
      <div class="n-grid" data-ns>${CG.CHALLENGE_SIZES.map(([k, l, t]) => `<button type="button" data-n="${k}" data-t="${t}"><b>${k}</b><span>${l}</span><small>${t}</small></button>`).join("")}</div>
      <p class="small muted">Il faut avoir appris au moins autant de mots que de questions, vous <b>et</b> votre adversaire.</p>
      <p class="set-label">Mode</p>
      <div class="mode-pick" data-modes>${Object.entries(MODES).map(([k, [l, d]]) => `<button type="button" data-mode="${k}" class="${pendingPick.mode === k ? "on" : ""}"><b>${l}</b><small>${d}</small></button>`).join("")}</div>
      <label class="live-opt"><input type="checkbox" data-live ${pendingPick.live ? "checked" : ""}><span class="live-txt"><b>⚡ En direct</b><small>Vous jouez en même temps et voyez la progression de l'autre en temps réel</small></span></label>
      <ul class="defi-rules"><li>🎲 Questions variées sur <b>vos mots appris</b>, chacun dans sa langue</li><li>⏳ Votre ami doit accepter${""}, puis chacun joue quand il veut (ou ensemble en direct)</li></ul>`,
    actions: [{ label: "Annuler", value: "" }, { label: "⚔️ Lancer le défi", value: "go", kind: "primary" }],
    onOpen: paintSizes,
  });
  if (v !== "go") return;
  target = friend || fr.find((f) => f.id === pendingPick.friend) || null;
  if (!target) { toast("Choisissez un adversaire", "warn"); return askChallenge(null); }
  const n = pendingPick.n;
  if (!n || !sizeState(n, target).ok) { toast("Ce nombre de questions n'est pas possible avec cet adversaire", "warn"); return askChallenge(friend); }
  try {
    const id = await So.createChallenge(target.id, n, pendingPick.mode, pendingPick.live);
    toast(`${pendingPick.live ? "Duel en direct" : "Défi"} envoyé à ${target.pseudo || target.username} ⚔️`, "ok");
    if (pendingPick.live && id) location.hash = `defi-${id}`; // salle d'attente du duel
  } catch (e) { toast(e.message, "warn"); }
}
document.addEventListener("click", (e) => {
  // Sélections dans la fenêtre « Nouveau défi »
  const pf = e.target.closest(".pick-friend"), pn = e.target.closest("[data-ns] [data-n]"), pm = e.target.closest("[data-modes] [data-mode]");
  if (pf) { document.querySelectorAll(".pick-friend").forEach((x) => x.classList.toggle("on", x === pf)); pendingPick.friend = pf.dataset.f; paintSizes(); }
  if (pn && !pn.disabled) { pendingPick.n = +pn.dataset.n; paintSizes(); }
  if (pm) { document.querySelectorAll("[data-modes] [data-mode]").forEach((x) => x.classList.toggle("on", x === pm)); pendingPick.mode = pm.dataset.mode; }
});
const pendingPick = { friend: null, fixed: null, n: null, mode: "speed", live: false };
document.addEventListener("change", (e) => { if (e.target.matches?.("[data-live]")) pendingPick.live = e.target.checked; });

/* ============================== #amis ============================== */
let tab = "classement"; // onglet actif : classement | fil | defis | amis
const MEDALS = ["🥇", "🥈", "🥉"];
const weekLabel = (start) => {
  const end = new Date(start); end.setUTCDate(end.getUTCDate() + 6);
  const f = (d) => d.toLocaleDateString("fr-FR", { day: "numeric", month: "short", timeZone: "UTC" });
  return `${f(start)} – ${f(end)}`;
};
function countdown() {
  const ms = P.nextWeekReset() - Date.now(), d = Math.floor(ms / 864e5), h = Math.floor((ms % 864e5) / 36e5), m = Math.floor((ms % 36e5) / 6e4);
  return d ? `${d} j ${h} h` : h ? `${h} h ${m} min` : `${m} min`;
}

export function renderAmis(app, opts = {}) {
  if (opts.tab) tab = opts.tab;
  if (gate(app, "Amis")) return;
  const S = So.social();
  if (!S.ready) { loadThen(app, () => renderAmis(app, opts)); return; }
  if (!S.me) return renderUsername(app);

  app.innerHTML = `<div class="s-page fr-page">
  <header class="fr-head">
    <div><h1>👥 Amis</h1><p class="muted small">Vous êtes <b class="s-me">@${esc(S.me.username)}</b></p></div>
    <a class="btn ghost small" href="#profil-ajout">👤＋ Ajouter</a>
  </header>
  <div data-zone="push"></div>
  <div data-zone="requests"></div>
  <nav class="fr-tabs" role="tablist">
    <button role="tab" data-tab-btn="classement">🏆 Classement</button>
    <button role="tab" data-tab-btn="defis">⚔️ Défis <em class="err-badge" data-b="defis" hidden></em></button>
    <button role="tab" data-tab-btn="amis">👥 Amis <em class="err-badge" data-b="amis" hidden></em></button>
    <button role="tab" data-tab-btn="fil">📰 Fil</button>
  </nav>
  <div data-zone="panel"></div>
  </div>`;
  const page = app.firstElementChild;
  const z = (n) => page.querySelector(`[data-zone="${n}"]`);
  let history = null; // historique chargé une fois par visite

  const paint = () => {
    if (!page.isConnected) return off?.();
    const inc = So.incoming(), all = So.allChallenges(), fr = So.friends();
    const todo = all.filter((c) => c.stage === "to_accept" || c.stage === "to_play");
    const unread = Object.values(S.unread).reduce((a, b) => a + b, 0);
    z("requests").innerHTML = inc.length ? `<section class="card s-highlight fr-req"><h2 class="h3">📬 ${inc.length > 1 ? `${inc.length} demandes d'ami` : "Demande d'ami"}</h2><ul class="s-list">
      ${inc.map((r) => `<li class="s-row">${av(r.from)}<div class="s-row-txt"><b>${who(r.from)}</b>${handle(r.from)}</div>
        <div class="s-row-actions"><button class="btn primary small" data-accept="${r.id}">Accepter</button><button class="btn ghost small" data-remove="${r.id}">Refuser</button></div></li>`).join("")}
      </ul></section>` : "";
    const badge = (k, n) => { const b = page.querySelector(`[data-b="${k}"]`); b.textContent = n; b.hidden = !n; };
    badge("defis", todo.length); badge("amis", unread);
    page.querySelectorAll("[data-tab-btn]").forEach((b) => { b.classList.toggle("on", b.dataset.tabBtn === tab); b.setAttribute("aria-selected", b.dataset.tabBtn === tab); });
    z("panel").innerHTML = tab === "classement" ? panelBoard(fr) : tab === "fil" ? panelFeed() : tab === "defis" ? panelDefis(all, fr) : panelAmis(fr);
    if (tab === "classement") paintHistory();
  };

  /* ---- 🏆 Classement : podium de la semaine + semaines précédentes */
  function panelBoard(fr) {
    const board = So.leaderboard();
    if (board.length < 2) return `<section class="card fr-empty"><span>🏆</span><p>Ajoutez des amis pour comparer vos XP chaque semaine.</p><a class="btn primary" href="#profil-ajout">👤＋ Ajouter un ami</a></section>`;
    const top = board.slice(0, 3), order = [top[1], top[0], top[2]].filter(Boolean);
    return `<section class="card fr-board">
      <div class="fr-board-head"><h2 class="h3">Cette semaine</h2><span class="chip">⏳ Fin dans ${countdown()}</span></div>
      <div class="podium">${order.map((p) => { const i = board.indexOf(p); return `
        <div class="pod pod-${i + 1} ${p.isMe ? "me" : ""}">
          ${i === 0 && p.xp ? `<span class="crown">👑</span>` : ""}${av(p, "lg")}
          <b>${p.isMe ? "Vous" : who(p)}</b><small>${p.xp} XP</small>
          <div class="pod-block">${p.xp ? MEDALS[i] : "–"}</div></div>`; }).join("")}</div>
      ${board.length > 3 ? `<ol class="s-board" start="4">${board.slice(3).map((p, k) => `<li class="${p.isMe ? "me" : ""}"><span class="s-rank">${k + 4}</span>${av(p, "sm")}
        <span class="s-board-name">${p.isMe ? "Vous" : who(p)}<small>${p.allXp} XP au total</small></span><b>${p.xp} XP</b></li>`).join("")}</ol>` : ""}
      <p class="muted small">XP gagnés depuis lundi (toutes langues), en direct. Nouvelle semaine : <b>${P.nextWeekReset().toLocaleString("fr-FR", { weekday: "long", hour: "2-digit", minute: "2-digit" })}</b> (votre heure).</p>
    </section>
    <section class="card"><h2 class="h3">📜 Semaines précédentes</h2><div data-zone="history" aria-busy="true">${skelRows(3)}</div></section>`;
  }
  async function paintHistory() {
    const zone = z("history"); if (!zone) return;
    try { history ||= await So.weeklyHistory(12); } catch { zone.innerHTML = `<p class="muted small">Historique indisponible pour le moment.</p>`; return; }
    if (!z("history")) return;
    if (!history.length) { z("history").innerHTML = `<p class="muted small">Le premier gagnant sera couronné lundi. Revenez voir le palmarès !</p>`; return; }
    const titles = new Map();
    history.forEach((w) => { const id = w.ranking[0].id; titles.set(id, (titles.get(id) || 0) + 1); });
    const champs = [...titles.entries()].sort((a, b) => b[1] - a[1]).map(([id, n]) => {
      const p = id === S.me.id ? S.me : S.profiles[id];
      return `<span class="champ">${av(p, "sm")}<b>${id === S.me.id ? "Vous" : who(p)}</b> 👑×${n}</span>`;
    }).join("");
    z("history").innerHTML = `<div class="champs">${champs}</div><ul class="hist">${history.map((w, k) => `
      <li><details ${k === 0 ? "open" : ""}><summary><span class="hist-week">${weekLabel(w.start)}</span>
        <span class="hist-win">👑 ${av(w.ranking[0].profile, "sm")}<b>${w.ranking[0].isMe ? "Vous" : who(w.ranking[0].profile)}</b><small>${w.ranking[0].xp} XP</small></span></summary>
        <ol class="s-board">${w.ranking.map((r, i) => `<li class="${r.isMe ? "me" : ""}"><span class="s-rank">${MEDALS[i] || i + 1}</span>${av(r.profile, "sm")}
          <span class="s-board-name">${r.isMe ? "Vous" : who(r.profile)}</span><b>${r.xp} XP</b></li>`).join("")}</ol></details></li>`).join("")}</ul>`;
  }

  /* ---- 📰 Fil : les grandes étapes de chacun, avec réactions */
  function panelFeed() {
    const list = So.feed();
    if (!list) { So.loadFeed().catch(() => {}); return `<section class="card" aria-busy="true">${skelRows(4)}</section>`; }
    if (!list.length) return `<section class="card fr-empty"><span>📰</span><p>Rien pour l'instant. Niveaux terminés, séries, mots appris, défis gagnés : les grandes étapes de vos amis et les vôtres apparaîtront ici.</p></section>`;
    return `<section class="card feed-card"><ul class="feed">${list.map(feedItem).join("")}</ul>
      <p class="muted small">Réagissez aux étapes de vos amis : ils reçoivent une notification.</p></section>`;
  }
  function feedItem(a) {
    const { icon, text } = So.activityText(a);
    const mineRx = a.reactions.find((r) => r.user_id === S.me.id)?.emoji;
    const nameOf = (r) => (r.user_id === S.me.id ? "vous" : who(S.profiles[r.user_id]));
    const rx = So.REACTIONS.map((e) => {
      const rs = a.reactions.filter((r) => r.emoji === e);
      if (a.mine && !rs.length) return "";
      return `<button class="rx ${mineRx === e ? "on" : ""}" data-rx="${a.id}" data-e="${e}" ${a.mine ? "disabled" : ""} title="${esc(rs.map(nameOf).join(", "))}">${e}${rs.length ? `<i>${rs.length}</i>` : ""}</button>`;
    }).join("");
    const by = a.reactions.length ? `<p class="feed-by">${a.reactions.slice(0, 4).map((r) => `${r.emoji} ${esc(nameOf(r))}`).join(" · ")}${a.reactions.length > 4 ? ` · +${a.reactions.length - 4}` : ""}</p>` : "";
    const link = a.mine ? "#profil" : a.who ? `#ami-${esc(a.who.username)}` : "#amis";
    return `<li class="feed-item ${a.mine ? "mine" : ""}">
      <a class="feed-av" href="${link}">${av(a.who)}<span class="feed-ico">${icon}</span></a>
      <div class="feed-body"><p><b>${a.mine ? "Vous" : who(a.who)}</b> ${a.mine ? "avez " + text.slice(2) : text}</p>
        <small class="muted">${when(a.created_at)}${a.lang ? ` · <span class="flag mini">${flagSVG(a.lang)}</span>` : ""}</small>
        ${rx ? `<div class="rx-row">${rx}</div>` : ""}${by}</div></li>`;
  }

  /* ---- ⚔️ Défis : bilan, nouveau défi, à jouer / en attente / terminés */
  function panelDefis(all, fr) {
    const r = So.record(), rate = r.total ? Math.round((r.win / r.total) * 100) : 0;
    const group = (title, list, empty) => `<section class="card"><h2 class="h3">${title}</h2>${list.length ? `<ul class="s-ch-list">${list.map((c) => challengeCard(c)).join("")}</ul>` : `<p class="muted small">${empty}</p>`}</section>`;
    return `<section class="card fr-record">
        <div class="rec"><b>${r.win}</b><small>🏆 Victoires</small></div>
        <div class="rec"><b>${r.draw}</b><small>🤝 Égalités</small></div>
        <div class="rec"><b>${r.lose}</b><small>😤 Défaites</small></div>
        <div class="rec"><b>${rate}%</b><small>Taux de victoire</small></div>
        <button class="btn primary fr-new" data-new ${fr.length ? "" : "disabled"}>⚔️ Nouveau défi</button>
      </section>
      ${group("🔔 À vous de jouer", all.filter((c) => c.stage === "to_accept" || c.stage === "to_play"), "Rien à jouer pour l'instant.")}
      ${group("⏳ En attente", all.filter((c) => c.stage === "waiting_accept" || c.stage === "waiting_play"), "Aucun défi en attente.")}
      ${group("📜 Terminés", all.filter((c) => ["done", "declined", "cancelled"].includes(c.stage)).slice(0, 20), fr.length ? "Lancez votre premier défi !" : "Ajoutez un ami pour lancer votre premier défi.")}`;
  }

  /* ---- 👥 Amis : liste, messages non lus, demandes envoyées */
  function panelAmis(fr) {
    const out = So.outgoing();
    return `<section class="card">
      ${fr.length ? `<ul class="s-list">${fr.map((f) => {
        const st = So.statsOf(f.id), n = S.unread[f.id] || 0, rec = So.record(f.id);
        const chips = Object.keys(LANGS).filter((c) => st[c]).map((c) => `<span class="s-lang-chip"><span class="flag mini">${flagSVG(c)}</span>${esc(st[c].level)} · ${st[c].pct}%</span>`).join("");
        return `<li><a class="s-row s-friend" href="#ami-${esc(f.username)}">${av(f)}
          <div class="s-row-txt"><b>${who(f)}</b>${handle(f)}<div class="s-chips">${chips || `<small class="muted">Pas encore de progression</small>`}${rec.total ? `<span class="s-lang-chip">⚔️ ${rec.win}–${rec.lose}</span>` : ""}</div></div>
          ${n ? `<span class="s-unread" title="${n} message(s) non lu(s)">💬 ${n}</span>` : ""}<span class="s-go">›</span></a></li>`;
      }).join("")}</ul>` : `<div class="fr-empty"><span>👋</span><p>Vous n'avez pas encore d'amis ici.</p><a class="btn primary" href="#profil-ajout">👤＋ Ajouter un ami</a></div>`}
    </section>
    ${out.length ? `<section class="card"><h2 class="h3">📤 Demandes envoyées</h2><ul class="s-list">
      ${out.map((r) => `<li class="s-row">${av(r.to)}<div class="s-row-txt"><b>${who(r.to)}</b>${handle(r.to)}<small class="muted">En attente</small></div>
        <div class="s-row-actions"><button class="btn ghost small" data-remove="${r.id}">Annuler</button></div></li>`).join("")}</ul></section>` : ""}`;
  }

  paint();

  // Invitation à activer les notifications (si possible et pas encore fait)
  PWA.pushState().then((st) => {
    const zone = z("push");
    if (!zone || (st !== "off" && st !== "needs-install")) return;
    let hidden = false; try { hidden = localStorage.getItem("impara.pushHint") === "no"; } catch {}
    if (hidden) return;
    zone.innerHTML = `<section class="card s-push-hint"><p>🔔 <b>Soyez prévenu</b> quand un ami vous écrit ou vous lance un défi.</p>
      <div class="btn-row">${st === "off" ? `<button class="btn primary small" data-push-on>Activer les notifications</button>` : `<a class="btn ghost small" href="#reglages">Installer l'application d'abord</a>`}
      <button class="btn ghost small" data-push-no>Plus tard</button></div></section>`;
    zone.querySelector("[data-push-no]").onclick = () => { try { localStorage.setItem("impara.pushHint", "no"); } catch {} zone.innerHTML = ""; };
    zone.querySelector("[data-push-on]")?.addEventListener("click", async (e) => {
      e.target.disabled = true;
      try { await PWA.enablePush(); toast("Notifications activées 🔔", "ok"); zone.innerHTML = ""; }
      catch (err) { toast(err.message, "warn"); e.target.disabled = false; }
    });
  });

  page.addEventListener("click", async (e) => {
    const t = e.target.closest("[data-tab-btn]");
    if (t) { tab = t.dataset.tabBtn; paint(); return; }
    if (e.target.closest("[data-new]")) { askChallenge(); return; }
    const rx = e.target.closest("[data-rx]");
    if (rx) { rx.disabled = true; try { await So.react(+rx.dataset.rx, rx.dataset.e); } catch (err) { toast(So.socialError(err), "warn"); rx.disabled = false; } return; }
    const a = e.target.closest("[data-accept]"), r = e.target.closest("[data-remove]");
    if (!a && !r) return;
    (a || r).disabled = true;
    try {
      if (a) { await So.acceptFriend(+a.dataset.accept); toast("🎉 Nouvel ami !", "ok"); }
      else { await So.removeFriendship(+r.dataset.remove); }
    } catch (err) { toast(So.socialError(err), "warn"); (a || r).disabled = false; }
  });
  bindChallengeActions(page);
  const off = So.onSocial((what) => { if (what !== "message") paint(); else paint(); });
  // Le compte à rebours du classement se met à jour toutes les minutes
  const tick = setInterval(() => { const c = page.querySelector(".fr-board .chip"); if (c) c.textContent = `⏳ Fin dans ${countdown()}`; }, 60000);
  app._cleanup = () => { off(); clearInterval(tick); };
}

/* ------------------------- Choix du nom d'utilisateur --------------- */
function renderUsername(app) {
  const suggestion = (state.profile?.pseudo || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9_]/g, "").slice(0, 20);
  app.innerHTML = `
  <header class="page-head"><p class="eyebrow">Amis</p><h1>👥 Choisissez votre nom d'utilisateur</h1>
    <p class="muted">C'est grâce à lui que vos amis pourront vous ajouter. Il est unique et visible des autres utilisateurs.</p></header>
  <form class="card account-card auth-form" data-form="username" autocomplete="off">
    <label class="field"><span>Nom d'utilisateur</span>
      <div class="s-add-row"><span class="s-at">@</span><input name="u" required minlength="3" maxlength="20" value="${esc(suggestion.length >= 3 ? suggestion : "")}" placeholder="ex. thomas_92" autocapitalize="none" spellcheck="false"></div></label>
    <p class="muted small">3 à 20 caractères : lettres minuscules, chiffres et « _ ». Pas d'espace ni d'accent.</p>
    <p class="form-msg" role="alert"></p>
    <button class="btn primary big" type="submit">Valider</button>
  </form>`;
  const form = app.querySelector("form"), msg = form.querySelector(".form-msg");
  form.u.oninput = () => { const v = form.u.value.toLowerCase().replace(/\s/g, "_"); if (v !== form.u.value) form.u.value = v; };
  form.onsubmit = async (e) => {
    e.preventDefault();
    const btn = form.querySelector("button[type=submit]"); btn.disabled = true; msg.className = "form-msg"; msg.textContent = "";
    try { await So.createProfile(form.u.value); toast("Nom d'utilisateur enregistré ✓", "ok"); renderAmis(app); }
    catch (err) { msg.className = "form-msg error"; msg.textContent = err.message; btn.disabled = false; }
  };
  setTimeout(() => form.u.focus(), 50);
}

/* =========================== #ami-<nom> ============================ */
export function renderAmi(app, username) {
  if (gate(app, "Amis")) return;
  const S = So.social();
  if (!S.ready) { loadThen(app, () => renderAmi(app, username)); return; }
  if (!S.me) { location.hash = "amis"; return; }
  const f = So.friendByUsername(username);
  if (!f) {
    app.innerHTML = `<section class="card account-card"><p>@${esc(username)} ne fait pas (ou plus) partie de vos amis.</p><a class="btn ghost" href="#amis">← Mes amis</a></section>`;
    return;
  }
  const color = f.color || "#cfe6ff";
  const ink = (() => { const n = parseInt(color.slice(1), 16); return ((n >> 16) * 299 + ((n >> 8) & 255) * 587 + (n & 255) * 114) / 1000 > 150 ? "#1d2733" : "#ffffff"; })();

  app.innerHTML = `<div class="pf fp">
    <section class="pf-banner" style="--banner:${esc(color)};--banner-ink:${ink}">
      <a class="pf-icon" href="#amis" aria-label="Fermer">✕</a>
      <h1 class="pf-title">${who(f)}</h1>
      <span></span>
      <span class="pf-avatar">${esc(f.avatar || "👤")}</span>
    </section>
    <section class="pf-body">
      <p class="pf-handle">@${esc(f.username)} · ami depuis ${new Date(f.since).toLocaleDateString("fr-FR", { month: "long", year: "numeric" })}</p>
      <div data-zone="head"></div>
      <div class="fp-actions">
        <button class="fp-btn msg" data-chat>💬<b>Message</b><em class="err-badge" data-unread hidden></em></button>
        <button class="fp-btn duel" data-challenge>⚔️<b>Défi</b></button>
      </div>
      <div class="fp-friendrow"><button class="btn ghost pf-add is-friend" data-friend-menu>👤✓ AMIS</button></div>

      <h2 class="pf-h2">Bilan hebdomadaire</h2>
      <div data-zone="chart"></div>

      <h2 class="pf-h2">Récap</h2>
      <div data-zone="recap"></div>

      <h2 class="pf-h2">Défis entre vous</h2>
      <div data-zone="challenges"></div>
    </section>
  </div>`;
  const page = app.firstElementChild;
  const z = (n) => page.querySelector(`[data-zone="${n}"]`);

  const paint = () => {
    if (!page.isConnected) return off?.();
    const theirs = So.statsOf(f.id);
    const mine = { ...So.statsOf(S.me.id), [code]: So.mySummary() };
    const langs = Object.keys(LANGS).filter((c) => theirs[c]);
    // En-tête : cours suivis + bilan des duels
    const rec = So.record(f.id);
    z("head").innerHTML = `<div class="pf-stats">
        <div class="pf-stat"><div class="pf-flags">${langs.length ? langs.map((c) => `<span class="pf-flag" title="${esc(LANGS[c].label)}">${flagSVG(c)}</span>`).join("") : `<span class="muted small">—</span>`}</div><span>Cours</span></div>
        <div class="pf-stat"><b>${rec.win}–${rec.lose}${rec.draw ? `–${rec.draw}` : ""}</b><span>Duels (V–D${rec.draw ? "–N" : ""})</span></div>
        <div class="pf-stat"><b>${Object.values(theirs).reduce((n, x) => n + (x.week === P.weekKey() ? x.weekXp || 0 : 0), 0)}</b><span>XP cette semaine</span></div>
      </div>`;
    z("chart").innerHTML = weekChart(f, theirs, mine);
    // Récap par langue
    z("recap").innerHTML = langs.length ? langs.map((c) => {
      const t = theirs[c];
      return `<div class="fp-recap"><p class="fp-lang"><span class="flag mini">${flagSVG(c)}</span>${esc(LANGS[c].label)} · <b>${esc(t.level)}</b> <small>${esc(t.levelName || "")}</small></p>
        <div class="pf-grid">
          <div class="pf-card"><span>🔥</span><b>${t.streak} j</b><small>Série</small></div>
          <div class="pf-card"><span>⚡</span><b>${t.xp}</b><small>XP au total</small></div>
          <div class="pf-card"><span>📈</span><b>${t.pct} %</b><small>du parcours</small></div>
          <div class="pf-card"><span>📒</span><b>${t.words}</b><small>Mots appris</small></div>
          <div class="pf-card"><span>✅</span><b>${t.lessons ?? "–"}</b><small>Leçons</small></div>
          <div class="pf-card"><span>🏅</span><b>${esc(t.level)}</b><small>Niveau</small></div>
        </div></div>`;
    }).join("") : `<p class="muted small">${who(f)} n'a pas encore commencé de parcours.</p>`;
    const chs = So.challengesWith(f.id);
    z("challenges").innerHTML = chs.length ? `<ul class="s-ch-list">${chs.slice(0, 15).map((c) => challengeCard(c, { showFriend: false })).join("")}</ul>`
      : `<p class="muted small">Aucun défi pour l'instant. Lancez le premier !</p>`;
    const n = S.unread[f.id] || 0, b = page.querySelector("[data-unread]");
    b.textContent = n; b.hidden = !n;
  };
  paint();

  page.querySelector("[data-chat]").onclick = () => (location.hash = `chat-${f.username}`);
  page.querySelector("[data-challenge]").onclick = () => askChallenge(f);
  page.querySelector("[data-friend-menu]").onclick = async () => {
    const v = await modal({ title: `${who(f)} et vous êtes amis`, body: `<p class="muted">Amis depuis le ${new Date(f.since).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}.</p>`,
      actions: [{ label: "Fermer", value: "", kind: "ghost" }, { label: "Retirer des amis", value: "rm", kind: "danger" }] });
    if (v !== "rm") return;
    const ok = await modal({ title: `Retirer ${who(f)} ?`, body: "<p>Vous ne verrez plus sa progression et ne pourrez plus vous écrire. Vous pourrez le réinviter plus tard.</p>",
      actions: [{ label: "Annuler", value: "" }, { label: "Retirer", value: "yes", kind: "danger" }] });
    if (ok !== "yes") return;
    try { await So.removeFriendship(f.friendshipId); toast("Ami retiré"); location.hash = "amis"; } catch (e) { toast(So.socialError(e), "warn"); }
  };
  bindChallengeActions(page);
  const off = So.onSocial((what) => {
    if (what === "message" || what === "unread") { if (page.isConnected) paint(); return; }
    if (!So.friendByUsername(username)) { location.hash = "amis"; return; }
    paint();
  });
  app._cleanup = off;
}

/** Graphique des 7 derniers jours : XP de l'ami et les miens */
function weekChart(f, theirs, mine) {
  const days = Object.keys(P.last7Days());
  const sum = (stats, d) => Object.values(stats).reduce((n, s) => n + (s?.days?.[d] || 0), 0);
  const a = days.map((d) => sum(theirs, d)), b = days.map((d) => sum(mine, d));
  const totA = a.reduce((x, y) => x + y, 0), totB = b.reduce((x, y) => x + y, 0);
  const hasData = Object.values(theirs).some((s) => s?.days);
  const max = Math.max(50, ...a, ...b), top = Math.ceil(max / 50) * 50;
  const W = 320, H = 170, L = 34, R = 10, T = 10, B = 26, iw = W - L - R, ih = H - T - B;
  const x = (i) => L + (iw * i) / 6, y = (v) => T + ih - (ih * v) / top;
  const line = (arr) => arr.map((v, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");
  const grid = [0, 0.5, 1].map((k) => `<line x1="${L}" x2="${W - R}" y1="${y(top * k)}" y2="${y(top * k)}" class="ch-grid"/><text x="${L - 6}" y="${y(top * k) + 4}" class="ch-ax" text-anchor="end">${Math.round(top * k)}</text>`).join("");
  const labels = days.map((d, i) => `<text x="${x(i)}" y="${H - 6}" class="ch-ax" text-anchor="middle">${"DLMMJVS"[new Date(d + "T12:00").getDay()]}</text>`).join("");
  const dots = (arr, cls) => arr.map((v, i) => `<circle cx="${x(i)}" cy="${y(v)}" r="4.5" class="${cls}"><title>${v} XP</title></circle>`).join("");
  return `<div class="wk-chart">
    <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="XP des 7 derniers jours">${grid}${labels}
      <path d="${line(b)}" class="ch-me"/>${dots(b, "dot-me")}
      <path d="${line(a)}" class="ch-fr"/>${dots(a, "dot-fr")}</svg>
    <ul class="wk-legend"><li><i class="lg-fr"></i><b>${who(f)}</b><span>${hasData ? `${totA} XP` : "bientôt disponible"}</span></li><li><i class="lg-me"></i><b>Moi</b><span>${totB} XP</span></li></ul>
    ${hasData ? "" : `<p class="muted small">Le graphique de ${who(f)} se remplira dès sa prochaine activité sur la nouvelle version.</p>`}
  </div>`;
}

/* =========================== #chat-<nom> =========================== */
export function renderChat(app, username) {
  if (gate(app, "Messages")) return;
  const S = So.social();
  const hash = location.hash;
  if (!S.ready) { loadThen(app, () => renderChat(app, username)); return; }
  const f = So.friendByUsername(username);
  if (!f) { location.hash = "amis"; return; }
  const st = Object.entries(So.statsOf(f.id)).sort((a, b) => (b[1]?.xp || 0) - (a[1]?.xp || 0))[0];
  const status = st ? `${st[1].streak ? `🔥 ${st[1].streak} j · ` : ""}<span class="flag mini">${flagSVG(st[0])}</span> ${esc(st[1].level || "")}` : `@${esc(f.username)}`;
  document.body.classList.add("chat-mode");
  app.innerHTML = `<div class="chat-full">
    <header class="cf-head">
      <a class="cf-back" href="#ami-${esc(f.username)}" aria-label="Retour">‹</a>
      <a class="cf-who" href="#ami-${esc(f.username)}">${av(f, "sm")}<span><b>${who(f)}</b><small>${status}</small></span></a>
      <button class="cf-defi" data-challenge aria-label="Lancer un défi">⚔️</button>
    </header>
    <div class="cf-msgs" aria-live="polite"><div class="skel-chat" aria-busy="true"><span class="skel sb l"></span><span class="skel sb r"></span><span class="skel sb l w"></span><span class="skel sb r"></span></div></div>
    <button class="cf-new" hidden>↓ Nouveau message</button>
    <footer class="cf-foot">
      <div class="cf-quick">${["👋 Salut !", "🔥 Bien joué !", "⚔️ Un défi ?", "📚 Tu as révisé ?", "😂", "👍"].map((t) => `<button type="button" class="chip-btn" data-q="${esc(t)}">${esc(t)}</button>`).join("")}</div>
      <form class="cf-send" autocomplete="off">
        <textarea name="m" rows="1" maxlength="1000" placeholder="Message à ${who(f)}…" aria-label="Message"></textarea>
        <button class="cf-go" type="submit" aria-label="Envoyer" disabled>➤</button>
      </form>
    </footer>
  </div>`;
  const page = app.firstElementChild;
  const box = page.querySelector(".cf-msgs"), newBtn = page.querySelector(".cf-new");
  const msgs = new Map(); // id → message
  const me = S.me.id;
  const dayLabel = (d) => {
    const k = (x) => x.toDateString(), t = new Date(), y = new Date(Date.now() - 864e5);
    if (k(d) === k(t)) return "Aujourd'hui";
    if (k(d) === k(y)) return "Hier";
    return d.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" });
  };
  const onlyEmoji = (t) => /^(\p{Extended_Pictographic}|\p{Emoji_Component}|\s){1,8}$/u.test(t) && !/[0-9#*]/.test(t);
  const nearBottom = () => box.scrollHeight - box.scrollTop - box.clientHeight < 120;

  function paint(stick = true) {
    const list = [...msgs.values()].sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
    if (!list.length) { box.innerHTML = `<div class="cf-empty">${av(f, "xl")}<p><b>${who(f)}</b></p><p class="muted small">Aucun message pour l'instant. Dites bonjour 👋</p></div>`; return; }
    const lastMine = [...list].reverse().find((m) => m.sender === me);
    let html = "", lastDay = "";
    list.forEach((m, i) => {
      const d = new Date(m.created_at), day = dayLabel(d);
      if (day !== lastDay) { html += `<p class="cf-day"><span>${day}</span></p>`; lastDay = day; }
      const prev = list[i - 1], next = list[i + 1];
      const close = (a, b) => a && b && a.sender === b.sender && Math.abs(new Date(a.created_at) - new Date(b.created_at)) < 5 * 60000 && dayLabel(new Date(a.created_at)) === dayLabel(new Date(b.created_at));
      const first = !close(prev, m), last = !close(m, next);
      const mine = m.sender === me, big = onlyEmoji(m.body);
      html += `<div class="cf-msg ${mine ? "me" : "them"} ${first ? "first" : ""} ${last ? "last" : ""} ${big ? "big" : ""} ${m.pending ? "pending" : ""}">
        <p>${esc(m.body)}<time>${d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</time></p></div>`;
      if (m === lastMine) html += `<p class="cf-receipt">${m.pending ? "Envoi…" : m.failed ? "⚠️ Non envoyé" : m.read_at ? "Vu ✓✓" : "Envoyé ✓"}</p>`;
    });
    const wasNear = nearBottom();
    box.innerHTML = html;
    if (stick || wasNear) { box.scrollTop = box.scrollHeight; newBtn.hidden = true; }
    else newBtn.hidden = false;
  }
  function merge(list, { fromOther = false } = {}) {
    let changed = false;
    list.forEach((m) => {
      const old = msgs.get(m.id);
      if (!old || old.read_at !== m.read_at) { msgs.set(m.id, { ...old, ...m }); changed = true; }
    });
    if (changed) paint(!fromOther);
  }
  newBtn.onclick = () => { box.scrollTo({ top: box.scrollHeight, behavior: "smooth" }); newBtn.hidden = true; };
  box.addEventListener("scroll", () => { if (nearBottom()) newBtn.hidden = true; });

  So.loadMessages(f.id).then((list) => { if (!stillHere(hash)) return; box.innerHTML = ""; list.forEach((m) => msgs.set(m.id, m)); paint(true); So.markRead(f.id); })
    .catch((e) => (box.innerHTML = `<p class="form-msg error">${esc(So.socialError(e))}</p>`));

  const form = page.querySelector(".cf-send"), ta = form.m, go = form.querySelector(".cf-go");
  const grow = () => { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 120) + "px"; go.disabled = !ta.value.trim(); };
  ta.oninput = grow;
  ta.onkeydown = (e) => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); form.requestSubmit(); } };
  let tmp = 0;
  const send = async (text) => {
    const id = `tmp-${++tmp}`;
    msgs.set(id, { id, sender: me, body: text, created_at: new Date().toISOString(), pending: true });
    paint(true);
    try {
      const m = await So.sendMessage(f.id, text);
      msgs.delete(id);
      if (m) msgs.set(m.id, m);
      paint(true); return true;
    } catch (err) {
      msgs.set(id, { ...msgs.get(id), pending: false, failed: true }); paint(true);
      toast(err.message, "warn"); msgs.delete(id); return false;
    }
  };
  form.onsubmit = async (e) => {
    e.preventDefault();
    const text = ta.value.trim(); if (!text) return;
    ta.value = ""; grow(); ta.focus();
    if (!(await send(text))) { ta.value = text; grow(); }
  };
  page.querySelectorAll("[data-q]").forEach((b) => (b.onclick = () => send(b.dataset.q)));
  page.querySelector("[data-challenge]").onclick = () => askChallenge(f);

  // Plein écran qui suit le clavier (iPhone / Android)
  const vv = window.visualViewport;
  const fit = () => { if (!vv) return; page.style.height = `${vv.height}px`; page.style.top = `${vv.offsetTop}px`; if (document.activeElement === ta) box.scrollTop = box.scrollHeight; };
  vv?.addEventListener("resize", fit); vv?.addEventListener("scroll", fit); fit();

  const poll = setInterval(() => {
    if (document.visibilityState === "visible") So.loadMessages(f.id, 30).then((l) => { if (stillHere(hash)) { merge(l, { fromOther: true }); So.markRead(f.id); } }).catch(() => {});
  }, 8000);
  const off = So.onSocial((what, m) => { if (what === "message" && m.sender === f.id && page.isConnected) { merge([m], { fromOther: true }); So.markRead(f.id); } });
  app._cleanup = () => { off(); clearInterval(poll); vv?.removeEventListener("resize", fit); vv?.removeEventListener("scroll", fit); document.body.classList.remove("chat-mode"); };
}

/* =========================== #defi-<id> ============================ */
/** Pas assez de mots appris : explication + raccourci vers le parcours */
function notEnoughWords(title = "Pas encore assez de mots", size = 5) {
  const n = CG.missingWords(size), other = Object.values(LANGS).find((l) => l.code !== code);
  return modal({
    title: `📒 ${title}`,
    body: `<p>Les défis utilisent uniquement les mots que <b>vous avez appris</b> en ${esc(L.label.toLowerCase())} (ceux de vos leçons réussies), avec des questions variées.</p>
      <p>Il vous faut au moins <b>${CG.wordsNeeded(size)} mots</b> : encore <b>${n}</b> à apprendre. Terminez une ou deux leçons de plus !</p>
      ${other ? `<p class="muted small">Vous avez plus de mots en ${esc(other.label.toLowerCase())} ? Changez de langue en haut de la page.</p>` : ""}`,
    actions: [{ label: "Fermer", value: "close", kind: "ghost" }, { label: "Aller au parcours", value: "go", kind: "primary" }],
  }).then((v) => { if (v === "go") location.hash = "parcours"; });
}

export function renderDefi(app, id, opts = {}) {
  if (gate(app, "Défi")) return;
  const hash = location.hash;
  loading(app);
  So.getChallenge(id).then((c) => {
    if (!stillHere(hash)) return;
    if (!c) { app.innerHTML = `<section class="card account-card"><p>Ce défi est introuvable.</p><a class="btn ghost" href="#amis">← Amis</a></section>`; return; }
    if (LIVE && LIVE.id !== c.id) leaveLive();
    const liveOk = c.live && !c.theirs && !opts.solo && (c.stage === "to_play" || c.stage === "waiting_accept");
    if (c.stage !== "to_play" && !liveOk) return showDefi(app, c);
    if (!CG.canChallenge(c.n)) {
      app.innerHTML = `<a class="back-link" href="#amis">← Amis</a>
      <section class="card s-defi-intro"><p class="eyebrow">Défi</p><h1>📒 Encore quelques mots à apprendre</h1>
        <p class="lead">Ce défi utilise uniquement les mots que vous avez appris en ${esc(L.label.toLowerCase())}. Pour ${c.n} questions, il en faut au moins ${CG.wordsNeeded(c.n)} : encore <b>${CG.missingWords(c.n)}</b>.</p>
        <p class="muted">Terminez une ou deux leçons, puis revenez : le défi vous attend. Vous apprenez une autre langue ? Changez de langue en haut de la page.</p>
        <a class="btn primary big" href="#parcours">Continuer mon parcours</a></section>`;
      return;
    }
    if (liveOk) return renderLobby(app, c);
    const qs = CG.buildChallengeQuestions(c.n);
    const rec = So.record(c.friend?.id);
    app.innerHTML = `
    <a class="back-link" href="#amis">← Amis</a>
    <section class="card s-defi-intro defi-arena">
      <p class="eyebrow">Défi · ${c.n} questions · ${modeLabel(c.mode)}</p>
      <div class="s-vs vs-anim">${av(So.social().me, "xl")}<span class="s-vs-x">VS</span>${av(c.friend, "xl")}</div>
      <h1>Vous contre ${who(c.friend)}</h1>
      ${rec.total ? `<p class="h2h">Bilan : <b>${rec.win}</b> victoire${rec.win > 1 ? "s" : ""} · <b>${rec.lose}</b> défaite${rec.lose > 1 ? "s" : ""}${rec.draw ? ` · <b>${rec.draw}</b> égalité${rec.draw > 1 ? "s" : ""}` : ""}</p>` : `<p class="h2h">Premier duel entre vous !</p>`}
      ${c.theirs ? `<div class="to-beat">🎯 À battre : <b>${c.theirs.score}/${c.theirs.total}</b>${c.mode === "precision" ? "" : ` en <b>${secs(c.theirs.ms)}</b>`}${c.mode === "speed" ? ` · <b>${c.theirs.points} pts</b>` : ""}</div>` : `<div class="to-beat soft">Vous jouez en premier : placez la barre haut !</div>`}
      <ul class="defi-rules">
        <li>🎲 ${qs.length} questions variées sur vos <b>${CG.learnedWords().length} mots</b> de ${esc(L.label.toLowerCase())} <span class="flag mini">${flagSVG(code)}</span></li>
        <li>${c.mode === "precision" ? "🎯 Mode précision : seules les bonnes réponses comptent, le temps n'est pas pris en compte" : c.mode === "speed" ? `⏱️ Mode vitesse : ${So.SPEED_PER_GOOD} pts par bonne réponse, −${So.SPEED_PER_SEC} pts par seconde. Vite… mais juste !` : "⏱️ Chronomètre lancé au départ : à égalité, le plus rapide gagne"}</li>
        <li>☝️ Une seule tentative</li>
      </ul>
      <button class="btn primary big" data-go>C'est parti !</button>
      <p class="muted small">Vous apprenez aussi une autre langue ? Changez de langue en haut de la page avant de commencer.</p>
    </section>`;
    app.querySelector("[data-go]").onclick = () => countdownThen(app, () => play(app, c, qs));
  }).catch((e) => { app.innerHTML = `<section class="card"><p class="form-msg error">${esc(So.socialError(e))}</p></section>`; });
}

/** 3, 2, 1… avant le départ */
function countdownThen(app, go) {
  document.body.classList.add("focus-mode");
  app.innerHTML = `<div class="cd"><span>3</span></div>`;
  const el = app.querySelector(".cd span");
  let n = 3;
  const t = setInterval(() => {
    n--;
    if (n > 0) { el.textContent = n; el.style.animation = "none"; el.offsetWidth; el.style.animation = ""; }
    else if (n === 0) { el.textContent = "GO !"; el.style.animation = "none"; el.offsetWidth; el.style.animation = ""; }
    else { clearInterval(t); go(); }
  }, 650);
  const prev = app._cleanup;
  app._cleanup = () => { clearInterval(t); prev?.(); };
}

function play(app, c, questions, live = null) {
  document.body.classList.add("focus-mode");
  const t0 = performance.now();
  const recap = [];
  let good = 0, bad = 0;
  runQuiz(app, {
    title: `Défi contre ${c.friend?.pseudo || c.friend?.username || "un ami"}`,
    questions,
    onAnswer: ({ q, correct, expected, given }) => {
      correct ? good++ : bad++;
      recap.push({ q: plainQ(q), expected: String(expected ?? ""), given: String(given ?? ""), correct });
      live?.duel.progress({ good, bad, total: questions.length, ms: Math.round(performance.now() - t0) });
      paintHud();
    },
    onQuit: () => {
      // Rien n'est envoyé : le défi pourra être rejoué plus tard (avec d'autres questions)
      clearInterval(timer);
      document.body.classList.remove("focus-mode");
      toast("Défi interrompu : vous pourrez le rejouer plus tard");
      location.hash = "amis";
    },
    onFinish: async (results) => {
      clearInterval(timer);
      document.body.classList.remove("focus-mode");
      const ms = performance.now() - t0;
      const score = results.filter((r) => r.correct).length;
      live?.duel.progress({ good: score, bad: results.length - score, total: results.length, ms: Math.round(ms), finished: true });
      if (live) live.meDone = true;
      try { localStorage.setItem(`impara.defi.${c.id}`, JSON.stringify(recap)); } catch {}
      app.innerHTML = `<p class="muted s-loading">Envoi de votre score…</p>`;
      try {
        await So.submitChallenge(c.id, { score, total: results.length, ms });
        const v = await So.getChallenge(c.id);
        showDefi(app, v, true);
      } catch (e) {
        app.innerHTML = `<section class="card account-card"><p class="form-msg error">${esc(e.message)}</p>
          <p>Votre score : ${score}/${results.length}</p><a class="btn ghost" href="#amis">← Amis</a></section>`;
      }
    },
  });
  // Bandeau du duel : chrono, bonnes / mauvaises réponses, score à battre
  const hud = document.createElement("div");
  hud.className = "duel-hud";
  app.querySelector(".quiz")?.prepend(hud);
  const total = questions.length;
  function paintHud() {
    const el = (performance.now() - t0) / 1000;
    const t = `${Math.floor(el / 60)}:${String(Math.floor(el % 60)).padStart(2, "0")}`;
    let race = "";
    if (c.theirs) {
      const maxMine = good + (total - good - bad);
      race = good > c.theirs.score ? `<span class="ahead">🔥 Devant !</span>`
        : maxMine < c.theirs.score ? `<span class="behind">Plus possible de gagner…</span>`
        : `<span>🎯 ${c.theirs.score}/${c.theirs.total} à battre</span>`;
    }
    const pts = c.mode === "speed" ? Math.max(0, good * So.SPEED_PER_GOOD - Math.round(el) * So.SPEED_PER_SEC) : null;
    if (c.theirs && c.mode === "speed") race = pts > c.theirs.points ? `<span class="ahead">🔥 ${pts} pts</span>` : `<span>${pts} / ${c.theirs.points} pts</span>`;
    else if (c.mode === "speed") race = `<span>${pts} pts</span>`;
    if (live) race = "";
    hud.innerHTML = `${c.mode === "precision" ? "" : `<span class="hud-t">⏱️ ${t}</span>`}<span class="hud-ok">✓ ${good}</span><span class="hud-ko">✗ ${bad}</span>${race}`
      + (live ? liveBars(c, { good, bad, total, el }, live.opp, el) : "");
  }
  paintHud();
  if (live) live.onUpdate = paintHud;
  const timer = setInterval(paintHud, 500);
  const prev = app._cleanup;
  app._cleanup = () => { clearInterval(timer); prev?.(); };
}

/** Intitulé lisible d'une question (pour le récapitulatif) */
function plainQ(q) {
  const base = q.type === "fill" ? `Compléter : ${q.q}` : q.type === "match" ? "Associer les mots et leur sens" : q.q;
  return q.reveal ? `${base} (${q.reveal})` : base;
}

function showDefi(app, c, justPlayed = false) {
  const f = c.friend, me = So.social().me;
  let recap = null;
  try { recap = JSON.parse(localStorage.getItem(`impara.defi.${c.id}`) || "null"); } catch {}
  const col = (r, label, p, win) => r ? `<div class="s-res-col ${win ? "winner" : ""}">${win ? `<span class="crown">👑</span>` : ""}${av(p, "lg")}<p class="s-res-who">${label}</p>
      <p class="big-score" data-count="${r.score}">0</p><p class="muted small">sur ${r.total}${c.mode === "precision" ? "" : ` · ⏱ ${secs(r.ms)}`} <span class="flag mini">${flagSVG(r.lang)}</span></p>${r.points != null ? `<p class="pts-line">${r.points} pts</p>` : ""}</div>`
    : `<div class="s-res-col">${av(p, "lg")}<p class="s-res-who">${label}</p><p class="big-score muted">?</p><p class="muted small">${c.stage === "to_accept" || c.stage === "waiting_accept" ? "Pas encore accepté" : "Pas encore joué"}</p></div>`;
  const head = {
    done: { win: "🏆 Victoire !", lose: `${who(f)} l'emporte`, draw: c.mode === "precision" ? "🤝 Égalité" : "🤝 Égalité parfaite" }[c.outcome],
    waiting_play: "Score envoyé ✓", to_accept: `${who(f)} vous défie !`, waiting_accept: `En attente de ${who(f)}`,
    declined: "Défi refusé", cancelled: "Défi annulé",
  }[c.stage] || "Défi";
  const sub = {
    waiting_play: `Vous serez prévenu dès que ${who(f)} aura joué.`,
    done: c.stage !== "done" ? "" : c.mode === "speed" ? (c.outcome === "draw" ? "Exactement le même nombre de points !"
        : (() => { const w = c.outcome === "win" ? c.mine : c.theirs, l = c.outcome === "win" ? c.theirs : c.mine;
            const by = w.score < l.score ? " grâce à la vitesse ⚡" : w.score === l.score ? ", plus rapide ⚡" : "";
            return `${c.outcome === "win" ? "Vous gagnez" : `${who(f)} gagne`} ${w.points} à ${l.points} pts${by}`; })())
      : c.mode === "precision" ? (c.outcome === "draw" ? "Même nombre de bonnes réponses : match nul !" : c.outcome === "win" ? "Plus de bonnes réponses : bien joué !" : "La revanche vous attend !")
      : c.outcome === "win" ? (c.mine.score === c.theirs.score ? "Même score, mais vous avez été plus rapide ⚡" : "Bien joué ! Prêt à remettre ça ?")
      : c.outcome === "lose" ? (c.mine.score === c.theirs.score ? `Même score, ${who(f)} a été plus rapide.` : "La revanche vous attend !") : "Même score, même temps : impressionnant.",
  }[c.stage] || "";
  const rec = So.record(f?.id);
  const watching = LIVE && LIVE.id === c.id && c.stage === "waiting_play";
  const reactions = c.stage === "done" ? (c.outcome === "win" ? ["👏 GG !", "😎 Trop facile", "🔥 Revanche ?"] : c.outcome === "lose" ? ["👏 Bien joué !", "🔥 Revanche !", "😅 La prochaine fois…"] : ["🤝 Égalité parfaite !", "🔥 On départage ?"]) : [];
  app.innerHTML = `<div class="s-page">
  <a class="back-link" href="#amis">← Amis</a>
  <section class="card s-defi-res ${c.outcome || ""} ${justPlayed ? "fresh" : ""}">
    <p class="eyebrow">Défi · ${c.n} questions · ${modeLabel(c.mode)} · ${when(c.created_at)}</p>
    <h1>${head}</h1>${sub ? `<p class="muted">${sub}</p>` : ""}
    <div class="s-res">${col(c.mine, "Vous", me, c.outcome === "win")}<span class="s-vs-x">VS</span>${col(c.theirs, who(f), f, c.outcome === "lose")}</div>
    ${watching ? `<div class="live-watch" data-watch></div>` : ""}
    ${rec.total ? `<p class="h2h">Bilan contre ${who(f)} : <b>${rec.win}</b>V · <b>${rec.lose}</b>D${rec.draw ? ` · <b>${rec.draw}</b>N` : ""}</p>` : ""}
    ${reactions.length && f ? `<div class="reactions"><p class="muted small">Envoyer un message à ${who(f)} :</p>${reactions.map((r) => `<button class="chip-btn" data-react="${esc(r)}">${esc(r)}</button>`).join("")}</div>` : ""}
    <div class="result-actions">
      ${c.stage === "to_accept" ? `<button class="btn primary big" data-ch-accept="${c.id}">Accepter le défi</button>` : ""}
      ${c.stage === "done" && f ? `<button class="btn primary big" data-rematch>⚔️ Revanche</button>` : ""}
      ${f ? `<a class="btn ghost" href="#ami-${esc(f.username)}">💬 ${who(f)}</a>` : ""}
    </div>
  </section>
  ${recap?.length ? `<section class="card recap"><h2 class="h3">📝 Vos réponses</h2><ol>${recap.map((r) => `
    <li class="${r.correct ? "ok" : "ko"}"><span class="rc-ico">${r.correct ? "✓" : "✗"}</span><div><p>${esc(r.q)}</p>
      ${r.correct ? "" : `<p class="small">Bonne réponse : <b>${esc(r.expected)}</b>${r.given ? ` · vous : <s>${esc(r.given)}</s>` : ""}</p>`}</div></li>`).join("")}</ol></section>` : ""}
  </div>`;
  // Les scores défilent jusqu'à leur valeur
  app.querySelectorAll("[data-count]").forEach((el) => {
    const end = +el.dataset.count; let n = 0;
    const step = () => { el.textContent = n; if (n++ < end) setTimeout(step, Math.max(25, 500 / Math.max(1, end))); };
    step();
  });
  if (justPlayed && c.outcome === "win") setTimeout(celebrate, 500);
  app.querySelector("[data-rematch]")?.addEventListener("click", () => askChallenge(f));
  app.querySelectorAll("[data-react]").forEach((b) => (b.onclick = async () => {
    b.disabled = true;
    try { await So.sendMessage(f.id, `${b.dataset.react} (défi ${c.mine?.score ?? "?"}–${c.theirs?.score ?? "?"})`); toast("Message envoyé ✓", "ok"); }
    catch (e) { toast(e.message, "warn"); b.disabled = false; }
  }));
  bindChallengeActions(app.firstElementChild);
  if (watching) {
    const paintWatch = () => {
      const z = app.querySelector("[data-watch]"); if (!z) return;
      const o = LIVE?.opp || {};
      z.innerHTML = !o.present && !o.finished ? `<p class="muted small">📴 ${who(f)} s'est déconnecté : son score arrivera quand il aura fini.</p>`
        : `<p class="live-h">⚡ ${who(f)} joue en ce moment</p>${liveBars(c, null, o, (performance.now() - (LIVE?.t0 || performance.now())) / 1000)}`;
    };
    LIVE.onUpdate = paintWatch; paintWatch();
    const w = setInterval(paintWatch, 1000);
    const prevC = app._cleanup; app._cleanup = () => { clearInterval(w); prevC?.(); };
  }
  if (c.stage === "done" && LIVE?.id === c.id) leaveLive();
  const off = So.onSocial((what) => {
    if (what !== "all") return;
    const fresh = So.allChallenges().find((x) => x.id === c.id);
    if (fresh && fresh.stage !== c.stage) { off(); app._cleanup?.(); app._cleanup = null; showDefi(app, fresh, fresh.stage === "done" && (justPlayed || !!LIVE)); }
  });
  const prevS = app._cleanup;
  app._cleanup = () => { off(); prevS?.(); };
}


/* ======================== Duel en direct ⚡ ======================== */
let LIVE = null; // { id, duel, opp: { present, ready, good, bad, total, ms, finished }, onUpdate, t0, meDone }
export function leaveLive() { if (LIVE) { LIVE.duel?.leave(); LIVE = null; } }

/** Deux barres de progression : moi et l'adversaire */
function liveBars(c, me, opp, el) {
  const pts = (good, ms) => Math.max(0, good * So.SPEED_PER_GOOD - Math.round(ms / 1000) * So.SPEED_PER_SEC);
  const bar = (label, p, cls) => {
    if (!p) return "";
    const n = (p.good || 0) + (p.bad || 0), total = p.total || c.n;
    const extra = c.mode === "speed" ? ` · ${pts(p.good || 0, p.finished ? p.ms : el * 1000)} pts` : "";
    return `<div class="lb ${cls}"><span class="lb-who">${label}</span><div class="lb-bar"><span style="width:${Math.round((n / total) * 100)}%"></span></div>
      <span class="lb-sc">${p.finished ? "🏁 " : ""}✓${p.good || 0} ✗${p.bad || 0}${extra}</span></div>`;
  };
  const f = c.friend;
  const oppState = opp && (opp.present || opp.finished) ? opp : null;
  return `<div class="live-bars">${me ? bar("Vous", me, "me") : ""}${oppState ? bar(who(f), { ...opp, total: opp.total || c.n }, "op") : `<p class="muted small">📴 ${who(f)} n'est plus connecté</p>`}</div>`;
}

async function renderLobby(app, c) {
  const f = c.friend, me = So.social().me;
  app.innerHTML = `<a class="back-link" href="#amis">← Amis</a>
  <section class="card s-defi-intro defi-arena live-lobby">
    <p class="eyebrow">⚡ Duel en direct · ${c.n} questions · ${modeLabel(c.mode)}</p>
    <div class="s-vs"><div class="seat">${av(me, "xl")}<span class="seat-st" data-st="me"></span></div><span class="s-vs-x">VS</span><div class="seat">${av(f, "xl")}<span class="seat-st" data-st="op"></span></div></div>
    <h1 data-l="title">Connexion…</h1><p class="muted" data-l="sub"></p>
    <button class="btn primary big" data-ready disabled>Je suis prêt !</button>
    <ul class="defi-rules">
      <li>⚡ Vous jouez en même temps, chacun sur ses propres mots</li>
      <li>👀 Vous voyez la progression de ${who(f)} pendant la partie</li>
      <li>${c.mode === "precision" ? "🎯 Seules les bonnes réponses comptent" : `⏱️ ${So.SPEED_PER_GOOD} pts par bonne réponse, −${So.SPEED_PER_SEC} pts par seconde`}</li>
    </ul>
    <button class="btn ghost small" data-solo ${c.stage === "waiting_accept" ? "hidden" : ""}>Jouer sans attendre (${who(f)} jouera plus tard)</button>
  </section>`;
  const $ = (q) => app.querySelector(q);
  let started = false, meReady = false;
  const opp = { present: false, ready: false };

  function paint() {
    if (started || !$(".live-lobby")) return;
    const waitingAccept = c.stage === "waiting_accept";
    $('[data-st="me"]').textContent = meReady ? "✓ Prêt" : "En ligne";
    $('[data-st="op"]').textContent = waitingAccept ? "Invité…" : opp.ready ? "✓ Prêt" : opp.present ? "En ligne" : "Absent";
    $('[data-st="op"]').className = `seat-st ${opp.ready ? "ok" : opp.present ? "on" : ""}`;
    $('[data-st="me"]').className = `seat-st ${meReady ? "ok" : "on"}`;
    const [t, sub] = waitingAccept ? [`En attente de ${who(f)}…`, `Il a reçu une notification. Dès qu'il accepte, il vous rejoint ici.`]
      : !opp.present ? [`En attente de ${who(f)}…`, "Restez sur cette page : le duel commence quand vous êtes prêts tous les deux."]
      : !meReady ? [`${who(f)} est là ! 👋`, opp.ready ? `${who(f)} est prêt : à vous !` : "Cliquez sur « Je suis prêt » pour lancer le duel."]
      : [`En attente que ${who(f)} soit prêt…`, ""];
    $('[data-l="title"]').textContent = t; $('[data-l="sub"]').textContent = sub;
    const b = $("[data-ready]");
    b.disabled = waitingAccept || meReady;
    b.textContent = meReady ? "Prêt ✓" : "Je suis prêt !";
    $("[data-solo]").hidden = waitingAccept;
  }

  function go() {
    if (started) return;
    started = true;
    LIVE.t0 = performance.now() + 1950;
    const qs = CG.buildChallengeQuestions(c.n);
    countdownThen(app, () => { LIVE.t0 = performance.now(); play(app, c, qs, LIVE); });
  }

  leaveLive();
  LIVE = { id: c.id, opp, duel: null, onUpdate: null, t0: 0, meDone: false };
  const mine = LIVE;
  try {
    mine.duel = await So.joinDuel(c.id, {
      onPresence: (others) => {
        const o = others[0];
        const was = opp.present;
        opp.present = !!o; opp.ready = !!o?.ready;
        if (was && !o && started && !opp.finished) toast(`${who(f)} s'est déconnecté`, "warn");
        paint(); mine.onUpdate?.();
        // Le lanceur du défi donne le départ quand les deux sont prêts
        if (!started && c.iAmChallenger && meReady && opp.ready) { mine.duel.start({ n: c.n }); go(); }
      },
      onStart: () => go(),
      onProgress: (p) => { Object.assign(opp, p, { present: true }); mine.onUpdate?.(); },
    });
  } catch {
    $('[data-l="title"]').textContent = "Connexion au duel impossible";
    $('[data-l="sub"]').textContent = "Vous pouvez jouer sans attendre : votre score sera comparé à celui de votre ami.";
    $("[data-solo]").hidden = false;
  }
  if (LIVE !== mine) { mine.duel?.leave(); return; } // page quittée pendant la connexion
  paint();

  $("[data-ready]").onclick = async () => {
    meReady = true; paint();
    await mine.duel?.ready(true);
    if (!started && c.iAmChallenger && opp.ready) { mine.duel.start({ n: c.n }); go(); }
  };
  $("[data-solo]").onclick = () => { leaveLive(); renderDefi(app, c.id, { solo: true }); };

  // L'adversaire accepte (ou joue seul) pendant qu'on attend
  const off = So.onSocial((what) => {
    if (what !== "all" || started) return;
    const fresh = So.allChallenges().find((x) => x.id === c.id);
    if (!fresh) return;
    if (fresh.theirs || ["declined", "cancelled"].includes(fresh.stage)) { off(); leaveLive(); renderDefi(app, c.id, { solo: true }); return; }
    if (fresh.stage !== c.stage) { c = fresh; paint(); }
  });
  app._cleanup = () => { off(); };
}
