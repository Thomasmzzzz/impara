/* =====================================================================
   Vues sociales
   - #amis          : nom d'utilisateur, ajout d'amis, demandes, défis
   - #ami-<pseudo>  : progression comparée, défis et messages avec un ami
   - #defi-<id>     : jouer un défi
   ===================================================================== */

import { state, commit } from "../core/storage.js";
import { L, LANGS, code, flagSVG } from "../core/lang.js";
import { esc, toast, modal, shuffle, ring, celebrate, speak } from "../core/ui.js";
import { runQuiz } from "../core/quiz-engine.js";
import * as P from "../core/progress.js";
import { ALL_LESSONS, LEVELS } from "../data/curriculum.js";
import { isConfigured } from "../core/cloud.js";
import * as So from "../core/social.js";
import * as PWA from "../core/pwa.js";
import * as CG from "../core/challenge-gen.js";
import * as C from "../core/cosmetics.js";
import { icon } from "../core/icons.js";

/* ------------------------------ Outils ----------------------------- */
const who = (p) => esc(p?.pseudo || p?.username || "Ami");
const av = (p, cls = "") => `<span class="s-avatar ${cls} ${C.frameClass(p?.frame)}"${p?.color ? ` style="background:${esc(p.color)}"` : ""}>${esc(p?.avatar || "👤")}</span>`;
const handle = (p) => (p?.username ? `<span class="s-handle">@${esc(p.username)}</span>` : "");
const stillHere = (hash) => location.hash === hash;

function when(ts) {
  const d = new Date(ts), now = new Date();
  const hm = d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  if (d.toDateString() === now.toDateString()) return hm;
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return `hier ${hm}`;
  return `${d.toLocaleDateString("fr-FR", { day: "numeric", month: "short" })} ${hm}`;
}
/** « aujourd'hui 14:05 » · « hier » · « lun. 3 nov. » */
function dayWhen(ts) {
  const d = new Date(ts), now = new Date(), y = new Date(now); y.setDate(now.getDate() - 1);
  if (d.toDateString() === now.toDateString()) return `aujourd'hui ${d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;
  if (d.toDateString() === y.toDateString()) return "hier";
  return d.toLocaleDateString("fr-FR", { weekday: "short", day: "numeric", month: "short" });
}

/* --------------------------- Fil : regroupement --------------------------- */
const FEED_ICONS = { exam: "grad", defi_win: "swords", streak: "flame", words: "notebook", xp: "zap", lesson: "book", start: "sprout", recap: "chart" };
const FEED_RANK = ["exam", "defi_win", "streak", "words", "xp", "lesson", "start"];
/** Les activités d'une même personne le même jour forment une seule carte (le bilan reste à part) */
function groupFeed(list) {
  const groups = [], byKey = new Map();
  for (const a of list) {
    if (a.kind === "recap") { groups.push({ who: a.who, mine: a.mine, items: [a], at: Date.parse(a.created_at), recap: a, top: "recap", langs: [], lessons: [] }); continue; }
    const key = `${a.user_id}|${new Date(a.created_at).toDateString()}`;
    let g = byKey.get(key);
    if (!g) { g = { who: a.who, mine: a.mine, items: [], at: Date.parse(a.created_at), langs: [], lessons: [] }; byKey.set(key, g); groups.push(g); }
    g.items.push(a);
    if (a.lang && !g.langs.includes(a.lang)) g.langs.push(a.lang);
    if (a.kind === "lesson" && a.data?.title) g.lessons.push(a.data.title);
  }
  groups.forEach((g) => { if (!g.recap) g.top = FEED_RANK.find((k) => g.items.some((a) => a.kind === k)) || "start"; });
  return groups;
}
const LANG_FR = { it: "l'italien", zh: "le mandarin" };
/** « a terminé 3 leçons, appris 50 mots et gagné un défi contre @bob » */
function groupSentence(g) {
  const of = (k) => g.items.filter((a) => a.kind === k);
  const max = (k) => Math.max(...of(k).map((a) => +a.data?.n || 0));
  const parts = [];
  of("exam").forEach((a) => parts.push(`validé le niveau <b>${esc(a.data?.level || "")}</b>`));
  const les = of("lesson").length;
  if (les === 1) parts.push(`terminé la leçon <b>${esc(of("lesson")[0].data?.title || "")}</b>`);
  else if (les > 1) parts.push(`terminé <b>${les} leçons</b>${new Date(g.at).toDateString() === new Date().toDateString() ? " aujourd'hui" : ""}`);
  const wins = of("defi_win");
  if (wins.length === 1) parts.push(`gagné un défi${wins[0].data?.vs ? ` contre <b>@${esc(wins[0].data.vs)}</b>` : ""}`);
  else if (wins.length > 1) parts.push(`gagné <b>${wins.length} défis</b>`);
  if (of("streak").length) parts.push(`atteint <b>${max("streak")} jours</b> de série`);
  if (of("words").length) parts.push(`appris <b>${max("words")} mots</b>`);
  if (of("xp").length) parts.push(`dépassé <b>${max("xp").toLocaleString("fr-FR")} XP</b>`);
  of("start").forEach((a) => parts.push(`commencé ${LANG_FR[a.lang] || "une nouvelle langue"}`));
  const list = parts.length > 1 ? `${parts.slice(0, -1).join(", ")} et ${parts.at(-1)}` : parts[0] || "franchi une nouvelle étape";
  return `${g.mine ? "avez" : "a"} ${list}`;
}
function recapBody(d = {}) {
  const t = (v, l, ic) => `<span class="rc-t"><b>${(+v || 0).toLocaleString("fr-FR")}</b><small>${icon(ic, { size: 13, stroke: 2.6 })} ${l}</small></span>`;
  return `<div class="recap-tiles">${t(d.xp, "XP", "zap")}${t(d.words, "mots", "notebook")}${t(d.lessons, "leçons", "book")}${t(d.streak, "j de série", "flame")}</div>`;
}
/* « Depuis ta dernière visite » : repère mémorisé sur cet appareil */
const SEEN_KEY = "impara.feedSeen";
let feedMark = null;               // repère utilisé pendant la visite en cours de l'onglet Fil
const readSeen = () => { try { return +localStorage.getItem(SEEN_KEY) || 0; } catch { return 0; } };
function feedSince() {
  if (feedMark == null) { feedMark = readSeen() || Date.now(); try { localStorage.setItem(SEEN_KEY, String(Date.now())); } catch {} }
  return feedMark;
}
/** Nombre de cartes d'amis arrivées depuis la dernière visite du Fil (pastille de l'onglet) */
function feedNewCount() {
  const list = So.feed(); if (!list) return 0;
  const since = readSeen(); if (!since) return 0;
  return groupFeed(list).filter((g) => !g.mine && g.at > since).length;
}

const secs = (ms) => (ms < 60000 ? `${Math.round(ms / 1000)} s` : `${Math.floor(ms / 60000)} min ${String(Math.round((ms % 60000) / 1000)).padStart(2, "0")}`);

/** Écrans communs : pas de serveur / pas connecté / chargement */
function gate(app, title) {
  if (!isConfigured()) {
    app.innerHTML = `<header class="page-head"><p class="eyebrow">Amis</p><h1>👥 ${title}</h1></header>
      <section class="card"><p>L'espace amis nécessite les comptes en ligne, qui ne sont pas activés sur ce site.</p></section>`;
    return true;
  }
  if (!So.isAvailable()) {
    app.innerHTML = `<header class="page-head"><p class="eyebrow">Amis</p><h1>👥 ${title}</h1>
      <p class="muted">Ajoutez vos amis, suivez leurs progrès, discutez et lancez-vous des défis.</p></header>
      <section class="card account-card"><p>Connectez-vous pour accéder à l'espace amis.</p>
      <a class="btn primary" href="#compte">☁️ Se connecter ou créer un compte</a></section>`;
    return true;
  }
  return false;
}
const skelRows = (n = 4) => Array.from({ length: n }, () => `<div class="skel-row"><span class="skel skel-av"></span><span class="skel-lines"><span class="skel skel-l1"></span><span class="skel skel-l2"></span></span></div>`).join("");
const loading = (app) => (app.innerHTML = `<div class="s-page skel-page" aria-busy="true" aria-label="Chargement"><span class="skel skel-title"></span><section class="card">${skelRows(5)}</section></div>`);
/** Charge les données sociales puis affiche ; en cas d'échec, message + bouton Réessayer */
function loadThen(app, render) {
  const hash = location.hash;
  loading(app);
  So.refresh().then(() => { if (stillHere(hash) && So.social().ready) { app._cleanup?.(); app._cleanup = null; render(); } })
    .catch((e) => {
      if (!stillHere(hash)) return;
      app.innerHTML = `<section class="card account-card"><p class="form-msg error">${esc(So.socialError(e))}</p>
        <button class="btn primary" data-retry>Réessayer</button></section>`;
      app.querySelector("[data-retry]").onclick = () => loadThen(app, render);
    });
}

/* ---------------------------- Cartes défi -------------------------- */
const OUT = { win: ["V", "Victoire", "win"], lose: ["D", "Défaite", "lose"], draw: ["N", "Égalité", "draw"] };
const MODE_ICON = { speed: "zap", precision: "target", survival: "skull", listen: "headphones" };
const modeIco = (m) => icon(MODE_ICON[m] || "timer", { size: 13, stroke: 2.6 });
/** « 14:05 » aujourd'hui · « hier » · « lun. » · « 3 nov. » */
function shortWhen(ts) {
  const d = new Date(ts), now = new Date(), y = new Date(now); y.setDate(now.getDate() - 1);
  if (d.toDateString() === now.toDateString()) return d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  if (d.toDateString() === y.toDateString()) return "hier";
  if (now - d < 6 * 864e5) return d.toLocaleDateString("fr-FR", { weekday: "short" });
  return d.toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
}
/** Une ligne de défi (même gabarit dans l'onglet Défis et sur la fiche d'un ami) */
function challengeCard(c, { showFriend = true } = {}) {
  const f = c.friend;
  const meta = `<small class="ch-meta">${modeIco(c.mode)} ${chSize(c)}${c.words ? ` · 🎯 ${terrainOf(c)}` : ""}${c.live ? " · ⚡ direct" : ""} · ${shortWhen(c.updated_at || c.created_at)}${c.mine?.lang ? ` · <span class="flag mini">${flagSVG(c.mine.lang)}</span>` : ""}</small>`;
  let lead = av(f, "sm"), title = "", right = "", actions = "", cls = "";
  switch (c.stage) {
    case "to_accept":
      title = c.rematch_of ? `🔁 ${who(f)} veut sa revanche` : c.live ? `⚡ ${who(f)} vous défie en direct` : `${who(f)} vous défie`; cls = "todo";
      actions = `<button class="btn ghost small" data-ch-decline="${c.id}">Refuser</button><button class="btn primary small" data-ch-accept="${c.id}">Accepter</button>`;
      break;
    case "to_play":
      title = c.theirs ? (c.mode === "survival" ? `${who(f)} a tenu ${c.theirs.score} question${c.theirs.score > 1 ? "s" : ""}` : `${who(f)} a fait ${c.theirs.score}/${c.theirs.total}`) : `Contre ${who(f)}`; cls = "todo";
      actions = `<a class="btn primary small" href="#defi-${c.id}">Jouer</a>`;
      break;
    case "waiting_accept":
      title = `Envoyé à ${who(f)}`; cls = "wait";
      actions = `${c.live ? `<a class="btn primary small" href="#defi-${c.id}">⚡ Salle</a>` : ""}<button class="btn ghost small" data-ch-cancel="${c.id}">Annuler</button>`;
      break;
    case "waiting_play":
      title = `${who(f)} doit jouer`; cls = "wait";
      right = `<span class="ch-score">${c.mode === "survival" ? `${c.mine.score} 🔥` : `${c.mine.score}/${c.mine.total}`}</span>`;
      break;
    case "done": {
      const [letter, label, k] = OUT[c.outcome]; cls = k;
      lead = `<span class="ch-pill ${k}" title="${label}">${letter}</span>`;
      title = showFriend ? `contre ${who(f)}` : label;
      right = `<span class="ch-score">${c.mine.score}<i>–</i>${c.theirs.score}</span>`;
      break;
    }
    case "declined": lead = `<span class="ch-pill off">–</span>`; title = c.iAmChallenger ? `${who(f)} a refusé` : "Défi refusé"; cls = "off"; break;
    case "cancelled": lead = `<span class="ch-pill off">–</span>`; title = "Défi annulé"; cls = "off"; break;
  }
  const link = ["done", "waiting_play", "to_play", "to_accept"].includes(c.stage) ? `href="#defi-${c.id}"` : "";
  return `<li class="ch-row ${cls}">
    ${link ? `<a class="ch-link" ${link} aria-label="Voir le défi"></a>` : ""}
    ${lead}
    <div class="ch-txt"><b>${title}</b>${meta}</div>
    ${right}${actions ? `<div class="ch-act">${actions}</div>` : ""}
  </li>`;
}
/** En-tête de section commun : icône + titre à gauche, action à droite */
const secHead = (ico, title, action = "") => `<header class="fr-sec-h"><h2>${icon(ico, { size: 18, stroke: 2.5 })}<span>${title}</span></h2>${action}</header>`;

/** Boutons d'action des défis (délégation) */
function bindChallengeActions(root) {
  root.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-ch-accept],[data-ch-decline],[data-ch-cancel]");
    if (!b) return;
    e.preventDefault();
    b.disabled = true;
    try {
      const ch = So.allChallenges().find((x) => x.id === b.dataset.chAccept);
      if (b.dataset.chAccept && ch && !canPlay(ch)) { b.disabled = false; const k = playNeed(ch); return notEnoughWords(`Pas assez de mots pour ${k} questions`, k); }
      if (b.dataset.chAccept) { await So.respondChallenge(b.dataset.chAccept, true); toast("Défi accepté ⚔️", "ok");
        if (location.hash === `#defi-${b.dataset.chAccept}`) window.dispatchEvent(new HashChangeEvent("hashchange"));
        else location.hash = `defi-${b.dataset.chAccept}`; }
      else if (b.dataset.chDecline) { await So.respondChallenge(b.dataset.chDecline, false); toast("Défi refusé"); }
      else { await So.cancelChallenge(b.dataset.chCancel); toast("Défi annulé"); }
    } catch (err) { toast(err.message, "warn"); b.disabled = false; }
  });
}

const MODES = {
  speed: ["⏱️ Vitesse", "Le temps compte : 100 pts par bonne réponse, −3 pts par seconde"],
  precision: ["🎯 Précision", "Seules les bonnes réponses comptent, prenez votre temps"],
  survival: ["💀 Mort subite", "Jusqu'à la première erreur : la plus longue série gagne"],
  listen: ["🎧 Écoute", "Tout à l'oreille : mot entendu, sens, dictée…"],
};
const modeLabel = (m) => (MODES[m] ? MODES[m][0] : "⏱️ Classique");
/** « 10 questions » ou « Mort subite », plus « sur le terrain de … » */
const chSize = (c) => (c.mode === "survival" ? "Mort subite" : `${c.n} questions`);
const terrainOf = (c) => (!c.words ? "" : c.iAmChallenger ? `terrain de ${who(c.friend)}` : "votre terrain");
/** Un défi est jouable si l'on a assez de mots (ou si la liste de mots est imposée) */
const canPlay = (c) => (c.words?.length >= CG.MIN_WORDS) || CG.canChallenge(c.mode === "survival" ? 5 : c.n);
const playNeed = (c) => (c.mode === "survival" ? 5 : c.n);
/** Points faibles publiés par un ami dans la langue en cours (null si inconnus) */
const friendWeak = (f) => { const w = So.statsOf(f?.id)?.[code]?.weak; return Array.isArray(w) && w.length >= CG.MIN_WORDS ? w : null; };

/** Tailles possibles pour un adversaire : il faut assez de mots des DEUX côtés */
function sizeState(n, friend) {
  if (pendingPick.terrain && friend && friendWeak(friend)) return { ok: true }; // mots imposés : ceux de l'adversaire
  const mine = CG.learnedWords().length, need = CG.wordsNeeded(n);
  if (mine < need) return { ok: false, why: `Il vous faut ${need} mots` };
  if (!friend) return { ok: true };
  const theirs = So.friendWords(friend.id);
  if (theirs == null) return n <= 15 ? { ok: true } : { ok: false, why: `Progression de ${who(friend)} inconnue` };
  if (theirs < need) return { ok: false, why: `${who(friend)} : ${theirs} mots` };
  return { ok: true };
}
function paintSizes() {
  const fr = So.friends();
  const friend = pendingPick.fixed || fr.find((f) => f.id === pendingPick.friend) || null;
  let firstOk = null;
  document.querySelectorAll("[data-ns] [data-n]").forEach((b) => {
    const st = sizeState(+b.dataset.n, friend);
    b.disabled = !st.ok;
    b.querySelector("small").textContent = st.ok ? b.dataset.t : `🔒 ${st.why}`;
    if (st.ok && firstOk == null) firstOk = +b.dataset.n;
  });
  // Taille choisie devenue impossible (autre ami) : on se replie sur la plus grande possible
  const cur = document.querySelector(`[data-ns] [data-n="${pendingPick.n}"]`);
  if (cur?.disabled) {
    const ok = [...document.querySelectorAll("[data-ns] [data-n]:not(:disabled)")].pop();
    pendingPick.n = ok ? +ok.dataset.n : null;
  }
  document.querySelectorAll("[data-ns] [data-n]").forEach((x) => x.classList.toggle("on", +x.dataset.n === pendingPick.n));
  // Mort subite : pas de nombre de questions à choisir
  const sz = document.querySelector("[data-sizes]");
  if (sz) sz.hidden = pendingPick.mode === "survival";
  // « Sur son terrain » : possible seulement si l'ami a partagé ses points faibles dans cette langue
  const t = document.querySelector("[data-terrain]");
  if (t) {
    const weak = friend ? friendWeak(friend) : null, real = So.statsOf(friend?.id)?.[code]?.weakReal || 0;
    t.disabled = !weak;
    if (!weak) { t.checked = false; pendingPick.terrain = false; }
    document.querySelector("[data-terrain-sub]").textContent = !friend ? "Choisissez d'abord un adversaire"
      : !weak ? `${who(friend)} n'a pas encore de points faibles connus en ${L.label.toLowerCase()}`
      : real >= 5 ? `Les questions portent sur les ${weak.length} mots que ${who(friend)} rate le plus`
      : `Les questions portent sur les ${weak.length} mots que ${who(friend)} maîtrise le moins`;
    t.closest(".live-opt")?.classList.toggle("off", !weak);
  }
}

/** Lancer un défi : ami, nombre de questions et mode */
async function askChallenge(friend = null) {
  if (!CG.canChallenge(5)) return notEnoughWords("Pas encore assez de mots pour défier", 5);
  const fr = So.friends();
  if (!friend && !fr.length) { toast("Ajoutez d'abord un ami depuis votre profil", "warn"); return; }
  let target = friend || (fr.length === 1 ? fr[0] : null);
  Object.assign(pendingPick, { friend: target?.id || null, fixed: friend, n: 10, mode: pendingPick.mode || "speed", terrain: false });
  if (!sizeState(10, target).ok) pendingPick.n = 5;
  const rec = (f) => { const r = So.record(f.id); return r.total ? `${r.win}V · ${r.lose}D${r.draw ? ` · ${r.draw}N` : ""}` : "Premier duel"; };
  const v = await modal({
    title: friend ? `⚔️ Défier ${who(friend)}` : "⚔️ Nouveau défi",
    body: `${friend ? "" : `<p class="set-label">Adversaire</p><div class="pick-friends">${fr.map((f) => `<button type="button" class="pick-friend ${target?.id === f.id ? "on" : ""}" data-f="${f.id}">${av(f, "sm")}<b>${who(f)}</b><small>${rec(f)}</small></button>`).join("")}</div>`}
      <p class="set-label">Mode</p>
      <div class="mode-pick" data-modes>${Object.entries(MODES).map(([k, [l, d]]) => `<button type="button" data-mode="${k}" class="${pendingPick.mode === k ? "on" : ""}"><b>${l}</b><small>${d}</small></button>`).join("")}</div>
      <div data-sizes>
        <p class="set-label">Nombre de questions</p>
        <div class="n-grid" data-ns>${CG.CHALLENGE_SIZES.map(([k, l, t]) => `<button type="button" data-n="${k}" data-t="${t}"><b>${k}</b><span>${l}</span><small>${t}</small></button>`).join("")}</div>
        <p class="small muted">Il faut avoir appris au moins autant de mots que de questions, vous <b>et</b> votre adversaire.</p>
      </div>
      <p class="set-label">Options</p>
      <label class="live-opt terrain-opt"><input type="checkbox" data-terrain><span class="live-txt"><b>🎯 Sur son terrain</b><small data-terrain-sub></small></span></label>
      <label class="live-opt"><input type="checkbox" data-live ${pendingPick.live ? "checked" : ""}><span class="live-txt"><b>⚡ En direct</b><small>Vous jouez en même temps et voyez la progression de l'autre en temps réel</small></span></label>
      <ul class="defi-rules"><li>🎲 Questions variées sur <b>vos mots appris</b> (ou ses points faibles, sur son terrain)</li><li>⏳ Votre ami doit accepter, puis chacun joue quand il veut (ou ensemble en direct)</li></ul>`,
    actions: [{ label: "Annuler", value: "" }, { label: "⚔️ Lancer le défi", value: "go", kind: "primary" }],
    onOpen: paintSizes,
  });
  if (v !== "go") return;
  target = friend || fr.find((f) => f.id === pendingPick.friend) || null;
  if (!target) { toast("Choisissez un adversaire", "warn"); return askChallenge(null); }
  const survival = pendingPick.mode === "survival";
  const n = survival ? 50 : pendingPick.n;
  if (!survival && (!n || !sizeState(n, target).ok)) { toast("Ce nombre de questions n'est pas possible avec cet adversaire", "warn"); return askChallenge(friend); }
  if (survival && !sizeState(5, target).ok) { toast(`Il faut au moins ${CG.MIN_WORDS} mots chacun pour la mort subite`, "warn"); return; }
  const words = pendingPick.terrain ? friendWeak(target) : null;
  if (pendingPick.terrain && !words) { toast(`${who(target)} n'a pas encore de points faibles connus`, "warn"); return; }
  await launch(target, { n, mode: pendingPick.mode, live: pendingPick.live, words });
}
/** Envoie un défi (nouveau ou revanche) puis, en direct, ouvre la salle d'attente */
async function launch(target, { n, mode, live, words = null, rematch = null }) {
  try {
    const id = await So.createChallenge(target.id, n, mode, live, { words, rematch });
    toast(rematch ? `Revanche envoyée à ${target.pseudo || target.username} 🔁` : `${live ? "Duel en direct" : "Défi"} envoyé à ${target.pseudo || target.username} ⚔️`, "ok");
    if (live && id) location.hash = `defi-${id}`; // salle d'attente du duel
    return id;
  } catch (e) { toast(e.message, "warn"); return null; }
}
/** Revanche en un clic : mêmes réglages, même adversaire (son terrain mis à jour) */
async function rematch(c) {
  const f = c.friend;
  if (!f) return;
  const terrain = !!c.words, words = terrain ? friendWeak(f) : null;
  if (!CG.canChallenge(c.mode === "survival" ? 5 : terrain ? 5 : c.n) && !words) return notEnoughWords("Pas assez de mots pour cette revanche", c.n);
  const id = await launch(f, { n: c.n, mode: c.mode || "speed", live: !!c.live, words: terrain ? words : null, rematch: c.outcome === "win" ? null : c.id });
  if (id && !c.live) location.hash = "amis-defis";
}
document.addEventListener("click", (e) => {
  // Sélections dans la fenêtre « Nouveau défi »
  const pf = e.target.closest(".pick-friend"), pn = e.target.closest("[data-ns] [data-n]"), pm = e.target.closest("[data-modes] [data-mode]");
  if (pf) { document.querySelectorAll(".pick-friend").forEach((x) => x.classList.toggle("on", x === pf)); pendingPick.friend = pf.dataset.f; paintSizes(); }
  if (pn && !pn.disabled) { pendingPick.n = +pn.dataset.n; paintSizes(); }
  if (pm) { document.querySelectorAll("[data-modes] [data-mode]").forEach((x) => x.classList.toggle("on", x === pm)); pendingPick.mode = pm.dataset.mode; paintSizes(); }
});
const pendingPick = { friend: null, fixed: null, n: null, mode: "speed", live: false, terrain: false };
document.addEventListener("change", (e) => {
  if (e.target.matches?.("[data-live]")) pendingPick.live = e.target.checked;
  if (e.target.matches?.("[data-terrain]")) { pendingPick.terrain = e.target.checked; paintSizes(); }
});

/* ============================== #amis ============================== */
let tab = "classement"; // onglet actif : classement | fil | defis | amis
const flt = { friend: "", mode: "", out: "" }; // filtres de l'historique des défis
const MEDALS = ["🥇", "🥈", "🥉"];
const weekLabel = (start) => {
  const end = new Date(start); end.setUTCDate(end.getUTCDate() + 6);
  const f = (d) => d.toLocaleDateString("fr-FR", { day: "numeric", month: "short", timeZone: "UTC" });
  return `${f(start)} – ${f(end)}`;
};
function countdown() {
  const ms = P.nextWeekReset() - Date.now(), d = Math.floor(ms / 864e5), h = Math.floor((ms % 864e5) / 36e5), m = Math.floor((ms % 36e5) / 6e4);
  return d ? `${d} j ${h} h` : h ? `${h} h ${m} min` : `${m} min`;
}

export function renderAmis(app, opts = {}) {
  if (opts.tab) tab = opts.tab;
  if (gate(app, "Amis")) return;
  const S = So.social();
  if (!S.ready) { loadThen(app, () => renderAmis(app, opts)); return; }
  if (!S.me) return renderUsername(app);

  app.innerHTML = `<div class="s-page fr-page">
  <header class="fr-head">
    <div><h1>👥 Amis</h1></div>
    <div class="fr-head-act"><a class="fr-inbox" href="#messages" aria-label="Messages">${icon("chat", { size: 22 })}<em class="err-badge" data-b="inbox" hidden></em></a>
      <a class="fr-add" href="#profil-ajout" aria-label="Ajouter un ami">${icon("user-plus", { size: 20 })}<span>Ajouter</span></a></div>
  </header>
  <div data-zone="push"></div>
  <div data-zone="requests"></div>
  <nav class="fr-tabs" role="tablist">
    <span class="fr-tab-ind" aria-hidden="true"></span>
    <button role="tab" data-tab-btn="classement">${icon("trophy", { size: 19 })}<span>Classement</span></button>
    <button role="tab" data-tab-btn="defis">${icon("swords", { size: 19 })}<span>Défis</span><em class="err-badge" data-b="defis" hidden></em></button>
    <button role="tab" data-tab-btn="amis">${icon("users", { size: 19 })}<span>Amis</span><em class="err-badge" data-b="amis" hidden></em></button>
    <button role="tab" data-tab-btn="fil">${icon("news", { size: 19 })}<span>Fil</span><em class="err-badge" data-b="fil" hidden></em></button>
  </nav>
  <div data-zone="panel"></div>
  </div>`;
  const page = app.firstElementChild;
  const z = (n) => page.querySelector(`[data-zone="${n}"]`);
  let history = null; // historique chargé une fois par visite
  let showAllDone = false, histLoading = false;

  const paint = () => {
    if (!page.isConnected) return off?.();
    const inc = So.incoming(), all = So.allChallenges(), fr = So.friends();
    const todo = all.filter((c) => c.stage === "to_accept" || c.stage === "to_play");
    const unread = Object.values(S.unread).reduce((a, b) => a + b, 0);
    // Demandes d'ami : simple bandeau (le détail est dans l'onglet Amis)
    z("requests").innerHTML = inc.length && tab !== "amis" ? `<button class="fr-banner" data-goto-tab="amis">${av(inc[0].from, "sm")}
      <span><b>${inc.length > 1 ? `${inc.length} demandes d'ami` : `${who(inc[0].from)} veut être votre ami`}</b></span><span class="fr-banner-go">Voir ${icon("chevron", { size: 16, stroke: 2.6 })}</span></button>` : "";
    const badge = (k, n) => { const b = page.querySelector(`[data-b="${k}"]`); b.textContent = n; b.hidden = !n; };
    badge("defis", todo.length); badge("amis", inc.length); badge("inbox", unread);
    if (!So.feed()) So.loadFeed().catch(() => {});           // pour la pastille « nouveau » du Fil
    badge("fil", tab === "fil" ? 0 : feedNewCount());
    page.querySelectorAll("[data-tab-btn]").forEach((b, i) => { const on = b.dataset.tabBtn === tab; b.classList.toggle("on", on); b.setAttribute("aria-selected", on); if (on) page.querySelector(".fr-tabs").style.setProperty("--i", i); });
    z("panel").innerHTML = tab === "classement" ? panelBoard(fr) : tab === "fil" ? panelFeed() : tab === "defis" ? panelDefis(all, fr) : panelAmis(fr);
    if (tab === "classement") paintHistory();
  };

  /* ---- 🏆 Classement : podium de la semaine + semaines précédentes */
  function panelBoard(fr) {
    const board = So.leaderboard();
    if (board.length < 2) return `<section class="card fr-empty"><span>🏆</span><p>Ajoutez des amis pour comparer vos XP chaque semaine.</p><a class="btn primary" href="#profil-ajout">Ajouter un ami</a></section>`;
    const top = board.slice(0, 3), order = [top[1], top[0], top[2]].filter(Boolean);
    return `<section class="card fr-sec fr-board">
      ${secHead("trophy", "Cette semaine", `<span class="fr-chip" data-countdown>${icon("clock", { size: 13, stroke: 2.6 })} ${countdown()}</span>`)}
      <div class="podium">${order.map((p) => { const i = board.indexOf(p); return `
        <div class="pod pod-${i + 1} ${p.isMe ? "me" : ""}">
          ${i === 0 && p.xp ? `<span class="crown">${icon("crown", { size: 28, stroke: 2, fill: "#ffd24a" })}</span>` : ""}${av(p, "lg")}
          <b>${p.isMe ? "Vous" : who(p)}</b><small>${p.xp} XP</small>
          <div class="pod-block">${p.xp ? MEDALS[i] : "–"}</div></div>`; }).join("")}</div>
      ${board.length > 3 ? `<ol class="s-board" start="4">${board.slice(3).map((p, k) => `<li class="${p.isMe ? "me" : ""}"><span class="s-rank">${k + 4}</span>${av(p, "sm")}
        <span class="s-board-name">${p.isMe ? "Vous" : who(p)}<small>${p.allXp} XP au total</small></span><b>${p.xp} XP</b></li>`).join("")}</ol>` : ""}
      <p class="fr-foot">XP gagnés depuis lundi, toutes langues. Nouvelle semaine ${P.nextWeekReset().toLocaleString("fr-FR", { weekday: "long", hour: "2-digit", minute: "2-digit" })}.</p>
    </section>
    <section class="card fr-sec">${secHead("medal", "Semaines précédentes")}<div data-zone="history" aria-busy="true">${skelRows(3)}</div></section>`;
  }
  async function paintHistory() {
    const zone = z("history"); if (!zone) return;
    try { history ||= await So.weeklyHistory(12); } catch { zone.innerHTML = `<p class="muted small">Historique indisponible pour le moment.</p>`; return; }
    if (!z("history")) return;
    if (!history.length) { z("history").innerHTML = `<p class="muted small">Le premier gagnant sera couronné lundi. Revenez voir le palmarès !</p>`; return; }
    const titles = new Map();
    history.forEach((w) => { const id = w.ranking[0].id; titles.set(id, (titles.get(id) || 0) + 1); });
    const champs = [...titles.entries()].sort((a, b) => b[1] - a[1]).map(([id, n]) => {
      const p = id === S.me.id ? S.me : S.profiles[id];
      return `<span class="champ">${av(p, "sm")}<b>${id === S.me.id ? "Vous" : who(p)}</b> 👑×${n}</span>`;
    }).join("");
    z("history").innerHTML = `<div class="champs">${champs}</div><ul class="hist">${history.map((w, k) => `
      <li><details ${k === 0 ? "open" : ""}><summary><span class="hist-week">${weekLabel(w.start)}</span>
        <span class="hist-win">👑 ${av(w.ranking[0].profile, "sm")}<b>${w.ranking[0].isMe ? "Vous" : who(w.ranking[0].profile)}</b><small>${w.ranking[0].xp} XP</small></span></summary>
        <ol class="s-board">${w.ranking.map((r, i) => `<li class="${r.isMe ? "me" : ""}"><span class="s-rank">${MEDALS[i] || i + 1}</span>${av(r.profile, "sm")}
          <span class="s-board-name">${r.isMe ? "Vous" : who(r.profile)}</span><b>${r.xp} XP</b></li>`).join("")}</ol></details></li>`).join("")}</ul>`;
  }

  /* ---- 📰 Fil : les étapes de chacun, regroupées par personne et par jour */
  function panelFeed() {
    const list = So.feed();
    if (!list) { So.loadFeed().catch(() => {}); return `<section class="card" aria-busy="true">${skelRows(4)}</section>`; }
    if (!list.length) return `<section class="card fr-empty"><span>📰</span><p>Rien pour l'instant. Leçons, niveaux, séries, défis gagnés : les étapes de vos amis et les vôtres apparaîtront ici.</p></section>`;
    const groups = groupFeed(list), since = feedSince();
    const fresh = groups.filter((g) => !g.mine && g.at > since);
    const old = groups.filter((g) => !fresh.includes(g));
    return `<section class="card feed-card">
      ${fresh.length ? `<p class="feed-sep new"><span>Depuis ta dernière visite · ${fresh.length}</span></p><ul class="feed">${fresh.map((g) => feedGroup(g, true)).join("")}</ul>` : ""}
      ${fresh.length && old.length ? `<p class="feed-sep"><span>Plus tôt</span></p>` : ""}
      ${old.length ? `<ul class="feed">${old.map((g) => feedGroup(g, false)).join("")}</ul>` : ""}
    </section>`;
  }
  function feedGroup(g, isNew) {
    const p = g.who, mine = g.mine;
    const link = mine ? "#profil" : p ? `#ami-${esc(p.username)}` : "#amis";
    // Réactions : toutes celles du groupe ; la mienne porte sur l'activité où je l'ai mise (sinon la plus récente)
    const all = g.items.flatMap((a) => a.reactions);
    const myRx = all.find((r) => r.user_id === S.me.id);
    const target = myRx ? myRx.activity_id : g.items[0].id;
    const nameOf = (r) => (r.user_id === S.me.id ? "vous" : who(S.profiles[r.user_id]));
    const counts = So.REACTIONS.map((e) => [e, all.filter((r) => r.emoji === e)]).filter(([, rs]) => rs.length);
    const pills = counts.map(([e, rs]) => `<button class="rx ${myRx?.emoji === e ? "on" : ""}" ${mine ? "disabled" : `data-rx="${target}" data-e="${e}"`} title="${esc(rs.map(nameOf).join(", "))}">${e}<i>${rs.length}</i></button>`).join("");
    const picker = mine ? "" : `<button class="rx rx-add" data-rx-open aria-label="Réagir">${icon("smile-plus", { size: 18 })}</button>
      <span class="rx-pick" hidden>${So.REACTIONS.map((e) => `<button class="rx ${myRx?.emoji === e ? "on" : ""}" data-rx="${target}" data-e="${e}">${e}</button>`).join("")}</span>`;
    const body = g.recap ? recapBody(g.recap.data) : `<p><b>${mine ? "Vous" : who(p)}</b> ${groupSentence(g)}</p>${g.lessons.length > 1 ? `<p class="feed-sub">${g.lessons.slice(0, 4).map(esc).join(" · ")}${g.lessons.length > 4 ? " · …" : ""}</p>` : ""}`;
    return `<li class="feed-item ${mine ? "mine" : ""} ${isNew ? "is-new" : ""} ${g.recap ? "recap" : ""}">
      <a class="feed-av" href="${link}">${av(p)}<span class="feed-ico k-${g.top}">${icon(FEED_ICONS[g.top] || "sparkles", { size: 15, stroke: 2.6 })}</span></a>
      <div class="feed-body">
        ${g.recap ? `<p class="feed-recap-t"><b>${mine ? "Votre" : `${who(p)} ·`} bilan de la semaine</b></p>` : ""}
        ${body}
        <div class="feed-meta"><small>${dayWhen(g.at)}${g.langs.map((l) => ` <span class="flag mini">${flagSVG(l)}</span>`).join("")}</small>
          <span class="rx-row">${pills}${picker}</span></div>
      </div></li>`;
  }
  /* ---- ⚔️ Défis : bilan, nouveau défi, à jouer / en attente / terminés */
  function panelDefis(all, fr) {
    const r = So.record(), rate = r.total ? Math.round((r.win / r.total) * 100) : 0;
    const todo = all.filter((c) => c.stage === "to_accept" || c.stage === "to_play");
    const wait = all.filter((c) => c.stage === "waiting_accept" || c.stage === "waiting_play");
    if (!So.historyLoaded() && !histLoading) { histLoading = true; So.loadHistory().then(() => page.isConnected && tab === "defis" && paint()).catch(() => {}); }
    const hist = So.history();
    const doneAll = hist.filter((c) => ["done", "declined", "cancelled"].includes(c.stage));
    const filtering = flt.friend || flt.mode || flt.out;
    const done = doneAll.filter((c) => (!flt.friend || c.friend?.id === flt.friend) && (!flt.mode || (c.mode || "speed") === flt.mode) && (!flt.out || c.outcome === flt.out));
    const shown = showAllDone || filtering ? done.slice(0, 60) : done.slice(0, 5);
    const usedModes = [...new Set(doneAll.map((c) => c.mode || "speed"))];
    const rivals = fr.map((f) => ({ f, rec: So.record(f.id) })).sort((a, b) => b.rec.total - a.rec.total);
    return `
    <section class="card fr-sec ch-summary">
      <div class="ch-ring">${ring(rate, 64, 7, r.total ? `${rate}%` : "–")}</div>
      <div class="ch-sum-txt"><b>${r.total ? `${r.win} V · ${r.draw} N · ${r.lose} D` : "Aucun défi joué"}</b><small>${r.total ? `${r.total} défi${r.total > 1 ? "s" : ""} · taux de victoire` : "Lancez votre premier duel !"}</small></div>
      <button class="btn primary ch-new" data-new ${fr.length ? "" : "disabled"}>${icon("swords", { size: 18, stroke: 2.5 })} Nouveau</button>
    </section>
    ${todo.length ? `<section class="ch-todo">${todo.map((c) => {
      const f = c.friend;
      return `<article class="ch-todo-card ${c.live ? "live" : ""}">
        <a class="ch-link" href="#defi-${c.id}" aria-label="Voir le défi"></a>
        <div class="ch-todo-top">${av(f)}<div><p class="ch-todo-k">${c.stage === "to_accept" ? (c.rematch_of ? "🔁 Revanche" : c.live ? "⚡ Duel en direct" : "Nouveau défi") : "À vous de jouer"}</p>
          <b>${c.stage === "to_accept" ? (c.rematch_of ? `${who(f)} veut sa revanche !` : `${who(f)} vous défie !`) : c.theirs ? (c.mode === "survival" ? `${who(f)} a tenu ${c.theirs.score} questions : à vous !` : `${who(f)} a fait ${c.theirs.score}/${c.theirs.total} : à vous !`) : `Votre tour contre ${who(f)}`}</b>
          <small class="ch-meta">${modeIco(c.mode)} ${modeLabel(c.mode).replace(/^\S+\s/, "")}${c.mode === "survival" ? "" : ` · ${c.n} questions`}${c.words ? ` · 🎯 ${terrainOf(c)}` : ""}</small></div></div>
        <div class="ch-todo-act">${c.stage === "to_accept"
          ? `<button class="btn ghost small" data-ch-decline="${c.id}">Refuser</button><button class="btn primary" data-ch-accept="${c.id}">Accepter</button>`
          : `<a class="btn primary" href="#defi-${c.id}">${icon("play", { size: 16, fill: "currentColor" })} Jouer</a>`}</div>
      </article>`; }).join("")}</section>` : ""}
    ${rivals.length ? `<section class="card fr-sec">${secHead("users", "Tes rivaux")}
      <div class="rivals">${rivals.map(({ f, rec }) => `<button class="rival" data-rival="${esc(f.username)}" aria-label="Défier ${who(f)}">${av(f)}<b>${who(f)}</b>
        <small>${rec.total ? `${rec.win}–${rec.lose}${rec.draw ? `–${rec.draw}` : ""}` : "Défier"}</small></button>`).join("")}</div></section>` : ""}
    ${wait.length ? `<section class="card fr-sec">${secHead("hourglass", "En attente")}<ul class="ch-list">${wait.map((c) => challengeCard(c)).join("")}</ul></section>` : ""}
    ${statsCard()}
    <section class="card fr-sec">${secHead("medal", "Historique", done.length > 5 && !showAllDone && !filtering ? `<button class="fr-link" data-show-all>Voir tout (${done.length})</button>` : "")}
      ${doneAll.length > 3 ? `<div class="ch-filters">
        ${fr.length > 1 ? `<select data-flt="friend" aria-label="Filtrer par ami"><option value="">Tous les amis</option>${fr.map((f) => `<option value="${f.id}" ${flt.friend === f.id ? "selected" : ""}>${who(f)}</option>`).join("")}</select>` : ""}
        <select data-flt="mode" aria-label="Filtrer par mode"><option value="">Tous les modes</option>${usedModes.map((m) => `<option value="${m}" ${flt.mode === m ? "selected" : ""}>${modeLabel(m)}</option>`).join("")}</select>
        <select data-flt="out" aria-label="Filtrer par résultat"><option value="">Tous les résultats</option>${[["win", "Victoires"], ["lose", "Défaites"], ["draw", "Égalités"]].map(([k, l]) => `<option value="${k}" ${flt.out === k ? "selected" : ""}>${l}</option>`).join("")}</select>
      </div>${filtering ? `<p class="ch-flt-n">${done.length} défi${done.length > 1 ? "s" : ""} · <button class="fr-link" data-flt-reset>Effacer les filtres</button></p>` : ""}` : ""}
      ${shown.length ? `<ul class="ch-list">${shown.map((c) => challengeCard(c)).join("")}</ul>` : `<p class="fr-none">${filtering ? "Aucun défi pour ces filtres." : fr.length ? "Vos défis terminés apparaîtront ici." : "Ajoutez un ami pour lancer votre premier défi."}</p>`}
    </section>`;
  }

  /** Records personnels + taux de victoire par mode */
  function statsCard() {
    const R = So.records(), M = So.modeStats();
    const tiles = [
      R.survival && ["💀", R.survival.value, "meilleure série", "Mort subite", R.survival.c],
      R.speed && ["⚡", `${R.speed.value}`, "pts en vitesse", "Meilleur score", R.speed.c],
      R.listen && ["🎧", `${R.listen.value} %`, "à l'écoute", "Meilleur score", R.listen.c],
      R.fastest && ["⏱️", dur(R.fastest.value), "par question", "Sans-faute le plus rapide", R.fastest.c],
      R.perfect && ["🎯", R.perfect.value, "questions sans faute", "Plus long sans-faute", R.perfect.c],
    ].filter(Boolean);
    const modes = Object.entries(M).filter(([, o]) => o.total).sort((a, b) => b[1].total - a[1].total);
    if (!tiles.length && !modes.length) return "";
    const pct = (o) => Math.round((o.win / o.total) * 100);
    const ranked = modes.filter(([, o]) => o.total >= 3).sort((a, b) => pct(b[1]) - pct(a[1]));
    const tip = ranked.length >= 2 && pct(ranked[0][1]) > pct(ranked[ranked.length - 1][1])
      ? `Point fort : <b>${modeLabel(ranked[0][0]).replace(/^\S+\s/, "")}</b> (${pct(ranked[0][1])} %) · à travailler : <b>${modeLabel(ranked[ranked.length - 1][0]).replace(/^\S+\s/, "")}</b> (${pct(ranked[ranked.length - 1][1])} %)` : "";
    return `<section class="card fr-sec ch-stats">${secHead("chart", "Tes stats")}
      ${tiles.length ? `<p class="ch-sub">Records personnels</p><div class="rec-grid">${tiles.map(([e, v, u, l, c]) => `<a class="rec-tile" href="#defi-${c.id}"><span class="rec-e">${e}</span><b>${v}</b><small>${u}</small><em>${l}</em></a>`).join("")}</div>` : ""}
      ${modes.length ? `<p class="ch-sub">Victoires par mode</p><ul class="mode-stats">${modes.map(([m, o]) => `<li><span class="ms-l">${modeIco(m)} ${modeLabel(m).replace(/^\S+\s/, "")}</span>
          <span class="ms-bar"><i class="w" style="flex:${o.win}"></i><i class="d" style="flex:${o.draw}"></i><i class="l" style="flex:${o.lose}"></i></span>
          <span class="ms-n"><b>${pct(o)} %</b><small>${o.win} V · ${o.lose} D${o.draw ? ` · ${o.draw} N` : ""}</small></span></li>`).join("")}</ul>` : ""}
      ${tip ? `<p class="ms-tip">${tip}</p>` : ""}
    </section>`;
  }

  /* ---- 👥 Amis : liste, messages non lus, demandes envoyées */
  function panelAmis(fr) {
    const out = So.outgoing(), inc = So.incoming();
    const reqs = inc.length ? `<section class="card fr-sec fr-req">${secHead("user-plus", inc.length > 1 ? `${inc.length} demandes d'ami` : "Demande d'ami")}<ul class="fr-list">
      ${inc.map((r) => `<li class="fr-row">${av(r.from)}<div class="fr-row-txt"><b>${who(r.from)}</b><small>@${esc(r.from?.username || "")}</small></div>
        <div class="fr-row-act"><button class="btn ghost small" data-remove="${r.id}">Refuser</button><button class="btn primary small" data-accept="${r.id}">Accepter</button></div></li>`).join("")}</ul></section>` : "";
    const list = fr.length ? `<section class="card fr-sec">${secHead("users", `Mes amis · ${fr.length}`)}<ul class="fr-list">${fr.map((f) => {
      const st = So.statsOf(f.id), n = S.unread[f.id] || 0;
      const streak = Math.max(0, ...Object.values(st).map((x) => x?.streak || 0));
      const langs = Object.keys(LANGS).filter((c) => st[c]).map((c) => `<span class="fr-lang"><span class="flag mini">${flagSVG(c)}</span>${esc(st[c].level)}</span>`).join("");
      return `<li class="fr-row fr-friend">
        <a class="ch-link" href="#ami-${esc(f.username)}" aria-label="Profil de ${who(f)}"></a>
        ${av(f)}<div class="fr-row-txt"><b>${who(f)}</b><small>${langs || "Pas encore de progression"}${streak ? `<span class="fr-streak">${icon("flame", { size: 13, stroke: 2.6 })}${streak}</span>` : ""}</small></div>
        <div class="fr-row-act"><a class="fr-round" href="#chat-${esc(f.username)}" aria-label="Écrire à ${who(f)}">${icon("chat", { size: 19 })}${n ? `<em class="err-badge">${n}</em>` : ""}</a>
          <button class="fr-round" data-rival="${esc(f.username)}" aria-label="Défier ${who(f)}">${icon("swords", { size: 19 })}</button></div></li>`;
    }).join("")}</ul></section>` : `<section class="card fr-empty"><span>👋</span><p>Vous n'avez pas encore d'amis ici.</p><a class="btn primary" href="#profil-ajout">Ajouter un ami</a></section>`;
    const sent = out.length ? `<section class="card fr-sec">${secHead("clock", "Demandes envoyées")}<ul class="fr-list">
      ${out.map((r) => `<li class="fr-row">${av(r.to)}<div class="fr-row-txt"><b>${who(r.to)}</b><small>En attente de réponse</small></div>
        <div class="fr-row-act"><button class="btn ghost small" data-remove="${r.id}">Annuler</button></div></li>`).join("")}</ul></section>` : "";
    return reqs + list + sent;
  }

  paint();

  // Invitation à activer les notifications (si possible et pas encore fait)
  PWA.pushState().then((st) => {
    const zone = z("push");
    if (!zone || (st !== "off" && st !== "needs-install")) return;
    let hidden = false; try { hidden = localStorage.getItem("impara.pushHint") === "no"; } catch {}
    if (hidden) return;
    zone.innerHTML = `<section class="card s-push-hint"><p>🔔 <b>Soyez prévenu</b> quand un ami vous écrit ou vous lance un défi.</p>
      <div class="btn-row">${st === "off" ? `<button class="btn primary small" data-push-on>Activer les notifications</button>` : `<a class="btn ghost small" href="#reglages-notifications">Installer l'application d'abord</a>`}
      <button class="btn ghost small" data-push-no>Plus tard</button></div></section>`;
    zone.querySelector("[data-push-no]").onclick = () => { try { localStorage.setItem("impara.pushHint", "no"); } catch {} zone.innerHTML = ""; };
    zone.querySelector("[data-push-on]")?.addEventListener("click", async (e) => {
      e.target.disabled = true;
      try { await PWA.enablePush(); toast("Notifications activées 🔔", "ok"); zone.innerHTML = ""; }
      catch (err) { toast(err.message, "warn"); e.target.disabled = false; }
    });
  });

  page.addEventListener("change", (e) => { const f = e.target.closest("[data-flt]"); if (f) { flt[f.dataset.flt] = f.value; paint(); } });
  page.addEventListener("click", async (e) => {
    const gt = e.target.closest("[data-goto-tab]");
    if (gt) { tab = gt.dataset.gotoTab; paint(); return; }
    const rv = e.target.closest("[data-rival]");
    if (rv) { e.preventDefault(); askChallenge(So.friendByUsername(rv.dataset.rival)); return; }
    const sa = e.target.closest("[data-show-all]");
    if (sa) { showAllDone = true; paint(); return; }
    if (e.target.closest("[data-flt-reset]")) { Object.assign(flt, { friend: "", mode: "", out: "" }); paint(); return; }
    const t = e.target.closest("[data-tab-btn]");
    if (t) { if (tab === "fil" && t.dataset.tabBtn !== "fil") feedMark = null; tab = t.dataset.tabBtn; paint(); return; }
    const open = e.target.closest("[data-rx-open]");
    if (open) { const pk = open.nextElementSibling; page.querySelectorAll(".rx-pick").forEach((x) => { if (x !== pk) x.hidden = true; }); pk.hidden = !pk.hidden; open.classList.toggle("on", !pk.hidden); return; }
    if (e.target.closest("[data-new]")) { askChallenge(); return; }
    const rx = e.target.closest("[data-rx]");
    if (rx) { rx.disabled = true; try { await So.react(+rx.dataset.rx, rx.dataset.e); } catch (err) { toast(So.socialError(err), "warn"); rx.disabled = false; } return; }
    const a = e.target.closest("[data-accept]"), r = e.target.closest("[data-remove]");
    if (!a && !r) return;
    (a || r).disabled = true;
    try {
      if (a) { await So.acceptFriend(+a.dataset.accept); toast("🎉 Nouvel ami !", "ok"); }
      else { await So.removeFriendship(+r.dataset.remove); }
    } catch (err) { toast(So.socialError(err), "warn"); (a || r).disabled = false; }
  });
  bindChallengeActions(page);
  const off = So.onSocial((what) => { if (what !== "message") paint(); else paint(); });
  // Le compte à rebours du classement se met à jour toutes les minutes
  const tick = setInterval(() => { const c = page.querySelector("[data-countdown]"); if (c) c.innerHTML = `${icon("clock", { size: 13, stroke: 2.6 })} ${countdown()}`; }, 60000);
  app._cleanup = () => { off(); clearInterval(tick); feedMark = null; };
}

/* ------------------------- Choix du nom d'utilisateur --------------- */
function renderUsername(app) {
  const suggestion = (state.profile?.pseudo || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9_]/g, "").slice(0, 20);
  app.innerHTML = `
  <header class="page-head"><p class="eyebrow">Amis</p><h1>👥 Choisissez votre nom d'utilisateur</h1>
    <p class="muted">C'est grâce à lui que vos amis pourront vous ajouter. Il est unique et visible des autres utilisateurs.</p></header>
  <form class="card account-card auth-form" data-form="username" autocomplete="off">
    <label class="field"><span>Nom d'utilisateur</span>
      <div class="s-add-row"><span class="s-at">@</span><input name="u" required minlength="3" maxlength="20" value="${esc(suggestion.length >= 3 ? suggestion : "")}" placeholder="ex. thomas_92" autocapitalize="none" spellcheck="false"></div></label>
    <p class="muted small">3 à 20 caractères : lettres minuscules, chiffres et « _ ». Pas d'espace ni d'accent.</p>
    <p class="form-msg" role="alert"></p>
    <button class="btn primary big" type="submit">Valider</button>
  </form>`;
  const form = app.querySelector("form"), msg = form.querySelector(".form-msg");
  form.u.oninput = () => { const v = form.u.value.toLowerCase().replace(/\s/g, "_"); if (v !== form.u.value) form.u.value = v; };
  form.onsubmit = async (e) => {
    e.preventDefault();
    const btn = form.querySelector("button[type=submit]"); btn.disabled = true; msg.className = "form-msg"; msg.textContent = "";
    try { await So.createProfile(form.u.value); toast("Nom d'utilisateur enregistré ✓", "ok"); renderAmis(app); }
    catch (err) { msg.className = "form-msg error"; msg.textContent = err.message; btn.disabled = false; }
  };
  setTimeout(() => form.u.focus(), 50);
}

/* =========================== #ami-<nom> ============================ */
export function renderAmi(app, username) {
  if (gate(app, "Amis")) return;
  const S = So.social();
  if (!S.ready) { loadThen(app, () => renderAmi(app, username)); return; }
  if (!S.me) { location.hash = "amis"; return; }
  const f = So.friendByUsername(username);
  if (!f) {
    app.innerHTML = `<section class="card account-card"><p>@${esc(username)} ne fait pas (ou plus) partie de vos amis.</p><a class="btn ghost" href="#amis">← Mes amis</a></section>`;
    return;
  }
  const color = f.color || "#cfe6ff";
  const ink = (() => { const n = parseInt(color.slice(1), 16); return ((n >> 16) * 299 + ((n >> 8) & 255) * 587 + (n & 255) * 114) / 1000 > 150 ? "#1d2733" : "#ffffff"; })();

  const fb = C.bannerStyle(f.banner);
  app.innerHTML = `<div class="pf fp">
    <section class="fh-banner ${fb ? "has-pattern" : ""}" style="--banner:${esc(color)};--banner-ink:${fb ? fb.ink : ink}${fb ? `;--banner-bg:${fb.bg}` : ""}">
      <a class="fh-btn" href="#amis" aria-label="Retour">‹</a>
      <button class="fh-btn fh-friend" data-friend-menu aria-label="Options d'amitié">✓ Ami</button>
      <span class="fh-avatar ${C.frameClass(f.frame)}">${esc(f.avatar || "👤")}</span>
    </section>
    <section class="pf-body fh-body">
      <h1 class="fh-name">${who(f)}</h1>
      <p class="fh-handle">@${esc(f.username)} · ami depuis ${new Date(f.since).toLocaleDateString("fr-FR", { month: "long", year: "numeric" })}</p>
      <div data-zone="head"></div>
      <div class="fp-actions">
        <button class="fp-btn msg" data-chat>💬<b>Message</b><em class="err-badge" data-unread hidden></em></button>
        <button class="fp-btn duel" data-challenge>⚔️<b>Défi</b></button>
      </div>

      <h2 class="pf-h2">Bilan hebdomadaire</h2>
      <div data-zone="chart"></div>

      <h2 class="pf-h2">Récap</h2>
      <div data-zone="recap"></div>

      <h2 class="pf-h2">Défis entre vous</h2>
      <div data-zone="challenges"></div>
    </section>
  </div>`;
  const page = app.firstElementChild;
  const z = (n) => page.querySelector(`[data-zone="${n}"]`);
  let expanded = false; // historique des défis : 3 derniers par défaut

  const paint = () => {
    if (!page.isConnected) return off?.();
    const theirs = So.statsOf(f.id);
    const mine = { ...So.statsOf(S.me.id), [code]: So.mySummary() };
    const langs = Object.keys(LANGS).filter((c) => theirs[c]);
    // En-tête : cours suivis + bilan des duels
    const rec = So.record(f.id);
    const week = P.weekKey(), wk = (st) => Object.values(st).reduce((n, x) => n + (x?.week === week ? x.weekXp || 0 : 0), 0);
    const herWeek = wk(theirs), myWeek = wk(mine);
    const streak = Math.max(0, ...Object.values(theirs).map((x) => x?.streak || 0));
    const board = So.leaderboard(), rank = board.findIndex((p) => p.id === f.id) + 1;
    const share = herWeek + myWeek ? Math.round((myWeek / (herWeek + myWeek)) * 100) : 50;
    z("head").innerHTML = `
      <div class="fh-chips">
        ${streak ? `<span class="fh-chip fire">🔥 ${streak} j de série</span>` : ""}
        ${langs.map((c) => `<span class="fh-chip"><span class="flag mini">${flagSVG(c)}</span>${esc(theirs[c].level || "")}</span>`).join("")}
        ${rank && herWeek ? `<span class="fh-chip gold">🏆 ${rank === 1 ? "1er" : rank + "e"} cette semaine</span>` : ""}
      </div>
      ${rivalryCard(f, rec, S.me)}
      <div class="fh-stats two">
        <div class="fh-stat"><span class="fh-ico">⚡</span><b>${herWeek}</b><small>XP cette semaine</small><small class="fh-sub">vous : ${myWeek}</small></div>
        <div class="fh-stat"><span class="fh-ico">📒</span><b>${Math.max(0, ...Object.values(theirs).map((x) => x?.words || 0))}</b><small>Mots appris</small><small class="fh-sub">${langs.length} langue${langs.length > 1 ? "s" : ""}</small></div>
      </div>
      <div class="fh-rival">
        <div class="fh-rival-top"><span>Vous <b>${myWeek}</b></span><small>Duel de la semaine</small><span><b>${herWeek}</b> ${who(f)}</span></div>
        <div class="fh-rival-bar"><span class="me" style="width:${share}%"></span><span class="her" style="width:${100 - share}%"></span></div>
        <p class="fh-rival-msg">${myWeek === herWeek ? "Égalité parfaite cette semaine !" : myWeek > herWeek ? `Vous menez de ${myWeek - herWeek} XP 💪` : `${who(f)} mène de ${herWeek - myWeek} XP : à vous de jouer !`}</p>
      </div>`;
    z("chart").innerHTML = weekChart(f, theirs, mine);
    // Récap par langue
    z("recap").innerHTML = langs.length ? langs.map((c) => {
      const t = theirs[c];
      return `<div class="fp-recap"><p class="fp-lang"><span class="flag mini">${flagSVG(c)}</span>${esc(LANGS[c].label)} · <b>${esc(t.level)}</b> <small>${esc(t.levelName || "")}</small></p>
        <div class="pf-grid">
          <div class="pf-card"><span>🔥</span><b>${t.streak} j</b><small>Série</small></div>
          <div class="pf-card"><span>⚡</span><b>${t.xp}</b><small>XP au total</small></div>
          <div class="pf-card"><span>📈</span><b>${t.pct} %</b><small>du parcours</small></div>
          <div class="pf-card"><span>📒</span><b>${t.words}</b><small>Mots appris</small></div>
          <div class="pf-card"><span>✅</span><b>${t.lessons ?? "–"}</b><small>Leçons</small></div>
          <div class="pf-card"><span>🏅</span><b>${esc(t.level)}</b><small>Niveau</small></div>
        </div></div>`;
    }).join("") : `<p class="muted small">${who(f)} n'a pas encore commencé de parcours.</p>`;
    const chs = So.challengesWith(f.id);
    const shown = expanded ? chs.slice(0, 30) : chs.slice(0, 3);
    z("challenges").innerHTML = chs.length ? `<ul class="s-ch-list">${shown.map((c) => challengeCard(c, { showFriend: false })).join("")}</ul>
        ${chs.length > 3 ? `<button class="fh-more" data-more aria-expanded="${expanded}">${expanded ? "Voir moins <span>▴</span>" : `Voir les ${Math.min(chs.length, 30) - 3} autres défis <span>▾</span>`}</button>` : ""}`
      : `<p class="muted small">Aucun défi pour l'instant. Lancez le premier !</p>`;
    z("challenges").querySelector("[data-more]")?.addEventListener("click", () => { expanded = !expanded; paint(); });
    const n = S.unread[f.id] || 0, b = page.querySelector("[data-unread]");
    b.textContent = n; b.hidden = !n;
  };
  paint();
  So.loadRivalry(f.id).then(() => page.isConnected && paint()).catch(() => {});
  page.addEventListener("click", (e) => {
    const b = e.target.closest("[data-rv-rematch]"); if (!b) return;
    const last = So.rivalry(f.id).last;
    if (last) { b.disabled = true; rematch(last).then((id) => { if (!id) b.disabled = false; }); } else askChallenge(f);
  });

  page.querySelector("[data-chat]").onclick = () => (location.hash = `chat-${f.username}`);
  page.querySelector("[data-challenge]").onclick = () => askChallenge(f);
  page.querySelector("[data-friend-menu]").onclick = async () => {
    const v = await modal({ title: `${who(f)} et vous êtes amis`, body: `<p class="muted">Amis depuis le ${new Date(f.since).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}.</p>`,
      actions: [{ label: "Fermer", value: "", kind: "ghost" }, { label: "Retirer des amis", value: "rm", kind: "danger" }] });
    if (v !== "rm") return;
    const ok = await modal({ title: `Retirer ${who(f)} ?`, body: "<p>Vous ne verrez plus sa progression et ne pourrez plus vous écrire. Vous pourrez le réinviter plus tard.</p>",
      actions: [{ label: "Annuler", value: "" }, { label: "Retirer", value: "yes", kind: "danger" }] });
    if (ok !== "yes") return;
    try { await So.removeFriendship(f.friendshipId); toast("Ami retiré"); location.hash = "amis"; } catch (e) { toast(So.socialError(e), "warn"); }
  };
  bindChallengeActions(page);
  const off = So.onSocial((what) => {
    if (what === "message" || what === "unread") { if (page.isConnected) paint(); return; }
    if (!So.friendByUsername(username)) { location.hash = "amis"; return; }
    paint();
  });
  app._cleanup = off;
}

/** Bilan de rivalité : « Thomas 7 – 4 Léa », série en cours, dernier résultat */
function rivalryCard(f, rec, me) {
  const myName = esc(me?.pseudo || me?.username || "Vous");
  if (!rec.total) return `<div class="rv-card empty"><div class="rv-score"><span class="rv-p">${av(me, "sm")}<b>${myName}</b></span><span class="rv-num">0<i>–</i>0</span><span class="rv-p her"><b>${who(f)}</b>${av(f, "sm")}</span></div>
    <p class="rv-line">Aucun duel terminé entre vous. Qui ouvrira le score ?</p><button class="btn primary small rv-btn" data-rv-rematch>${icon("swords", { size: 16, stroke: 2.5 })} Lancer le premier défi</button></div>`;
  const lead = rec.win > rec.lose ? "me" : rec.win < rec.lose ? "her" : "";
  const st = rec.streak, last = rec.last;
  const streak = !st.count ? "" : st.outcome === "win"
    ? `<span class="rv-st win">🔥 ${st.count === 1 ? "Vous avez gagné le dernier duel" : `${st.count} victoires d'affilée`}</span>`
    : `<span class="rv-st lose">${st.count === 1 ? `${who(f)} a gagné le dernier duel` : `${who(f)} enchaîne ${st.count} victoires`} : cassez sa série !</span>`;
  const lastTxt = last ? `${OUT[last.outcome][1]} ${last.mine.score}–${last.theirs.score} · ${modeLabel(last.mode).replace(/^\S+\s/, "")}${last.words ? " · 🎯" : ""} · ${shortWhen(last.updated_at || last.created_at)}` : "";
  const wantRevenge = last && last.outcome !== "win";
  return `<div class="rv-card lead-${lead || "even"}">
    <p class="rv-k">Bilan de rivalité · ${rec.total} défi${rec.total > 1 ? "s" : ""}${rec.draw ? ` · ${rec.draw} nul${rec.draw > 1 ? "s" : ""}` : ""}</p>
    <div class="rv-score"><span class="rv-p ${lead === "me" ? "top" : ""}">${av(me, "sm")}<b>${myName}</b></span>
      <span class="rv-num"><em class="${lead === "me" ? "top" : ""}">${rec.win}</em><i>–</i><em class="${lead === "her" ? "top" : ""}">${rec.lose}</em></span>
      <span class="rv-p her ${lead === "her" ? "top" : ""}"><b>${who(f)}</b>${av(f, "sm")}</span></div>
    <div class="h2h-bar"><i class="w" style="flex:${rec.win}"></i><i class="d" style="flex:${rec.draw}"></i><i class="l" style="flex:${rec.lose}"></i></div>
    ${streak}
    ${last ? `<a class="rv-last ${last.outcome}" href="#defi-${last.id}"><span class="ch-pill ${OUT[last.outcome][2]}">${OUT[last.outcome][0]}</span><span>Dernier défi : ${lastTxt}</span></a>` : ""}
    ${wantRevenge ? `<button class="btn primary small rv-btn" data-rv-rematch>${icon("repeat", { size: 16, stroke: 2.5 })} Prendre ma revanche</button>` : ""}
  </div>`;
}

/** Graphique des 7 derniers jours : XP de l'ami et les miens */
function weekChart(f, theirs, mine) {
  const days = Object.keys(P.last7Days());
  const sum = (stats, d) => Object.values(stats).reduce((n, s) => n + (s?.days?.[d] || 0), 0);
  const a = days.map((d) => sum(theirs, d)), b = days.map((d) => sum(mine, d));
  const totA = a.reduce((x, y) => x + y, 0), totB = b.reduce((x, y) => x + y, 0);
  const hasData = Object.values(theirs).some((s) => s?.days);
  const max = Math.max(50, ...a, ...b), top = Math.ceil(max / 50) * 50;
  const W = 320, H = 170, L = 34, R = 10, T = 10, B = 26, iw = W - L - R, ih = H - T - B;
  const x = (i) => L + (iw * i) / 6, y = (v) => T + ih - (ih * v) / top;
  const line = (arr) => arr.map((v, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");
  const grid = [0, 0.5, 1].map((k) => `<line x1="${L}" x2="${W - R}" y1="${y(top * k)}" y2="${y(top * k)}" class="ch-grid"/><text x="${L - 6}" y="${y(top * k) + 4}" class="ch-ax" text-anchor="end">${Math.round(top * k)}</text>`).join("");
  const labels = days.map((d, i) => `<text x="${x(i)}" y="${H - 6}" class="ch-ax" text-anchor="middle">${"DLMMJVS"[new Date(d + "T12:00").getDay()]}</text>`).join("");
  const dots = (arr, cls) => arr.map((v, i) => `<circle cx="${x(i)}" cy="${y(v)}" r="4.5" class="${cls}"><title>${v} XP</title></circle>`).join("");
  return `<div class="wk-chart">
    <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="XP des 7 derniers jours">${grid}${labels}
      <path d="${line(b)}" class="ch-me"/>${dots(b, "dot-me")}
      <path d="${line(a)}" class="ch-fr"/>${dots(a, "dot-fr")}</svg>
    <ul class="wk-legend"><li><i class="lg-fr"></i><b>${who(f)}</b><span>${hasData ? `${totA} XP` : "bientôt disponible"}</span></li><li><i class="lg-me"></i><b>Moi</b><span>${totB} XP</span></li></ul>
    ${hasData ? "" : `<p class="muted small">Le graphique de ${who(f)} se remplira dès sa prochaine activité sur la nouvelle version.</p>`}
  </div>`;
}

/* =========================== #chat-<nom> =========================== */
/** « Vu à 9h30 » · « Vu hier à 21h05 » · « Vu le 3 nov. à 9h30 » */
function seenLabel(iso) {
  const d = new Date(iso), now = new Date();
  const hm = `${d.getHours()}h${String(d.getMinutes()).padStart(2, "0")}`;
  const sameDay = (a, b) => a.toDateString() === b.toDateString();
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (sameDay(d, now)) return `Vu à ${hm}`;
  if (sameDay(d, y)) return `Vu hier à ${hm}`;
  return `Vu le ${d.toLocaleDateString("fr-FR", { day: "numeric", month: "short" })} à ${hm}`;
}

/* =========================== #messages ============================= */
/** « 14:05 » aujourd'hui · « hier » · « lun. » cette semaine · « 3 nov. » avant */
function inboxWhen(ts) {
  const d = new Date(ts), now = new Date(), y = new Date(now); y.setDate(now.getDate() - 1);
  if (d.toDateString() === now.toDateString()) return d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  if (d.toDateString() === y.toDateString()) return "hier";
  if (now - d < 6 * 864e5) return d.toLocaleDateString("fr-FR", { weekday: "short" });
  return d.toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
}
/** Boîte de réception : toutes les conversations, la plus récente en haut */
export function renderInbox(app) {
  if (gate(app, "Messages")) return;
  const S = So.social();
  if (!S.ready) { loadThen(app, () => renderInbox(app)); return; }
  if (!S.me) return renderUsername(app);
  app.innerHTML = `<div class="s-page inbox">
    <a class="back-link" href="#amis">← Amis</a>
    <header class="page-head"><h1>💬 Messages</h1></header>
    <section class="card inbox-card"><ul class="inbox-list" aria-busy="true">${skelRows(4)}</ul></section>
    <section class="inbox-new" hidden><h2 class="h3">Écrire à…</h2><div class="inbox-chips"></div></section>
  </div>`;
  const page = app.firstElementChild, hash = location.hash;
  const preview = (m) => {
    const mine = m.sender === S.me.id;
    const t = m.kind === "word" ? `📒 ${m.body.replace(/^📒\s*/, "")}` : m.body;
    return `${mine ? "Vous : " : ""}${esc(t.length > 60 ? t.slice(0, 60) + "…" : t)}`;
  };
  async function load() {
    let conv;
    try { conv = await So.loadInbox(); } catch (e) { page.querySelector(".inbox-list").innerHTML = `<p class="form-msg error">${esc(So.socialError(e))}</p>`; return; }
    if (!stillHere(hash)) return;
    const fr = So.friends(), byId = new Map(fr.map((f) => [f.id, f]));
    const rows = conv.filter((c) => byId.has(c.friendId));
    const list = page.querySelector(".inbox-list");
    list.removeAttribute("aria-busy");
    list.innerHTML = rows.length ? rows.map((c) => {
      const f = byId.get(c.friendId), unread = c.unread > 0;
      return `<li><a class="inbox-row ${unread ? "unread" : ""}" href="#chat-${esc(f.username)}">${av(f)}
        <span class="inbox-txt"><span class="inbox-top"><b>${who(f)}</b><small>${inboxWhen(c.last.created_at)}</small></span>
          <span class="inbox-bottom"><span class="inbox-prev">${preview(c.last)}</span>${unread ? `<em class="inbox-n">${c.unread > 9 ? "9+" : c.unread}</em>` : ""}</span></span></a></li>`;
    }).join("") : `<li class="inbox-empty muted small">Aucune conversation pour l'instant. Choisissez un ami ci-dessous pour lui écrire.</li>`;
    const others = fr.filter((f) => !conv.some((c) => c.friendId === f.id));
    const nw = page.querySelector(".inbox-new");
    nw.hidden = !others.length;
    nw.querySelector(".inbox-chips").innerHTML = others.map((f) => `<a class="inbox-chip" href="#chat-${esc(f.username)}">${av(f, "sm")}<span>${who(f)}</span></a>`).join("");
  }
  load();
  const off = So.onSocial((what) => { if (page.isConnected && (what === "message" || what === "msgupdate" || what === "unread")) load(); });
  app._cleanup = off;
}

/* ============================ #chat-<ami> ============================ */
export function renderChat(app, username) {
  if (gate(app, "Messages")) return;
  const S = So.social();
  const hash = location.hash;
  if (!S.ready) { loadThen(app, () => renderChat(app, username)); return; }
  const f = So.friendByUsername(username);
  if (!f) { location.hash = "amis"; return; }
  const st = Object.entries(So.statsOf(f.id)).sort((a, b) => (b[1]?.xp || 0) - (a[1]?.xp || 0))[0];
  const status = st ? `<span class="flag mini">${flagSVG(st[0])}</span>${esc(st[1].level || "")}${st[1].streak ? `<span class="cf-streak">${icon("flame", { size: 13, stroke: 2.6 })}${st[1].streak} j</span>` : ""}` : `@${esc(f.username)}`;
  document.body.classList.add("chat-mode");
  app.innerHTML = `<div class="chat-full">
    <header class="cf-head">
      <a class="cf-back" href="#messages" aria-label="Retour">${icon("back", { size: 24, stroke: 2.6 })}</a>
      <a class="cf-who" href="#ami-${esc(f.username)}">${av(f)}<span><b>${who(f)}</b><small class="cf-status">${status}</small></span></a>
      <button class="cf-defi" data-challenge aria-label="Lancer un défi">${icon("swords", { size: 18, stroke: 2.5 })}<span>Défier</span></button>
    </header>
    <div class="cf-msgs" aria-live="polite"><div class="skel-chat" aria-busy="true"><span class="skel sb l"></span><span class="skel sb r"></span><span class="skel sb l w"></span><span class="skel sb r"></span></div></div>
    <div class="cf-typing" hidden><span class="cf-dots"><i></i><i></i><i></i></span><small>${who(f)} écrit…</small></div>
    <button class="cf-new" hidden>↓ Nouveau message</button>
    <footer class="cf-foot">
      <div class="cf-reply" hidden><span class="cf-reply-txt"></span><button type="button" class="cf-reply-x" aria-label="Annuler la réponse">✕</button></div>
      <form class="cf-send" autocomplete="off">
        <button type="button" class="cf-word-btn" data-word aria-label="Partager un mot du carnet" title="Partager un mot du carnet">${icon("notebook", { size: 22 })}</button>
        <textarea name="m" rows="1" maxlength="1000" placeholder="Message à ${who(f)}…" aria-label="Message"></textarea>
        <button class="cf-go" type="submit" aria-label="Envoyer" disabled>${icon("send", { size: 22, stroke: 2.4 })}</button>
      </form>
    </footer>
  </div>`;
  const page = app.firstElementChild;
  const box = page.querySelector(".cf-msgs"), newBtn = page.querySelector(".cf-new"), typingEl = page.querySelector(".cf-typing");
  const replyBar = page.querySelector(".cf-reply");
  const msgs = new Map(); // id → message
  const me = S.me.id;
  let replyTo = null;
  const back = page.querySelector(".cf-back");
  back.onclick = (e) => { if (history.length > 1) { e.preventDefault(); history.back(); } };
  const dayLabel = (d) => {
    const k = (x) => x.toDateString(), t = new Date(), y = new Date(Date.now() - 864e5);
    if (k(d) === k(t)) return "Aujourd'hui";
    if (k(d) === k(y)) return "Hier";
    return d.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" });
  };
  const onlyEmoji = (t) => /^(\p{Extended_Pictographic}|\p{Emoji_Component}|\s){1,8}$/u.test(t) && !/[0-9#*]/.test(t);
  const nearBottom = () => box.scrollHeight - box.scrollTop - box.clientHeight < 120;
  const snippet = (m) => (m ? (m.kind === "word" ? `📒 ${m.meta?.w || ""} — ${m.meta?.fr || ""}` : m.body) : "Message");

  /* Carte « mot du carnet » */
  function wordCard(m) {
    const w = m.meta || {}, zh = w.lang === "zh", mine = m.sender === me;
    const have = w.lang === code && state.vocab?.[w.w];
    return `<span class="cf-word">
      <span class="cfw-top"><span class="flag mini">${flagSVG(w.lang || "it")}</span><small>Mot du carnet</small></span>
      <span class="cfw-w ${zh ? "zh" : ""}">${esc(w.w || "")}</span>${w.py ? `<span class="cfw-py">${esc(w.py)}</span>` : ""}
      <span class="cfw-fr">${esc(w.fr || "")}</span>
      <span class="cfw-act"><button type="button" class="cfw-btn" data-say="${m.id}" aria-label="Écouter">🔊</button>
        ${mine ? "" : have ? `<span class="cfw-ok">✓ Dans votre carnet</span>` : `<button type="button" class="cfw-btn add" data-add="${m.id}">＋ Ajouter à mon carnet</button>`}</span>
    </span>`;
  }

  function paint(stick = true) {
    const list = [...msgs.values()].sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
    if (!list.length) { box.innerHTML = `<div class="cf-empty">${av(f, "xl")}<p><b>${who(f)}</b></p><p class="muted small">Aucun message pour l'instant. Dites bonjour 👋</p></div>`; return; }
    const lastMine = [...list].reverse().find((m) => m.sender === me);
    let html = "", lastDay = "";
    list.forEach((m, i) => {
      const d = new Date(m.created_at), day = dayLabel(d);
      if (day !== lastDay) { html += `<p class="cf-day"><span>${day}</span></p>`; lastDay = day; }
      const prev = list[i - 1], next = list[i + 1];
      const close = (a, b) => a && b && a.sender === b.sender && Math.abs(new Date(a.created_at) - new Date(b.created_at)) < 5 * 60000 && dayLabel(new Date(a.created_at)) === dayLabel(new Date(b.created_at));
      const first = !close(prev, m) || !!m.reply_to, last = !close(m, next) || !!next?.reply_to;
      const mine = m.sender === me, word = m.kind === "word", big = !word && !m.reply_to && onlyEmoji(m.body);
      const q = m.reply_to ? msgs.get(m.reply_to) : null;
      const quote = m.reply_to ? `<span class="cf-q" data-goto="${m.reply_to}"><b>${q ? (q.sender === me ? "Vous" : who(f)) : ""}</b>${esc(snippet(q).slice(0, 90))}</span>` : "";
      const rx = Object.values(m.reactions || {});
      const rxHtml = rx.length ? `<span class="cf-rx" data-rx-of="${m.id}">${[...new Set(rx)].join("")}${rx.length > 1 ? `<i>${rx.length}</i>` : ""}</span>` : "";
      const time = `<time>${d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</time>`;
      html += `<div class="cf-msg ${mine ? "me" : "them"} ${first ? "first" : ""} ${last ? "last" : ""} ${big ? "big" : ""} ${word ? "word" : ""} ${m.pending ? "pending" : ""} ${rx.length ? "has-rx" : ""}" data-id="${m.id}">
        <div class="cf-b">${quote}${word ? wordCard(m) : `<span class="cf-t">${esc(m.body)}</span>`}${time}${rxHtml}</div></div>`;
      if (m === lastMine) html += `<p class="cf-receipt">${m.pending ? "Envoi…" : m.failed ? "⚠️ Non envoyé" : m.read_at ? seenLabel(m.read_at) : "Envoyé ✓"}</p>`;
    });
    const wasNear = nearBottom();
    box.innerHTML = html;
    if (stick || wasNear) { box.scrollTop = box.scrollHeight; newBtn.hidden = true; }
    else newBtn.hidden = false;
  }
  const sig = (m) => `${m.read_at}|${JSON.stringify(m.reactions || {})}`;
  function merge(list, { fromOther = false } = {}) {
    let changed = false;
    list.forEach((m) => {
      const old = msgs.get(m.id);
      if (!old || sig(old) !== sig({ ...old, ...m })) { msgs.set(m.id, { ...old, ...m }); changed = true; }
    });
    if (changed) paint(!fromOther);
  }
  newBtn.onclick = () => { box.scrollTo({ top: box.scrollHeight, behavior: "smooth" }); newBtn.hidden = true; };
  box.addEventListener("scroll", () => { if (nearBottom()) newBtn.hidden = true; closeMenu(); });

  So.loadMessages(f.id).then((list) => { if (!stillHere(hash)) return; box.innerHTML = ""; list.forEach((m) => msgs.set(m.id, m)); paint(true); So.markRead(f.id, list.some((m) => m.sender === f.id && !m.read_at)); })
    .catch((e) => (box.innerHTML = `<p class="form-msg error">${esc(So.socialError(e))}</p>`));

  /* ---------- Saisie, réponse citée, envoi ---------- */
  const form = page.querySelector(".cf-send"), ta = form.m, go = form.querySelector(".cf-go");
  const grow = () => { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 120) + "px"; go.disabled = !ta.value.trim(); };
  let typing = null;
  So.typingChannel(f.id, (on) => showTyping(on)).then((t) => { if (page.isConnected) typing = t; else t.leave(); }).catch(() => {});
  ta.oninput = () => { grow(); if (ta.value.trim()) typing?.ping(true); };
  ta.onblur = () => typing?.ping(false);
  ta.onkeydown = (e) => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); form.requestSubmit(); } };
  function setReply(m) {
    replyTo = m ? m.id : null;
    replyBar.hidden = !m;
    if (m) {
      replyBar.querySelector(".cf-reply-txt").innerHTML = `<b>${m.sender === me ? "Réponse à votre message" : `Réponse à ${who(f)}`}</b><small>${esc(snippet(m).slice(0, 80))}</small>`;
      ta.focus();
    }
  }
  replyBar.querySelector(".cf-reply-x").onclick = () => setReply(null);

  let tmp = 0;
  const send = async (text, opts = {}) => {
    const id = `tmp-${++tmp}`;
    const reply = replyTo; setReply(null);
    msgs.set(id, { id, sender: me, body: text, created_at: new Date().toISOString(), pending: true, reply_to: reply, kind: opts.kind || "text", meta: opts.meta || null });
    paint(true);
    typing?.ping(false);
    try {
      const m = await So.sendMessage(f.id, text, { ...opts, replyTo: reply });
      msgs.delete(id);
      if (m) msgs.set(m.id, m);
      paint(true); return true;
    } catch (err) {
      msgs.set(id, { ...msgs.get(id), pending: false, failed: true }); paint(true);
      toast(err.message, "warn"); msgs.delete(id); return false;
    }
  };
  form.onsubmit = async (e) => {
    e.preventDefault();
    const text = ta.value.trim(); if (!text) return;
    ta.value = ""; grow(); ta.focus();
    if (!(await send(text))) { ta.value = text; grow(); }
  };
  page.querySelector("[data-challenge]").onclick = () => askChallenge(f);

  /* ---------- « … écrit » ---------- */
  let typingT = null;
  function showTyping(on) {
    clearTimeout(typingT);
    const wasNear = nearBottom();
    typingEl.hidden = !on;
    if (on) { typingT = setTimeout(() => (typingEl.hidden = true), 5000); if (wasNear) box.scrollTop = box.scrollHeight; }
  }

  /* ---------- Partager un mot du carnet ---------- */
  page.querySelector("[data-word]").onclick = async () => {
    const words = Object.values(state.vocab || {}).sort((a, b) => (b.added || 0) - (a.added || 0));
    if (!words.length) { toast("Votre carnet est encore vide : terminez une leçon pour y ajouter des mots.", "warn"); return; }
    const v = await modal({
      title: "📒 Partager un mot",
      body: `<input class="cfw-search" type="search" placeholder="Rechercher un mot…" aria-label="Rechercher">
        <div class="cfw-list">${words.slice(0, 300).map((w, i) => `<button type="button" class="cfw-pick" data-value="${i}" data-s="${esc((w.zh + " " + (w.py || "") + " " + w.fr).toLowerCase())}">
          <b class="${code === "zh" ? "zh" : ""}">${esc(w.zh)}</b>${w.py ? `<small class="py">${esc(w.py)}</small>` : ""}<span>${esc(w.fr)}</span></button>`).join("")}</div>`,
      actions: [{ label: "Annuler", value: "", kind: "ghost" }],
      onOpen: (root) => {
        const s = root.querySelector(".cfw-search");
        s.oninput = () => { const q = s.value.trim().toLowerCase(); root.querySelectorAll(".cfw-pick").forEach((b) => (b.hidden = !!q && !b.dataset.s.includes(q))); };
        setTimeout(() => s.focus(), 50);
      },
    });
    if (v == null || v === "") return;
    const w = words[+v];
    if (w) send(`📒 ${w.zh} — ${w.fr}`, { kind: "word", meta: { w: w.zh, py: w.py || "", fr: w.fr, lang: code } });
  };

  /* ---------- Réactions, réponse, actions sur une bulle ---------- */
  let menu = null;
  function closeMenu() { menu?.remove(); menu = null; box.querySelectorAll(".cf-msg.picked").forEach((x) => x.classList.remove("picked")); }
  function openMenu(el) {
    const m = msgs.get(isNaN(+el.dataset.id) ? el.dataset.id : +el.dataset.id);
    if (!m || m.pending) return;
    closeMenu();
    el.classList.add("picked");
    if (navigator.vibrate) try { navigator.vibrate(12); } catch {}
    const mineRx = m.reactions?.[me];
    menu = document.createElement("div");
    menu.className = `cf-menu ${m.sender === me ? "me" : ""}`;
    menu.innerHTML = `<div class="cf-menu-rx">${So.MSG_REACTIONS.map((e) => `<button type="button" class="${mineRx === e ? "on" : ""}" data-r="${e}">${e}</button>`).join("")}</div>
      <div class="cf-menu-act"><button type="button" data-act="reply">↩︎ Répondre</button>${m.kind !== "word" ? `<button type="button" data-act="copy">Copier</button>` : ""}</div>`;
    page.appendChild(menu);
    const r = el.querySelector(".cf-b").getBoundingClientRect(), pr = page.getBoundingClientRect();
    const top = r.top - pr.top - menu.offsetHeight - 8;
    menu.style.top = `${top < 60 ? r.bottom - pr.top + 8 : top}px`;
    menu.onclick = async (e) => {
      const b = e.target.closest("button"); if (!b) return;
      e.stopPropagation();
      if (b.dataset.act === "reply") { closeMenu(); setReply(m); return; }
      if (b.dataset.act === "copy") { try { await navigator.clipboard.writeText(m.body); toast("Copié ✓", "ok"); } catch {} closeMenu(); return; }
      const emoji = b.dataset.r === mineRx ? null : b.dataset.r;
      closeMenu();
      const before = m.reactions || {};
      const next = { ...before }; if (emoji) next[me] = emoji; else delete next[me];
      msgs.set(m.id, { ...m, reactions: next }); paint(false);
      try { const rx = await So.reactMessage(m.id, emoji); if (rx) { msgs.set(m.id, { ...msgs.get(m.id), reactions: rx }); paint(false); } }
      catch (err) { msgs.set(m.id, { ...msgs.get(m.id), reactions: before }); paint(false); toast(So.socialError(err), "warn"); }
    };
  }
  // Appui long (tactile) ou clic droit (ordinateur) : réactions ; glisser vers la droite : répondre
  let press = null;
  box.addEventListener("pointerdown", (e) => {
    const el = e.target.closest(".cf-msg"); if (!el || e.target.closest("button, .cf-q")) return;
    press = { el, x: e.clientX, y: e.clientY, dx: 0, swiping: false, t: setTimeout(() => { if (press && !press.swiping) { openMenu(el); press.done = true; } }, 450), touch: e.pointerType !== "mouse" };
  });
  box.addEventListener("pointermove", (e) => {
    if (!press) return;
    const dx = e.clientX - press.x, dy = e.clientY - press.y;
    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) clearTimeout(press.t);
    if (!press.touch) return;
    if (!press.swiping && dx > 12 && Math.abs(dy) < 14) press.swiping = true;
    if (press.swiping) { press.dx = Math.max(0, Math.min(80, dx)); press.el.style.transform = `translateX(${press.dx}px)`; press.el.classList.toggle("swipe-ok", press.dx > 55); }
  });
  const endPress = () => {
    if (!press) return;
    clearTimeout(press.t);
    const p = press; press = null;
    if (p.swiping) {
      p.el.style.transition = "transform .2s"; p.el.style.transform = "";
      setTimeout(() => { p.el.style.transition = ""; p.el.classList.remove("swipe-ok"); }, 220);
      if (p.dx > 55) { const m = msgs.get(isNaN(+p.el.dataset.id) ? p.el.dataset.id : +p.el.dataset.id); if (m && !m.pending) setReply(m); }
    }
  };
  box.addEventListener("pointerup", endPress); box.addEventListener("pointercancel", endPress);
  box.addEventListener("contextmenu", (e) => { const el = e.target.closest(".cf-msg"); if (!el) return; e.preventDefault(); openMenu(el); });
  box.addEventListener("click", (e) => {
    const say = e.target.closest("[data-say]");
    if (say) { const m = msgs.get(+say.dataset.say); if (m) speak(m.meta?.w || "", { force: true, lang: m.meta?.lang }); return; }
    const add = e.target.closest("[data-add]");
    if (add) { addWord(msgs.get(+add.dataset.add)); return; }
    const q = e.target.closest("[data-goto]");
    if (q) { const t = box.querySelector(`.cf-msg[data-id="${q.dataset.goto}"]`); if (t) { t.scrollIntoView({ behavior: "smooth", block: "center" }); t.classList.add("flash"); setTimeout(() => t.classList.remove("flash"), 1200); } return; }
    const rxEl = e.target.closest("[data-rx-of]");
    if (rxEl) { const el = rxEl.closest(".cf-msg"); openMenu(el); return; }
  });
  document.addEventListener("click", docClose, true);
  function docClose(e) { if (menu && !menu.contains(e.target)) closeMenu(); }

  function addWord(m) {
    const w = m?.meta; if (!w) return;
    if (w.lang !== code) { toast(`Ce mot est en ${LANGS[w.lang]?.label.toLowerCase() || "une autre langue"} : passez à cette langue pour l'ajouter à votre carnet.`, "warn"); return; }
    if (state.vocab?.[w.w]) { toast("Ce mot est déjà dans votre carnet ✓"); paint(false); return; }
    commit((s) => { s.vocab[w.w] = { zh: w.w, py: w.py || "", fr: w.fr, levelId: P.currentLevel().id, lessonId: null, added: Date.now(), from: f.username }; });
    toast("📒 Ajouté à votre carnet ✓", "ok");
    paint(false);
  }

  // Plein écran qui suit le clavier (iPhone / Android)
  const vv = window.visualViewport;
  const fit = () => { if (!vv) return; page.style.height = `${vv.height}px`; page.style.top = `${vv.offsetTop}px`; if (document.activeElement === ta) box.scrollTop = box.scrollHeight; };
  vv?.addEventListener("resize", fit); vv?.addEventListener("scroll", fit); fit();

  const poll = setInterval(() => {
    if (document.visibilityState === "visible") So.loadMessages(f.id, 30).then((l) => { if (stillHere(hash)) { merge(l, { fromOther: true }); So.markRead(f.id, l.some((m) => m.sender === f.id && !m.read_at)); } }).catch(() => {});
  }, 8000);
  const off = So.onSocial((what, m) => {
    if (!page.isConnected) return;
    if (what === "message" && m.sender === f.id) { showTyping(false); merge([m], { fromOther: true }); So.markRead(f.id, true); }
    if (what === "msgupdate" && msgs.has(m?.id)) merge([m], { fromOther: true });
  });
  app._cleanup = () => { off(); clearInterval(poll); typing?.ping(false); typing?.leave(); document.removeEventListener("click", docClose, true); vv?.removeEventListener("resize", fit); vv?.removeEventListener("scroll", fit); document.body.classList.remove("chat-mode"); };
}

/* =========================== #defi-<id> ============================ */
/** Pas assez de mots appris : explication + raccourci vers le parcours */
function notEnoughWords(title = "Pas encore assez de mots", size = 5) {
  const n = CG.missingWords(size), other = Object.values(LANGS).find((l) => l.code !== code);
  return modal({
    title: `📒 ${title}`,
    body: `<p>Les défis utilisent uniquement les mots que <b>vous avez appris</b> en ${esc(L.label.toLowerCase())} (ceux de vos leçons réussies), avec des questions variées.</p>
      <p>Il vous faut au moins <b>${CG.wordsNeeded(size)} mots</b> : encore <b>${n}</b> à apprendre. Terminez une ou deux leçons de plus !</p>
      ${other ? `<p class="muted small">Vous avez plus de mots en ${esc(other.label.toLowerCase())} ? Changez de langue en haut de la page.</p>` : ""}`,
    actions: [{ label: "Fermer", value: "close", kind: "ghost" }, { label: "Aller au parcours", value: "go", kind: "primary" }],
  }).then((v) => { if (v === "go") location.hash = "parcours"; });
}

export function renderDefi(app, id, opts = {}) {
  if (gate(app, "Défi")) return;
  const hash = location.hash;
  loading(app);
  So.getChallenge(id).then((c) => {
    if (!stillHere(hash)) return;
    if (!c) { app.innerHTML = `<section class="card account-card"><p>Ce défi est introuvable.</p><a class="btn ghost" href="#amis">← Amis</a></section>`; return; }
    if (LIVE && LIVE.id !== c.id) leaveLive();
    const liveOk = c.live && !c.theirs && !opts.solo && (c.stage === "to_play" || c.stage === "waiting_accept");
    if (c.stage !== "to_play" && !liveOk) return showDefi(app, c);
    if (!canPlay(c)) {
      const k = playNeed(c);
      app.innerHTML = `<a class="back-link" href="#amis">← Amis</a>
      <section class="card s-defi-intro"><p class="eyebrow">Défi</p><h1>📒 Encore quelques mots à apprendre</h1>
        <p class="lead">Ce défi utilise uniquement les mots que vous avez appris en ${esc(L.label.toLowerCase())}. Il en faut au moins ${CG.wordsNeeded(k)} : encore <b>${CG.missingWords(k)}</b>.</p>
        <p class="muted">Terminez une ou deux leçons, puis revenez : le défi vous attend. Vous apprenez une autre langue ? Changez de langue en haut de la page.</p>
        <a class="btn primary big" href="#parcours">Continuer mon parcours</a></section>`;
      return;
    }
    if (liveOk) return renderLobby(app, c);
    const qs = CG.buildChallengeQuestions(c.n, { words: c.words, audio: c.mode === "listen" });
    const rec = So.record(c.friend?.id);
    if (!So.historyLoaded()) So.loadHistory().catch(() => {}); // pour repérer un nouveau record à la fin
    const sv = c.mode === "survival";
    app.innerHTML = `
    <a class="back-link" href="#amis">← Défis</a>
    <section class="card s-defi-intro defi-arena vs-card t-invite">
      <div class="vs-band">
        <p class="vs-kicker">${modeIco(c.mode)} ${modeLabel(c.mode).replace(/^\S+\s/, "")}${sv ? "" : ` · ${c.n} questions`}${c.words ? ` · 🎯 ${terrainOf(c)}` : ""}</p>
        <h1>${c.rematch_of && !c.iAmChallenger ? `${who(c.friend)} veut sa revanche` : `Vous contre ${who(c.friend)}`}</h1>
        <div class="vs-row vs-anim"><div class="vs-col"><span class="vs-av">${av(So.social().me, "xl")}</span><p class="vs-who">Vous</p></div><span class="vs-x">VS</span><div class="vs-col"><span class="vs-av">${av(c.friend, "xl")}</span><p class="vs-who">${who(c.friend)}</p></div></div>
      </div>
      ${rec.total ? `<p class="h2h">Face à face : <b>${rec.win}</b> V · <b>${rec.lose}</b> D${rec.draw ? ` · <b>${rec.draw}</b> N` : ""}</p>` : `<p class="h2h">Premier duel entre vous !</p>`}
      ${c.theirs ? (sv ? `<div class="to-beat">🎯 À battre : <b>${c.theirs.score} bonne${c.theirs.score > 1 ? "s" : ""} réponse${c.theirs.score > 1 ? "s" : ""} d'affilée</b></div>`
        : `<div class="to-beat">🎯 À battre : <b>${c.theirs.score}/${c.theirs.total}</b>${c.mode === "precision" ? "" : ` en <b>${secs(c.theirs.ms)}</b>`}${c.mode === "speed" ? ` · <b>${c.theirs.points} pts</b>` : ""}</div>`) : `<div class="to-beat soft">Vous jouez en premier : placez la barre haut !</div>`}
      <ul class="defi-rules">
        <li>${c.words ? (c.iAmChallenger ? `🎯 Sur le terrain de ${who(c.friend)} : <b>${c.words.length} mots</b> qu'il rate le plus` : `🎯 Sur votre terrain : vos <b>${c.words.length} mots</b> les plus ratés. Montrez qu'ils sont acquis !`)
          : `🎲 ${sv ? "Questions" : `${qs.length} questions`} variées sur vos <b>${CG.learnedWords().length} mots</b> de ${esc(L.label.toLowerCase())} <span class="flag mini">${flagSVG(code)}</span>`}</li>
        <li>${sv ? "💀 Mort subite : la première erreur arrête la partie. La plus longue série gagne (à égalité, le plus rapide)" : c.mode === "listen" ? "🎧 Mode écoute : tout se joue à l'oreille (mot entendu, sens, dictée). Le plus de bonnes réponses gagne, à égalité le plus rapide. Montez le son !" : c.mode === "precision" ? "🎯 Mode précision : seules les bonnes réponses comptent, le temps n'est pas pris en compte" : c.mode === "speed" ? `⏱️ Mode vitesse : ${So.SPEED_PER_GOOD} pts par bonne réponse, −${So.SPEED_PER_SEC} pts par seconde. Vite… mais juste !` : "⏱️ Chronomètre lancé au départ : à égalité, le plus rapide gagne"}</li>
        <li>☝️ Une seule tentative</li>
      </ul>
      <button class="btn primary big" data-go>C'est parti !</button>
      <p class="muted small">Vous apprenez aussi une autre langue ? Changez de langue en haut de la page avant de commencer.</p>
    </section>`;
    app.querySelector("[data-go]").onclick = () => countdownThen(app, () => play(app, c, qs));
    if (rec.total === 0 && c.friend) So.loadRivalry(c.friend.id).then((r) => { const h = app.querySelector(".h2h"); if (h && r.total) h.innerHTML = `Face à face : <b>${r.win}</b> V · <b>${r.lose}</b> D${r.draw ? ` · <b>${r.draw}</b> N` : ""}`; }).catch(() => {});
  }).catch((e) => { app.innerHTML = `<section class="card"><p class="form-msg error">${esc(So.socialError(e))}</p></section>`; });
}

/** 3, 2, 1… avant le départ */
function countdownThen(app, go) {
  document.body.classList.add("focus-mode");
  app.innerHTML = `<div class="cd"><span>3</span></div>`;
  const el = app.querySelector(".cd span");
  let n = 3;
  const t = setInterval(() => {
    n--;
    if (n > 0) { el.textContent = n; el.style.animation = "none"; el.offsetWidth; el.style.animation = ""; }
    else if (n === 0) { el.textContent = "GO !"; el.style.animation = "none"; el.offsetWidth; el.style.animation = ""; }
    else { clearInterval(t); go(); }
  }, 650);
  const prev = app._cleanup;
  app._cleanup = () => { clearInterval(t); prev?.(); };
}

function play(app, c, questions, live = null) {
  document.body.classList.add("focus-mode");
  const t0 = performance.now();
  const recap = [];
  let good = 0, bad = 0;
  const sv = c.mode === "survival";
  runQuiz(app, {
    title: `Défi contre ${c.friend?.pseudo || c.friend?.username || "un ami"}`,
    questions,
    // Mort subite : la première erreur termine la partie
    stopWhen: sv ? (res) => res.some((r) => !r.correct) : null,
    countText: sv ? (i) => `🔥 ${i + 1}` : null,
    onAnswer: ({ q, correct, expected, given }) => {
      correct ? good++ : bad++;
      // Déroulé compact (partagé avec l'adversaire une fois que les deux ont joué)
      recap.push({ q: plainQ(q).slice(0, 160), e: String(expected ?? "").slice(0, 80), g: String(given ?? "").slice(0, 80), c: !!correct, t: Math.round(performance.now() - t0) });
      live?.duel.progress({ good, bad, total: questions.length, ms: Math.round(performance.now() - t0) });
      paintHud();
    },
    onQuit: () => {
      // Rien n'est envoyé : le défi pourra être rejoué plus tard (avec d'autres questions)
      clearInterval(timer);
      document.body.classList.remove("focus-mode");
      toast("Défi interrompu : vous pourrez le rejouer plus tard");
      location.hash = "amis";
    },
    onFinish: async (results) => {
      clearInterval(timer);
      document.body.classList.remove("focus-mode");
      const ms = performance.now() - t0;
      const score = results.filter((r) => r.correct).length;
      live?.duel.progress({ good: score, bad: results.length - score, total: results.length, ms: Math.round(ms), finished: true });
      if (live) live.meDone = true;
      try { localStorage.setItem(`impara.defi.${c.id}`, JSON.stringify(recap)); } catch {}
      app.innerHTML = `<p class="muted s-loading">Envoi de votre score…</p>`;
      try {
        await So.submitChallenge(c.id, { score, total: results.length, ms, recap });
        const v = await So.getChallenge(c.id);
        showDefi(app, v, true);
      } catch (e) {
        app.innerHTML = `<section class="card account-card"><p class="form-msg error">${esc(e.message)}</p>
          <p>Votre score : ${score}/${results.length}</p><a class="btn ghost" href="#amis">← Amis</a></section>`;
      }
    },
  });
  // Le titre « Défi contre … » est inutile ici (le bandeau du duel le dit déjà) : on le retire
  app.querySelector(".quiz-title")?.remove();
  // Bandeau du duel : chrono, bonnes / mauvaises réponses, score à battre
  const hud = document.createElement("div");
  hud.className = "duel-hud";
  app.querySelector(".quiz")?.prepend(hud);
  const total = questions.length;
  function paintHud() {
    const el = (performance.now() - t0) / 1000;
    const t = `${Math.floor(el / 60)}:${String(Math.floor(el % 60)).padStart(2, "0")}`;
    let race = "";
    if (sv) {
      race = !c.theirs ? `<span>🔥 série : ${good}</span>` : good > c.theirs.score ? `<span class="ahead">🔥 ${good} : record battu !</span>` : `<span>🔥 ${good} / ${c.theirs.score} à battre</span>`;
    } else if (c.theirs) {
      const maxMine = good + (total - good - bad);
      race = good > c.theirs.score ? `<span class="ahead">🔥 Devant !</span>`
        : maxMine < c.theirs.score ? `<span class="behind">Plus possible de gagner…</span>`
        : `<span>🎯 ${c.theirs.score}/${c.theirs.total} à battre</span>`;
    }
    const pts = c.mode === "speed" ? Math.max(0, good * So.SPEED_PER_GOOD - Math.round(el) * So.SPEED_PER_SEC) : null;
    if (c.theirs && c.mode === "speed") race = pts > c.theirs.points ? `<span class="ahead">🔥 ${pts} pts</span>` : `<span>${pts} / ${c.theirs.points} pts</span>`;
    else if (c.mode === "speed") race = `<span>${pts} pts</span>`;
    if (live) race = "";
    hud.innerHTML = `${c.mode === "precision" ? "" : `<span class="hud-t">⏱️ ${t}</span>`}<span class="hud-ok">✓ ${good}</span>${sv ? (bad ? `<span class="hud-ko">💀</span>` : "") : `<span class="hud-ko">✗ ${bad}</span>`}${race}`
      + (live ? liveBars(c, { good, bad, total, el }, live.opp, el) : "");
  }
  paintHud();
  if (live) live.onUpdate = paintHud;
  const timer = setInterval(paintHud, 500);
  const prev = app._cleanup;
  app._cleanup = () => { clearInterval(timer); prev?.(); };
}

/** Intitulé lisible d'une question (pour le récapitulatif) */
function plainQ(q) {
  const base = q.type === "fill" ? `Compléter : ${q.q}` : q.type === "match" ? "Associer les mots et leur sens" : q.q;
  return q.reveal ? `${base} (${q.reveal})` : base;
}

/** Ancien format local ({ expected, given, correct }) → format compact { q, e, g, c, t } */
const normRecap = (r) => (Array.isArray(r) && r.length ? r.map((x) => ({ q: x.q, e: x.e ?? x.expected ?? "", g: x.g ?? x.given ?? "", c: x.c ?? x.correct, t: x.t ?? null })) : null);
const dur = (ms) => `${(ms / 1000).toFixed(1).replace(".", ",")} s`;

/** Déroulé du défi : une pastille par question pour chacun, puis le détail des réponses */
function replayCard(c, mine, theirs) {
  if (!mine?.length && !theirs?.length) return "";
  const f = c.friend;
  const dots = (r) => `<div class="rp-dots">${r.map((x, i) => `<i class="${x.c ? "ok" : "ko"}" title="Q${i + 1} ${x.c ? "✓" : "✗"}"></i>`).join("")}</div>`;
  const line = (label, r, cls) => `<div class="rp-line ${cls}"><span class="rp-who">${label}</span>${r ? dots(r) : `<span class="rp-wait">${c.stage === "done" ? "déroulé indisponible" : "pas encore joué"}</span>`}${r ? `<b>${r.filter((x) => x.c).length}/${r.length}</b>` : ""}</div>`;
  const list = (r) => `<ol class="rp-list">${r.map((x, i) => {
      const dt = x.t != null ? x.t - (i ? r[i - 1].t || 0 : 0) : null;
      return `<li class="${x.c ? "ok" : "ko"}"><span class="rc-ico">${x.c ? "✓" : "✗"}</span><div><p>${esc(x.q)}</p>
        ${x.c ? "" : `<p class="small">Bonne réponse : <b>${esc(x.e)}</b>${x.g ? ` · réponse : <s>${esc(x.g)}</s>` : ""}</p>`}</div>${dt != null && dt >= 0 ? `<small class="rp-t">${dur(dt)}</small>` : ""}</li>`; }).join("")}</ol>`;
  const both = mine?.length && theirs?.length;
  return `<section class="card fr-sec recap replay">${secHead("route", "Déroulé du défi")}
    <div class="rp-lines">${line("Vous", mine, "me")}${line(who(f), theirs, "op")}</div>
    ${both ? `<p class="rp-note">Chacun a eu ses propres questions${c.words ? " (sur les mêmes mots)" : ""}.</p>` : ""}
    ${both ? `<div class="seg rp-tabs"><button class="on" data-rp="me">Vos réponses</button><button data-rp="op">Réponses de ${who(f)}</button></div>` : ""}
    ${mine?.length ? `<div data-rp-pane="me">${list(mine)}</div>` : ""}
    ${theirs?.length ? `<div data-rp-pane="op" ${mine?.length ? "hidden" : ""}>${list(theirs)}</div>` : ""}
  </section>`;
}
document.addEventListener("click", (e) => {
  const b = e.target.closest("[data-rp]"); if (!b) return;
  const card = b.closest(".replay");
  card.querySelectorAll("[data-rp]").forEach((x) => x.classList.toggle("on", x === b));
  card.querySelectorAll("[data-rp-pane]").forEach((p) => (p.hidden = p.dataset.rpPane !== b.dataset.rp));
});

function showDefi(app, c, justPlayed = false) {
  const f = c.friend, me = So.social().me;
  let recap = null;
  try { recap = JSON.parse(localStorage.getItem(`impara.defi.${c.id}`) || "null"); } catch {}
  const records = justPlayed ? So.newRecords(c) : [];
  const col = (r, label, p, win) => `<div class="vs-col ${win ? "winner" : ""}">
      <span class="vs-av">${win ? `<span class="vs-crown">${icon("crown", { size: 26, stroke: 2, fill: "#ffd24a" })}</span>` : ""}${av(p, "xl")}</span>
      <p class="vs-who">${label}</p>
      ${r ? `<p class="vs-score" data-count="${r.score}">0</p><p class="vs-sub">${c.mode === "survival" ? `d'affilée${r.score === r.total ? " · sans faute" : ""}` : `sur ${r.total}`}${r.lang ? ` · <span class="flag mini">${flagSVG(r.lang)}</span>` : ""}</p>
        ${c.mode === "survival" && r.ms ? `<p class="vs-pts">${secs(r.ms)}</p>` : c.mode === "speed" && r.points != null ? `<p class="vs-pts">${r.points} pts · ${secs(r.ms)}</p>` : c.mode !== "precision" && r.ms ? `<p class="vs-pts">${secs(r.ms)}</p>` : ""}`
        : `<p class="vs-score muted">?</p><p class="vs-sub">${c.stage === "to_accept" || c.stage === "waiting_accept" ? "Pas encore accepté" : "Pas encore joué"}</p>`}
    </div>`;
  const head = {
    done: { win: "Victoire !", lose: `${who(f)} l'emporte`, draw: "Égalité" }[c.outcome],
    waiting_play: "Score envoyé ✓", to_accept: `${who(f)} vous défie !`, waiting_accept: `En attente de ${who(f)}`, to_play: "À vous de jouer",
    declined: "Défi refusé", cancelled: "Défi annulé",
  }[c.stage] || "Défi";
  const sub = {
    waiting_play: `Vous serez prévenu dès que ${who(f)} aura joué.`,
    to_accept: "Acceptez pour jouer : vous aurez une seule tentative.",
    waiting_accept: `${who(f)} n'a pas encore accepté.`,
    done: c.stage !== "done" ? "" : c.mode === "survival" ? (c.outcome === "draw" ? "Même série, même temps : incroyable !"
        : c.mine.score === c.theirs.score ? (c.outcome === "win" ? "Même série, mais vous avez été plus rapide ⚡" : `Même série, ${who(f)} a été plus rapide.`)
        : c.outcome === "win" ? `Vous tenez ${c.mine.score} questions, ${who(f)} tombe à ${c.theirs.score} 💀` : `${who(f)} tient ${c.theirs.score} questions, vous tombez à ${c.mine.score} 💀`)
      : c.mode === "speed" ? (c.outcome === "draw" ? "Exactement le même nombre de points !"
        : (() => { const w = c.outcome === "win" ? c.mine : c.theirs, l = c.outcome === "win" ? c.theirs : c.mine;
            const by = w.score < l.score ? " grâce à la vitesse ⚡" : w.score === l.score ? ", plus rapide ⚡" : "";
            return `${c.outcome === "win" ? "Vous gagnez" : `${who(f)} gagne`} ${w.points} à ${l.points} pts${by}`; })())
      : c.mode === "precision" ? (c.outcome === "draw" ? "Même nombre de bonnes réponses : match nul !" : c.outcome === "win" ? "Plus de bonnes réponses : bien joué !" : "La revanche vous attend !")
      : c.outcome === "win" ? (c.mine.score === c.theirs.score ? "Même score, mais vous avez été plus rapide ⚡" : "Bien joué ! Prêt à remettre ça ?")
      : c.outcome === "lose" ? (c.mine.score === c.theirs.score ? `Même score, ${who(f)} a été plus rapide.` : "La revanche vous attend !") : "Même score, même temps : impressionnant.",
  }[c.stage] || "";
  const rec = So.record(f?.id);
  const tone = c.stage === "done" ? c.outcome : c.stage === "to_accept" || c.stage === "to_play" ? "invite" : c.stage === "declined" || c.stage === "cancelled" ? "off" : "wait";
  const watching = LIVE && LIVE.id === c.id && c.stage === "waiting_play";
  const reactions = c.stage === "done" ? (c.outcome === "win" ? ["👏 GG !", "😎 Trop facile", "🔥 Revanche ?"] : c.outcome === "lose" ? ["👏 Bien joué !", "🔥 Revanche !", "😅 La prochaine fois…"] : ["🤝 Égalité parfaite !", "🔥 On départage ?"]) : [];
  const h2h = rec.total ? `<div class="h2h-box"><div class="h2h-top"><span>Vous <b>${rec.win}</b></span><small>Face à face · ${rec.total} défi${rec.total > 1 ? "s" : ""}</small><span><b>${rec.lose}</b> ${who(f)}</span></div>
      <div class="h2h-bar"><i class="w" style="flex:${rec.win}"></i><i class="d" style="flex:${rec.draw}"></i><i class="l" style="flex:${rec.lose}"></i></div>${rec.draw ? `<small class="h2h-draw">${rec.draw} égalité${rec.draw > 1 ? "s" : ""}</small>` : ""}</div>` : "";
  app.innerHTML = `<div class="s-page defi-page">
  <a class="back-link" href="#amis">← Défis</a>
  <section class="card s-defi-res vs-card t-${tone} ${justPlayed ? "fresh" : ""}">
    <div class="vs-band">
      <p class="vs-kicker">${modeIco(c.mode)} ${modeLabel(c.mode).replace(/^\S+\s/, "")}${c.mode === "survival" ? "" : ` · ${c.n} questions`}${c.words ? ` · 🎯 ${terrainOf(c)}` : ""}${c.live ? " · ⚡ direct" : ""}</p>
      <h1>${head}</h1>${sub ? `<p class="vs-tag">${sub}</p>` : ""}
      <div class="vs-row">${col(c.mine, "Vous", me, c.outcome === "win")}<span class="vs-x">VS</span>${col(c.theirs, who(f), f, c.outcome === "lose")}</div>
    </div>
    ${records.length ? `<div class="rec-new"><span>🏆</span><div><b>Nouveau record !</b>${records.map(([, t]) => `<small>${esc(t)}</small>`).join("")}</div></div>` : ""}
    ${watching ? `<div class="live-watch" data-watch></div>` : ""}
    ${h2h}
    <div class="vs-actions">
      ${c.stage === "to_accept" ? `<button class="btn primary big" data-ch-accept="${c.id}">Accepter le défi</button><button class="btn ghost small" data-ch-decline="${c.id}">Refuser</button>` : ""}
      ${c.stage === "to_play" ? `<a class="btn primary big" href="#defi-${c.id}" data-reload>${icon("play", { size: 18, fill: "currentColor" })} Jouer</a>` : ""}
      ${c.stage === "waiting_accept" ? `<button class="btn ghost small" data-ch-cancel="${c.id}">Annuler le défi</button>` : ""}
      ${c.stage === "done" && f ? `<button class="btn primary big" data-rematch>${icon(c.outcome === "win" ? "swords" : "repeat", { size: 18, stroke: 2.5 })} ${c.outcome === "win" ? "Rejouer" : "Revanche"}</button>
        <small class="vs-rm-hint">${c.outcome === "win" ? "Même mode, même adversaire" : `Même mode, tout de suite : ${who(f)} sera prévenu que vous voulez votre revanche`}</small>` : ""}
      ${reactions.length && f ? `<div class="vs-quick">${reactions.map((r) => `<button class="chip-btn" data-react="${esc(r)}">${esc(r)}</button>`).join("")}</div>` : ""}
      ${f ? `<a class="fr-link vs-chat" href="#chat-${esc(f.username)}">${icon("chat", { size: 16 })} Écrire à ${who(f)}</a>` : ""}
    </div>
  </section>
  <div data-replay>${replayCard(c, normRecap(recap), null)}</div>
  </div>`;
  // Les scores défilent jusqu'à leur valeur
  app.querySelectorAll("[data-count]").forEach((el) => {
    const end = +el.dataset.count; let n = 0;
    const step = () => { el.textContent = n; if (n++ < end) setTimeout(step, Math.max(25, 500 / Math.max(1, end))); };
    step();
  });
  if (justPlayed && (c.outcome === "win" || records.length)) setTimeout(celebrate, 500);
  // Déroulé : le sien, et celui de l'adversaire dès que les deux ont joué
  if (c.mine) So.loadRecaps(c.id).then((map) => {
    const z = app.querySelector("[data-replay]"); if (!z) return;
    const mine = normRecap(map[me?.id]) || normRecap(recap);
    z.innerHTML = replayCard(c, mine, normRecap(map[f?.id]));
  }).catch(() => {});
  app.querySelector("[data-rematch]")?.addEventListener("click", async (e) => {
    const b = e.currentTarget; b.disabled = true;
    const id = await rematch(c);
    if (!id) b.disabled = false;
  });
  // Bilan complet du face-à-face (la liste locale ne garde que les derniers défis)
  if (f) So.loadRivalry(f.id).then((r) => {
    const box = app.querySelector(".h2h-box"); if (!box || !r.total) return;
    box.querySelector(".h2h-top").innerHTML = `<span>Vous <b>${r.win}</b></span><small>Face à face · ${r.total} défi${r.total > 1 ? "s" : ""}</small><span><b>${r.lose}</b> ${who(f)}</span>`;
    box.querySelector(".h2h-bar").innerHTML = `<i class="w" style="flex:${r.win}"></i><i class="d" style="flex:${r.draw}"></i><i class="l" style="flex:${r.lose}"></i>`;
  }).catch(() => {});
  app.querySelectorAll("[data-react]").forEach((b) => (b.onclick = async () => {
    b.disabled = true;
    try { await So.sendMessage(f.id, `${b.dataset.react} (défi ${c.mine?.score ?? "?"}–${c.theirs?.score ?? "?"})`); toast("Message envoyé ✓", "ok"); }
    catch (e) { toast(e.message, "warn"); b.disabled = false; }
  }));
  bindChallengeActions(app.firstElementChild);
  if (watching) {
    const paintWatch = () => {
      const z = app.querySelector("[data-watch]"); if (!z) return;
      const o = LIVE?.opp || {};
      z.innerHTML = !o.present && !o.finished ? `<p class="muted small">📴 ${who(f)} s'est déconnecté : son score arrivera quand il aura fini.</p>`
        : `<p class="live-h">⚡ ${who(f)} joue en ce moment</p>${liveBars(c, null, o, (performance.now() - (LIVE?.t0 || performance.now())) / 1000)}`;
    };
    LIVE.onUpdate = paintWatch; paintWatch();
    const w = setInterval(paintWatch, 1000);
    const prevC = app._cleanup; app._cleanup = () => { clearInterval(w); prevC?.(); };
  }
  if (c.stage === "done" && LIVE?.id === c.id) leaveLive();
  const off = So.onSocial((what) => {
    if (what !== "all") return;
    const fresh = So.allChallenges().find((x) => x.id === c.id);
    if (fresh && fresh.stage !== c.stage) { off(); app._cleanup?.(); app._cleanup = null; showDefi(app, fresh, fresh.stage === "done" && (justPlayed || !!LIVE)); }
  });
  const prevS = app._cleanup;
  app._cleanup = () => { off(); prevS?.(); };
}


/* ======================== Duel en direct ⚡ ======================== */
let LIVE = null; // { id, duel, opp: { present, ready, good, bad, total, ms, finished }, onUpdate, t0, meDone }
export function leaveLive() { if (LIVE) { LIVE.duel?.leave(); LIVE = null; } }

/** Deux barres de progression : moi et l'adversaire */
function liveBars(c, me, opp, el) {
  const pts = (good, ms) => Math.max(0, good * So.SPEED_PER_GOOD - Math.round(ms / 1000) * So.SPEED_PER_SEC);
  const bar = (label, p, cls) => {
    if (!p) return "";
    const n = (p.good || 0) + (p.bad || 0), total = c.mode === "survival" ? Math.max(10, me?.good || 0, opp?.good || 0) + 2 : p.total || c.n;
    const extra = c.mode === "speed" ? ` · ${pts(p.good || 0, p.finished ? p.ms : el * 1000)} pts` : "";
    return `<div class="lb ${cls}"><span class="lb-who">${label}</span><div class="lb-bar"><span style="width:${Math.round((n / total) * 100)}%"></span></div>
      <span class="lb-sc">${c.mode === "survival" ? `${p.bad ? "💀 " : p.finished ? "🏁 " : "🔥 "}${p.good || 0}` : `${p.finished ? "🏁 " : ""}✓${p.good || 0} ✗${p.bad || 0}${extra}`}</span></div>`;
  };
  const f = c.friend;
  const oppState = opp && (opp.present || opp.finished) ? opp : null;
  return `<div class="live-bars">${me ? bar("Vous", me, "me") : ""}${oppState ? bar(who(f), { ...opp, total: opp.total || c.n }, "op") : `<p class="muted small">📴 ${who(f)} n'est plus connecté</p>`}</div>`;
}

async function renderLobby(app, c) {
  const f = c.friend, me = So.social().me;
  app.innerHTML = `<a class="back-link" href="#amis">← Amis</a>
  <section class="card s-defi-intro defi-arena live-lobby">
    <p class="eyebrow">⚡ Duel en direct · ${c.mode === "survival" ? "" : `${c.n} questions · `}${modeLabel(c.mode)}${c.words ? ` · 🎯 ${terrainOf(c)}` : ""}</p>
    <div class="s-vs"><div class="seat">${av(me, "xl")}<span class="seat-st" data-st="me"></span></div><span class="s-vs-x">VS</span><div class="seat">${av(f, "xl")}<span class="seat-st" data-st="op"></span></div></div>
    <h1 data-l="title">Connexion…</h1><p class="muted" data-l="sub"></p>
    <button class="btn primary big" data-ready disabled>Je suis prêt !</button>
    <ul class="defi-rules">
      <li>⚡ Vous jouez en même temps, ${c.words ? "sur les mêmes mots (points faibles)" : "chacun sur ses propres mots"}</li>
      <li>👀 Vous voyez la progression de ${who(f)} pendant la partie</li>
      <li>${c.mode === "survival" ? "💀 La première erreur vous élimine : tenez plus longtemps que l'autre" : c.mode === "listen" ? "🎧 Uniquement des questions audio : montez le son !" : c.mode === "precision" ? "🎯 Seules les bonnes réponses comptent" : `⏱️ ${So.SPEED_PER_GOOD} pts par bonne réponse, −${So.SPEED_PER_SEC} pts par seconde`}</li>
    </ul>
    <button class="btn ghost small" data-solo ${c.stage === "waiting_accept" ? "hidden" : ""}>Jouer sans attendre (${who(f)} jouera plus tard)</button>
  </section>`;
  const $ = (q) => app.querySelector(q);
  let started = false, meReady = false;
  const opp = { present: false, ready: false };

  function paint() {
    if (started || !$(".live-lobby")) return;
    const waitingAccept = c.stage === "waiting_accept";
    $('[data-st="me"]').textContent = meReady ? "✓ Prêt" : "En ligne";
    $('[data-st="op"]').textContent = waitingAccept ? "Invité…" : opp.ready ? "✓ Prêt" : opp.present ? "En ligne" : "Absent";
    $('[data-st="op"]').className = `seat-st ${opp.ready ? "ok" : opp.present ? "on" : ""}`;
    $('[data-st="me"]').className = `seat-st ${meReady ? "ok" : "on"}`;
    const [t, sub] = waitingAccept ? [`En attente de ${who(f)}…`, `Il a reçu une notification. Dès qu'il accepte, il vous rejoint ici.`]
      : !opp.present ? [`En attente de ${who(f)}…`, "Restez sur cette page : le duel commence quand vous êtes prêts tous les deux."]
      : !meReady ? [`${who(f)} est là ! 👋`, opp.ready ? `${who(f)} est prêt : à vous !` : "Cliquez sur « Je suis prêt » pour lancer le duel."]
      : [`En attente que ${who(f)} soit prêt…`, ""];
    $('[data-l="title"]').textContent = t; $('[data-l="sub"]').textContent = sub;
    const b = $("[data-ready]");
    b.disabled = waitingAccept || meReady;
    b.textContent = meReady ? "Prêt ✓" : "Je suis prêt !";
    $("[data-solo]").hidden = waitingAccept;
  }

  function go() {
    if (started) return;
    started = true;
    LIVE.t0 = performance.now() + 1950;
    const qs = CG.buildChallengeQuestions(c.n, { words: c.words, audio: c.mode === "listen" });
    countdownThen(app, () => { LIVE.t0 = performance.now(); play(app, c, qs, LIVE); });
  }

  leaveLive();
  LIVE = { id: c.id, opp, duel: null, onUpdate: null, t0: 0, meDone: false };
  const mine = LIVE;
  try {
    mine.duel = await So.joinDuel(c.id, {
      onPresence: (others) => {
        const o = others[0];
        const was = opp.present;
        opp.present = !!o; opp.ready = !!o?.ready;
        if (was && !o && started && !opp.finished) toast(`${who(f)} s'est déconnecté`, "warn");
        paint(); mine.onUpdate?.();
        // Le lanceur du défi donne le départ quand les deux sont prêts
        if (!started && c.iAmChallenger && meReady && opp.ready) { mine.duel.start({ n: c.n }); go(); }
      },
      onStart: () => go(),
      onProgress: (p) => { Object.assign(opp, p, { present: true }); mine.onUpdate?.(); },
    });
  } catch {
    $('[data-l="title"]').textContent = "Connexion au duel impossible";
    $('[data-l="sub"]').textContent = "Vous pouvez jouer sans attendre : votre score sera comparé à celui de votre ami.";
    $("[data-solo]").hidden = false;
  }
  if (LIVE !== mine) { mine.duel?.leave(); return; } // page quittée pendant la connexion
  paint();

  $("[data-ready]").onclick = async () => {
    meReady = true; paint();
    await mine.duel?.ready(true);
    if (!started && c.iAmChallenger && opp.ready) { mine.duel.start({ n: c.n }); go(); }
  };
  $("[data-solo]").onclick = () => { leaveLive(); renderDefi(app, c.id, { solo: true }); };

  // L'adversaire accepte (ou joue seul) pendant qu'on attend
  const off = So.onSocial((what) => {
    if (what !== "all" || started) return;
    const fresh = So.allChallenges().find((x) => x.id === c.id);
    if (!fresh) return;
    if (fresh.theirs || ["declined", "cancelled"].includes(fresh.stage)) { off(); leaveLive(); renderDefi(app, c.id, { solo: true }); return; }
    if (fresh.stage !== c.stage) { c = fresh; paint(); }
  });
  app._cleanup = () => { off(); };
}
