/* =====================================================================
   Vue « Tableau de bord » — statistiques et suivi
   ===================================================================== */

import { LEVELS, ALL_LESSONS, lvlLabel, lvlBadge } from "../data/curriculum.js";
import { state } from "../core/storage.js";
import * as P from "../core/progress.js";
import { pyText } from "../core/pinyin.js";
import { esc, ring } from "../core/ui.js";
import { L } from "../core/lang.js";

export function renderDashboard(app) {
  const g = P.globalProgress();
  const goal = state.profile?.dailyGoal || 50;
  const today = P.dailyXp();
  const goalPct = Math.min(100, Math.round((today / goal) * 100));
  const lessonsDone = ALL_LESSONS.filter((l) => P.isLessonDone(l.id)).length;
  const words = Object.keys(state.vocab).length;
  const errors = Object.keys(state.errors).length;
  const next = P.nextStep();
  const attempts = state.history.filter((h) => h.kind !== "review");
  const avg = attempts.length ? Math.round((attempts.reduce((a, h) => a + h.score / h.total, 0) / attempts.length) * 100) : 0;

  app.innerHTML = `
  <header class="page-head">
    <p class="eyebrow">Tableau de bord</p>
    <h1>${esc(state.profile?.avatar || "")} ${esc(state.profile?.pseudo || "")}, voici votre progression</h1>
  </header>

  <div class="dash-grid">
    <section class="card dash-main">
      ${ring(g.pct, 168, 14)}
      <div>
        <p class="eyebrow">Progression globale ${lvlLabel(LEVELS[0])} → ${lvlLabel(LEVELS[LEVELS.length - 1])}</p>
        <h2>${g.done} / ${g.total} étapes</h2>
        <p class="muted">Niveau actuel : <b>${lvlLabel(P.currentLevel())} · ${P.currentLevel().name}</b></p>
        ${next ? `<a class="btn primary" href="#${P.stepHref(next)}">
          ${next.kind === "lesson" ? "Reprendre : " + pyText(next.lesson.levelId, next.lesson.title) : next.kind === "checkpoint" ? "Test de mi-palier " + lvlLabel(next.level) : "Passer l'examen " + lvlLabel(next.level)} →</a>` : ""}
      </div>
    </section>

    <section class="card goal">
      ${ring(goalPct, 96, 9, `${today}`)}
      <div>
        <p class="eyebrow">Objectif du jour</p>
        <h3>${today} / ${goal} XP</h3>
        <p class="small muted">${goalPct >= 100 ? "Objectif atteint, ${L.goalDone} ! 🎉" : `Encore ${goal - today} XP aujourd'hui.`}</p>
      </div>
    </section>

    <section class="stats">
      ${stat("🔥", P.streakCount(), "jour(s) de série")}
      ${stat("⚡", state.xp, "XP au total")}
      ${stat("✅", lessonsDone, `leçon(s) sur ${ALL_LESSONS.length}`)}
      ${stat("🎯", avg + "%", "réussite moyenne")}
      <a class="stat link" href="#carnet">${statInner("📒", words, "mots dans le carnet")}</a>
      <a class="stat link ${errors ? "warn" : ""}" href="#erreurs">${statInner("🔁", errors, "erreur(s) à revoir")}</a>
    </section>

    <section class="card levels-card">
      <h2 class="h3">Progression par palier</h2>
      <ul class="level-bars">
        ${LEVELS.map((l, i) => {
          const p = P.levelProgress(i), open = P.isLevelUnlocked(i);
          return `<li class="${open ? "" : "locked"}" style="--lvl:${l.color}">
            <span class="lb-id">${lvlLabel(l)}</span>
            <span class="lb-name">${l.name}${l.hsk && !l.label ? ` · ${l.hsk}` : ""}${P.isExamPassed(l.id) ? " 🏆" : ""}</span>
            <span class="lb-bar"><i style="width:${p.pct}%"></i></span>
            <span class="lb-pct">${open ? p.pct + "%" : "🔒"}</span>
          </li>`;
        }).join("")}
      </ul>
    </section>

    <section class="card history-card">
      <h2 class="h3">Activité récente</h2>
      ${state.history.length ? `<ul class="history">${state.history.slice(0, 8).map((h) => `
        <li>
          <span class="h-dot ${h.passed ? "ok" : "ko"}"></span>
          <span class="h-label">${esc(h.label)}</span>
          <span class="h-score">${h.score}/${h.total}</span>
          <time>${new Date(h.date).toLocaleDateString("fr-FR", { day: "numeric", month: "short" })}</time>
        </li>`).join("")}</ul>`
        : `<p class="empty">Aucune activité pour l'instant. <a href="#parcours">Commencez votre première leçon</a> !</p>`}
    </section>
  </div>`;
}

const statInner = (icon, val, label) => `<span class="stat-icon">${icon}</span><b>${val}</b><small>${label}</small>`;
const stat = (icon, val, label) => `<div class="stat">${statInner(icon, val, label)}</div>`;
