/* =====================================================================
   Vue « Fiches de grammaire » (#fiches) : toutes les explications des
   leçons débloquées, regroupées par thème, consultables à tout moment
   (sans repasser par la leçon). Recherche par mot-clé.
   ===================================================================== */
import { LEVELS, MODULES, lvlLabel } from "../data/curriculum.js";
import * as P from "../core/progress.js";
import { esc } from "../core/ui.js";
import { pyText, pyHtml } from "../core/pinyin.js";
import { L } from "../core/lang.js";
import { section } from "./lecon.js";
import { moduleIcon } from "../core/icons.js";

const ui = { mod: "all", q: "" };
const plainOf = (l) => [l.title, l.intro, ...l.sections.flatMap((s) => [s.title, s.text, ...(s.examples || []).flat(), ...(s.table?.rows || []).flat()])].join(" ").replace(/<[^>]+>/g, " ").toLowerCase();

export function renderFiches(app) {
  const all = LEVELS.flatMap((lv) => lv.lessons.filter((l) => l.module !== "vocab" && l.sections?.length).map((l) => ({ l, lv })));
  const open = all.filter(({ l }) => P.isLessonUnlocked(l) || P.isLessonDone(l.id));
  const locked = all.length - open.length;
  const mods = Object.keys(MODULES).filter((m) => open.some(({ l }) => l.module === m));
  app.innerHTML = `
  <a class="back-link" href="#entrainement">← Entraînement</a>
  <header class="page-head">
    <p class="eyebrow">Fiches de grammaire</p>
    <h1>📋 ${open.length} fiche${open.length > 1 ? "s" : ""}</h1>
    <p class="muted">Toutes les explications de vos leçons, rangées par thème.${locked ? ` ${locked} autres se débloquent au fil du parcours.` : ""}</p>
  </header>
  <div class="toolbar fi-bar">
    <input type="search" class="search" placeholder="Rechercher (ex. : subjonctif, 了, articles…)" value="${esc(ui.q)}" aria-label="Rechercher une fiche">
    <div class="chips fi-mods" role="group" aria-label="Thème">
      ${["all", ...mods].map((m) => `<button type="button" class="chip-btn ${ui.mod === m ? "on" : ""}" data-mod="${m}">${m === "all" ? "Tout" : `${moduleIcon(m, { size: 15 })} ${esc(MODULES[m].label)}`}</button>`).join("")}
    </div>
  </div>
  <div class="fi-list"></div>`;
  const list = app.querySelector(".fi-list");
  const draw = () => {
    const q = ui.q.trim().toLowerCase();
    const items = open.filter(({ l }) => (ui.mod === "all" || l.module === ui.mod) && (!q || plainOf(l).includes(q)));
    if (!items.length) { list.innerHTML = `<p class="empty">Aucune fiche ne correspond.</p>`; return; }
    const groups = ui.mod === "all" ? mods.map((m) => [m, items.filter(({ l }) => l.module === m)]).filter(([, a]) => a.length) : [[ui.mod, items]];
    list.innerHTML = groups.map(([m, arr]) => `
      <h2 class="fi-group">${moduleIcon(m, { size: 18 })} ${esc(MODULES[m].label)} <small>${arr.length}</small></h2>
      ${arr.map(({ l, lv }) => `
        <details class="fiche card" style="--lvl:${lv.color}" ${q && items.length <= 3 ? "open" : ""}>
          <summary><span class="fi-emoji">${l.emoji}</span><span class="fi-t"><b>${pyText(lv.id, l.title)}</b><small>${esc(lvlLabel(lv))}${P.isLessonDone(l.id) ? "" : " · pas encore validée"}</small></span></summary>
          <div class="fi-body">
            ${l.intro ? `<p class="lead">${pyHtml(lv.id, l.intro)}</p>` : ""}
            ${l.sections.map((s, i) => section(s, i, lv.id)).join("")}
            ${l.mnemo ? `<aside class="mnemo"><span class="mnemo-icon">💡</span><div><p class="eyebrow">Astuce</p><p>${pyHtml(lv.id, l.mnemo)}</p></div></aside>` : ""}
            <a class="btn ghost small" href="#lecon-${l.id}">Ouvrir la leçon →</a>
          </div>
        </details>`).join("")}`).join("");
  };
  app.querySelector(".search").oninput = (e) => { ui.q = e.target.value; draw(); };
  app.querySelectorAll("[data-mod]").forEach((b) => (b.onclick = () => {
    ui.mod = b.dataset.mod; app.querySelectorAll("[data-mod]").forEach((x) => x.classList.toggle("on", x === b)); draw();
  }));
  draw();
  return true;
}
