/* =====================================================================
   Écran de passage de palier : plein écran, badge du nouveau niveau,
   partage aux amis. Affiché une fois, quand l'examen d'un palier est
   réussi pour la première fois.
   ===================================================================== */
import { LEVELS, lvlLabel, lvlBadge } from "../data/curriculum.js";
import { state } from "../core/storage.js";
import { esc, celebrate, toast } from "../core/ui.js";
import { L } from "../core/lang.js";
import { mascot } from "../core/mascot.js";
import * as P from "../core/progress.js";

export function showLevelUp(levelId) {
  const i = LEVELS.findIndex((l) => l.id === levelId);
  if (i < 0) return;
  const done = LEVELS[i], next = LEVELS[i + 1];
  const words = Object.keys(state.vocab).length, lessons = done.lessons.length;
  const root = document.createElement("div");
  root.className = "levelup";
  root.setAttribute("role", "dialog");
  root.style.setProperty("--lv", (next || done).color || "#1e8e5a");
  root.innerHTML = `
    <div class="lu-rays" aria-hidden="true"></div>
    <div class="lu-inner">
      <p class="lu-kicker">Palier ${esc(lvlLabel(done))} validé</p>
      <div class="lu-badge"><span class="lu-ring"></span><b>${next ? lvlBadge(next) : lvlBadge(done)}</b></div>
      <h1>${next ? `Bienvenue en ${esc(lvlLabel(next))} !` : "Parcours terminé !"}</h1>
      <p class="lu-sub">${next ? `${esc(next.name)} · ${esc(next.title)}` : esc(L.finished || "Vous avez terminé tous les paliers.")}</p>
      <div class="lu-stats">
        <span><b>${lessons}</b><small>leçons</small></span>
        <span><b>${words}</b><small>mots appris</small></span>
        <span><b>${P.streakCount()}</b><small>jours de série</small></span>
      </div>
      <span class="lu-mascot">${mascot("cheer", { size: 110 })}</span>
      <div class="lu-actions">
        <button type="button" class="btn big lu-share" data-share>Partager à mes amis</button>
        <button type="button" class="btn big lu-go" data-close>${next ? `Commencer ${esc(lvlLabel(next))}` : "Continuer"} →</button>
      </div>
    </div>`;
  document.body.appendChild(root);
  requestAnimationFrame(() => root.classList.add("in"));
  setTimeout(() => celebrate({ sound: "win" }), 250);
  setTimeout(() => celebrate({ sound: null }), 1300);
  const close = () => { root.classList.remove("in"); setTimeout(() => root.remove(), 300); };
  root.querySelector("[data-close]").onclick = () => { close(); location.hash = "parcours"; };
  root.querySelector("[data-share]").onclick = async () => {
    const text = `🎓 J'ai validé le palier ${lvlLabel(done)} en ${L.label.toLowerCase()} sur ${L.brand || "Impara"} ! ${next ? `Prochaine étape : ${lvlLabel(next)}.` : ""}`;
    const url = location.origin + location.pathname;
    try {
      if (navigator.share) { await navigator.share({ title: L.brand || "Impara", text, url }); return; }
      await navigator.clipboard.writeText(`${text} ${url}`);
      toast("Message copié : collez-le à vos amis ✓", "ok");
    } catch {}
  };
}
