/* =====================================================================
   Vue « Carnet de vocabulaire » — liste filtrable + mode flashcards
   ===================================================================== */

import { LEVELS, getLesson, lvlLabel, lvlBadge } from "../data/curriculum.js";
import { state } from "../core/storage.js";
import { esc, speakBtn, speak, shuffle } from "../core/ui.js";
import { L } from "../core/lang.js";
import * as S from "../core/srs.js";
import * as P from "../core/progress.js";

// État local de la vue (non persisté : simple confort d'affichage)
const ui = { query: "", level: "all", mode: "list", deck: [], pos: 0, flipped: false, cardType: readType("cardType", "hanzi"), study: readType("study", "srs"), deckKey: null, done: 0 };

/* Types de flashcards (mandarin) : on garde le dernier choix */
const CARD_TYPES = [["hanzi", "汉字 → pinyin + sens"], ["pinyin", "Pinyin → sens"]];
function readType(k, def) { try { return localStorage.getItem("impara." + k) || def; } catch { return def; } }
function saveType(t, study) { try { localStorage.setItem("impara.cardType", t); localStorage.setItem("impara.study", study); } catch {} }

/** Ouvre directement la révision du jour (lien « mots à réviser ») */
export function openReview() { ui.mode = "cards"; ui.study = "srs"; ui.deckKey = null; }

export function renderCarnet(app) {
  const all = Object.values(state.vocab).sort((a, b) => b.added - a.added);

  app.innerHTML = `
  <a class="back-link" href="#entrainement">← Entraînement</a>
  <header class="page-head">
    <p class="eyebrow">Carnet de vocabulaire</p>
    <h1>📒 ${all.length} mot${all.length > 1 ? "s" : ""} et expressions</h1>
    <p class="muted">Chaque leçon réussie enrichit automatiquement votre carnet.</p>
    <div class="btn-row head-actions">
      ${all.length ? `<button class="btn primary small" data-go-srs>📅 Réviser${S.srsStats(all).todo ? ` (${S.srsStats(all).todo})` : ""}</button>` : ""}
    </div>
  </header>
  ${all.length ? `
  <div class="toolbar">
    <input type="search" class="search" placeholder="${esc(L.search)}" value="${esc(ui.query)}" aria-label="Rechercher">
    <div class="chips" role="group" aria-label="Filtrer par palier">
      ${["all", ...LEVELS.map((l) => l.id)].map((id) => `<button class="chip-btn ${ui.level === id ? "on" : ""}" data-level="${id}">${id === "all" ? "Tous" : lvlLabel(id)}</button>`).join("")}
    </div>
    <div class="seg" role="group" aria-label="Mode d'affichage">
      <button class="${ui.mode === "list" ? "on" : ""}" data-mode="list">Liste</button>
      <button class="${ui.mode === "cards" ? "on" : ""}" data-mode="cards">Flashcards</button>
    </div>
  </div>
  <div class="carnet-body"></div>`
  : `<div class="empty-state"><span>📭</span><p>Votre carnet est vide pour l'instant.</p><a class="btn primary" href="#parcours">Commencer une leçon</a></div>`}`;

  if (!all.length) return;

  const body = app.querySelector(".carnet-body");
  const filtered = () => all.filter((w) =>
    (ui.level === "all" || w.levelId === ui.level) &&
    (!ui.query || (w.zh + " " + (w.py || "") + " " + (w.py || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "") + " " + w.fr).toLowerCase().includes(ui.query.toLowerCase())));

  function draw() {
    const list = filtered();
    if (ui.mode === "list") {
      body.innerHTML = list.length ? `<ul class="word-list">${list.map((w) => `
        <li>${speakBtn(w.zh)}
          <span class="it"><span class="${L.wordClass}">${esc(w.zh)}</span>${w.py ? ` <span class="py">${esc(w.py)}</span>` : ""}</span>
          <span class="fr">${esc(w.fr)}</span>
          <span class="tag" style="--lvl:${LEVELS.find((l) => l.id === w.levelId)?.color}" title="${esc(getLesson(w.lessonId)?.title || "")}">${lvlLabel(w.levelId)}</span>
        </li>`).join("")}</ul>` : `<p class="empty">Aucun résultat.</p>`;
    } else {
      drawCards(list);
    }
  }

  /* ----------------------------- Flashcards ---------------------------- */
  function drawCards(list) {
    const hasPinyin = list.some((w) => w.py);
    const pinyinMode = hasPinyin && ui.cardType === "pinyin";
    const pool = pinyinMode ? list.filter((w) => w.py) : list;
    const srs = ui.study === "srs";
    const st = S.srsStats(pool);
    const source = srs ? S.dueWords(pool) : pool;
    const key = `${ui.study}|${ui.cardType}|${ui.level}|${ui.query}`;
    if (ui.deckKey !== key || (!srs && ui.deck.some((w) => !pool.includes(w)))) {
      ui.deckKey = key;
      // Révision : d'abord les mots déjà vus et dus, puis les nouveaux (20 max par séance)
      ui.deck = srs ? [...shuffle(source.filter((w) => !S.isNew(w))), ...shuffle(source.filter(S.isNew)).slice(0, 20)] : shuffle(pool);
      ui.pos = 0; ui.flipped = false; ui.done = 0;
    }
    const w = ui.deck[ui.pos];

    const studySwitch = `<div class="seg" role="group" aria-label="Mode de révision">
        <button class="${srs ? "on" : ""}" data-study="srs">📅 Révision du jour${st.todo ? ` <span class="count-pill">${st.todo}</span>` : ""}</button>
        <button class="${!srs ? "on" : ""}" data-study="free">🔀 Libre</button></div>`;
    const typeSwitch = hasPinyin ? `<div class="seg card-type" role="group" aria-label="Type de flashcard">
        ${CARD_TYPES.map(([t, label]) => `<button class="${ui.cardType === t ? "on" : ""}" data-type="${t}">${label}</button>`).join("")}</div>` : "";
    const statsLine = `<p class="srs-stats small muted">🆕 ${st.fresh} nouveau${st.fresh > 1 ? "x" : ""} · 🔁 ${st.due} à revoir · ✅ ${st.known} bien connu${st.known > 1 ? "s" : ""}</p>`;

    if (!w) {
      body.innerHTML = `<div class="flash-wrap">${studySwitch}${typeSwitch}
        <div class="card srs-done"><span class="big-emoji">🎉</span>
          <h2>${srs ? "Révision du jour terminée !" : "Aucun mot pour ce filtre."}</h2>
          ${srs ? `<p class="muted">${ui.done ? `${ui.done} carte${ui.done > 1 ? "s" : ""} révisée${ui.done > 1 ? "s" : ""}. ` : ""}Revenez demain : les mots reviendront au bon moment.</p>
          <button class="btn ghost" data-study="free">🔀 Continuer en mode libre</button>` : ""}
        </div>${statsLine}</div>`;
      bindCardControls(pool);
      return;
    }

    const faces = pinyinMode
      ? `<span class="face front"><small>Pinyin</small><b class="big-py">${esc(w.py)}</b><em>Touchez pour voir la traduction</em></span>
         <span class="face back"><small>${esc(w.py)}</small><b>${esc(w.fr)}</b><em class="${L.wordClass}">${esc(w.zh)}</em></span>`
      : `<span class="face front"><small>${esc(L.cardFront)}</small><b class="${L.wordClass ? L.wordClass + " big-zh" : ""}">${esc(w.zh)}</b><em>${esc(L.cardHint)}</em></span>
         <span class="face back"><small>${esc(w.py || "Français")}</small><b>${esc(w.fr)}</b><em class="${L.wordClass}">${esc(w.zh)}</em></span>`;
    const pv = S.preview(w);
    const controls = srs
      ? (ui.flipped
        ? `<div class="grade-row">
            <button class="btn grade again" data-grade="again">😕 À revoir<small>${pv.again}</small></button>
            <button class="btn grade hard" data-grade="hard">🤔 Difficile<small>${pv.hard}</small></button>
            <button class="btn grade good" data-grade="good">😄 Je savais<small>${pv.good}</small></button></div>`
        : `<div class="flash-nav"><button class="btn primary" data-flip>Retourner la carte</button><span>${ui.pos + 1} / ${ui.deck.length}</span></div>`)
      : `<div class="flash-nav">
          <button class="btn ghost" data-nav="-1">← Précédent</button>
          <span>${ui.pos + 1} / ${ui.deck.length}</span>
          <button class="btn ghost" data-nav="1">Suivant →</button></div>
        <button class="btn ghost small" data-shuffle>🔀 Mélanger</button>`;

    body.innerHTML = `
      <div class="flash-wrap">
        ${studySwitch}${typeSwitch}
        ${srs && S.isNew(w) ? `<span class="chip new-chip">🆕 Nouveau mot</span>` : ""}
        <button class="flashcard ${ui.flipped ? "flipped" : ""}" aria-label="Retourner la carte">${faces}</button>
        ${controls}
        ${srs ? statsLine : ""}
      </div>`;

    const flip = () => {
      ui.flipped = !ui.flipped;
      if (srs) { draw(); } else body.querySelector(".flashcard").classList.toggle("flipped");
      if (ui.flipped) speak(w.zh);
    };
    body.querySelector(".flashcard").addEventListener("click", flip);
    body.querySelector("[data-flip]")?.addEventListener("click", flip);
    body.querySelectorAll("[data-nav]").forEach((b) => (b.onclick = () => {
      ui.pos = (ui.pos + +b.dataset.nav + ui.deck.length) % ui.deck.length; ui.flipped = false; draw();
    }));
    body.querySelector("[data-shuffle]")?.addEventListener("click", () => { ui.deck = shuffle(pool); ui.pos = 0; ui.flipped = false; draw(); });
    body.querySelectorAll("[data-grade]").forEach((b) => (b.onclick = () => {
      const g = b.dataset.grade;
      S.grade(w, g);
      if (g === "good") P.recordPractice({ label: "Flashcards", score: 1, total: 0, xpPer: 2 });
      ui.done++;
      ui.deck.splice(ui.pos, 1);
      if (g === "again") ui.deck.push(w);            // revient en fin de séance
      if (ui.pos >= ui.deck.length) ui.pos = 0;
      ui.flipped = false; draw();
    }));
    bindCardControls(pool);
  }

  function bindCardControls() {
    body.querySelectorAll("[data-study]").forEach((b) => (b.onclick = () => {
      if (ui.study === b.dataset.study) return;
      ui.study = b.dataset.study; saveType(ui.cardType, ui.study); ui.deckKey = null; draw();
    }));
    body.querySelectorAll("[data-type]").forEach((b) => (b.onclick = () => {
      if (ui.cardType === b.dataset.type) return;
      ui.cardType = b.dataset.type; saveType(ui.cardType, ui.study); ui.deckKey = null; draw();
    }));
  }

  app.querySelector("[data-go-srs]")?.addEventListener("click", () => {
    ui.mode = "cards"; ui.study = "srs"; ui.deckKey = null;
    app.querySelectorAll("[data-mode]").forEach((x) => x.classList.toggle("on", x.dataset.mode === "cards")); draw();
  });
  app.querySelector(".search").oninput = (e) => { ui.query = e.target.value; draw(); };
  app.querySelectorAll("[data-level]").forEach((b) => (b.onclick = () => {
    ui.level = b.dataset.level;
    app.querySelectorAll("[data-level]").forEach((x) => x.classList.toggle("on", x === b)); draw();
  }));
  app.querySelectorAll("[data-mode]").forEach((b) => (b.onclick = () => {
    ui.mode = b.dataset.mode; ui.flipped = false;
    app.querySelectorAll("[data-mode]").forEach((x) => x.classList.toggle("on", x === b)); draw();
  }));
  draw();
}
