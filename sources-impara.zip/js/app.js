/* =====================================================================
   app.js — Point d'entrée : routeur, en-tête et navigation
   ---------------------------------------------------------------------
   Routage par ancre (#parcours, #lecon-a1-numeri, #quiz-…, #examen-A1)
   → fonctionne sans serveur et reste partageable/bookmarkable.
   ===================================================================== */

import { state, subscribe } from "./core/storage.js";
import { streakCount } from "./core/progress.js";
import { $, $$, esc, speak, toast } from "./core/ui.js";
import { L, LANGS, code, flagSVG, setLang } from "./core/lang.js";
import { renderParcours } from "./views/parcours.js";
import { renderLecon } from "./views/lecon.js";
import { renderQuiz, renderExamen, renderRevision } from "./views/quiz.js";
import { renderDashboard } from "./views/dashboard.js";
import { renderCarnet, openReview } from "./views/carnet.js";
import { renderErreurs } from "./views/erreurs.js";
import { renderProfil, renderOnboarding } from "./views/profil.js";
import { renderCompte } from "./views/compte.js";
import { initCloud, onCloud, isConfigured } from "./core/cloud.js";
import { renderAmis, renderAmi, renderDefi } from "./views/amis.js";
import { renderEntrainement, renderEcoute, renderTons, renderTrace } from "./views/entrainement.js";
import { initSocial, onSocial, badgeCount } from "./core/social.js";
import { initPwa } from "./core/pwa.js";

const app = $("#app");

/** Table de routage : [motif, rendu, onglet actif] */
const ROUTES = [
  [/^parcours$/, (a) => renderParcours(a), "parcours"],
  [/^tableau$/, (a) => renderDashboard(a), "tableau"],
  [/^carnet$/, (a) => renderCarnet(a), "carnet"],
  [/^erreurs$/, (a) => renderErreurs(a), "erreurs"],
  [/^profil$/, (a) => renderProfil(a), "profil"],
  [/^compte$/, (a) => renderCompte(a), "profil"],
  [/^reviser$/, (a) => { openReview(); renderCarnet(a); }, "carnet"],
  [/^entrainement$/, (a) => renderEntrainement(a), "carnet"],
  [/^ecoute$/, (a) => renderEcoute(a), "carnet"],
  [/^tons$/, (a) => renderTons(a), "carnet"],
  [/^trace(?:-(.+))?$/, (a, m) => renderTrace(a, m[1]), "carnet"],
  [/^amis$/, (a) => renderAmis(a), "amis"],
  [/^ami-(.+)$/, (a, m) => renderAmi(a, m[1]), "amis"],
  [/^defi-(.+)$/, (a, m) => renderDefi(a, m[1]), "amis"],
  [/^revision$/, (a) => renderRevision(a), "erreurs"],
  [/^lecon-(.+)$/, (a, m) => renderLecon(a, m[1]), "parcours"],
  [/^quiz-(.+)$/, (a, m) => renderQuiz(a, m[1]), "parcours"],
  [/^examen-(.+)$/, (a, m) => renderExamen(a, m[1]), "parcours"],
];

function route() {
  app._cleanup?.(); app._cleanup = null;           // nettoie un quiz en cours
  document.body.classList.remove("focus-mode");

  const raw = decodeURIComponent(location.hash.slice(1));
  if (!state.profile && raw === "compte") {          // connexion possible avant l'accueil
    document.body.classList.add("onboarding");
    renderCompte(app);
    return;
  }
  if (!state.profile) {                              // premier lancement
    document.body.classList.add("onboarding");
    renderOnboarding(app, () => { document.body.classList.remove("onboarding"); location.hash = "parcours"; route(); });
    return;
  }
  document.body.classList.remove("onboarding");

  const hash = decodeURIComponent(location.hash.slice(1)) || "parcours";
  for (const [re, render, tab] of ROUTES) {
    const m = hash.match(re);
    if (!m) continue;
    if (render(app, m) === false) {                  // contenu verrouillé ou introuvable
      toast("🔒 Cette étape n'est pas encore débloquée", "warn");
      location.hash = "parcours";
      return;
    }
    setActiveTab(tab);
    window.scrollTo({ top: 0 });
    app.focus({ preventScroll: true });
    return;
  }
  location.hash = "parcours";                        // route inconnue
}

function setActiveTab(tab) {
  $$("[data-tab]").forEach((a) => a.classList.toggle("active", a.dataset.tab === tab));
}

/** Met à jour les compteurs de l'en-tête (appelé à chaque sauvegarde) */
function renderHeader() {
  const p = state.profile;
  $("#hdr-streak").textContent = streakCount();
  $("#hdr-xp").textContent = state.xp;
  $$(".hdr-avatar").forEach((el) => (el.textContent = p?.avatar || "👤"));
  const n = Object.keys(state.errors).length;
  $$(".err-badge").forEach((b) => { b.textContent = n; b.hidden = !n; });
  $("#hdr-pseudo").textContent = p ? p.pseudo : "";
  renderSocialBadge();
}

/** Pastille de l'onglet Amis : demandes, messages non lus, défis à jouer */
function renderSocialBadge() {
  $$("[data-tab=amis]").forEach((a) => (a.hidden = !isConfigured()));
  const n = badgeCount();
  $$(".social-badge").forEach((b) => { b.textContent = n > 9 ? "9+" : n; b.hidden = !n; });
}

/** Pastille de synchronisation dans l'en-tête */
const CLOUD_ICONS = { guest: ["☁️", "Se connecter"], syncing: ["🔄", "Synchronisation…"], synced: ["✅", "Synchronisé"], offline: ["📴", "Hors ligne"], error: ["⚠️", "Erreur de synchronisation"] };
function renderCloud(i) {
  const pill = $("#hdr-cloud");
  if (!isConfigured()) { pill.hidden = true; return; }
  pill.hidden = false;
  const [icon, label] = CLOUD_ICONS[i.status] || CLOUD_ICONS.guest;
  pill.innerHTML = `${icon}<span>${i.user ? "" : label}</span>`;
  pill.title = i.user ? `${label} · ${i.user.email}` : label;
  pill.className = `pill cloud-pill cloud-${i.status}`;
}

/* ---------------------- Sélecteur de langue ------------------------ */
function initLangSwitch() {
  const btn = $("#lang-btn"), menu = $("#lang-menu");
  $("#brand-flag").innerHTML = flagSVG(code);
  $("#brand-name").textContent = L.brand;
  menu.innerHTML = `
    <p class="lang-menu-title">Je veux apprendre…</p>
    ${Object.values(LANGS).map((l) => `
      <button role="menuitemradio" aria-checked="${l.code === code}" class="lang-item ${l.code === code ? "on" : ""}" data-lang="${l.code}">
        <span class="flag">${flagSVG(l.code)}</span>
        <span class="lang-txt"><b>${esc(l.label)}</b><small>${esc(l.native)} · ${esc(l.brand)}</small></span>
        <span class="check">${l.code === code ? "✓" : ""}</span>
      </button>`).join("")}
    <p class="lang-menu-note">Chaque langue garde sa propre progression.</p>`;

  const open = (v) => { menu.hidden = !v; btn.setAttribute("aria-expanded", String(v)); if (v) menu.querySelector(".lang-item.on")?.focus(); };
  btn.onclick = (e) => { e.stopPropagation(); open(menu.hidden); };
  menu.onclick = (e) => {
    const item = e.target.closest("[data-lang]");
    if (!item) return;
    if (item.dataset.lang === code) return open(false);
    setLang(item.dataset.lang);
  };
  document.addEventListener("click", (e) => { if (!menu.hidden && !e.target.closest(".lang-switch")) open(false); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !menu.hidden) { open(false); btn.focus(); } });
}

/* -------------------- Délégation d'événements globale -------------- */
document.addEventListener("click", (e) => {
  const sp = e.target.closest("[data-speak]");
  if (sp) { e.preventDefault(); speak(sp.dataset.speak, { slow: "slow" in sp.dataset }); return; }

  const sc = e.target.closest("[data-scroll]");
  if (sc) { e.preventDefault(); document.getElementById(sc.dataset.scroll)?.scrollIntoView({ behavior: "smooth", block: "start" }); return; }

  const link = e.target.closest("a[href^='#']");
  if (link?.getAttribute("aria-disabled") === "true") { e.preventDefault(); toast("🔒 Terminez les étapes précédentes pour débloquer celle-ci", "warn"); return; }
  // Lien vers la page courante (ex. « Réessayer ») : on force le rendu
  if (link && link.getAttribute("href") === location.hash) { e.preventDefault(); route(); }
});

window.addEventListener("hashchange", route);
initLangSwitch();
onCloud((i) => {
  renderCloud(i);
  // Rafraîchit la page « Compte » si elle est affichée
  if (location.hash === "#compte" && !document.querySelector(".auth-form")) renderCompte(app);
  if (location.hash === "#amis" && !document.querySelector(".s-page, .auth-form") && !document.body.classList.contains("focus-mode")) renderAmis(app);
});
// Progression récupérée depuis un autre appareil : on réaffiche (sauf pendant un quiz)
window.addEventListener("impara:remote-update", () => { if (!document.body.classList.contains("focus-mode")) route(); });
initPwa();
initCloud();
initSocial();
onSocial(renderSocialBadge);
subscribe(renderHeader);
renderHeader();
route();
