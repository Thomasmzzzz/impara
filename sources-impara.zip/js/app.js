/* =====================================================================
   app.js — Point d'entrée : routeur, en-tête et navigation
   ---------------------------------------------------------------------
   Routage par ancre (#parcours, #lecon-a1-numeri, #quiz-…, #examen-A1)
   → fonctionne sans serveur et reste partageable/bookmarkable.
   ===================================================================== */

import { state, subscribe } from "./core/storage.js";
import { streakCount, currentLevel } from "./core/progress.js";
import { lvlLabel } from "./data/curriculum.js";
import { $, $$, esc, speak, toast } from "./core/ui.js";
import { L, LANGS, code, flagSVG, setLang } from "./core/lang.js";
import { renderParcours } from "./views/parcours.js";
import { initCloud, onCloud, isConfigured } from "./core/cloud.js";
import { initSocial, onSocial, badgeCount } from "./core/social.js";
import { initPwa } from "./core/pwa.js";
import { initTheme } from "./core/theme.js";
import { maybeShowStreak } from "./views/streak.js";
import { frameClass, takeNewUnlocks } from "./core/cosmetics.js";
import { hydrateIcons } from "./core/icons.js";

const app = $("#app");

/* Pages chargées à la demande : seul le parcours fait partie du premier
   téléchargement ; le reste arrive au premier clic (puis en arrière-plan). */
let amisMod = null;
const V = {
  lecon: () => import("./views/lecon.js"),
  quiz: () => import("./views/quiz.js"),
  dash: () => import("./views/dashboard.js"),
  carnet: () => import("./views/carnet.js"),
  erreurs: () => import("./views/erreurs.js"),
  profil: () => import("./views/profil.js"),
  compte: () => import("./views/compte.js"),
  reglages: () => import("./views/reglages.js"),
  amis: () => import("./views/amis.js").then((m) => (amisMod = m)),
  entr: () => import("./views/entrainement.js"),
  hist: () => import("./views/histoires.js"),
  pron: () => import("./views/prononciation.js"),
  dict: () => import("./views/dictee.js"),
  seance: () => import("./views/seance.js"),
};
let nav = 0;                       // numéro de navigation : ignore un chargement devenu inutile
const STALE = Symbol("stale");
const lazy = (load, fn) => async (a, m) => { const n = nav; const mod = await load(); return n === nav ? fn(mod, a, m) : STALE; };

/** Table de routage : [motif, rendu, onglet actif] */
const ROUTES = [
  [/^parcours$/, (a) => renderParcours(a), "parcours"],
  [/^tableau$/, lazy(V.dash, (M, a) => M.renderDashboard(a)), "tableau"],
  [/^carnet$/, lazy(V.carnet, (M, a) => M.renderCarnet(a)), "entrainement"],
  [/^erreurs$/, lazy(V.erreurs, (M, a) => M.renderErreurs(a)), "entrainement"],
  [/^profil$/, lazy(V.profil, (M, a) => M.renderProfil(a)), "profil"],
  [/^compte$/, lazy(V.compte, (M, a) => M.renderCompte(a)), "reglages"],
  [/^reglages$/, lazy(V.reglages, (M, a) => M.renderReglages(a)), "reglages"],
  [/^reviser$/, lazy(V.carnet, (M, a) => { M.openReview(); return M.renderCarnet(a); }), "entrainement"],
  [/^entrainement$/, lazy(V.entr, (M, a) => M.renderEntrainement(a)), "entrainement"],
  [/^ecoute$/, lazy(V.entr, (M, a) => M.renderEcoute(a)), "entrainement"],
  [/^tons$/, lazy(V.entr, (M, a) => M.renderTons(a)), "entrainement"],
  [/^ordre$/, lazy(V.entr, (M, a) => M.renderOrdre(a)), "entrainement"],
  [/^repeter$/, lazy(V.pron, (M, a) => M.renderShadowing(a)), "entrainement"],
  [/^histoires$/, lazy(V.hist, (M, a) => M.renderHistoires(a)), "entrainement"],
  [/^histoire-(.+)$/, lazy(V.hist, (M, a, m) => M.renderHistoire(a, m[1])), "entrainement"],
  [/^prononciation$/, lazy(V.pron, (M, a) => M.renderPrononciation(a)), "entrainement"],
  [/^dictee$/, lazy(V.dict, (M, a) => M.renderDictee(a)), "entrainement"],
  [/^seance$/, lazy(V.seance, (M, a) => M.renderSeance(a)), "parcours"],
  [/^trace(?:-(.+))?$/, lazy(V.entr, (M, a, m) => M.renderTrace(a, m[1])), "entrainement"],
  [/^amis$/, lazy(V.amis, (M, a) => M.renderAmis(a)), "amis"],
  [/^amis-fil$/, lazy(V.amis, (M, a) => M.renderAmis(a, { tab: "fil" })), "amis"],
  [/^amis-defis$/, lazy(V.amis, (M, a) => M.renderAmis(a, { tab: "defis" })), "amis"],
  [/^ami-(.+)$/, lazy(V.amis, (M, a, m) => M.renderAmi(a, m[1])), "amis"],
  [/^chat-(.+)$/, lazy(V.amis, (M, a, m) => M.renderChat(a, m[1])), "amis"],
  [/^messages$/, lazy(V.amis, (M, a) => M.renderInbox(a)), "amis"],
  [/^defi-(.+)$/, lazy(V.amis, (M, a, m) => M.renderDefi(a, m[1])), "amis"],
  [/^revision$/, lazy(V.quiz, (M, a) => M.renderRevision(a)), "entrainement"],
  [/^personnaliser$/, lazy(V.profil, (M, a) => M.renderPersonnaliser(a)), "profil"],
  [/^ajout-(.+)$/, lazy(V.profil, (M, a, m) => M.renderProfil(a, { invite: decodeURIComponent(m[1]) })), "profil"],
  [/^profil-ajout$/, lazy(V.profil, (M, a) => M.renderProfil(a, { add: true })), "profil"],
  [/^lecon-(.+)$/, lazy(V.lecon, (M, a, m) => M.renderLecon(a, m[1])), "parcours"],
  [/^quiz-(.+)$/, lazy(V.quiz, (M, a, m) => M.renderQuiz(a, m[1])), "parcours"],
  [/^examen-(.+)$/, lazy(V.quiz, (M, a, m) => M.renderExamen(a, m[1])), "parcours"],
  [/^blanc-(.+)$/, lazy(V.quiz, (M, a, m) => M.renderBlanc(a, m[1])), "parcours"],
  [/^mipalier-(.+)$/, lazy(V.quiz, (M, a, m) => M.renderMiPalier(a, m[1])), "parcours"],
];

/** Petite roue d'attente si une page met du temps à arriver (réseau lent) */
function pending(p) {
  const t = setTimeout(() => { app.innerHTML = `<div class="page-loading" aria-label="Chargement"><span></span></div>`; }, 160);
  return p.finally(() => clearTimeout(t));
}
const offline = () => {
  app.innerHTML = `<section class="card empty-state"><p class="big-emoji">📶</p><h1 class="h3">Page indisponible hors connexion</h1>
    <p class="muted">Cette page n'a pas encore été téléchargée sur cet appareil. Reconnectez-vous à Internet puis réessayez.</p>
    <button class="btn primary" type="button" onclick="location.reload()">Réessayer</button></section>`;
};

async function route() {
  const n = ++nav;
  app._cleanup?.(); app._cleanup = null;           // nettoie un quiz en cours
  if (!location.hash.startsWith("#defi-")) amisMod?.leaveLive(); // quitte un duel en direct
  document.body.classList.remove("focus-mode", "chat-mode");

  const raw = decodeURIComponent(location.hash.slice(1));
  try {
    if (!state.profile && raw === "compte") {          // connexion possible avant l'accueil
      document.body.classList.add("onboarding");
      const M = await pending(V.compte()); if (n !== nav) return;
      M.renderCompte(app);
      return;
    }
    if (!state.profile) {                              // premier lancement
      document.body.classList.add("onboarding");
      const M = await pending(V.profil()); if (n !== nav) return;
      M.renderOnboarding(app, () => { document.body.classList.remove("onboarding"); location.hash = "parcours"; route(); });
      return;
    }
  } catch (err) { console.error(err); offline(); return; }
  document.body.classList.remove("onboarding");

  const hash = decodeURIComponent(location.hash.slice(1)) || "parcours";
  for (const [re, render, tab] of ROUTES) {
    const m = hash.match(re);
    if (!m) continue;
    setActiveTab(tab);
    let res;
    try {
      res = render(app, m);
      if (res instanceof Promise) res = await pending(res);
    } catch (err) {
      if (n !== nav) return;
      console.error(err); offline(); return;
    }
    if (res === STALE || n !== nav) return;
    if (res === false) {                             // contenu verrouillé ou introuvable
      toast("🔒 Cette étape n'est pas encore débloquée", "warn");
      location.hash = "parcours";
      return;
    }
    app.classList.remove("page-in"); void app.offsetWidth; app.classList.add("page-in"); // transition douce
    window.scrollTo({ top: 0 });
    app.focus({ preventScroll: true });
    return;
  }
  location.hash = "parcours";                        // route inconnue
}

function setActiveTab(tab) {
  $$("[data-tab]").forEach((a) => a.classList.toggle("active", a.dataset.tab === tab));
}

/** Met à jour les compteurs de l'en-tête (appelé à chaque sauvegarde) */
function renderHeader() {
  const p = state.profile;
  const streak = streakCount();
  $("#hdr-streak").textContent = streak;
  // Flamme grise tant qu'aucune activité aujourd'hui
  const d = new Date(), today = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const lit = state.streak.last === today;
  $("#hdr-streak-pill").classList.toggle("lit", lit);
  $("#hdr-streak-pill").title = lit ? `Série de ${streak} jour(s) : bravo, objectif du jour lancé !` : streak ? `Série de ${streak} jour(s) : faites un exercice aujourd'hui pour la prolonger` : "Faites un exercice pour démarrer une série";
  $("#hdr-xp").textContent = lvlLabel(currentLevel());
  $$(".hdr-avatar").forEach((el) => { el.textContent = p?.avatar || "👤"; el.style.setProperty("--me", p?.color || ""); el.className = `hdr-avatar ${frameClass(p?.frame)}`; });
  const n = Object.keys(state.errors).length;
  $$(".err-badge:not(.social-badge)").forEach((b) => { b.textContent = n > 99 ? "99+" : n; b.hidden = !n; });
  renderSocialBadge();
}

/** Pastille de l'onglet Amis : demandes, messages non lus, défis à jouer */
function renderSocialBadge() {
  $$("[data-tab=amis]").forEach((a) => (a.hidden = !isConfigured()));
  const n = badgeCount();
  $$(".social-badge").forEach((b) => { b.textContent = n > 9 ? "9+" : n; b.hidden = !n; });
}

/** Roue ⚙️ des réglages : un petit point signale l'état de la synchronisation */
const SYNC_LABELS = { off: "", guest: "Non connecté", syncing: "Synchronisation…", synced: "Synchronisé", offline: "Hors ligne", error: "Problème de synchronisation" };
function renderCloud(i) {
  const gear = $("#hdr-gear"), dot = gear.querySelector(".sync-dot");
  const label = isConfigured() ? SYNC_LABELS[i.status] || "" : "";
  gear.title = label ? `Réglages · ${label}${i.user ? " · " + i.user.email : ""}` : "Réglages";
  gear.setAttribute("aria-label", gear.title);
  dot.hidden = !isConfigured() || i.status === "synced" || i.status === "off";
  dot.className = `sync-dot dot-${i.status}`;
}

/* ---------------------- Sélecteur de langue ------------------------ */
function initLangSwitch() {
  const btn = $("#lang-btn"), menu = $("#lang-menu");
  $("#brand-flag").innerHTML = flagSVG(code);
  $("#brand-name").textContent = L.label;
  menu.innerHTML = `
    <p class="lang-menu-title">Je veux apprendre…</p>
    ${Object.values(LANGS).map((l) => `
      <button role="menuitemradio" aria-checked="${l.code === code}" class="lang-item ${l.code === code ? "on" : ""}" data-lang="${l.code}">
        <span class="flag">${flagSVG(l.code)}</span>
        <span class="lang-txt"><b>${esc(l.label)}</b><small>${esc(l.native)} · ${esc(l.brand)}</small></span>
        <span class="check">${l.code === code ? "✓" : ""}</span>
      </button>`).join("")}
    <p class="lang-menu-note">Chaque langue garde sa propre progression.</p>`;

  const open = (v) => { menu.hidden = !v; btn.setAttribute("aria-expanded", String(v)); if (v) menu.querySelector(".lang-item.on")?.focus(); };
  btn.onclick = (e) => { e.stopPropagation(); open(menu.hidden); };
  menu.onclick = (e) => {
    const item = e.target.closest("[data-lang]");
    if (!item) return;
    if (item.dataset.lang === code) return open(false);
    setLang(item.dataset.lang);
  };
  document.addEventListener("click", (e) => { if (!menu.hidden && !e.target.closest(".lang-switch")) open(false); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !menu.hidden) { open(false); btn.focus(); } });
}

/* -------------------- Délégation d'événements globale -------------- */
document.addEventListener("click", (e) => {
  const sp = e.target.closest("[data-speak]");
  if (sp) { e.preventDefault(); speak(sp.dataset.speak, { slow: "slow" in sp.dataset }); return; }

  const sc = e.target.closest("[data-scroll]");
  if (sc) { e.preventDefault(); document.getElementById(sc.dataset.scroll)?.scrollIntoView({ behavior: "smooth", block: "start" }); return; }

  const link = e.target.closest("a[href^='#']");
  if (link?.getAttribute("aria-disabled") === "true") { e.preventDefault(); toast("🔒 Terminez les étapes précédentes pour débloquer celle-ci", "warn"); return; }
  // Lien vers la page courante (ex. « Réessayer ») : on force le rendu
  if (link && link.getAttribute("href") === location.hash) { e.preventDefault(); route(); }
});

window.addEventListener("hashchange", route);
initLangSwitch();
onCloud((i) => {
  renderCloud(i);
  // Rafraîchit la page « Compte » si elle est affichée
  if (location.hash === "#compte" && !document.querySelector(".auth-form")) V.compte().then((M) => location.hash === "#compte" && M.renderCompte(app)).catch(() => {});
  // Pages sociales ouvertes avant la fin de la connexion (lien, notification) : on les réaffiche
  if (/^#(amis|ami-|chat-|defi-|ajout-|profil)/.test(location.hash) && i.user && !document.body.classList.contains("focus-mode") && !document.body.classList.contains("chat-mode")
      && !document.querySelector(".s-page, .auth-form, .s-defi-intro, .s-defi-res, .pf, .fp") ) route();
  else if (location.hash === "#profil" && !document.querySelector(".modal") && !document.body.classList.contains("focus-mode")) route();
});
// Progression récupérée depuis un autre appareil : on réaffiche (sauf pendant un quiz)
window.addEventListener("impara:remote-update", () => { if (!document.body.classList.contains("focus-mode")) route(); });
hydrateIcons();
// Hauteur de l'en-tête (pour les barres collantes sous l'en-tête)
const setHdr = () => document.documentElement.style.setProperty("--hdr-h", `${document.querySelector(".topbar")?.offsetHeight || 60}px`);
setHdr(); addEventListener("resize", setHdr);
initTheme();
initPwa();
initCloud();
initSocial();
onSocial(renderSocialBadge);
subscribe(renderHeader);
// Écran de série : dès qu'on sort d'un quiz / d'une conversation (vérifié régulièrement)
subscribe(() => setTimeout(maybeShowStreak, 900));

/* Cadres et bannières : annonce des nouveautés débloquées */
let unlockTimer = null;
const checkUnlocks = () => {
  clearTimeout(unlockTimer);
  unlockTimer = setTimeout(() => {
    if (!state.profile) return;
    takeNewUnlocks().slice(0, 3).forEach((x, i) => setTimeout(() =>
      toast(`🎁 Nouveau ${x.kind === "cadre" ? "cadre" : "fond de bannière"} débloqué : ${x.name} ! Touchez pour l'essayer`, "ok", { href: "personnaliser", ms: 4500 }), 600 + i * 1800));
  }, 1500);
};
subscribe(checkUnlocks);
setInterval(maybeShowStreak, 1500);
renderHeader();
route();
// Une fois l'appli affichée, on télécharge discrètement les autres pages
// (navigation instantanée ensuite, et disponibles hors connexion).
const prefetch = () => Object.values(V).forEach((load, i) => setTimeout(() => load().catch(() => {}), i * 120));
setTimeout(() => ("requestIdleCallback" in window ? requestIdleCallback(prefetch, { timeout: 4000 }) : prefetch()), 2500);
// Écran de lancement : visible au moins ~0,7 s, puis fondu
(() => {
  const sp = document.getElementById("splash");
  if (!sp) return;
  setTimeout(() => { sp.classList.add("out"); setTimeout(() => sp.remove(), 500); }, Math.max(150, 700 - performance.now()));
})();
