/* =====================================================================
   XUÉXÍ 学习 — Contenu pédagogique du mandarin (HSK 1 → HSK 6)
   Les id internes (A1…C2) sont conservés pour ne pas perdre les
   progressions enregistrées ; seul le libellé affiché (label) change.
   ---------------------------------------------------------------------
   Ce fichier ne contient QUE des données.
   - Exemples et vocabulaire : triplets [caractères, pinyin, français].
   - Associations (match) : un côté peut s'écrire "汉字|pinyin" pour
     afficher le pinyin sous les caractères.
   - Réponses libres (fill / translate) : listez les caractères ET le
     pinyin acceptés. Le moteur ignore espaces, ponctuation et casse,
     et accepte le pinyin sans tons avec un avertissement.

   Types de questions :
   - mcq       : QCM            { q, options[], answer:index, explain }
   - fill      : texte à trous  { q (avec ___), answer:[acceptées], explain }
   - match     : association    { q, pairs:[[gauche, droite], ...], explain }
   - translate : traduction     { q, answer:[acceptées], explain }
   Repères HSK indicatifs : les équivalences CECRL ↔ HSK sont approximatives.
   ===================================================================== */

import { HSK1_PLUS, HSK1_EXAM_PLUS } from "./zh-hsk1-plus.js";
import { HSK2_PLUS, HSK2_EXAM_PLUS } from "./zh-hsk2-plus.js";

const mcq = (q, options, answer, explain = "") => ({ type: "mcq", q, options, answer, explain });
const fill = (q, answer, explain = "") => ({ type: "fill", q, answer, explain });
const match = (q, pairs, explain = "") => ({ type: "match", q, pairs, explain });
const tr = (q, answer, explain = "") => ({ type: "translate", q, answer, explain });

export const MODULES = {
  bases: { label: "Bases", icon: "🔤" },
  hanzi: { label: "Caractères", icon: "🖌️" },
  vocab: { label: "Vocabulaire", icon: "📚" },
  gram: { label: "Grammaire", icon: "🧩" },
  temps: { label: "Aspects & temps", icon: "⏳" },
  nombres: { label: "Nombres", icon: "🔢" },
  expr: { label: "Expressions", icon: "💬" },
};

export const LEVELS = [
  /* ================================================================ A1 */
  {
    id: "A1", label: "HSK 1", name: "Débutant", hsk: "HSK 1", title: "Les premiers pas", emoji: "🌱", color: "#2a8a66",
    desc: "Pinyin et tons, salutations, chiffres, premières phrases et caractères.",
    lessons: [
      {
        id: "a1-pinyin", module: "bases", title: "Le pinyin et les quatre tons", emoji: "🎵",
        intro: "Le pinyin est l'alphabet latin qui note la prononciation. Chaque syllabe porte un ton : changer de ton, c'est changer de mot.",
        sections: [
          {
            title: "Les quatre tons (+ le ton neutre)",
            text: "1er ton <b>ā</b> : haut et plat · 2e ton <b>á</b> : montant (comme une question) · 3e ton <b>ǎ</b> : descend puis remonte · 4e ton <b>à</b> : descendant sec (comme un ordre) · ton neutre <b>a</b> : léger, sans accent.",
            examples: [["妈", "mā", "maman"], ["麻", "má", "chanvre"], ["马", "mǎ", "cheval"], ["骂", "mà", "gronder"], ["吗", "ma", "particule de question"]],
          },
          {
            title: "Les sons pièges pour un francophone",
            text: "<b>zh, ch, sh, r</b> : langue recourbée vers le palais · <b>j, q, x</b> : langue plate contre les dents (« dj », « tch », « s » chuinté) · <b>c</b> = « ts » · <b>h</b> = « r » raclé léger · <b>ü</b> = « u » français, alors que <b>u</b> = « ou ».",
            examples: [["是", "shì", "être — « shr »"], ["去", "qù", "aller — « tchu »"], ["谢谢", "xièxie", "merci — « sié-sié »"], ["菜", "cài", "plat — « tsaï »"], ["女", "nǚ", "femme — « nu »"]],
          },
          {
            title: "Le changement de ton (3 + 3)",
            text: "Deux 3e tons qui se suivent : le premier devient un <b>2e ton</b>. On écrit <i>nǐ hǎo</i>, on prononce « ní hǎo ». De même, <b>不 bù</b> devient <b>bú</b> devant un 4e ton, et <b>一 yī</b> change selon le ton suivant.",
            examples: [["你好", "nǐ hǎo", "bonjour (prononcé ní hǎo)"], ["不是", "bú shì", "ne pas être"], ["一个", "yí gè", "un (+ classificateur)"]],
          },
        ],
        mnemo: "Dessinez les tons avec la main en parlant : ā une ligne plate ➡, á une flèche qui monte ↗, ǎ un creux ✓, à une flèche qui tombe ↘. Le geste ancre la mélodie.",
        vocab: [["妈妈", "māma", "maman"], ["马", "mǎ", "cheval"], ["你好", "nǐ hǎo", "bonjour"], ["谢谢", "xièxie", "merci"], ["是", "shì", "être"], ["不", "bù", "ne… pas"], ["吗", "ma", "particule de question"]],
        quiz: [
          mcq("Quel ton monte, comme une question ?", ["1er ton (ā)", "2e ton (á)", "3e ton (ǎ)", "4e ton (à)"], 1, "Le 2e ton est montant."),
          mcq("« mǎ » (3e ton) signifie :", ["maman", "chanvre", "cheval", "gronder"], 2, "马 mǎ = cheval. Mā = maman, má = chanvre, mà = gronder."),
          mcq("Comment se prononce réellement 你好 nǐ hǎo ?", ["« nǐ hǎo » tel quel", "« ní hǎo »", "« nì hào »", "« nī hāo »"], 1, "Deux 3e tons de suite : le premier devient un 2e ton."),
          match("Associez le pinyin et le son", [["x", "« s » chuinté (langue plate)"], ["c", "« ts »"], ["u", "« ou »"], ["ü", "« u » français"]]),
          tr("Écrivez « merci » en pinyin ou en caractères", ["谢谢", "xièxie", "xièxiè"], "谢谢 xièxie (la 2e syllabe est au ton neutre)."),
        ],
      },
      {
        id: "a1-salutations", module: "expr", title: "Saluer et se présenter", emoji: "👋",
        intro: "Les premières phrases de toute rencontre : dire bonjour, remercier, s'excuser et dire son nom.",
        sections: [
          {
            title: "Bonjour, merci, pardon",
            text: "<b>您 nín</b> est le « vous » de politesse (personnes âgées, clients, supérieurs).",
            examples: [["你好！", "nǐ hǎo!", "Bonjour !"], ["您好！", "nín hǎo!", "Bonjour ! (poli)"], ["谢谢！— 不客气。", "xièxie! — bú kèqi.", "Merci ! — De rien."], ["对不起。— 没关系。", "duìbuqǐ. — méi guānxi.", "Pardon. — Ce n'est rien."], ["再见！", "zàijiàn!", "Au revoir !"]],
          },
          {
            title: "Se présenter",
            examples: [["你叫什么名字？", "nǐ jiào shénme míngzi?", "Comment t'appelles-tu ?"], ["我叫马丁。", "wǒ jiào Mǎdīng.", "Je m'appelle Martin."], ["很高兴认识你。", "hěn gāoxìng rènshi nǐ.", "Ravi(e) de te connaître."], ["我是法国人。", "wǒ shì Fǎguórén.", "Je suis français(e)."]],
          },
          {
            title: "Selon le moment",
            text: "<b>早上好</b> le matin, <b>晚上好</b> le soir. Entre amis, on demande souvent <b>你吃了吗？</b> (« Tu as mangé ? ») : c'est une simple salutation, pas une invitation !",
            examples: [["早上好！", "zǎoshang hǎo!", "Bonjour ! (le matin)"], ["晚上好！", "wǎnshang hǎo!", "Bonsoir !"], ["你吃了吗？", "nǐ chī le ma?", "Tu as mangé ? (= salut, ça va ?)"]],
          },
        ],
        mnemo: "您 = 你 + 心 (le cœur) : on met du cœur, donc du respect, dans le « vous ».",
        vocab: [["你好", "nǐ hǎo", "bonjour"], ["您", "nín", "vous (poli)"], ["不客气", "bú kèqi", "de rien"], ["对不起", "duìbuqǐ", "pardon"], ["没关系", "méi guānxi", "ce n'est rien"], ["再见", "zàijiàn", "au revoir"], ["名字", "míngzi", "nom, prénom"], ["法国人", "Fǎguórén", "Français(e)"]],
        quiz: [
          mcq("Quelqu'un vous dit 谢谢. Vous répondez :", ["再见", "不客气", "对不起", "你好"], 1, "不客气 bú kèqi = de rien."),
          fill("你叫什么名字？— 我 ___ 马丁。", ["叫", "jiào", "jiao"], "我叫… = je m'appelle…"),
          mcq("Pour saluer poliment le directeur de l'entreprise :", ["你好", "您好", "早上", "你吃了吗"], 1, "您 nín est la forme respectueuse."),
          match("Associez", [["对不起|duìbuqǐ", "pardon"], ["没关系|méi guānxi", "ce n'est rien"], ["再见|zàijiàn", "au revoir"], ["晚上好|wǎnshang hǎo", "bonsoir"]]),
          tr("Traduisez : Je suis français.", ["我是法国人", "wǒ shì fǎguórén", "wo shi faguoren"], "我是法国人 wǒ shì Fǎguórén. 人 = personne : 法国 (France) + 人."),
        ],
      },
      {
        id: "a1-nombres", module: "nombres", title: "Les chiffres et les nombres", emoji: "🔢",
        intro: "Le système chinois est parfaitement logique : avec 11 mots, vous comptez jusqu'à 99.",
        sections: [
          {
            title: "De 0 à 10",
            table: { cols: ["", "", "", ""], rows: [["0 零 líng", "1 一 yī", "2 二 èr", "3 三 sān"], ["4 四 sì", "5 五 wǔ", "6 六 liù", "7 七 qī"], ["8 八 bā", "9 九 jiǔ", "10 十 shí", ""]] },
          },
          {
            title: "Construire les nombres",
            text: "On assemble comme des briques : <b>十一</b> = 10 + 1 = 11, <b>二十</b> = 2 × 10 = 20, <b>二十一</b> = 2 × 10 + 1 = 21. Puis <b>百 bǎi</b> (100), <b>千 qiān</b> (1 000) et <b>万 wàn</b> (10 000 !).",
            examples: [["十五", "shíwǔ", "15"], ["三十八", "sānshíbā", "38"], ["九十九", "jiǔshíjiǔ", "99"], ["一百", "yìbǎi", "100"], ["一万", "yíwàn", "10 000"]],
          },
          {
            title: "二 ou 两 ? Et demander un nombre",
            text: "Pour compter des choses (devant un classificateur), « deux » se dit <b>两 liǎng</b>, pas 二. Pour demander : <b>几 jǐ</b> (petit nombre, < 10) ou <b>多少 duōshao</b> (quantité quelconque).",
            examples: [["两个人", "liǎng gè rén", "deux personnes"], ["你几岁？", "nǐ jǐ suì?", "Tu as quel âge ? (enfant)"], ["多少钱？", "duōshao qián?", "Combien ça coûte ?"]],
          },
        ],
        mnemo: "Les chiffres 一, 二, 三 se dessinent avec 1, 2 et 3 traits. Et 十 (10) est une croix : comme le X romain !",
        vocab: [["一", "yī", "un"], ["二", "èr", "deux"], ["两", "liǎng", "deux (pour compter)"], ["十", "shí", "dix"], ["百", "bǎi", "cent"], ["万", "wàn", "dix mille"], ["多少钱", "duōshao qián", "combien ça coûte ?"]],
        quiz: [
          mcq("Comment dit-on 15 ?", ["五十", "十五", "一五", "五一"], 1, "十五 = 10 + 5. 五十 = 5 × 10 = 50."),
          fill("2 × 10 + 1 = ___ (en caractères)", ["二十一", "èrshíyī", "ershiyi"], "二十一 : deux-dix-un."),
          mcq("« Deux personnes » se dit :", ["二个人", "两个人", "二人个", "两人个"], 1, "Devant un classificateur, on utilise 两 liǎng."),
          match("Associez", [["四十|sìshí", "40"], ["十四|shísì", "14"], ["一百|yìbǎi", "100"], ["一万|yíwàn", "10 000"]]),
          tr("Demandez « Combien ça coûte ? »", ["多少钱", "duōshao qián", "duoshao qian"], "多少钱？duōshao qián? (钱 = argent)."),
        ],
      },
      {
        id: "a1-phrases", module: "gram", title: "Premières phrases : 是, 不 et 吗", emoji: "🧩",
        intro: "La grammaire chinoise n'a ni conjugaison, ni genre, ni pluriel : l'ordre des mots fait tout le travail.",
        sections: [
          {
            title: "Les pronoms",
            table: { cols: ["Singulier", "Pluriel (+ 们 men)"], rows: [["我 wǒ — je", "我们 wǒmen — nous"], ["你 nǐ — tu", "你们 nǐmen — vous"], ["他 / 她 tā — il / elle", "他们 tāmen — ils / elles"]] },
          },
          {
            title: "Sujet + 是 + nom",
            text: "<b>是 shì</b> relie deux noms. Il ne change jamais. La négation se place devant : <b>不是 bú shì</b>.",
            examples: [["我是学生。", "wǒ shì xuésheng.", "Je suis étudiant."], ["她不是老师。", "tā bú shì lǎoshī.", "Elle n'est pas professeure."]],
          },
          {
            title: "Poser une question avec 吗",
            text: "Ajoutez <b>吗 ma</b> à la fin d'une affirmation : elle devient une question fermée. On répond en reprenant le verbe (pas de « oui » universel).",
            examples: [["你是中国人吗？", "nǐ shì Zhōngguórén ma?", "Es-tu chinois(e) ?"], ["是。/ 不是。", "shì. / bú shì.", "Oui. / Non."]],
          },
        ],
        mnemo: "Le chinois, c'est du LEGO : les mots ne changent jamais de forme, on se contente de les déplacer ou d'en ajouter (们 pour le pluriel, 吗 pour la question, 不 pour la négation).",
        vocab: [["我", "wǒ", "je, moi"], ["你", "nǐ", "tu, toi"], ["他 / 她", "tā", "il / elle"], ["我们", "wǒmen", "nous"], ["学生", "xuésheng", "étudiant"], ["老师", "lǎoshī", "professeur"], ["中国人", "Zhōngguórén", "Chinois(e)"]],
        quiz: [
          fill("我 ___ 学生。(être)", ["是", "shì", "shi"], "是 shì, invariable."),
          mcq("Transformez en question : 你是老师。", ["吗你是老师？", "你是老师吗？", "你吗是老师？", "你是吗老师？"], 1, "吗 se place à la fin de la phrase."),
          mcq("« Ils » se dit :", ["他", "他们", "我们", "你们"], 1, "他 + 们 (pluriel) = 他们."),
          fill("她 ___ 是中国人，她是法国人。(négation)", ["不", "bù", "bú", "bu"], "不 se place devant le verbe."),
          tr("Traduisez : Es-tu étudiant ?", ["你是学生吗", "nǐ shì xuésheng ma", "ni shi xuesheng ma"], "你是学生吗？"),
        ],
      },
      {
        id: "a1-caracteres", module: "hanzi", title: "Les caractères et leurs clés", emoji: "🖌️",
        intro: "Les caractères ne sont pas des dessins aléatoires : ils se construisent avec des éléments récurrents, les clés.",
        sections: [
          {
            title: "Des pictogrammes à l'origine",
            text: "Les caractères les plus anciens représentaient des objets.",
            examples: [["人", "rén", "personne (deux jambes)"], ["口", "kǒu", "bouche"], ["日", "rì", "soleil, jour"], ["月", "yuè", "lune, mois"], ["山", "shān", "montagne (trois sommets)"], ["木", "mù", "arbre"]],
          },
          {
            title: "Combiner pour créer du sens",
            examples: [["好", "hǎo", "bien = 女 femme + 子 enfant"], ["明", "míng", "clair = 日 soleil + 月 lune"], ["林", "lín", "bosquet = 2 arbres"], ["森", "sēn", "forêt = 3 arbres"]],
          },
          {
            title: "Les clés indiquent le thème",
            text: "<b>氵</b> (eau) → 河 rivière, 海 mer · <b>口</b> (bouche) → 吃 manger, 喝 boire · <b>讠</b> (parole) → 说 parler, 语 langue · <b>亻</b> (personne) → 你 tu, 他 il.",
            examples: [["海", "hǎi", "mer (clé de l'eau)"], ["喝", "hē", "boire (clé de la bouche)"], ["说", "shuō", "parler (clé de la parole)"]],
          },
        ],
        mnemo: "Un arbre 木, un bosquet 林, une forêt 森 : plus il y a d'arbres, plus le bois est grand. Les clés racontent des histoires, inventez-en pour chaque caractère.",
        vocab: [["人", "rén", "personne"], ["口", "kǒu", "bouche"], ["日", "rì", "soleil, jour"], ["月", "yuè", "lune, mois"], ["好", "hǎo", "bien, bon"], ["明", "míng", "clair, lumineux"], ["水", "shuǐ", "eau"]],
        quiz: [
          mcq("好 (bien) est composé de :", ["日 + 月", "女 + 子", "木 + 木", "口 + 人"], 1, "Une femme et un enfant : l'image du bonheur."),
          mcq("Quel caractère signifie « forêt » ?", ["木", "林", "森", "本"], 2, "Trois arbres : 森 sēn."),
          match("Associez", [["人|rén", "personne"], ["口|kǒu", "bouche"], ["山|shān", "montagne"], ["月|yuè", "lune"]]),
          mcq("La clé 氵 sur 河 et 海 évoque :", ["le feu", "l'eau", "la parole", "la main"], 1, "氵 est la forme réduite de 水 (eau)."),
          tr("Écrivez « bien / bon » (pinyin ou caractère)", ["好", "hǎo", "hao"], "好 hǎo, comme dans 你好."),
        ],
      },
    ],
    exam: [
      mcq("Quel est le 4e ton ?", ["mā", "má", "mǎ", "mà"], 3, "Le 4e ton est descendant : mà."),
      fill("对不起！— ___ 。(Ce n'est rien.)", ["没关系", "méi guānxi", "mei guanxi"], "没关系 méi guānxi."),
      mcq("38 se dit :", ["八十三", "三八十", "三十八", "三百八"], 2, "3 × 10 + 8 = 三十八."),
      tr("Traduisez : Au revoir", ["再见", "zàijiàn", "zaijian"], "再见 zàijiàn."),
      mcq("Comment rendre 他是老师 interrogatif ?", ["他是老师吗？", "吗他是老师？", "他吗是老师？", "他是吗老师？"], 0, "吗 en fin de phrase."),
      fill("我有 ___ 个朋友。(deux)", ["两", "liǎng", "liang"], "Devant un classificateur : 两."),
      match("Associez", [["你好|nǐ hǎo", "bonjour"], ["谢谢|xièxie", "merci"], ["不客气|bú kèqi", "de rien"], ["再见|zàijiàn", "au revoir"]]),
      mcq("明 (clair) réunit :", ["日 + 月", "女 + 子", "口 + 木", "人 + 人"], 0, "Le soleil et la lune."),
    ],
  },

  /* ================================================================ A2 */
  {
    id: "A2", label: "HSK 2", name: "Élémentaire", hsk: "HSK 2", title: "La vie quotidienne", emoji: "🥟", color: "#2f7d8c",
    desc: "Classificateurs, aspects 了 et 过, l'heure et la date, 的 et 有.",
    lessons: [
      {
        id: "a2-classificateurs", module: "gram", title: "Les classificateurs", emoji: "🧩",
        intro: "En chinois, on ne dit pas « trois livres » mais « trois volumes de livre ». Ce mot intermédiaire est le classificateur.",
        sections: [
          {
            title: "Nombre (ou 这/那) + classificateur + nom",
            text: "Le classificateur est obligatoire entre un nombre (ou <b>这 zhè</b> « ce », <b>那 nà</b> « ce…là ») et le nom.",
            examples: [["三本书", "sān běn shū", "trois livres"], ["这个人", "zhè ge rén", "cette personne"], ["那杯咖啡", "nà bēi kāfēi", "ce café-là"]],
          },
          {
            title: "Les classificateurs essentiels",
            table: { cols: ["Classificateur", "Pour…", "Exemple"], rows: [["个 gè", "tout usage, personnes", "一个苹果 une pomme"], ["本 běn", "livres, cahiers", "两本书 deux livres"], ["只 zhī", "animaux", "一只猫 un chat"], ["杯 bēi", "verres, tasses", "一杯茶 un thé"], ["张 zhāng", "objets plats", "一张纸 une feuille"], ["件 jiàn", "vêtements, affaires", "一件衣服 un vêtement"], ["位 wèi", "personnes (poli)", "一位老师 un professeur"]] },
          },
          {
            title: "En cas de doute : 个",
            text: "<b>个</b> est le classificateur universel. Il ne sonne pas toujours naturel, mais il est toujours compris.",
          },
        ],
        mnemo: "Le classificateur décrit la forme : 张 (étirer) pour ce qui est plat, 本 (racine/tronc) pour le livre relié, 只 pour les petites bêtes. Visualisez la forme de l'objet.",
        vocab: [["个", "gè", "classificateur général"], ["本", "běn", "cl. des livres"], ["只", "zhī", "cl. des animaux"], ["杯", "bēi", "tasse, verre"], ["书", "shū", "livre"], ["猫", "māo", "chat"], ["这 / 那", "zhè / nà", "ce…ci / ce…là"]],
        quiz: [
          mcq("Trois livres : 三 ___ 书", ["只", "本", "张", "杯"], 1, "本 pour les livres."),
          mcq("Un chat : 一 ___ 猫", ["只", "本", "件", "位"], 0, "只 pour les animaux."),
          fill("我要一 ___ 咖啡。(une tasse de)", ["杯", "bēi", "bei"], "一杯咖啡 : une tasse de café."),
          match("Associez", [["张|zhāng", "objets plats"], ["件|jiàn", "vêtements"], ["位|wèi", "personnes (poli)"], ["个|gè", "usage général"]]),
          tr("Traduisez : cette personne", ["这个人", "zhè ge rén", "zhe ge ren", "这位", "zhè wèi"], "这个人 (ou poliment 这位)."),
        ],
      },
      {
        id: "a2-le-guo", module: "temps", title: "L'action accomplie : 了 et 过", emoji: "⏳",
        intro: "Le verbe chinois ne se conjugue pas. Pour parler du passé, on utilise des particules d'aspect.",
        sections: [
          {
            title: "了 le : l'action est accomplie",
            examples: [["我吃了饭。", "wǒ chī le fàn.", "J'ai mangé."], ["他买了三本书。", "tā mǎi le sān běn shū.", "Il a acheté trois livres."], ["下雨了。", "xià yǔ le.", "Il s'est mis à pleuvoir (changement)."]],
          },
          {
            title: "La négation : 没 sans 了",
            text: "Pour dire qu'une action n'a pas eu lieu : <b>没 méi</b> + verbe, et <b>le 了 disparaît</b>.",
            examples: [["我没吃饭。", "wǒ méi chī fàn.", "Je n'ai pas mangé."], ["你吃饭了吗？— 还没。", "nǐ chī fàn le ma? — hái méi.", "Tu as mangé ? — Pas encore."]],
          },
          {
            title: "过 guo : l'expérience vécue",
            text: "<b>过</b> indique qu'on a déjà fait quelque chose au moins une fois dans sa vie.",
            examples: [["我去过中国。", "wǒ qù guo Zhōngguó.", "Je suis déjà allé en Chine."], ["你吃过北京烤鸭吗？", "nǐ chī guo Běijīng kǎoyā ma?", "As-tu déjà goûté le canard laqué ?"], ["我没去过。", "wǒ méi qù guo.", "Je n'y suis jamais allé."]],
          },
        ],
        mnemo: "了 = « c'est fait ✓ ». 过 = « déjà vécu 🧳 » (on garde 过 avec 没 : 没去过). Avec 没, seul 了 disparaît.",
        vocab: [["了", "le", "particule d'action accomplie"], ["过", "guo", "particule d'expérience"], ["没", "méi", "ne… pas (passé)"], ["还没", "hái méi", "pas encore"], ["吃饭", "chī fàn", "manger (un repas)"], ["买", "mǎi", "acheter"], ["去", "qù", "aller"]],
        quiz: [
          mcq("« Je n'ai pas mangé » se dit :", ["我不吃了饭。", "我没吃饭。", "我没吃了饭。", "我不吃饭了。"], 1, "Négation du passé : 没 + verbe, sans 了."),
          fill("我去 ___ 中国。(déjà allé = expérience)", ["过", "guo", "guò"], "过 marque l'expérience vécue."),
          mcq("你吃饭了吗？Réponse « pas encore » :", ["还没。", "不吃。", "没有了。", "不了。"], 0, "还没 hái méi = pas encore."),
          fill("他买 ___ 一本书。(il a acheté)", ["了", "le"], "了 après le verbe = action accomplie."),
          tr("Traduisez : Je ne suis jamais allé en Chine.", ["我没去过中国", "wǒ méi qù guo zhōngguó", "wo mei qu guo zhongguo"], "我没去过中国 (过 reste avec 没)."),
        ],
      },
      {
        id: "a2-heure", module: "nombres", title: "L'heure, les jours et les dates", emoji: "🕒",
        intro: "Les nombres appliqués au temps : en chinois, tout est numéroté, même les jours de la semaine.",
        sections: [
          {
            title: "现在几点？Quelle heure est-il ?",
            text: "<b>点 diǎn</b> = heure, <b>分 fēn</b> = minute, <b>半 bàn</b> = demie, <b>一刻 yí kè</b> = un quart. Attention : 2 h se dit <b>两点</b>.",
            examples: [["三点。", "sān diǎn.", "3 h."], ["两点半。", "liǎng diǎn bàn.", "2 h 30."], ["八点一刻。", "bā diǎn yí kè.", "8 h 15."], ["十点二十分。", "shí diǎn èrshí fēn.", "10 h 20."]],
          },
          {
            title: "Les jours : 星期 + numéro",
            text: "Lundi = <b>星期一</b> (semaine-1), mardi = 星期二… samedi = 星期六. Seul dimanche fait exception : <b>星期天</b> (ou 星期日).",
            examples: [["今天星期五。", "jīntiān xīngqīwǔ.", "Aujourd'hui, c'est vendredi."], ["明天", "míngtiān", "demain"], ["昨天", "zuótiān", "hier"]],
          },
          {
            title: "Les dates : du plus grand au plus petit",
            text: "Année <b>年</b> → mois <b>月</b> → jour <b>号</b> (ou 日 à l'écrit). Les mois sont simplement numérotés : 一月 (janvier) à 十二月 (décembre). L'année se lit chiffre par chiffre.",
            examples: [["二〇二六年十一月一号", "èr líng èr liù nián shíyī yuè yī hào", "1er novembre 2026"]],
          },
        ],
        mnemo: "Du plus grand au plus petit, toujours : année → mois → jour → heure. Comme une adresse chinoise : pays → ville → rue → numéro.",
        vocab: [["现在", "xiànzài", "maintenant"], ["几点", "jǐ diǎn", "quelle heure"], ["半", "bàn", "demi"], ["星期", "xīngqī", "semaine"], ["今天", "jīntiān", "aujourd'hui"], ["明天", "míngtiān", "demain"], ["昨天", "zuótiān", "hier"]],
        quiz: [
          mcq("Il est 2 h. On dit :", ["二点", "两点", "二时", "两个点"], 1, "Pour l'heure, 2 se dit 两 : 两点."),
          mcq("星期三 signifie :", ["lundi", "mardi", "mercredi", "jeudi"], 2, "Semaine-3 = mercredi (le 3e jour)."),
          match("Associez", [["今天|jīntiān", "aujourd'hui"], ["明天|míngtiān", "demain"], ["昨天|zuótiān", "hier"], ["星期天|xīngqītiān", "dimanche"]]),
          fill("现在三点 ___ 。(et demie)", ["半", "bàn", "ban"], "三点半 = 3 h 30."),
          mcq("Comment écrire « 5 mars » ?", ["五号三月", "三月五号", "五三月号", "号五三月"], 1, "Du plus grand au plus petit : mois puis jour."),
        ],
      },
      {
        id: "a2-de-you", module: "gram", title: "La possession : 的, 很 et 有", emoji: "🧩",
        intro: "Dire « mon livre », « elle est belle » et « j'ai un frère » : trois structures ultra-fréquentes.",
        sections: [
          {
            title: "的 de : la possession et la qualification",
            text: "<b>A 的 B</b> = le B de A. Avec la famille proche, on omet souvent 的.",
            examples: [["我的书", "wǒ de shū", "mon livre"], ["老师的电话", "lǎoshī de diànhuà", "le téléphone du professeur"], ["我妈妈", "wǒ māma", "ma mère (的 omis)"]],
          },
          {
            title: "Adjectif : pas de 是, mais 很",
            text: "Devant un adjectif, on n'utilise <b>pas 是</b>. On ajoute 很 hěn (« très », souvent affaibli).",
            examples: [["她很漂亮。", "tā hěn piàoliang.", "Elle est belle."], ["中文很有意思。", "Zhōngwén hěn yǒu yìsi.", "Le chinois est intéressant."]],
          },
          {
            title: "有 yǒu : avoir, il y a — et sa négation 没有",
            text: "La négation de 有 est toujours <b>没有</b>, jamais 不有.",
            examples: [["我有一个哥哥。", "wǒ yǒu yí ge gēge.", "J'ai un grand frère."], ["我没有钱。", "wǒ méiyǒu qián.", "Je n'ai pas d'argent."], ["这儿有一家咖啡馆。", "zhèr yǒu yì jiā kāfēiguǎn.", "Il y a un café ici."]],
          },
        ],
        mnemo: "« Elle est belle » ≠ « elle EST belle » : en chinois, l'adjectif est déjà un verbe (« elle belle »). 很 sert juste de coussin rythmique.",
        vocab: [["的", "de", "particule de possession"], ["很", "hěn", "très"], ["有", "yǒu", "avoir, il y a"], ["没有", "méiyǒu", "ne pas avoir"], ["漂亮", "piàoliang", "beau, belle"], ["哥哥", "gēge", "grand frère"], ["电话", "diànhuà", "téléphone"]],
        quiz: [
          mcq("« Elle est belle » :", ["她是漂亮。", "她很漂亮。", "她是很漂亮。", "她有漂亮。"], 1, "Pas de 是 devant un adjectif : 她很漂亮."),
          fill("这是我 ___ 书。(mon livre)", ["的", "de"], "我的书 = mon livre."),
          mcq("« Je n'ai pas de voiture » :", ["我不有车。", "我没有车。", "我没车有。", "我不是车。"], 1, "La négation de 有 est 没有."),
          fill("我 ___ 一个哥哥。(avoir)", ["有", "yǒu", "you"], "有 = avoir."),
          tr("Traduisez : le téléphone du professeur", ["老师的电话", "lǎoshī de diànhuà", "laoshi de dianhua"], "A 的 B : 老师的电话."),
        ],
      },
    ],
    exam: [
      mcq("Deux chats : 两 ___ 猫", ["本", "只", "张", "杯"], 1, "只 pour les animaux."),
      mcq("« Il n'est pas venu » :", ["他不来了。", "他没来。", "他没来了。", "他不有来。"], 1, "没 + verbe, sans 了."),
      fill("你吃 ___ 北京烤鸭吗？(déjà goûté)", ["过", "guo"], "过 = expérience."),
      mcq("10 h 15 :", ["十点一刻", "十点半", "十一点", "十五点十"], 0, "一刻 = un quart."),
      fill("我 ___ 有钱。(négation de 有)", ["没", "méi", "mei"], "没有."),
      match("Associez", [["星期一|xīngqīyī", "lundi"], ["星期五|xīngqīwǔ", "vendredi"], ["一月|yīyuè", "janvier"], ["十二月|shí'èryuè", "décembre"]]),
      mcq("« Le chinois est intéressant » :", ["中文是有意思。", "中文很有意思。", "中文有很意思。", "中文的有意思。"], 1, "很 + adjectif."),
      tr("Traduisez : cette tasse de thé", ["这杯茶", "zhè bēi chá", "zhe bei cha"], "这 + 杯 + 茶."),
    ],
  },

  /* ================================================================ B1 */
  {
    id: "B1", label: "HSK 3", name: "Seuil", hsk: "HSK 3", title: "Comparer et agir", emoji: "🏮", color: "#d39b2a",
    desc: "Comparaison, structure 把, compléments de résultat, expressions du quotidien.",
    lessons: [
      {
        id: "b1-comparaison", module: "gram", title: "Comparer : 比, 没有, 一样, 最", emoji: "🧩",
        intro: "Plus grand, moins cher, aussi bien, le meilleur : la comparaison en chinois tient en quelques structures fixes.",
        sections: [
          {
            title: "A 比 B + adjectif",
            text: "« A est plus … que B ». Piège : <b>pas de 很</b> dans cette structure. Pour préciser l'écart, ajoutez-le après l'adjectif.",
            examples: [["我比他高。", "wǒ bǐ tā gāo.", "Je suis plus grand que lui."], ["今天比昨天冷一点。", "jīntiān bǐ zuótiān lěng yìdiǎn.", "Aujourd'hui il fait un peu plus froid qu'hier."], ["他比我大三岁。", "tā bǐ wǒ dà sān suì.", "Il a trois ans de plus que moi."]],
          },
          {
            title: "Moins que, aussi… que",
            examples: [["我没有他那么高。", "wǒ méiyǒu tā nàme gāo.", "Je ne suis pas aussi grand que lui."], ["我跟你一样高。", "wǒ gēn nǐ yíyàng gāo.", "Je suis aussi grand que toi."]],
          },
          {
            title: "Le superlatif et « encore plus »",
            examples: [["他最高。", "tā zuì gāo.", "C'est lui le plus grand."], ["上海更大。", "Shànghǎi gèng dà.", "Shanghai est encore plus grande."]],
          },
        ],
        mnemo: "比 ressemble à deux personnes côte à côte qu'on compare. Et rappelez-vous : « 比 chasse 很 » — jamais les deux ensemble.",
        vocab: [["比", "bǐ", "comparé à"], ["一样", "yíyàng", "pareil"], ["最", "zuì", "le plus"], ["更", "gèng", "encore plus"], ["一点", "yìdiǎn", "un peu"], ["高", "gāo", "grand, haut"], ["冷", "lěng", "froid"]],
        quiz: [
          mcq("« Je suis plus grand que lui » :", ["我比他很高。", "我比他高。", "我高比他。", "我很比他高。"], 1, "Pas de 很 avec 比."),
          fill("北京 ___ 上海冷。(plus… que)", ["比", "bǐ", "bi"], "A 比 B + adjectif."),
          mcq("« Je suis aussi grand que toi » :", ["我跟你一样高。", "我比你一样高。", "我一样你高。", "我没有你高一样。"], 0, "A 跟 B 一样 + adjectif."),
          fill("他是我们班 ___ 高的学生。(le plus)", ["最", "zuì", "zui"], "最 = le plus."),
          tr("Traduisez : Il a trois ans de plus que moi.", ["他比我大三岁", "tā bǐ wǒ dà sān suì", "ta bi wo da san sui"], "L'écart se place après l'adjectif."),
        ],
      },
      {
        id: "b1-ba", module: "gram", title: "La structure 把 bǎ", emoji: "🧩",
        intro: "Pour dire ce qu'on fait D'UN objet précis et le résultat obtenu : la structure emblématique du chinois.",
        sections: [
          {
            title: "Sujet + 把 + objet + verbe + complément",
            text: "<b>把</b> avance l'objet avant le verbe pour insister sur ce qui lui arrive. Le verbe ne peut pas rester seul : il lui faut un résultat (了, 完, 好, une direction…).",
            examples: [["我把作业做完了。", "wǒ bǎ zuòyè zuò wán le.", "J'ai terminé mes devoirs."], ["请把门关上。", "qǐng bǎ mén guān shang.", "Fermez la porte, s'il vous plaît."], ["他把钱包丢了。", "tā bǎ qiánbāo diū le.", "Il a perdu son portefeuille."]],
          },
          {
            title: "Les conditions d'emploi",
            text: "L'objet doit être <b>précis</b> (connu des deux interlocuteurs). La négation se place <b>avant 把</b> : 我没把作业做完.",
            examples: [["我没把手机带来。", "wǒ méi bǎ shǒujī dài lai.", "Je n'ai pas apporté mon téléphone."]],
          },
          {
            title: "Les verbes de placement",
            examples: [["把书放在桌子上。", "bǎ shū fàng zài zhuōzi shang.", "Pose le livre sur la table."], ["把这句话翻译成法语。", "bǎ zhè jù huà fānyì chéng Fǎyǔ.", "Traduis cette phrase en français."]],
          },
        ],
        mnemo: "把 = « prendre en main » (sa clé 扌 est la main). On attrape l'objet, on agit dessus, et on montre le résultat.",
        vocab: [["把", "bǎ", "particule de traitement"], ["作业", "zuòyè", "devoirs"], ["关", "guān", "fermer"], ["门", "mén", "porte"], ["放", "fàng", "poser, mettre"], ["丢", "diū", "perdre"], ["翻译", "fānyì", "traduire"]],
        quiz: [
          mcq("Quelle phrase est correcte ?", ["我把作业做。", "我把作业做完了。", "我做把作业完了。", "我把做完作业了。"], 1, "Le verbe doit avoir un complément de résultat."),
          fill("请 ___ 门关上。", ["把", "bǎ", "ba"], "请把门关上 : fermez la porte."),
          mcq("Où place-t-on la négation ?", ["我把手机没带来。", "我没把手机带来。", "我把没手机带来。", "我把手机带没来。"], 1, "La négation précède 把."),
          fill("把书放 ___ 桌子上。(poser sur)", ["在", "zài", "zai"], "放在… = poser sur…"),
          tr("Traduisez : Il a perdu son portefeuille.", ["他把钱包丢了", "tā bǎ qiánbāo diū le", "ta ba qianbao diu le", "他丢了钱包"], "他把钱包丢了."),
        ],
      },
      {
        id: "b1-complements", module: "temps", title: "Compléments de résultat et modaux", emoji: "⏳",
        intro: "Écouter ≠ comprendre : le chinois précise toujours si l'action a atteint son but.",
        sections: [
          {
            title: "Verbe + résultat",
            text: "<b>完 wán</b> fini · <b>懂 dǒng</b> compris · <b>到 dào</b> atteint · <b>好 hǎo</b> bien fait · <b>见 jiàn</b> perçu.",
            examples: [["我听懂了。", "wǒ tīng dǒng le.", "J'ai compris (en écoutant)."], ["我找到了！", "wǒ zhǎo dào le!", "J'ai trouvé !"], ["我没看见他。", "wǒ méi kàn jiàn tā.", "Je ne l'ai pas vu."]],
          },
          {
            title: "Le complément potentiel : 得 / 不",
            examples: [["你听得懂吗？", "nǐ tīng de dǒng ma?", "Tu arrives à comprendre ?"], ["我听不懂。", "wǒ tīng bu dǒng.", "Je n'arrive pas à comprendre."]],
          },
          {
            title: "会, 能, 可以",
            text: "<b>会 huì</b> : savoir faire (compétence apprise) · <b>能 néng</b> : pouvoir (capacité, circonstances) · <b>可以 kěyǐ</b> : avoir la permission.",
            examples: [["我会说中文。", "wǒ huì shuō Zhōngwén.", "Je sais parler chinois."], ["我今天不能来。", "wǒ jīntiān bù néng lái.", "Je ne peux pas venir aujourd'hui."], ["这里可以拍照吗？", "zhèlǐ kěyǐ pāizhào ma?", "On peut prendre des photos ici ?"]],
          },
        ],
        mnemo: "听 (écouter) + 懂 (comprendre) = 听懂. Le chinois raconte l'action ET son résultat, comme deux photos : avant / après.",
        vocab: [["懂", "dǒng", "comprendre"], ["完", "wán", "finir"], ["找到", "zhǎo dào", "trouver"], ["听不懂", "tīng bu dǒng", "ne pas comprendre (à l'oral)"], ["会", "huì", "savoir (faire)"], ["能", "néng", "pouvoir"], ["可以", "kěyǐ", "avoir le droit"]],
        quiz: [
          mcq("« Je n'arrive pas à comprendre (ce que tu dis) » :", ["我不听。", "我听不懂。", "我没听。", "我不会听。"], 1, "Complément potentiel négatif : 听不懂."),
          fill("我找 ___ 了我的钥匙！(trouvé)", ["到", "dào", "dao"], "找到 = chercher + atteindre = trouver."),
          mcq("« Je sais nager » (compétence apprise) :", ["我能游泳。", "我会游泳。", "我可以游泳。", "我要游泳。"], 1, "会 = savoir faire après apprentissage."),
          mcq("« Peut-on fumer ici ? » (permission) :", ["这里会抽烟吗？", "这里可以抽烟吗？", "这里懂抽烟吗？", "这里到抽烟吗？"], 1, "可以 = permission."),
          fill("你看 ___ 这本书了吗？(fini de lire)", ["完", "wán", "wan"], "看完 = finir de lire."),
        ],
      },
      {
        id: "b1-expressions", module: "expr", title: "Expressions du quotidien", emoji: "💬",
        intro: "Ce qui fait passer d'un chinois de manuel à un chinois vivant.",
        sections: [
          {
            title: "Encourager et rassurer",
            examples: [["加油！", "jiāyóu!", "Courage ! / Allez ! (litt. « ajoute de l'huile »)"], ["没问题！", "méi wèntí!", "Pas de problème !"], ["慢慢来。", "mànmàn lái.", "Prends ton temps."], ["辛苦了！", "xīnkǔ le!", "Merci pour tes efforts !"]],
          },
          {
            title: "Nuancer",
            examples: [["马马虎虎。", "mǎmahūhū.", "Couci-couça (litt. « cheval-cheval-tigre-tigre »)"], ["随便。", "suíbiàn.", "Comme tu veux / peu importe."], ["算了。", "suàn le.", "Laisse tomber."]],
          },
          {
            title: "Être poli",
            examples: [["不好意思。", "bù hǎoyìsi.", "Désolé / excusez-moi (gêne légère)."], ["麻烦你了。", "máfan nǐ le.", "Désolé de te déranger / merci."], ["哪里哪里。", "nǎlǐ nǎlǐ.", "Oh, pas du tout (réponse modeste à un compliment)."]],
          },
        ],
        mnemo: "Quand on vous complimente en Chine, la modestie est de rigueur : répondez 哪里哪里 (« où ça, où ça ? ») plutôt que 谢谢.",
        vocab: [["加油", "jiāyóu", "courage !"], ["没问题", "méi wèntí", "pas de problème"], ["马马虎虎", "mǎmahūhū", "couci-couça"], ["随便", "suíbiàn", "comme tu veux"], ["算了", "suàn le", "laisse tomber"], ["不好意思", "bù hǎoyìsi", "désolé, excusez-moi"], ["辛苦了", "xīnkǔ le", "merci pour tes efforts"]],
        quiz: [
          mcq("Un ami passe un examen demain. Vous lui dites :", ["算了！", "加油！", "随便！", "哪里哪里！"], 1, "加油 = courage !"),
          match("Associez", [["马马虎虎|mǎmahūhū", "couci-couça"], ["随便|suíbiàn", "comme tu veux"], ["算了|suàn le", "laisse tomber"], ["慢慢来|mànmàn lái", "prends ton temps"]]),
          mcq("On vous dit 你的中文很好！La réponse la plus modeste :", ["对！", "哪里哪里。", "没问题。", "加油。"], 1, "哪里哪里 : réponse modeste traditionnelle."),
          mcq("Vous bousculez quelqu'un légèrement :", ["不好意思。", "辛苦了。", "马马虎虎。", "加油。"], 0, "不好意思 = désolé, excusez-moi."),
          tr("Dites « Pas de problème ! »", ["没问题", "méi wèntí", "mei wenti"], "没问题 méi wèntí."),
        ],
      },
    ],
    exam: [
      mcq("« Shanghai est plus grande que Pékin » :", ["上海比北京很大。", "上海比北京大。", "上海大比北京。", "上海比大北京。"], 1, "Pas de 很 avec 比."),
      fill("我 ___ 他那么高。(pas aussi grand que)", ["没有", "méiyǒu", "meiyou"], "A 没有 B 那么 + adj."),
      mcq("Quelle phrase avec 把 est correcte ?", ["我把门关。", "我把门关上了。", "我关把门。", "把我门关上。"], 1, "Verbe + complément."),
      fill("老师说得太快，我听 ___ 懂。", ["不", "bu", "bù"], "听不懂."),
      mcq("« Je sais conduire » :", ["我会开车。", "我可以开车。", "我懂开车。", "我到开车。"], 0, "会 : compétence apprise."),
      match("Associez", [["加油|jiāyóu", "courage !"], ["辛苦了|xīnkǔ le", "merci pour tes efforts"], ["不好意思|bù hǎoyìsi", "désolé"], ["没问题|méi wèntí", "pas de problème"]]),
      fill("我找 ___ 了！(trouvé)", ["到", "dào", "dao"], "找到."),
      tr("Traduisez : C'est elle la plus grande.", ["她最高", "tā zuì gāo", "ta zui gao"], "最 + adjectif."),
    ],
  },

  /* ================================================================ B2 */
  {
    id: "B2", label: "HSK 4", name: "Avancé", hsk: "HSK 4", title: "Argumenter et travailler", emoji: "🐉", color: "#c23b32",
    desc: "Passif 被, connecteurs logiques et chinois des affaires.",
    lessons: [
      {
        id: "b2-bei", module: "gram", title: "Le passif avec 被 bèi", emoji: "🧩",
        intro: "Le passif chinois sert surtout à raconter quelque chose de subi, souvent désagréable.",
        sections: [
          {
            title: "Objet + 被 (+ agent) + verbe + complément",
            text: "Comme 把, le verbe a besoin d'un complément (了, un résultat…). L'agent peut être omis.",
            examples: [["我的手机被偷了。", "wǒ de shǒujī bèi tōu le.", "On m'a volé mon téléphone."], ["蛋糕被弟弟吃完了。", "dàngāo bèi dìdi chī wán le.", "Le gâteau a été fini par mon petit frère."]],
          },
          {
            title: "Une nuance souvent négative",
            text: "Traditionnellement, 被 exprime un événement <b>subi</b>. Pour un fait neutre, le chinois préfère souvent la voix active ou une phrase sans marque.",
            examples: [["他被老板批评了。", "tā bèi lǎobǎn pīpíng le.", "Il s'est fait réprimander par le patron."], ["信写好了。", "xìn xiě hǎo le.", "La lettre est écrite (passif implicite, neutre)."]],
          },
          {
            title: "Négation et variantes orales",
            text: "La négation se place devant 被 : <b>没被</b>. À l'oral, on entend aussi <b>叫 jiào</b> ou <b>让 ràng</b> à la place de 被.",
            examples: [["我没被发现。", "wǒ méi bèi fāxiàn.", "Je n'ai pas été découvert."], ["自行车让人借走了。", "zìxíngchē ràng rén jiè zǒu le.", "Le vélo a été emprunté par quelqu'un."]],
          },
        ],
        mnemo: "被 contient 衣 (le vêtement) : à l'origine, une couverture. Imaginez quelqu'un « couvert » par un événement qu'il subit.",
        vocab: [["被", "bèi", "marque du passif"], ["偷", "tōu", "voler (dérober)"], ["批评", "pīpíng", "critiquer"], ["发现", "fāxiàn", "découvrir"], ["手机", "shǒujī", "téléphone portable"], ["老板", "lǎobǎn", "patron"]],
        quiz: [
          fill("我的钱包 ___ 偷了。(passif)", ["被", "bèi", "bei"], "被 = passif."),
          mcq("Où va la négation ?", ["他被没批评。", "他没被批评。", "他被批评没。", "没他被批评。"], 1, "Négation devant 被."),
          mcq("Laquelle est correcte ?", ["蛋糕被吃。", "蛋糕被弟弟吃完了。", "蛋糕弟弟被吃了。", "被蛋糕吃完了。"], 1, "Le verbe a besoin d'un complément."),
          mcq("被 exprime traditionnellement un événement :", ["souhaité", "subi", "futur", "hypothétique"], 1, "Souvent désagréable ou subi."),
          tr("Traduisez : On m'a volé mon téléphone.", ["我的手机被偷了", "wǒ de shǒujī bèi tōu le", "wo de shouji bei tou le"], "我的手机被偷了."),
        ],
      },
      {
        id: "b2-connecteurs", module: "gram", title: "Les connecteurs logiques en paires", emoji: "🔗",
        intro: "En chinois, les connecteurs vont souvent par deux : un dans chaque partie de la phrase.",
        sections: [
          {
            title: "Cause, opposition",
            examples: [["因为下雨，所以我没去。", "yīnwèi xià yǔ, suǒyǐ wǒ méi qù.", "Comme il pleuvait, je n'y suis pas allé."], ["虽然很贵，但是质量很好。", "suīrán hěn guì, dànshì zhìliàng hěn hǎo.", "Bien que ce soit cher, la qualité est bonne."]],
          },
          {
            title: "Condition, addition",
            examples: [["如果你有时间，就来吧。", "rúguǒ nǐ yǒu shíjiān, jiù lái ba.", "Si tu as le temps, viens."], ["他不但会说中文，而且会写汉字。", "tā búdàn huì shuō Zhōngwén, érqiě huì xiě Hànzì.", "Non seulement il parle chinois, mais en plus il écrit les caractères."]],
          },
          {
            title: "Succession immédiate, condition suffisante",
            examples: [["我一到家就给你打电话。", "wǒ yí dào jiā jiù gěi nǐ dǎ diànhuà.", "Dès que j'arrive à la maison, je t'appelle."], ["只要努力，就能成功。", "zhǐyào nǔlì, jiù néng chénggōng.", "Il suffit de travailler dur pour réussir."]],
          },
        ],
        mnemo: "Pensez « tenons et mortaises » : chaque connecteur d'ouverture (因为, 虽然, 如果, 一) appelle son partenaire (所以, 但是, 就, 就).",
        vocab: [["因为…所以", "yīnwèi… suǒyǐ", "parce que… donc"], ["虽然…但是", "suīrán… dànshì", "bien que… mais"], ["如果…就", "rúguǒ… jiù", "si… alors"], ["不但…而且", "búdàn… érqiě", "non seulement… mais aussi"], ["一…就", "yī… jiù", "dès que…"], ["只要…就", "zhǐyào… jiù", "il suffit que…"]],
        quiz: [
          fill("虽然很累，___ 我很开心。", ["但是", "dànshì", "danshi", "可是", "kěshì"], "虽然… 但是 / 可是."),
          mcq("如果明天不下雨，我们 ___ 去爬山。", ["所以", "就", "而且", "但是"], 1, "如果… 就."),
          mcq("« Dès qu'il arrive, il mange » :", ["他一到就吃饭。", "他因为到所以吃饭。", "他虽然到就吃饭。", "他不但到吃饭。"], 0, "一… 就 = dès que."),
          match("Associez", [["因为|yīnwèi", "所以 suǒyǐ"], ["虽然|suīrán", "但是 dànshì"], ["不但|búdàn", "而且 érqiě"], ["如果|rúguǒ", "就 jiù"]]),
          fill("___ 努力，就能成功。(il suffit de)", ["只要", "zhǐyào", "zhiyao"], "只要… 就."),
        ],
      },
      {
        id: "b2-affaires", module: "vocab", title: "Le chinois des affaires", emoji: "💼",
        intro: "Entretien, réunion, négociation et e-mail : le vocabulaire et les codes du monde professionnel chinois.",
        sections: [
          {
            title: "Recherche d'emploi",
            examples: [["简历", "jiǎnlì", "CV"], ["面试", "miànshì", "entretien"], ["实习", "shíxí", "stage"], ["公司", "gōngsī", "entreprise"], ["工资", "gōngzī", "salaire"]],
          },
          {
            title: "Au bureau et en négociation",
            examples: [["会议", "huìyì", "réunion"], ["客户", "kèhù", "client"], ["合同", "hétong", "contrat"], ["发票", "fāpiào", "facture"], ["谈判", "tánpàn", "négociation"], ["报价", "bàojià", "offre de prix"]],
          },
          {
            title: "Codes culturels et e-mail formel",
            text: "On tend sa <b>carte de visite (名片)</b> à deux mains, texte tourné vers l'interlocuteur. Le <b>关系 guānxi</b> (réseau de confiance) compte autant que le contrat. Un e-mail formel s'ouvre par <b>尊敬的…</b> et se termine par <b>此致敬礼</b>.",
            examples: [["尊敬的王经理：", "zūnjìng de Wáng jīnglǐ:", "Monsieur le directeur Wang,"], ["期待您的回复。", "qīdài nín de huífù.", "Dans l'attente de votre réponse."], ["干杯！", "gānbēi!", "Santé ! (litt. « verre sec »)"]],
          },
        ],
        mnemo: "On s'adresse aux gens par nom + fonction : 王经理 (directeur Wang), 李老师 (professeur Li). Le nom de famille vient toujours en premier.",
        vocab: [["简历", "jiǎnlì", "CV"], ["面试", "miànshì", "entretien"], ["实习", "shíxí", "stage"], ["合同", "hétong", "contrat"], ["客户", "kèhù", "client"], ["发票", "fāpiào", "facture"], ["名片", "míngpiàn", "carte de visite"], ["关系", "guānxi", "relations, réseau"]],
        quiz: [
          match("Associez", [["简历|jiǎnlì", "CV"], ["合同|hétong", "contrat"], ["客户|kèhù", "client"], ["发票|fāpiào", "facture"]]),
          mcq("Comment tendre sa carte de visite ?", ["D'une main, rapidement", "À deux mains, texte vers l'interlocuteur", "En la posant sur la table", "En la glissant dans sa poche"], 1, "À deux mains, en signe de respect."),
          mcq("Un e-mail formel commence par :", ["嗨！", "尊敬的…", "再见", "加油"], 1, "尊敬的 = respecté(e)…"),
          fill("我下个月有一个 ___ 。(entretien)", ["面试", "miànshì", "mianshi"], "面试 = entretien."),
          tr("Dites « Santé ! » lors d'un banquet", ["干杯", "gānbēi", "ganbei"], "干杯 : on vide son verre."),
        ],
      },
    ],
    exam: [
      fill("他 ___ 老师批评了。(passif)", ["被", "bèi", "bei"], "被."),
      mcq("因为太累了，___ 我早睡了。", ["但是", "所以", "而且", "就"], 1, "因为… 所以."),
      mcq("« Bien que ce soit cher, j'achète » :", ["虽然很贵，但是我买。", "因为很贵，所以我买。", "如果很贵，就我买。", "不但很贵，所以我买。"], 0, "虽然… 但是."),
      fill("我一下班 ___ 回家。(dès que… alors)", ["就", "jiù", "jiu"], "一… 就."),
      mcq("« Stage » se dit :", ["实习", "实在", "学习", "练习"], 0, "实习 shíxí (学习 = étudier !)."),
      mcq("Laquelle est correcte ?", ["我的车被借。", "我的车被朋友借走了。", "我的车朋友被借了。", "被我的车借走了。"], 1, "Complément obligatoire."),
      match("Associez", [["会议|huìyì", "réunion"], ["谈判|tánpàn", "négociation"], ["名片|míngpiàn", "carte de visite"], ["工资|gōngzī", "salaire"]]),
      tr("Traduisez : Si tu as le temps, viens.", ["如果你有时间就来吧", "如果你有时间就来", "rúguǒ nǐ yǒu shíjiān jiù lái ba", "ruguo ni you shijian jiu lai ba"], "如果你有时间，就来吧."),
    ],
  },

  /* ================================================================ C1 */
  {
    id: "C1", label: "HSK 5", name: "Autonome", hsk: "HSK 5", title: "Précision et élégance", emoji: "🎋", color: "#6a4c93",
    desc: "Les trois « de », chengyu (成语) et registre écrit.",
    lessons: [
      {
        id: "c1-trois-de", module: "gram", title: "Les trois « de » : 的, 地, 得", emoji: "🧩",
        intro: "Trois caractères, une seule prononciation (de), trois fonctions : un classique des examens HSK.",
        sections: [
          {
            title: "的 : avant un nom",
            text: "Relie un déterminant (adjectif, possesseur, proposition) à un <b>nom</b>.",
            examples: [["漂亮的衣服", "piàoliang de yīfu", "de beaux vêtements"], ["我昨天买的书", "wǒ zuótiān mǎi de shū", "le livre que j'ai acheté hier"]],
          },
          {
            title: "地 : avant un verbe",
            text: "Transforme un adjectif en <b>adverbe de manière</b> placé devant le verbe.",
            examples: [["他慢慢地走。", "tā mànmàn de zǒu.", "Il marche lentement."], ["她高兴地笑了。", "tā gāoxìng de xiào le.", "Elle a souri joyeusement."]],
          },
          {
            title: "得 : après un verbe",
            text: "Introduit un <b>complément de degré</b> qui évalue l'action.",
            examples: [["他跑得很快。", "tā pǎo de hěn kuài.", "Il court vite."], ["你说得对。", "nǐ shuō de duì.", "Tu as raison (tu dis juste)."]],
          },
        ],
        mnemo: "的 est blanc (白) comme une étiquette sur un NOM · 地 est le sol (土) sur lequel on MARCHE (avant le verbe) · 得 a la clé 彳 du pas : on évalue le résultat APRÈS le verbe.",
        vocab: [["的", "de", "avant un nom"], ["地", "de", "avant un verbe"], ["得", "de", "après un verbe"], ["慢慢", "mànmàn", "lentement"], ["快", "kuài", "rapide"], ["高兴", "gāoxìng", "content"]],
        quiz: [
          mcq("他跑 ___ 很快。", ["的", "地", "得"], 2, "Après le verbe : 得."),
          mcq("她认真 ___ 学习。", ["的", "地", "得"], 1, "Avant le verbe : 地."),
          mcq("这是我妈妈做 ___ 菜。", ["的", "地", "得"], 0, "Avant un nom : 的."),
          fill("你说 ___ 对！", ["得", "de"], "Complément de degré après 说."),
          match("Associez", [["的", "avant un nom"], ["地", "avant un verbe"], ["得", "après un verbe"], ["很快", "complément de degré"]]),
        ],
      },
      {
        id: "c1-chengyu", module: "expr", title: "Les chengyu (成语)", emoji: "📜",
        intro: "Expressions figées de quatre caractères, souvent tirées de récits anciens : la marque d'un chinois cultivé.",
        sections: [
          {
            title: "Les plus utiles",
            examples: [["一举两得", "yì jǔ liǎng dé", "faire d'une pierre deux coups"], ["入乡随俗", "rù xiāng suí sú", "à Rome, fais comme les Romains"], ["半途而废", "bàn tú ér fèi", "abandonner à mi-chemin"], ["马到成功", "mǎ dào chénggōng", "réussite immédiate (vœu de succès)"]],
          },
          {
            title: "Des histoires derrière les mots",
            text: "<b>画蛇添足</b> : un homme qui dessine un serpent lui ajoute des pattes et perd le concours → en faire trop. <b>守株待兔</b> : un paysan attend qu'un autre lièvre se cogne contre la souche → attendre passivement la chance. <b>对牛弹琴</b> : jouer du luth à un bœuf → parler à quelqu'un qui ne peut pas comprendre.",
            examples: [["画蛇添足", "huà shé tiān zú", "en faire trop, gâcher par excès"], ["守株待兔", "shǒu zhū dài tù", "attendre que la chance tombe du ciel"], ["对牛弹琴", "duì niú tán qín", "donner de la confiture aux cochons"]],
          },
          {
            title: "Bien les employer",
            text: "Un chengyu fonctionne comme un mot : prédicat, adjectif ou complément. Un ou deux bien placés dans un discours font excellente impression ; trop, et cela paraît artificiel.",
            examples: [["这个办法一举两得。", "zhège bànfǎ yì jǔ liǎng dé.", "Cette méthode fait d'une pierre deux coups."]],
          },
        ],
        mnemo: "Retenez l'histoire, pas les caractères : le serpent à pattes, le lièvre contre la souche, le bœuf mélomane. L'image ramène automatiquement l'expression.",
        vocab: [["成语", "chéngyǔ", "expression idiomatique à 4 caractères"], ["一举两得", "yì jǔ liǎng dé", "d'une pierre deux coups"], ["入乡随俗", "rù xiāng suí sú", "s'adapter aux coutumes locales"], ["半途而废", "bàn tú ér fèi", "abandonner à mi-chemin"], ["画蛇添足", "huà shé tiān zú", "en faire trop"], ["对牛弹琴", "duì niú tán qín", "parler à un mur"]],
        quiz: [
          mcq("« Faire d'une pierre deux coups » :", ["半途而废", "一举两得", "对牛弹琴", "守株待兔"], 1, "一举两得 : un geste, deux gains."),
          match("Associez", [["画蛇添足", "en faire trop"], ["对牛弹琴", "parler à un mur"], ["守株待兔", "attendre passivement la chance"], ["入乡随俗", "s'adapter aux coutumes locales"]]),
          mcq("Un ami abandonne le chinois après deux mois. C'est :", ["马到成功", "半途而废", "一举两得", "入乡随俗"], 1, "Abandonner à mi-chemin."),
          fill("你已经写得很好了，别画蛇 ___ 足。", ["添", "tiān", "tian"], "画蛇添足."),
          mcq("Pour souhaiter bonne chance à quelqu'un qui lance son entreprise :", ["对牛弹琴！", "马到成功！", "半途而废！", "画蛇添足！"], 1, "马到成功 : succès dès l'arrivée du cheval."),
        ],
      },
      {
        id: "c1-registre", module: "hanzi", title: "Le registre écrit et formel", emoji: "🖋️",
        intro: "Rapports, articles, discours officiels : le chinois écrit emprunte des mots au chinois classique.",
        sections: [
          {
            title: "Les mots classiques encore vivants",
            table: { cols: ["Écrit", "Oral", "Sens"], rows: [["之 zhī", "的", "de (possession)"], ["于 yú", "在 / 对", "à, en, par rapport à"], ["以 yǐ", "用 / 为了", "par, afin de"], ["其 qí", "他的 / 它的", "son, sa, leur"], ["而 ér", "但是 / 而且", "et, mais"]] },
          },
          {
            title: "Expressions formelles",
            examples: [["您贵姓？", "nín guìxìng?", "Quel est votre nom ? (très poli)"], ["请问…", "qǐngwèn…", "Puis-je vous demander…"], ["进行讨论", "jìnxíng tǎolùn", "procéder à une discussion"], ["鉴于目前情况", "jiànyú mùqián qíngkuàng", "compte tenu de la situation actuelle"]],
          },
          {
            title: "Oral vs écrit",
            examples: [["我们得想办法。", "wǒmen děi xiǎng bànfǎ.", "Il faut qu'on trouve une solution (oral)."], ["我们须采取措施。", "wǒmen xū cǎiqǔ cuòshī.", "Nous devons prendre des mesures (écrit)."]],
          },
        ],
        mnemo: "之 est le grand-père de 的 : on le croise dans les noms solennels (中国之声, « La Voix de la Chine ») et les titres.",
        vocab: [["之", "zhī", "de (écrit)"], ["于", "yú", "à, en (écrit)"], ["其", "qí", "son, sa, leur (écrit)"], ["贵姓", "guìxìng", "votre nom (honorifique)"], ["进行", "jìnxíng", "procéder à"], ["鉴于", "jiànyú", "compte tenu de"], ["措施", "cuòshī", "mesure"]],
        quiz: [
          mcq("À l'écrit, 之 correspond à :", ["是", "的", "了", "在"], 1, "之 ≈ 的."),
          mcq("Demander très poliment le nom de quelqu'un :", ["你叫什么？", "您贵姓？", "你是谁？", "名字呢？"], 1, "您贵姓 : forme honorifique."),
          match("Associez", [["于|yú", "à, en"], ["以|yǐ", "par, afin de"], ["其|qí", "son, sa, leur"], ["而|ér", "et, mais"]]),
          fill("___ 目前的情况，会议推迟。(compte tenu de)", ["鉴于", "jiànyú", "jianyu"], "鉴于 = compte tenu de."),
          mcq("Registre le plus écrit :", ["我们得想办法。", "我们须采取措施。", "咱们看看吧。", "怎么办啊？"], 1, "须 + 采取措施 : registre administratif."),
        ],
      },
    ],
    exam: [
      mcq("她高兴 ___ 唱歌。", ["的", "地", "得"], 1, "Avant le verbe : 地."),
      mcq("他汉字写 ___ 很漂亮。", ["的", "地", "得"], 2, "Après le verbe : 得."),
      mcq("« À Rome, fais comme les Romains » :", ["入乡随俗", "画蛇添足", "半途而废", "一举两得"], 0, "入乡随俗."),
      fill("学习不能半途而 ___ 。", ["废", "fèi", "fei"], "半途而废."),
      mcq("您贵姓？est :", ["familier", "honorifique", "vulgaire", "enfantin"], 1, "Forme très polie."),
      match("Associez", [["一举两得", "deux gains d'un coup"], ["马到成功", "succès immédiat"], ["守株待兔", "attendre la chance"], ["对牛弹琴", "parler à un mur"]]),
      mcq("À l'écrit, « à, en » peut se dire :", ["于", "了", "吗", "呢"], 0, "于 yú."),
      fill("这是我昨天买 ___ 衣服。", ["的", "de"], "Avant un nom : 的."),
    ],
  },

  /* ================================================================ C2 */
  {
    id: "C2", label: "HSK 6", name: "Maîtrise", hsk: "HSK 6+", title: "Comme un natif", emoji: "👑", color: "#1f3a5f",
    desc: "Xiehouyu, nuances fines et références culturelles.",
    lessons: [
      {
        id: "c2-xiehouyu", module: "expr", title: "Les xiehouyu (歇后语)", emoji: "🎭",
        intro: "Des devinettes en deux parties : on énonce l'image, l'auditeur complète mentalement la chute — souvent un jeu de mots.",
        sections: [
          {
            title: "Le principe",
            text: "Première partie : une image. Seconde partie : le sens, souvent non prononcé. Le natif complète de lui-même.",
            examples: [["竹篮打水——一场空", "zhúlán dǎ shuǐ — yì chǎng kōng", "puiser de l'eau avec un panier — peine perdue"], ["泥菩萨过江——自身难保", "ní púsà guò jiāng — zìshēn nán bǎo", "un bouddha d'argile traverse le fleuve — il ne peut même pas se sauver lui-même"]],
          },
          {
            title: "Les jeux de mots (homophones)",
            examples: [["外甥打灯笼——照舅（旧）", "wàisheng dǎ dēnglong — zhào jiù (jiù)", "le neveu éclaire son oncle (舅) → « comme d'habitude » (旧)"], ["小葱拌豆腐——一清二白", "xiǎocōng bàn dòufu — yì qīng èr bái", "ciboule et tofu (vert et blanc) → limpide, irréprochable"]],
          },
          {
            title: "Exprimer l'indicible",
            examples: [["哑巴吃黄连——有苦说不出", "yǎba chī huánglián — yǒu kǔ shuō bu chū", "un muet mange une herbe amère → souffrir sans pouvoir le dire"]],
          },
        ],
        mnemo: "Le xiehouyu est une blague à chute : dites seulement la première moitié avec un sourire entendu, et laissez votre interlocuteur finir. C'est là tout le plaisir.",
        vocab: [["歇后语", "xiēhòuyǔ", "devinette à chute"], ["一场空", "yì chǎng kōng", "peine perdue"], ["自身难保", "zìshēn nán bǎo", "ne pas pouvoir se sauver soi-même"], ["一清二白", "yì qīng èr bái", "limpide, irréprochable"], ["照旧", "zhàojiù", "comme d'habitude"], ["有苦说不出", "yǒu kǔ shuō bu chū", "souffrir en silence"]],
        quiz: [
          mcq("竹篮打水—— ?", ["一清二白", "一场空", "自身难保", "照旧"], 1, "Puiser de l'eau avec un panier : tout s'écoule."),
          mcq("外甥打灯笼——照舅 joue sur l'homophonie de 舅 avec :", ["旧 (ancien)", "九 (neuf)", "酒 (alcool)", "就 (alors)"], 0, "照舅 ≈ 照旧 : comme d'habitude."),
          match("Associez la première partie et la chute", [["小葱拌豆腐", "一清二白"], ["泥菩萨过江", "自身难保"], ["哑巴吃黄连", "有苦说不出"], ["竹篮打水", "一场空"]]),
          mcq("« 一清二白 » qualifie une personne :", ["paresseuse", "irréprochable", "bavarde", "pauvre"], 1, "Limpide, sans tache."),
          fill("哑巴吃黄连——有苦说不 ___ 。", ["出", "chū", "chu"], "说不出 : ne pas pouvoir dire."),
        ],
      },
      {
        id: "c2-nuances", module: "vocab", title: "Nuances et quasi-synonymes", emoji: "🎯",
        intro: "Les distinctions que même les apprenants avancés confondent encore.",
        sections: [
          {
            title: "知道 ou 认识 ? 还是 ou 或者 ?",
            text: "<b>知道</b> : savoir une information · <b>认识</b> : connaître une personne, reconnaître. <b>还是</b> : « ou » dans une question · <b>或者</b> : « ou » dans une affirmation.",
            examples: [["我知道他住在哪儿。", "wǒ zhīdào tā zhù zài nǎr.", "Je sais où il habite."], ["我认识他。", "wǒ rènshi tā.", "Je le connais."], ["你喝茶还是咖啡？", "nǐ hē chá háishi kāfēi?", "Tu bois du thé ou du café ?"], ["茶或者咖啡都可以。", "chá huòzhě kāfēi dōu kěyǐ.", "Thé ou café, les deux me vont."]],
          },
          {
            title: "再 ou 又 ?",
            text: "<b>再</b> : de nouveau, dans le futur · <b>又</b> : de nouveau, déjà arrivé.",
            examples: [["明天再来吧。", "míngtiān zài lái ba.", "Reviens demain."], ["他昨天又迟到了。", "tā zuótiān yòu chídào le.", "Il est encore arrivé en retard hier."]],
          },
          {
            title: "次 ou 遍 ?",
            text: "<b>次</b> compte les occurrences ; <b>遍</b> insiste sur l'action faite du début à la fin.",
            examples: [["我去过三次北京。", "wǒ qù guo sān cì Běijīng.", "Je suis allé trois fois à Pékin."], ["这本书我看了两遍。", "zhè běn shū wǒ kàn le liǎng biàn.", "J'ai lu ce livre deux fois (en entier)."]],
          },
        ],
        mnemo: "再 regarde devant (futur), 又 regarde derrière (passé). Pour 还是 : la question attend un choix, comme un aiguillage.",
        vocab: [["知道", "zhīdào", "savoir"], ["认识", "rènshi", "connaître (quelqu'un)"], ["还是", "háishi", "ou (question)"], ["或者", "huòzhě", "ou (affirmation)"], ["再", "zài", "de nouveau (futur)"], ["又", "yòu", "de nouveau (passé)"], ["遍", "biàn", "fois (du début à la fin)"]],
        quiz: [
          mcq("我 ___ 他，他是我的同事。", ["知道", "认识", "会", "懂"], 1, "Connaître une personne : 认识."),
          mcq("你想去北京 ___ 上海？", ["或者", "还是", "和", "跟"], 1, "Question alternative : 还是."),
          mcq("他昨天 ___ 迟到了。", ["再", "又", "还是", "才"], 1, "Répétition déjà arrivée : 又."),
          fill("请你 ___ 说一遍。(répéter, futur)", ["再", "zài", "zai"], "再说一遍 : redis-le."),
          mcq("« J'ai relu tout le texte trois fois » :", ["我看了三次课文。", "我把课文看了三遍。", "我又看了课文三。", "我看课文三还是。"], 1, "遍 : du début à la fin."),
        ],
      },
      {
        id: "c2-culture", module: "expr", title: "Culture, tabous et jeux de sons", emoji: "🧧",
        intro: "La langue chinoise est indissociable de sa culture : la face, la politesse et les homophones qui portent bonheur ou malheur.",
        sections: [
          {
            title: "La face (面子)",
            text: "<b>给面子</b> : ménager quelqu'un · <b>丢脸</b> : perdre la face · <b>客气</b> : la politesse réservée (refuser deux fois avant d'accepter un cadeau est courant).",
            examples: [["给我个面子吧。", "gěi wǒ ge miànzi ba.", "Fais-le pour moi (sauve ma face)."], ["太丢脸了！", "tài diū liǎn le!", "Quelle honte !"], ["别客气！", "bié kèqi!", "Ne fais pas de manières !"]],
          },
          {
            title: "Les homophones porte-bonheur",
            examples: [["八 bā ≈ 发 fā", "bā / fā", "8 évoque la fortune"], ["年年有余（鱼）", "nián nián yǒu yú", "abondance chaque année (余 = 鱼, poisson)"], ["恭喜发财！", "gōngxǐ fācái!", "Bonne et prospère année !"]],
          },
          {
            title: "Les tabous",
            text: "<b>四 sì ≈ 死 sǐ</b> (mort) : beaucoup d'immeubles n'ont pas de 4e étage. On n'offre pas d'<b>horloge</b> (送钟 sòng zhōng ≈ 送终, accompagner un mourant) et on ne partage pas une <b>poire</b> (分梨 ≈ 分离, se séparer).",
          },
        ],
        mnemo: "Avant d'offrir un cadeau, prononcez-le à voix haute : si son nom sonne comme un mot funeste, changez d'idée.",
        vocab: [["面子", "miànzi", "la face, le prestige"], ["丢脸", "diū liǎn", "perdre la face"], ["客气", "kèqi", "poli, cérémonieux"], ["恭喜发财", "gōngxǐ fācái", "vœux de prospérité"], ["年年有余", "nián nián yǒu yú", "abondance chaque année"], ["送钟", "sòng zhōng", "offrir une horloge (tabou)"]],
        quiz: [
          mcq("Pourquoi le chiffre 4 est-il évité ?", ["Il ressemble à 死 (mort)", "Il est impair", "Il est difficile à écrire", "C'est le chiffre de l'empereur"], 0, "四 sì ≈ 死 sǐ."),
          mcq("Le cadeau à éviter absolument :", ["du thé", "une horloge", "des fruits", "un livre"], 1, "送钟 ≈ 送终."),
          match("Associez", [["面子|miànzi", "la face"], ["丢脸|diū liǎn", "perdre la face"], ["客气|kèqi", "cérémonieux"], ["恭喜发财|gōngxǐ fācái", "vœux de prospérité"]]),
          fill("年年有 ___ 。(abondance, homophone de « poisson »)", ["余", "yú", "yu", "鱼"], "余 yú = surplus, homophone de 鱼."),
          mcq("Pourquoi le 8 est-il populaire ?", ["Il ressemble à un dragon", "八 bā rappelle 发 fā (s'enrichir)", "Il est pair", "Il porte malheur"], 1, "发财 = faire fortune."),
        ],
      },
    ],
    exam: [
      mcq("泥菩萨过江—— ?", ["一场空", "自身难保", "照旧", "一清二白"], 1, "Le bouddha d'argile fond dans l'eau."),
      mcq("你要米饭 ___ 面条？", ["或者", "还是", "和", "也"], 1, "Question alternative : 还是."),
      mcq("« Je sais qu'il est malade » :", ["我认识他病了。", "我知道他病了。", "我会他病了。", "我懂他病了。"], 1, "Savoir une information : 知道."),
      fill("欢迎你下次 ___ 来！(revenir, futur)", ["再", "zài", "zai"], "再 = futur."),
      mcq("送钟 est tabou car il évoque :", ["la pauvreté", "accompagner un mourant", "la séparation", "la paresse"], 1, "送终."),
      match("Associez", [["竹篮打水", "一场空"], ["小葱拌豆腐", "一清二白"], ["外甥打灯笼", "照舅（旧）"], ["哑巴吃黄连", "有苦说不出"]]),
      mcq("« Perdre la face » :", ["给面子", "丢脸", "客气", "发财"], 1, "丢脸 diū liǎn."),
      tr("Souhaitez une bonne année prospère", ["恭喜发财", "gōngxǐ fācái", "gongxi facai", "新年快乐", "xīnnián kuàilè"], "恭喜发财 (ou 新年快乐 : bonne année)."),
    ],
  },
];

/* ---------------------------------------------------------------------
   Index et accès rapides
--------------------------------------------------------------------- */
// Compléments HSK 1 : ajoutés après les 5 leçons d'origine (progression conservée)
LEVELS[0].lessons.push(...HSK1_PLUS);
LEVELS[0].exam.push(...HSK1_EXAM_PLUS);
LEVELS[1].lessons.push(...HSK2_PLUS);
LEVELS[1].exam.push(...HSK2_EXAM_PLUS);

export const ALL_LESSONS = [];
LEVELS.forEach((level, li) => {
  level.lessons.forEach((lesson, i) => {
    lesson.levelId = level.id;
    lesson.levelIndex = li;
    lesson.index = i;
    ALL_LESSONS.push(lesson);
  });
});

export const getLevel = (id) => LEVELS.find((l) => l.id === id);
export const getLesson = (id) => ALL_LESSONS.find((l) => l.id === id);

/** Référence unique d'une question : "a1-nombres:2" ou "exam-A1:4" */
export function getQuestion(ref) {
  const [src, idx] = ref.split(":");
  if (src.startsWith("exam-")) return getLevel(src.slice(5))?.exam[+idx] || null;
  return getLesson(src)?.quiz[+idx] || null;
}

const lvlLabel = (id) => LEVELS.find((l) => l.id === id)?.label || id;

export function refLabel(ref) {
  const src = ref.split(":")[0];
  if (src.startsWith("exam-")) return `Examen ${lvlLabel(src.slice(5))}`;
  const l = getLesson(src);
  return l ? `${lvlLabel(l.levelId)} · ${l.title}` : src;
}
