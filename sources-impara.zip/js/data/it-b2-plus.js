/* =====================================================================
   Italien — compléments du palier B2 (CECRL, « Avancé »)
   ---------------------------------------------------------------------
   Calé sur le niveau B2 (descripteurs CECRL, certifications CELI 3 /
   CILS DUE-B2) : subjonctif passé et conjonctions + subjonctif,
   hypothèse irréelle du passé, conditionnel passé et futur dans le
   passé, futur antérieur et futur de probabilité, voix passive
   (essere, venire, andare, si passivant), gérondif et participe,
   relatifs avancés (il quale, il cui, ciò che), verbes à préposition,
   e-mail formel et registre, actualité et société, culture.
   Les leçons s'ajoutent APRÈS les 3 leçons d'origine du palier.
   ===================================================================== */

const mcq = (q, options, answer, explain = "") => ({ type: "mcq", q, options, answer, explain });
const fill = (q, answer, explain = "") => ({ type: "fill", q, answer, explain });
const match = (q, pairs, explain = "") => ({ type: "match", q, pairs, explain });
const tr = (q, answer, explain = "") => ({ type: "translate", q, answer, explain });

export const B2_PLUS = [
  /* ------------------------------------------------------------ 4 */
  {
    id: "b2-congiuntivo-passato", module: "conj", title: "Le subjonctif passé : penso che sia andato", emoji: "⏳",
    intro: "Pour donner son avis, exprimer un doute ou un sentiment sur un fait déjà ACCOMPLI, on utilise le subjonctif passé.",
    sections: [
      {
        title: "Formation : subjonctif présent de avere / essere + participe",
        text: "Mêmes auxiliaires et mêmes accords que le passé composé : <i>ho mangiato</i> → <b>che io abbia mangiato</b> ; <i>sono partita</i> → <b>che io sia partita</b>.",
        table: { cols: ["", "mangiare", "partire"], rows: [["che io", "abbia mangiato", "sia partito/a"], ["che tu", "abbia mangiato", "sia partito/a"], ["che lui / lei", "abbia mangiato", "sia partito/a"], ["che noi", "abbiamo mangiato", "siamo partiti/e"], ["che voi", "abbiate mangiato", "siate partiti/e"], ["che loro", "abbiano mangiato", "siano partiti/e"]] },
      },
      {
        title: "Présent ou passé ?",
        text: "Après un verbe d'opinion au présent (<i>penso, credo, mi sembra, spero, sono contento</i>…), on choisit le temps selon le moment de l'action : <b>simultanée ou future</b> → subjonctif présent ; <b>antérieure</b> → subjonctif passé.",
        examples: [["Penso che Luca sia a casa.", "Je pense que Luca est à la maison."], ["Penso che Luca sia già partito.", "Je pense que Luca est déjà parti."], ["Mi dispiace che tu non abbia potuto venire.", "Je regrette que tu n'aies pas pu venir."], ["Spero che abbiate fatto buon viaggio.", "J'espère que vous avez fait bon voyage."]],
      },
      {
        title: "Les expressions qui le déclenchent",
        text: "<b>È possibile che</b>, <b>è strano che</b>, <b>non sono sicuro che</b>, <b>dubito che</b>, <b>ho paura che</b>, <b>sono felice che</b>… Attention : <i>sono sicuro che</i> (certitude) prend l'indicatif.",
        examples: [["È strano che non abbia ancora risposto.", "C'est bizarre qu'il n'ait pas encore répondu."], ["Sono sicuro che ha capito.", "Je suis sûr qu'il a compris (indicatif)."], ["Non credo che sia stata una buona idea.", "Je ne crois pas que ç'ait été une bonne idée."]],
      },
    ],
    mnemo: "Même recette que le passé composé : on remplace juste ho / sono par abbia / sia.",
    vocab: [["dubitare", "douter"], ["sembrare", "sembler"], ["sperare", "espérer"], ["dispiacere", "regretter, être désolé"], ["essere sicuro", "être sûr"], ["ancora", "encore"], ["già", "déjà"], ["un'idea", "une idée"], ["rispondere", "répondre"], ["il viaggio", "le voyage"]],
    quiz: [
      mcq("Penso che Marta ___ ieri sera.", ["è uscita", "sia uscita", "esca", "uscirebbe"], 1, "Opinion + action passée → subjonctif passé."),
      fill("Mi dispiace che voi non ___ venuti. (essere)", ["siate"], "che voi siate venuti."),
      mcq("Sono sicuro che lui ___ la verità.", ["abbia detto", "ha detto", "dica", "avesse detto"], 1, "Certitude → indicatif."),
      fill("Spero che tu ___ dormito bene. (avere)", ["abbia"], "che tu abbia dormito."),
      mcq("Choisissez la phrase correcte :", ["Credo che hanno ragione.", "Credo che abbiano ragione.", "Credo che avranno avuto ragione.", "Credo che abbia avuti ragione."], 1, "credo che + subjonctif présent (fait actuel)."),
      mcq("È possibile che il treno ___ già ___.", ["è / partito", "sia / partito", "abbia / partito", "sia / partita"], 1, "partire → essere ; il treno est masculin."),
      tr("Traduisez : Je ne crois pas qu'il ait compris.", ["non credo che abbia capito"], "non credo che + subjonctif passé."),
    ],
  },

  /* ------------------------------------------------------------ 5 */
  {
    id: "b2-congiunzioni", module: "gram", title: "Benché, purché, affinché : conjonctions + subjonctif", emoji: "🔗",
    intro: "Certaines conjonctions imposent toujours le subjonctif. Les maîtriser, c'est le signe d'un italien vraiment avancé.",
    sections: [
      {
        title: "Concession : bien que, même si",
        text: "<b>Benché</b>, <b>sebbene</b>, <b>nonostante</b>, <b>malgrado</b> = bien que → subjonctif. Mais <b>anche se</b> (même si) prend l'indicatif !",
        examples: [["Benché sia stanco, continuo a lavorare.", "Bien que je sois fatigué, je continue à travailler."], ["Nonostante piovesse, siamo usciti.", "Malgré la pluie, nous sommes sortis."], ["Anche se è tardi, ti chiamo.", "Même s'il est tard, je t'appelle (indicatif)."]],
      },
      {
        title: "Condition et but",
        text: "<b>Purché</b>, <b>a patto che</b>, <b>a condizione che</b> = à condition que ; <b>affinché</b>, <b>perché</b> (+ subjonctif) = pour que ; <b>a meno che (non)</b> = à moins que.",
        examples: [["Ti presto la macchina purché tu la riporti stasera.", "Je te prête la voiture à condition que tu la ramènes ce soir."], ["Parlo piano affinché tutti capiscano.", "Je parle lentement pour que tout le monde comprenne."], ["Vengo, a meno che non piova.", "Je viens, à moins qu'il ne pleuve."]],
      },
      {
        title: "Le temps : prima che, senza che",
        text: "<b>Prima che</b> (avant que) et <b>senza che</b> (sans que) prennent le subjonctif quand les sujets sont différents. Même sujet → <b>prima di / senza</b> + infinitif.",
        examples: [["Torna prima che faccia buio.", "Rentre avant qu'il fasse nuit."], ["È uscito senza che nessuno se ne accorgesse.", "Il est sorti sans que personne s'en aperçoive."], ["Mangio prima di uscire.", "Je mange avant de sortir (même sujet)."]],
      },
    ],
    mnemo: "Les conjonctions en -ché (benché, purché, affinché) « attachent » toujours le subjonctif. Anche se, lui, reste libre : indicatif.",
    vocab: [["benché", "bien que"], ["sebbene", "bien que"], ["nonostante", "bien que, malgré"], ["purché", "pourvu que, à condition que"], ["affinché", "afin que"], ["a meno che", "à moins que"], ["prima che", "avant que"], ["senza che", "sans que"], ["anche se", "même si"], ["accorgersi", "s'apercevoir"]],
    quiz: [
      mcq("Benché ___ freddo, andiamo al mare.", ["fa", "faccia", "farà", "farebbe"], 1, "benché + subjonctif."),
      mcq("Anche se ___ freddo, andiamo al mare.", ["fa", "faccia", "facesse", "abbia fatto"], 0, "anche se + indicatif."),
      fill("Ti aiuto purché tu mi ___ . (ascoltare)", ["ascolti"], "purché + subjonctif présent : ascolti."),
      mcq("« Avant de partir » (même sujet) :", ["prima che partire", "prima di partire", "prima che parta", "avanti partire"], 1, "même sujet → prima di + infinitif."),
      fill("Te lo ripeto affinché tu lo ___ . (capire)", ["capisca"], "capire → che tu capisca."),
      match("Associez", [["benché", "bien que"], ["purché", "à condition que"], ["affinché", "afin que"], ["senza che", "sans que"]]),
      tr("Traduisez : Je viens, à moins qu'il ne pleuve.", ["vengo a meno che non piova", "vengo, a meno che non piova", "vengo a meno che piova"], "a meno che (non) + subjonctif."),
    ],
  },

  /* ------------------------------------------------------------ 6 */
  {
    id: "b2-ipotetico-passato", module: "gram", title: "Si j'avais su… : l'hypothèse irréelle du passé", emoji: "🔀",
    intro: "Regretter, imaginer ce qui se serait passé : c'est la troisième construction hypothétique, avec le plus-que-parfait du subjonctif.",
    sections: [
      {
        title: "Se + subjonctif plus-que-parfait → conditionnel passé",
        text: "Le subjonctif plus-que-parfait = <b>avessi / fossi</b> + participe. Le conditionnel passé = <b>avrei / sarei</b> + participe.",
        examples: [["Se avessi saputo, sarei venuto.", "Si j'avais su, je serais venu."], ["Se fossimo partiti prima, non avremmo perso il treno.", "Si nous étions partis plus tôt, nous n'aurions pas raté le train."], ["Se mi avessi chiamato, ti avrei aiutato.", "Si tu m'avais appelé, je t'aurais aidé."]],
      },
      {
        title: "L'hypothèse mixte",
        text: "Une condition passée peut avoir une conséquence PRÉSENTE : se + plus-que-parfait du subjonctif → conditionnel présent.",
        examples: [["Se avessi studiato di più, adesso parlerei meglio.", "Si j'avais étudié davantage, je parlerais mieux maintenant."], ["Se non fosse piovuto, ora saremmo al mare.", "S'il n'avait pas plu, nous serions à la mer maintenant."]],
      },
      {
        title: "À l'oral : l'imparfait partout",
        text: "Dans la conversation familière, on entend souvent l'imparfait de l'indicatif dans les deux parties : <i>Se lo sapevo, venivo</i>. À éviter à l'écrit et à l'examen.",
        examples: [["Se lo sapevo, venivo. (familier)", "Si je l'avais su, je serais venu."], ["Se lo avessi saputo, sarei venuto. (soutenu)", "Si je l'avais su, je serais venu."]],
      },
    ],
    mnemo: "Jamais de conditionnel après « se » : se avessi saputo, jamais « se avrei saputo ».",
    vocab: [["sapere", "savoir"], ["perdere il treno", "rater le train"], ["aiutare", "aider"], ["di più", "davantage"], ["adesso", "maintenant"], ["peccato!", "dommage !"], ["il rimpianto", "le regret"], ["magari", "si seulement, peut-être"]],
    quiz: [
      mcq("Se ___ prima, avremmo trovato posto.", ["arriviamo", "saremmo arrivati", "fossimo arrivati", "eravamo arrivati"], 2, "se + subjonctif plus-que-parfait."),
      fill("Se mi avessi chiesto, ti ___ aiutato. (avere)", ["avrei"], "conditionnel passé : avrei aiutato."),
      mcq("Quelle erreur faut-il éviter ?", ["Se avessi saputo, sarei venuto.", "Se avrei saputo, sarei venuto.", "Se lo avessi visto, gli avrei parlato.", "Se fossi stato lì, avrei capito."], 1, "Jamais de conditionnel après se."),
      mcq("Se non avessi perso il lavoro, ora ___ più tranquillo.", ["sarei", "sarei stato", "fossi", "ero"], 0, "Conséquence présente → conditionnel présent."),
      fill("Se ___ partite in tempo, sareste arrivate. (voi, essere)", ["foste"], "fossi, fossi, fosse, fossimo, foste, fossero."),
      tr("Traduisez : Si j'avais su, je serais venu.", ["se avessi saputo sarei venuto", "se avessi saputo, sarei venuto", "se lo avessi saputo sarei venuto"], "se + avessi saputo → sarei venuto."),
    ],
  },

  /* ------------------------------------------------------------ 7 */
  {
    id: "b2-condizionale-passato", module: "conj", title: "J'aurais voulu… et le futur dans le passé", emoji: "🔮",
    intro: "Le conditionnel passé exprime un regret ou un projet non réalisé. En italien, il sert aussi là où le français utilise le conditionnel présent : « il a dit qu'il viendrait ».",
    sections: [
      {
        title: "Formation et regret",
        text: "Conditionnel de avere / essere + participe : <b>avrei voluto</b>, <b>sarei andato</b>. Avec dovere, potere, volere, il exprime ce qu'on n'a pas fait.",
        examples: [["Avrei voluto vederti.", "J'aurais voulu te voir."], ["Saremmo andati volentieri.", "Nous y serions allés volontiers."], ["Avresti dovuto dirmelo.", "Tu aurais dû me le dire."]],
      },
      {
        title: "Le futur dans le passé : la grande différence avec le français",
        text: "Après un verbe au passé (<i>ha detto, pensavo, sapevo</i>), une action future se met au <b>conditionnel PASSÉ</b> en italien, là où le français dit « viendrait ».",
        examples: [["Ha detto che sarebbe venuto.", "Il a dit qu'il viendrait."], ["Pensavo che avresti chiamato.", "Je pensais que tu appellerais."], ["Sapevo che avrebbe vinto.", "Je savais qu'il gagnerait."]],
      },
      {
        title: "Information non confirmée",
        text: "Comme en français, le conditionnel sert dans les médias pour une information non vérifiée.",
        examples: [["Secondo i giornali, il ministro avrebbe dato le dimissioni.", "D'après les journaux, le ministre aurait démissionné."], ["L'incendio sarebbe partito da una cucina.", "L'incendie serait parti d'une cuisine."]],
      },
    ],
    mnemo: "« Il a dit qu'il viendrait » = Ha detto che SAREBBE VENUTO. Passé + futur → conditionnel passé, toujours.",
    vocab: [["volentieri", "volontiers"], ["dovere", "devoir"], ["promettere", "promettre"], ["vincere", "gagner"], ["il giornale", "le journal"], ["dare le dimissioni", "démissionner"], ["l'incendio", "l'incendie"], ["secondo", "selon"]],
    quiz: [
      mcq("Mi ha promesso che ___ alle otto.", ["arriverebbe", "sarebbe arrivato", "arriverà", "arrivasse"], 1, "Futur dans le passé → conditionnel passé."),
      fill("___ dovuto studiare di più. (io, avere)", ["Avrei", "avrei"], "Regret : avrei dovuto."),
      mcq("« Tu aurais pu m'appeler » :", ["Potresti chiamarmi.", "Avresti potuto chiamarmi.", "Avevi potuto chiamarmi.", "Potevi chiamarmi stato."], 1, "Conditionnel passé de potere."),
      mcq("Pensavamo che voi ___ .", ["sareste venuti", "verreste", "venite", "verrete"], 0, "Conditionnel passé après pensavamo."),
      fill("Secondo la polizia, il ladro ___ fuggito in moto. (essere)", ["sarebbe"], "Information non confirmée."),
      tr("Traduisez : Il a dit qu'il viendrait.", ["ha detto che sarebbe venuto", "ha detto che verrebbe"], "En bon italien : sarebbe venuto."),
    ],
  },

  /* ------------------------------------------------------------ 8 */
  {
    id: "b2-futuro-anteriore", module: "conj", title: "Quand j'aurai fini… : futur antérieur et probabilité", emoji: "🕰️",
    intro: "Le futur antérieur situe une action avant une autre dans l'avenir. Et en italien, le futur sert aussi à faire des suppositions.",
    sections: [
      {
        title: "Formation et usage",
        text: "Futur de avere / essere + participe : <b>avrò finito</b>, <b>sarò arrivato</b>. Après <b>quando, appena, dopo che</b>, l'italien l'emploie comme le français.",
        examples: [["Quando avrò finito, ti chiamerò.", "Quand j'aurai fini, je t'appellerai."], ["Appena sarete arrivati, mangeremo.", "Dès que vous serez arrivés, nous mangerons."], ["Entro giugno avremo traslocato.", "D'ici juin, nous aurons déménagé."]],
      },
      {
        title: "Le futur de probabilité",
        text: "Pour une supposition sur le présent, on utilise le <b>futur simple</b> ; sur le passé, le <b>futur antérieur</b>. Le français dit « doit / a dû ».",
        examples: [["Che ore sono? — Saranno le dieci.", "Quelle heure est-il ? — Il doit être dix heures."], ["Marco non risponde: starà dormendo.", "Marco ne répond pas : il doit être en train de dormir."], ["Avrà perso il treno.", "Il a dû rater le train."]],
      },
      {
        title: "Questions qu'on se pose",
        text: "Le futur exprime aussi l'incertitude dans une question : « je me demande… ».",
        examples: [["Dove sarà andata?", "Où a-t-elle bien pu aller ?"], ["Chi sarà a quest'ora?", "Qui ça peut bien être, à cette heure-ci ?"]],
      },
    ],
    mnemo: "« Saranno le dieci » : le futur italien est un haussement d'épaules. Sur le passé : avrà perso = il a dû perdre.",
    vocab: [["appena", "dès que"], ["entro", "d'ici, avant"], ["traslocare", "déménager"], ["dopo che", "après que"], ["a quest'ora", "à cette heure-ci"], ["probabilmente", "probablement"], ["chissà", "qui sait"], ["dimenticare", "oublier"]],
    quiz: [
      mcq("Quando ___ i compiti, potrai uscire.", ["avrai fatto", "hai fatto", "farai fatto", "avessi fatto"], 0, "Futur antérieur après quando."),
      mcq("Il est probablement 8 h : « ___ le otto. »", ["Sono", "Saranno", "Sarebbero", "Siano"], 1, "Futur de probabilité."),
      fill("Non trovo le chiavi: le ___ dimenticate in ufficio. (avere)", ["avrò"], "Supposition sur le passé : futur antérieur."),
      mcq("« Il a dû se tromper » :", ["Si sarà sbagliato.", "Si è sbagliato dovuto.", "Si sbaglierebbe.", "Si fosse sbagliato."], 0, "Futur antérieur de probabilité."),
      fill("Appena ___ arrivata, ti scriverò. (io, essere)", ["sarò"], "sarò arrivata."),
      tr("Traduisez : Quand j'aurai fini, je t'appellerai.", ["quando avrò finito ti chiamerò", "quando avrò finito, ti chiamerò"], "avrò finito… chiamerò."),
    ],
  },

  /* ------------------------------------------------------------ 9 */
  {
    id: "b2-passivo", module: "gram", title: "La voix passive : essere, venire, andare, si", emoji: "🔄",
    intro: "L'italien a quatre façons de construire le passif, chacune avec sa nuance. Indispensable pour lire la presse.",
    sections: [
      {
        title: "Essere et venire + participe",
        text: "<b>Essere</b> + participe (accordé) comme en français. <b>Venire</b> le remplace aux temps simples pour insister sur l'action : <i>la porta viene chiusa</i> (on la ferme) ≠ <i>la porta è chiusa</i> (elle est fermée). L'agent est introduit par <b>da</b>.",
        examples: [["Il romanzo è stato scritto da Elsa Morante.", "Le roman a été écrit par Elsa Morante."], ["Le lettere vengono spedite ogni mattina.", "Les lettres sont envoyées chaque matin."], ["Il ladro è stato arrestato dalla polizia.", "Le voleur a été arrêté par la police."]],
      },
      {
        title: "Andare + participe : l'obligation",
        text: "<b>Andare</b> + participe = « doit être » : <i>questo modulo va compilato</i> = ce formulaire doit être rempli.",
        examples: [["Il biglietto va convalidato prima di salire.", "Le billet doit être composté avant de monter."], ["Queste regole vanno rispettate.", "Ces règles doivent être respectées."]],
      },
      {
        title: "Le si passivant",
        text: "<b>Si</b> + verbe à la 3e personne, accordé avec le sujet : <i>si vende</i> (singulier), <i>si vendono</i> (pluriel). Très courant sur les panneaux et dans les recettes.",
        examples: [["Qui si parla inglese.", "Ici, on parle anglais."], ["Si affittano appartamenti.", "Appartements à louer."], ["Le cipolle si tagliano a fettine.", "On coupe les oignons en fines tranches."]],
      },
    ],
    mnemo: "VENIRE = l'action en cours, ESSERE = le résultat, ANDARE = l'obligation, SI = « on ».",
    vocab: [["scrivere", "écrire"], ["spedire", "envoyer, expédier"], ["arrestare", "arrêter"], ["convalidare", "composter, valider"], ["il modulo", "le formulaire"], ["compilare", "remplir (un formulaire)"], ["affittare", "louer"], ["rispettare", "respecter"]],
    quiz: [
      mcq("La Gioconda ___ da Leonardo.", ["ha dipinto", "è stata dipinta", "è stato dipinto", "si è dipinta"], 1, "Passif : è stata dipinta (féminin)."),
      mcq("« Ce formulaire doit être rempli » :", ["Questo modulo viene compilato.", "Questo modulo va compilato.", "Questo modulo si compila.", "Questo modulo ha compilato."], 1, "andare + participe = obligation."),
      fill("In questo negozio si ___ libri usati. (vendere)", ["vendono"], "Pluriel : si vendono."),
      mcq("Le notizie ___ trasmesse ogni ora.", ["vengono", "vanno", "hanno", "sono state stati"], 0, "venire = action habituelle."),
      fill("Il ponte è stato costruito ___ Romani.", ["dai"], "Agent : da + i = dai."),
      match("Associez", [["si affitta", "à louer"], ["va rispettato", "doit être respecté"], ["viene spedito", "est envoyé"], ["è stato scritto", "a été écrit"]]),
      tr("Traduisez : Ici, on parle anglais.", ["qui si parla inglese"], "Si impersonnel / passivant."),
    ],
  },

  /* ------------------------------------------------------------ 10 */
  {
    id: "b2-gerundio", module: "conj", title: "Le gérondif et le participe : sbagliando s'impara", emoji: "🏃",
    intro: "Le gérondif italien est plus riche que le français : il exprime la cause, le moyen, la condition ou la simultanéité, sans « en ».",
    sections: [
      {
        title: "Formation",
        text: "<b>-ando</b> pour les verbes en -are, <b>-endo</b> pour -ere et -ire : <i>parlando, leggendo, partendo</i>. Irréguliers : <i>facendo, dicendo, bevendo</i>. Gérondif passé : <b>avendo / essendo</b> + participe.",
        examples: [["Sbagliando s'impara.", "C'est en se trompant qu'on apprend."], ["Leggendo il giornale, ho scoperto la notizia.", "En lisant le journal, j'ai découvert la nouvelle."], ["Avendo finito il lavoro, sono uscito.", "Ayant fini le travail, je suis sorti."]],
      },
      {
        title: "Ce que le gérondif exprime",
        text: "Le gérondif a toujours le <b>même sujet</b> que le verbe principal. Il peut indiquer la manière, la cause ou la condition.",
        examples: [["Studiando ogni giorno, migliorerai.", "En étudiant chaque jour, tu progresseras (condition)."], ["Essendo stanca, è andata a letto presto.", "Comme elle était fatiguée, elle s'est couchée tôt (cause)."], ["Camminava cantando.", "Il marchait en chantant (manière)."]],
      },
      {
        title: "Le participe passé seul",
        text: "À l'écrit, le participe passé seul remplace une subordonnée : <i>finita la cena</i> = une fois le dîner terminé. Il s'accorde avec le nom.",
        examples: [["Finita la lezione, gli studenti sono usciti.", "Une fois le cours terminé, les étudiants sont sortis."], ["Arrivati a Roma, abbiamo cercato l'albergo.", "Arrivés à Rome, nous avons cherché l'hôtel."]],
      },
    ],
    mnemo: "Le gérondif italien n'a pas besoin de « en » : parlando = en parlant.",
    vocab: [["sbagliare", "se tromper"], ["imparare", "apprendre"], ["scoprire", "découvrir"], ["migliorare", "s'améliorer"], ["camminare", "marcher"], ["cantare", "chanter"], ["la lezione", "le cours"], ["l'albergo", "l'hôtel"]],
    quiz: [
      fill("Ho imparato l'italiano ___ film. (guardare)", ["guardando"], "-are → -ando."),
      mcq("Gérondif de « fare » :", ["fando", "facendo", "farendo", "fatto"], 1, "fare → facendo (de facere)."),
      mcq("« Ayant compris, il est parti » :", ["Capendo, è partito.", "Avendo capito, è partito.", "Essendo capito, è partito.", "Capito avendo, è partito."], 1, "Gérondif passé : avendo + participe."),
      fill("___ malata, Sara è rimasta a casa. (essere, cause)", ["Essendo"], "Gérondif de essere : essendo."),
      mcq("Finit___ la partita, siamo tornati a casa.", ["o", "a", "e", "i"], 1, "la partita → finita."),
      tr("Traduisez : C'est en se trompant qu'on apprend.", ["sbagliando s'impara", "sbagliando si impara"], "Proverbe très courant."),
    ],
  },

  /* ------------------------------------------------------------ 11 */
  {
    id: "b2-relativi-avanzati", module: "gram", title: "Il quale, il cui, ciò che : les relatifs avancés", emoji: "🧷",
    intro: "Pour des phrases plus précises et un italien soutenu : il quale, il cui (dont), ciò che (ce que) et chi (celui qui).",
    sections: [
      {
        title: "Il quale, la quale, i quali, le quali",
        text: "Il remplace <b>che</b> ou <b>cui</b> pour éviter une ambiguïté, surtout à l'écrit, et s'accorde avec le nom. Avec préposition : <i>al quale, della quale, con i quali</i>.",
        examples: [["Ho parlato con la sorella di Marco, la quale vive a Napoli.", "J'ai parlé avec la sœur de Marco, laquelle vit à Naples."], ["È un problema al quale non avevo pensato.", "C'est un problème auquel je n'avais pas pensé."]],
      },
      {
        title: "Il cui = dont (possession)",
        text: "<b>Article + cui + nom</b> : l'article s'accorde avec ce qui est possédé, pas avec le possesseur.",
        examples: [["Lo scrittore, il cui libro ho letto, viene domani.", "L'écrivain dont j'ai lu le livre vient demain."], ["La città, le cui strade sono strette, è antica.", "La ville, dont les rues sont étroites, est ancienne."]],
      },
      {
        title: "Ciò che / quello che, chi",
        text: "<b>Ciò che</b> (soutenu) et <b>quello che</b> = ce que, ce qui. <b>Chi</b> = celui qui, ceux qui, toujours suivi du singulier.",
        examples: [["Non capisco ciò che dici.", "Je ne comprends pas ce que tu dis."], ["Chi cerca trova.", "Qui cherche trouve."], ["Chi vuole venire deve iscriversi.", "Ceux qui veulent venir doivent s'inscrire."]],
      },
    ],
    mnemo: "Il cui : l'article regarde vers la droite (il cui LIBRO), pas vers la gauche.",
    vocab: [["lo scrittore", "l'écrivain"], ["stretto", "étroit"], ["antico", "ancien"], ["iscriversi", "s'inscrire"], ["pensare a", "penser à"], ["il problema", "le problème"], ["cercare", "chercher"], ["trovare", "trouver"]],
    quiz: [
      mcq("La ragazza, ___ padre è medico, studia legge.", ["che", "il cui", "la cui", "di cui il"], 1, "il cui padre : l'article s'accorde avec padre."),
      mcq("Non è ___ volevo dire.", ["che", "ciò che", "chi", "il quale"], 1, "ciò che = ce que."),
      fill("___ arriva tardi non entra. (celui qui)", ["Chi", "chi"], "chi + singulier."),
      mcq("I colleghi con ___ lavoro sono simpatici.", ["che", "i quali", "il quale", "le quali"], 1, "con i quali (colleghi, masculin pluriel)."),
      mcq("La casa, ___ finestre danno sul mare, è in vendita.", ["la cui", "le cui", "i cui", "il cui"], 1, "le cui finestre."),
      tr("Traduisez : Qui cherche trouve.", ["chi cerca trova"], "Proverbe."),
    ],
  },

  /* ------------------------------------------------------------ 12 */
  {
    id: "b2-verbi-preposizioni", module: "gram", title: "Pensare a, riuscire a, smettere di : verbes et prépositions", emoji: "🧭",
    intro: "Beaucoup d'erreurs de niveau B2 viennent des prépositions après les verbes. Voici les plus fréquentes, souvent différentes du français.",
    sections: [
      {
        title: "Verbe + a + infinitif",
        text: "<b>riuscire a</b> (réussir à), <b>cominciare a</b>, <b>continuare a</b>, <b>abituarsi a</b>, <b>aiutare a</b>, <b>imparare a</b>, <b>provare a</b> (essayer de !).",
        examples: [["Non riesco a dormire.", "Je n'arrive pas à dormir."], ["Prova a chiamarlo.", "Essaie de l'appeler."], ["Mi sono abituato a svegliarmi presto.", "Je me suis habitué à me lever tôt."]],
      },
      {
        title: "Verbe + di + infinitif",
        text: "<b>smettere di</b> (arrêter de), <b>cercare di</b> (essayer de), <b>decidere di</b>, <b>finire di</b>, <b>ricordarsi di</b>, <b>avere bisogno di</b>, <b>sperare di</b>.",
        examples: [["Ho smesso di fumare.", "J'ai arrêté de fumer."], ["Cerca di arrivare in orario.", "Essaie d'arriver à l'heure."], ["Ricordati di comprare il pane.", "Pense à acheter du pain."]],
      },
      {
        title: "Les pièges avec un nom",
        text: "<b>pensare a qualcuno</b> (penser à) mais <b>pensare di</b> + infinitif (penser faire) ; <b>dipendere da</b> (dépendre de) ; <b>innamorarsi di</b> (tomber amoureux de) ; <b>fidarsi di</b> (faire confiance à).",
        examples: [["Penso spesso a te.", "Je pense souvent à toi."], ["Penso di partire domani.", "Je pense partir demain."], ["Dipende da te.", "Ça dépend de toi."], ["Mi fido di lei.", "Je lui fais confiance."]],
      },
    ],
    mnemo: "« Essayer » a deux formes : provare A (tenter un essai) et cercare DI (s'efforcer de).",
    vocab: [["riuscire a", "réussir à, arriver à"], ["provare a", "essayer de"], ["cercare di", "essayer de, s'efforcer de"], ["smettere di", "arrêter de"], ["abituarsi a", "s'habituer à"], ["dipendere da", "dépendre de"], ["fidarsi di", "faire confiance à"], ["innamorarsi di", "tomber amoureux de"], ["ricordarsi di", "se souvenir de, penser à"]],
    quiz: [
      fill("Non riesco ___ capire.", ["a"], "riuscire a."),
      fill("Ho deciso ___ cambiare lavoro.", ["di"], "decidere di."),
      mcq("« Ça dépend de toi » :", ["Dipende di te.", "Dipende da te.", "Dipende a te.", "Dipende per te."], 1, "dipendere da."),
      mcq("« Je pense à toi » :", ["Penso di te.", "Penso a te.", "Penso te.", "Penso da te."], 1, "pensare a qualcuno."),
      fill("Smetti ___ lamentarti!", ["di"], "smettere di."),
      match("Associez", [["fidarsi di", "faire confiance à"], ["abituarsi a", "s'habituer à"], ["innamorarsi di", "tomber amoureux de"], ["cominciare a", "commencer à"]]),
      tr("Traduisez : J'ai arrêté de fumer.", ["ho smesso di fumare"], "smettere di."),
    ],
  },

  /* ------------------------------------------------------------ 13 */
  {
    id: "b2-email-formale", module: "expr", title: "Écrire un e-mail formel et choisir son registre", emoji: "✉️",
    intro: "Au niveau B2, on attend une lettre ou un e-mail formel correct : formules d'appel, vouvoiement avec Lei, formules de politesse.",
    sections: [
      {
        title: "Ouvrir et fermer",
        text: "Ouverture : <b>Gentile dottoressa Rossi</b>, <b>Egregio signor Bianchi</b> (très formel), <b>Spettabile ditta</b> (une entreprise). Fermeture : <b>Cordiali saluti</b>, <b>Distinti saluti</b>, <b>In attesa di un Suo cortese riscontro</b>.",
        examples: [["Gentile signora Bianchi,", "Chère Madame Bianchi,"], ["La ringrazio per la Sua risposta.", "Je vous remercie pour votre réponse."], ["In attesa di un Suo cortese riscontro, porgo distinti saluti.", "Dans l'attente de votre réponse, je vous prie d'agréer mes salutations distinguées."]],
      },
      {
        title: "Formuler une demande avec politesse",
        text: "Conditionnel et subjonctif adoucissent la demande. Le <b>Lei</b> de politesse s'écrit souvent avec une majuscule à l'écrit formel : <i>La, Le, Suo</i>.",
        examples: [["Vorrei sapere se è possibile cambiare la data.", "Je voudrais savoir s'il est possible de changer la date."], ["Le sarei grato se potesse inviarmi il contratto.", "Je vous serais reconnaissant de bien vouloir m'envoyer le contrat."], ["Mi permetto di scriverLe per…", "Je me permets de vous écrire au sujet de…"]],
      },
      {
        title: "Formel ou familier ?",
        text: "Familier : <i>ciao, ci sentiamo, un abbraccio</i>. Neutre : <i>buongiorno, a presto</i>. Formel : <i>gentile, distinti saluti</i>. Entre collègues, <b>Ciao</b> + tutoiement est fréquent en Italie, même au travail.",
        examples: [["Ciao Marta, ci sentiamo domani!", "Salut Marta, on s'appelle demain !"], ["Buongiorno, Le scrivo per una informazione.", "Bonjour, je vous écris pour un renseignement."]],
      },
    ],
    mnemo: "Gentile (cher) pour ouvrir, Cordiali / Distinti saluti pour fermer : le sandwich de la politesse italienne.",
    vocab: [["gentile", "cher (en-tête), aimable"], ["egregio", "très honoré (en-tête formel)"], ["cordiali saluti", "cordialement"], ["distinti saluti", "salutations distinguées"], ["il riscontro", "la réponse (formel)"], ["grato", "reconnaissant"], ["allegare", "joindre (une pièce)"], ["l'allegato", "la pièce jointe"], ["la richiesta", "la demande"]],
    quiz: [
      mcq("Pour ouvrir un e-mail à une avocate inconnue :", ["Ciao Avvocato!", "Gentile avvocata Verdi,", "Ehi Verdi,", "Cara amica,"], 1, "Gentile + titre + nom."),
      mcq("Formule de fin formelle :", ["Un bacio", "A dopo", "Distinti saluti", "Ci vediamo"], 2, "Distinti saluti / Cordiali saluti."),
      fill("Le sarei grato se ___ rispondermi entro venerdì. (potere, Lei)", ["potesse"], "se + subjonctif imparfait : potesse."),
      mcq("« Vous trouverez en pièce jointe le CV » :", ["In allegato trova il curriculum.", "Allegato Lei il curriculum.", "Il curriculum è attaccato.", "Ti mando il curriculum attaccato."], 0, "In allegato = en pièce jointe."),
      match("Associez", [["il riscontro", "la réponse"], ["l'allegato", "la pièce jointe"], ["la richiesta", "la demande"], ["grato", "reconnaissant"]]),
      tr("Traduisez : Je vous remercie pour votre réponse.", ["la ringrazio per la sua risposta", "la ringrazio per la risposta"], "Lei → La ringrazio."),
    ],
  },

  /* ------------------------------------------------------------ 14 */
  {
    id: "b2-attualita", module: "vocab", title: "Actualité et société : débattre d'un sujet", emoji: "📰",
    intro: "Lire un article, comprendre un journal télévisé, donner son avis sur un sujet de société : le vocabulaire indispensable du B2.",
    sections: [
      {
        title: "Politique et économie",
        examples: [["il governo", "le gouvernement"], ["le elezioni", "les élections"], ["la legge", "la loi"], ["la crisi economica", "la crise économique"], ["la disoccupazione", "le chômage"], ["le tasse", "les impôts"]],
      },
      {
        title: "Société",
        examples: [["l'immigrazione", "l'immigration"], ["l'invecchiamento della popolazione", "le vieillissement de la population"], ["la parità di genere", "l'égalité femmes-hommes"], ["il cambiamento climatico", "le changement climatique"], ["la fuga dei cervelli", "la fuite des cerveaux"]],
      },
      {
        title: "Débattre",
        text: "Pour nuancer : <b>da un lato… dall'altro</b> (d'un côté… de l'autre), <b>in realtà</b>, <b>tuttavia</b> (cependant), <b>inoltre</b> (en outre), <b>per quanto riguarda</b> (en ce qui concerne), <b>in conclusione</b>.",
        examples: [["Da un lato il turismo crea lavoro, dall'altro inquina.", "D'un côté le tourisme crée des emplois, de l'autre il pollue."], ["Per quanto riguarda le tasse, il governo non ha deciso niente.", "En ce qui concerne les impôts, le gouvernement n'a rien décidé."], ["Molti giovani laureati vanno all'estero.", "Beaucoup de jeunes diplômés partent à l'étranger."]],
      },
    ],
    mnemo: "La « fuga dei cervelli » (fuite des cerveaux) est un vrai sujet en Italie : près de 100 000 Italiens partent chaque année à l'étranger.",
    vocab: [["il governo", "le gouvernement"], ["la legge", "la loi"], ["le elezioni", "les élections"], ["la disoccupazione", "le chômage"], ["le tasse", "les impôts"], ["la popolazione", "la population"], ["inquinare", "polluer"], ["tuttavia", "cependant"], ["inoltre", "en outre"], ["all'estero", "à l'étranger"], ["laureato", "diplômé (université)"]],
    quiz: [
      match("Associez", [["la disoccupazione", "le chômage"], ["le tasse", "les impôts"], ["la legge", "la loi"], ["il governo", "le gouvernement"]]),
      mcq("« D'un côté… de l'autre » :", ["prima… poi", "da un lato… dall'altro", "sia… sia", "né… né"], 1, "da un lato… dall'altro."),
      fill("Molti giovani vanno a lavorare all'___ . (étranger)", ["estero"], "all'estero."),
      mcq("« La fuga dei cervelli » signifie :", ["la fuite des cerveaux", "la folie des grandeurs", "la course aux diplômes", "la grève des chercheurs"], 0, "Le départ des diplômés à l'étranger."),
      mcq("« Cependant » au registre soutenu :", ["però", "tuttavia", "anzi", "cioè"], 1, "tuttavia (però est plus courant)."),
      tr("Traduisez : le changement climatique", ["il cambiamento climatico", "cambiamento climatico"], "il cambiamento climatico."),
    ],
  },

  /* ------------------------------------------------------------ 15 */
  {
    id: "b2-cultura", module: "vocab", title: "Arts, cinéma et littérature", emoji: "🎭",
    intro: "Parler d'un film, d'un livre ou d'une exposition, et connaître quelques grands noms de la culture italienne.",
    sections: [
      {
        title: "Cinéma et livres",
        examples: [["il regista", "le réalisateur"], ["la trama", "l'intrigue"], ["il protagonista", "le personnage principal"], ["la recensione", "la critique (d'un film, d'un livre)"], ["il romanzo", "le roman"], ["l'autore / l'autrice", "l'auteur / l'autrice"]],
      },
      {
        title: "Donner son avis",
        examples: [["Il film mi è piaciuto moltissimo.", "Le film m'a énormément plu."], ["La trama è un po' scontata.", "L'intrigue est un peu prévisible."], ["Te lo consiglio vivamente.", "Je te le recommande vivement."], ["Mi ha lasciato senza parole.", "Ça m'a laissé sans voix."]],
      },
      {
        title: "Quelques repères",
        text: "Cinéma : <b>Fellini</b> (<i>La dolce vita</i>), <b>Benigni</b> (<i>La vita è bella</i>), <b>Sorrentino</b> (<i>La grande bellezza</i>). Littérature : <b>Dante</b>, <b>Calvino</b>, <b>Elena Ferrante</b> (<i>L'amica geniale</i>). Art : la <b>Galleria degli Uffizi</b> à Florence.",
        examples: [["Hai visto La grande bellezza?", "Tu as vu La Grande Bellezza ?"], ["L'amica geniale è ambientato a Napoli.", "L'Amie prodigieuse se déroule à Naples."]],
      },
    ],
    mnemo: "Attention : il regista = le réalisateur (pas le régisseur).",
    vocab: [["il regista", "le réalisateur"], ["la trama", "l'intrigue"], ["la recensione", "la critique"], ["il romanzo", "le roman"], ["la mostra", "l'exposition"], ["il quadro", "le tableau"], ["scontato", "prévisible"], ["consigliare", "conseiller, recommander"], ["ambientato", "qui se déroule (à)"]],
    quiz: [
      mcq("« Il regista » est :", ["le régisseur", "le réalisateur", "le registre", "l'acteur"], 1, "Faux ami : regista = réalisateur."),
      match("Associez", [["la trama", "l'intrigue"], ["la mostra", "l'exposition"], ["il quadro", "le tableau"], ["la recensione", "la critique"]]),
      fill("Il film mi è ___ molto. (piacere, participe)", ["piaciuto"], "piacere → piaciuto (avec essere)."),
      mcq("Qui a réalisé « La vita è bella » ?", ["Fellini", "Benigni", "Sorrentino", "Calvino"], 1, "Roberto Benigni, Oscar 1999."),
      mcq("« Une fin prévisible » :", ["un finale scontato", "un finale sconto", "un finale scontrato", "un finale contato"], 0, "scontato = prévisible."),
      tr("Traduisez : Je te le recommande vivement.", ["te lo consiglio vivamente", "te lo consiglio"], "consigliare."),
    ],
  },
];

export const B2_EXAM_PLUS = [
  mcq("Penso che Giulia ___ ieri.", ["è partita", "sia partita", "parta", "partirebbe"], 1, "Subjonctif passé."),
  mcq("Benché ___ tardi, ho continuato a lavorare.", ["era", "fosse", "sarebbe", "è stato"], 1, "benché + subjonctif."),
  fill("Se avessi avuto tempo, ___ venuto. (essere)", ["sarei"], "Hypothèse irréelle du passé."),
  mcq("Ha detto che ___ il giorno dopo.", ["tornerebbe", "sarebbe tornato", "tornerà", "tornasse"], 1, "Futur dans le passé."),
  mcq("Il biglietto ___ convalidato.", ["va", "ha", "è stata", "viene stato"], 0, "andare + participe = doit être."),
  fill("___ sbagliato, ho chiesto scusa. (avere, gérondif passé)", ["Avendo"], "Avendo sbagliato."),
  mcq("L'uomo, ___ figli vivono a Milano, è mio zio.", ["che", "il cui", "i cui", "di cui i"], 2, "i cui figli."),
  fill("Non riesco ___ smettere di fumare.", ["a"], "riuscire a + infinitif."),
  mcq("Formule de fin d'un e-mail formel :", ["Baci", "Distinti saluti", "Ciao ciao", "A dopo"], 1, "Distinti saluti."),
  tr("Traduisez : Il doit être dix heures.", ["saranno le dieci"], "Futur de probabilité."),
];
