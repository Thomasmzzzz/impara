/* =====================================================================
   Nouveautés (Paramètres › Nouveautés)
   À chaque mise à jour : ajouter une entrée EN HAUT de la liste, avec la
   date et l'heure de mise en ligne (heure de Paris), un titre court et
   ce qui change pour l'utilisateur (pas de détails techniques).
   lang : "it" / "zh" si la nouveauté ne concerne qu'une langue.
   ===================================================================== */
export const CHANGELOG = [
  {
    at: "2026-11-04T23:54", emoji: "📋", title: "Vos erreurs en fin de quiz",
    items: [
      "À la fin d'un quiz, d'un examen ou d'un entraînement : la liste de vos erreurs avec votre réponse, la bonne réponse, l'explication et un bouton pour l'écouter.",
    ],
  },
  {
    at: "2026-11-04T23:54", emoji: "🎨", title: "Nouvelles icônes",
    items: [
      "Les petits symboles de l'interface (son, série, XP, cadenas, réglages…) sont maintenant des icônes dessinées, identiques sur tous les appareils.",
    ],
  },
  {
    at: "2026-11-04T23:24", emoji: "🃏", title: "Jokers pour les fautes de frappe",
    items: [
      "Examen de fin de palier : 3 jokers. Test de mi-palier : 2 jokers.",
      "Une réponse écrite avec une seule lettre fausse, en trop, manquante ou deux lettres inversées est acceptée et utilise un joker. Les jokers restants s'affichent en haut.",
    ],
  },
  {
    at: "2026-11-04T17:50", emoji: "🛡️", title: "Tests de palier plus exigeants",
    items: [
      "Test de mi-palier : 25 questions, sans aucune faute.",
      "Examen de fin de palier : 50 questions, sans aucune faute (l'examen blanc suit le même format).",
      "Les tests de mi-palier réussis avec l'ancien format (10 questions) sont à repasser.",
    ],
  },
  {
    at: "2026-11-04T17:50", emoji: "🛠️", title: "Corrections suite à vos signalements",
    items: [
      "Défi « sur son terrain » entre langues différentes : l'appli propose de passer dans la langue des mots du défi (avant, aucun mot n'était prononcé).",
      "Italien : la fin des mots courts n'est plus coupée net (« salve », « grazie »…), avec Sara comme avec Nicola.",
    ],
  },
  {
    at: "2026-11-04T16:45", emoji: "🃏", title: "Flashcards repensées",
    items: [
      "La carte est au centre de l'écran : glissez-la à droite si vous savez, à gauche si vous ne savez pas (ou touchez ✓ / ✕).",
      "Un seul bouton pour choisir le palier ; les réglages des cartes sont rangés sous la carte.",
    ],
  },
  {
    at: "2026-11-04T16:45", emoji: "🧭", title: "Test de niveau",
    items: [
      "Déjà des bases ? Un test de quelques minutes vous place directement au bon palier.",
      "Proposé à l'inscription, sur le parcours et dans Paramètres › Cours. Votre progression n'est jamais effacée.",
    ],
  },
  {
    at: "2026-11-04T16:45", emoji: "🚀", lang: "it", title: "Niveau B2 complet",
    items: [
      "12 nouvelles leçons : subjonctif passé, hypothèse dans le passé, conditionnel passé, futur antérieur, passif, gérondif, relatifs, verbes à préposition, e-mail formel, actualité, culture…",
      "Examen B2 enrichi, 2 nouvelles histoires et 2 nouveaux dialogues (réclamation à l'hôtel, location d'appartement).",
    ],
  },
  {
    at: "2026-11-04T16:45", emoji: "🚀", lang: "zh", title: "Niveau HSK 4 complet",
    items: [
      "13 nouvelles leçons : 无论 / 即使 / 既然, compléments potentiels, questions rhétoriques, 竟然 / 难怪, probabilité, connecteurs, voyage, numérique, société, fêtes, expressions orales…",
      "Examen HSK 4 enrichi, 2 nouvelles histoires et 2 nouveaux dialogues (réclamation à l'hôtel, location d'appartement).",
    ],
  },
  {
    at: "2026-11-04T14:30", emoji: "📣", title: "Page « Nouveautés »",
    items: ["Retrouvez ici chaque mise à jour de l'appli, avec sa date et son heure.", "Une pastille signale les nouveautés que vous n'avez pas encore vues."],
  },
  {
    at: "2026-11-04T14:13", emoji: "⚑", title: "Signaler un problème",
    items: [
      "Un bouton ⚑ en haut des leçons, quiz, défis, entraînements, histoires, dialogues, dictées et exercices de prononciation.",
      "Choisissez : mauvaise traduction, phrase mal formulée, mauvaise prononciation, réponse refusée à tort ou bug, et ajoutez un commentaire.",
      "La question affichée est envoyée avec le signalement pour pouvoir la corriger.",
    ],
  },
  {
    at: "2026-11-04T13:50", emoji: "🗣️", lang: "it", title: "Italien : mots courts bien prononcés",
    items: [
      "Les 1 616 mots et petites expressions (« uno », « chi », « piccolo », « la nonna »…) sont maintenant prononcés aussi naturellement que dans les phrases, avec Sara comme avec Nicola.",
    ],
  },
  {
    at: "2026-11-04T05:37", emoji: "🎶", lang: "zh", title: "Mandarin : voix plus naturelles",
    items: ["Plus de petit son parasite en fin de mot (« ni hao-é »).", "La hauteur de la voix reste stable sur les mots courts (儿子…)."],
  },
  {
    at: "2026-11-04T04:24", emoji: "⚔️", title: "Défis de 75 et 100 questions",
    items: ["Deux nouveaux formats : « Endurance » (75) et « Légende » (100).", "iPhone : un double appui ne zoome plus sur la page."],
  },
  {
    at: "2026-11-04T04:09", emoji: "🧩", title: "Exercices plus justes",
    items: ["Les petits dialogues des leçons (« Di dove sei? — Sono francese. ») sont séparés : chaque réplique a sa propre traduction, on peut donc toujours deviner la réponse."],
  },
  {
    at: "2026-11-04T03:36", emoji: "🔈", title: "Choix de la voix",
    items: ["Paramètres › Préférences › Son : « Voix utilisée » enregistrée ou voix de l'appareil (iPhone…).", "Mandarin : les versions d'origine des voix restent disponibles."],
  },
  {
    at: "2026-11-04T03:03", emoji: "🎙️", lang: "it", title: "Italien : nouvelle voix Nicola",
    items: ["Une voix d'homme en plus de Sara, au choix comme voix principale.", "Dans les dialogues et les histoires, chaque personnage a sa voix."],
  },
  {
    at: "2026-11-04T01:33", emoji: "🧭", title: "Onglet « Découvrir »",
    items: ["Nombre de joueurs, classement général d'XP et de la semaine, profils des autres joueurs.", "À activer dans Paramètres › Compte ; vous n'apparaissez dans le classement que si vous le choisissez."],
  },
  {
    at: "2026-11-04T00:33", emoji: "🀄", lang: "zh", title: "Mandarin : tons corrigés et nouvelle voix Yunxi",
    items: ["Les tons des enregistrements sont maintenant justes.", "Nouvelle voix d'homme Yunxi ; dans les dialogues et histoires, deux voix différentes."],
  },
  {
    at: "2026-11-03T21:49", emoji: "🎤", title: "Prononciation repensée",
    items: ["Mandarin : analyse de vos tons syllabe par syllabe, avec votre courbe à côté de la courbe attendue.", "Texte affiché en direct pendant que vous parlez, et bouton pour réécouter votre voix."],
  },
  {
    at: "2026-11-03T21:18", emoji: "📖", title: "Histoires plus confortables",
    items: ["La traduction s'affiche bien sous la phrase.", "La voix ne s'arrête plus quand on touche l'écran."],
  },
  {
    at: "2026-11-03T21:08", emoji: "⚙️", title: "Nouveaux paramètres",
    items: ["Paramètres rangés par catégories : Compte, Notifications, Préférences, Cours.", "Notifications au choix : messages, demandes d'ami, défis, réactions, rappel de série à l'heure voulue."],
  },
  {
    at: "2026-11-03T20:47", emoji: "🔊", title: "Voix naturelles enregistrées",
    items: ["Toutes les phrases du cours sont lues par une voix naturelle, identique sur tous les appareils."],
  },
  {
    at: "2026-11-03T17:33", emoji: "💬", title: "Dialogues et nombres",
    items: ["Dialogues à choix : répondez dans des situations de la vie réelle.", "Exercices sans fin sur les nombres, l'heure, les dates et les prix."],
  },
  {
    at: "2026-11-03T17:09", emoji: "🔑", title: "Nouveaux outils d'apprentissage",
    items: ["Mots cliquables pour voir leur traduction.", "Phrases à remettre dans l'ordre, exercice « Répéter ».", "Mandarin : les clés des caractères pour les retenir."],
  },
  {
    at: "2026-11-03T13:20", emoji: "🏆", title: "Défis enrichis",
    items: ["Mode Écoute, déroulé de la partie, records, statistiques par mode et historique filtrable."],
  },
  {
    at: "2026-11-03T02:31", emoji: "🔁", title: "Duels entre amis",
    items: ["Bilan de rivalité, revanche en un clic, mode mort subite, défi « sur son terrain »."],
  },
  {
    at: "2026-11-03T02:09", emoji: "🎓", title: "Niveau B1 / HSK 3",
    items: ["25 nouvelles leçons, examens enrichis et nouvelles histoires."],
  },
];

/** Date lisible : « mar. 4 nov. 2026 · 14 h 13 » */
// Les heures sont notées à l'heure de Paris (hiver : +01:00) ; on les affiche dans le fuseau de l'appareil.
export const atDate = (at) => new Date(/[+-]\d\d:\d\d$|Z$/.test(at) ? at : `${at}:00+01:00`);
export function whenLabel(at) {
  const d = atDate(at);
  return `${d.toLocaleDateString("fr-FR", { weekday: "short", day: "numeric", month: "short", year: "numeric" })} · ${d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }).replace(":", " h ")}`;
}
