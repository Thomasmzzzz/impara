/* =====================================================================
   Mandarin — compléments du palier HSK 2
   ---------------------------------------------------------------------
   Avec les 4 leçons d'origine, ces 10 leçons couvrent les 150 mots
   ajoutés par la liste officielle du HSK 2 et sa grammaire : 正在…呢
   et 着, complément de degré 得, 因为…所以, 虽然…但是, 离 / 从…到 /
   往, 要…了, 已经…了, 就 et 还, 给 / 让 / 送, 一下, 次 et 第一,
   别…了, 可能, 件, couleurs, famille et fêtes.
   (La comparaison avec 比 est traitée au palier suivant.)
   Les leçons s'ajoutent APRÈS les 4 d'origine (identifiants inchangés).
   Vocabulaire et exemples : [caractères, pinyin, français].
   ===================================================================== */

const mcq = (q, options, answer, explain = "") => ({ type: "mcq", q, options, answer, explain });
const fill = (q, answer, explain = "") => ({ type: "fill", q, answer, explain });
const match = (q, pairs, explain = "") => ({ type: "match", q, pairs, explain });
const tr = (q, answer, explain = "") => ({ type: "translate", q, answer, explain });

export const HSK2_PLUS = [
  /* ------------------------------------------------------------ 5 */
  {
    id: "a2-zhengzai", module: "temps", title: "La journée : 正在…呢 et 着", emoji: "⏰",
    intro: "Dire ce qu'on est en train de faire et raconter sa routine : se lever, aller travailler, se reposer.",
    sections: [
      {
        title: "正在 zhèngzài + verbe (+ 呢) : être en train de",
        text: "Pour une action en cours : <b>正在</b>, <b>在</b> ou seulement <b>呢</b> en fin de phrase. Négation : <b>没（在）</b> + verbe.",
        examples: [["你在做什么呢？", "nǐ zài zuò shénme ne?", "Qu'est-ce que tu es en train de faire ?"], ["我正在洗衣服呢。", "wǒ zhèngzài xǐ yīfu ne.", "Je suis en train de laver des vêtements."], ["妈妈在打电话。", "māma zài dǎ diànhuà.", "Maman est en train de téléphoner."], ["他没在休息，他在工作。", "tā méi zài xiūxi, tā zài gōngzuò.", "Il n'est pas en train de se reposer, il travaille."]],
      },
      {
        title: "着 zhe : un état qui dure",
        text: "Verbe + <b>着</b> décrit un état ou une manière : la porte est ouverte, il est assis, il parle en souriant.",
        examples: [["门开着。", "mén kāi zhe.", "La porte est ouverte."], ["他笑着说：「没关系。」", "tā xiào zhe shuō: “méi guānxi.”", "Il dit en souriant : « Ce n'est rien. »"], ["我们坐着等你。", "wǒmen zuò zhe děng nǐ.", "On t'attend assis."]],
      },
      {
        title: "Ma journée",
        examples: [["我每天早上六点半起床。", "wǒ měi tiān zǎoshang liù diǎn bàn qǐchuáng.", "Je me lève tous les jours à 6 h 30."], ["我八点上班，晚上六点回家。", "wǒ bā diǎn shàngbān, wǎnshang liù diǎn huí jiā.", "Je commence le travail à 8 h et je rentre à 18 h."], ["我每天工作八个小时。", "wǒ měi tiān gōngzuò bā ge xiǎoshí.", "Je travaille huit heures par jour."], ["周末我在家休息，玩手机。", "zhōumò wǒ zài jiā xiūxi, wán shǒujī.", "Le week-end je me repose chez moi et je joue sur mon téléphone."], ["爸爸正在看报纸。", "bàba zhèngzài kàn bàozhǐ.", "Papa est en train de lire le journal."]],
      },
    ],
    mnemo: "正在 = « juste maintenant (正) en train de (在) ». Et 呢 à la fin, c'est le petit « hein, là » qui montre que ça se passe en ce moment.",
    vocab: [["正在", "zhèngzài", "être en train de"], ["着", "zhe", "particule d'état continu"], ["起床", "qǐchuáng", "se lever"], ["早上", "zǎoshang", "le matin (tôt)"], ["晚上", "wǎnshang", "le soir"], ["上班", "shàngbān", "aller au travail"], ["洗", "xǐ", "laver"], ["休息", "xiūxi", "se reposer"], ["等", "děng", "attendre"], ["玩", "wán", "jouer, s'amuser"], ["手机", "shǒujī", "téléphone portable"], ["小时", "xiǎoshí", "heure (durée)"], ["时间", "shíjiān", "temps"], ["每", "měi", "chaque"], ["门", "mén", "porte"], ["报纸", "bàozhǐ", "journal"]],
    quiz: [
      mcq("« Je suis en train de manger » :", ["我吃了饭。", "我正在吃饭呢。", "我过吃饭。", "我吃饭着。"], 1, "正在 + verbe + 呢."),
      fill("你在做什么 ___？(particule de l'action en cours)", ["呢", "ne"], "你在做什么呢？"),
      mcq("« La porte est ouverte » :", ["门开了。", "门开着。", "门正在开。", "门开过。"], 1, "着 : état qui dure."),
      mcq("Négation de 他在休息 :", ["他不在休息。", "他没在休息。", "他在不休息。", "他休息没。"], 1, "Action en cours : 没（在）."),
      fill("我每天早上七点 ___。(se lever)", ["起床", "qǐchuáng", "qichuang"], "起床 qǐchuáng."),
      match("Associez", [["上班|shàngbān", "aller au travail"], ["休息|xiūxi", "se reposer"], ["等|děng", "attendre"], ["洗|xǐ", "laver"]]),
      mcq("小时 xiǎoshí désigne :", ["une heure de l'horloge (3 h)", "une durée d'une heure", "une minute", "le matin"], 1, "两个小时 = deux heures (durée) ; 两点 = 2 h (horloge)."),
      tr("Traduisez : Je travaille huit heures par jour.", ["我每天工作八个小时", "wǒ měi tiān gōngzuò bā ge xiǎoshí", "wo mei tian gongzuo ba ge xiaoshi", "我每天工作八小时"], "每天 + verbe + durée."),
    ],
  },

  /* ------------------------------------------------------------ 6 */
  {
    id: "a2-de-degre", module: "gram", title: "Bien ou mal : le complément de degré 得", emoji: "🏃",
    intro: "Dire qu'on chante bien, qu'on court vite ou qu'on parle trop vite : la structure verbe + 得 + appréciation, et les sports.",
    sections: [
      {
        title: "Verbe + 得 + (很) + adjectif",
        text: "<b>得 de</b> relie le verbe à son appréciation. Négation : <b>不</b> devant l'adjectif. Question : <b>…得怎么样？</b>",
        examples: [["她唱得很好。", "tā chàng de hěn hǎo.", "Elle chante bien."], ["你说得太快了！", "nǐ shuō de tài kuài le!", "Tu parles trop vite !"], ["他跑得不快。", "tā pǎo de bú kuài.", "Il ne court pas vite."], ["你游泳游得怎么样？", "nǐ yóuyǒng yóu de zěnmeyàng?", "Tu nages comment ?"]],
      },
      {
        title: "Avec un complément : on répète le verbe",
        text: "Si le verbe a un objet (唱<b>歌</b>, 说<b>汉语</b>), on le répète : <b>Verbe + objet + Verbe + 得 + …</b> On peut aussi supprimer le premier verbe : 他汉语说得很好。",
        examples: [["他说汉语说得非常好。", "tā shuō Hànyǔ shuō de fēicháng hǎo.", "Il parle très bien chinois."], ["我跳舞跳得不好。", "wǒ tiàowǔ tiào de bù hǎo.", "Je danse mal."], ["她汉字写得真漂亮！", "tā Hànzì xiě de zhēn piàoliang!", "Elle écrit vraiment joliment les caractères !"]],
      },
      {
        title: "Les sports",
        text: "Attention aux verbes : <b>踢</b> (frapper du pied) le football, <b>打</b> (frapper de la main) le basket.",
        examples: [["我喜欢踢足球。", "wǒ xǐhuan tī zúqiú.", "J'aime jouer au foot."], ["我们一起去打篮球吧！", "wǒmen yìqǐ qù dǎ lánqiú ba!", "Allons jouer au basket ensemble !"], ["我每天早上跑步。", "wǒ měi tiān zǎoshang pǎobù.", "Je cours tous les matins."], ["运动对身体很好。", "yùndòng duì shēntǐ hěn hǎo.", "Le sport est bon pour la santé."]],
      },
    ],
    mnemo: "得 de se prononce comme 的 de, mais il vient APRÈS UN VERBE : « courir 得 vite », « chanter 得 bien ».",
    vocab: [["得", "de", "particule du complément de degré"], ["唱歌", "chànggē", "chanter"], ["跳舞", "tiàowǔ", "danser"], ["游泳", "yóuyǒng", "nager"], ["跑步", "pǎobù", "courir (footing)"], ["踢足球", "tī zúqiú", "jouer au football"], ["打篮球", "dǎ lánqiú", "jouer au basket"], ["运动", "yùndòng", "sport, faire du sport"], ["快", "kuài", "rapide"], ["慢", "màn", "lent"], ["非常", "fēicháng", "extrêmement"], ["真", "zhēn", "vraiment"], ["说话", "shuōhuà", "parler"], ["笑", "xiào", "rire, sourire"], ["一起", "yìqǐ", "ensemble"]],
    quiz: [
      mcq("« Elle chante bien » :", ["她唱很好。", "她唱得很好。", "她唱的很好。", "她很好唱。"], 1, "Verbe + 得 + appréciation."),
      mcq("« Il parle très bien chinois » :", ["他说汉语得很好。", "他说汉语说得很好。", "他很好说汉语。", "他说得汉语很好。"], 1, "On répète le verbe : 说汉语说得…"),
      fill("你说得太 ___ 了，请慢一点。(rapide)", ["快", "kuài", "kuai"], "快 kuài = rapide."),
      mcq("« Jouer au football » :", ["打足球", "踢足球", "玩足球", "做足球"], 1, "踢 tī = frapper du pied."),
      mcq("« Il ne court pas vite » :", ["他不跑得快。", "他跑得不快。", "他跑不得快。", "他没跑得快。"], 1, "不 devant l'adjectif."),
      match("Associez", [["游泳|yóuyǒng", "nager"], ["跳舞|tiàowǔ", "danser"], ["唱歌|chànggē", "chanter"], ["跑步|pǎobù", "courir"]]),
      fill("我们 ___ 去打篮球吧！(ensemble)", ["一起", "yìqǐ", "yiqi"], "一起 = ensemble."),
      tr("Traduisez : Je danse mal.", ["我跳舞跳得不好", "我跳得不好", "wǒ tiàowǔ tiào de bù hǎo", "wo tiaowu tiao de bu hao", "wǒ tiào de bù hǎo", "wo tiao de bu hao"], "跳舞跳得不好."),
    ],
  },

  /* ------------------------------------------------------------ 7 */
  {
    id: "a2-yinwei", module: "gram", title: "Pourquoi ? 因为…所以, 虽然…但是", emoji: "🤔",
    intro: "Expliquer une cause, une conséquence et une opposition : les phrases deviennent plus longues et plus naturelles.",
    sections: [
      {
        title: "为什么 ? — 因为…所以…",
        text: "<b>为什么</b> wèishénme = pourquoi. Réponse : <b>因为</b> yīnwèi (parce que)… <b>所以</b> suǒyǐ (donc)… Les deux mots vont souvent ensemble en chinois, contrairement au français.",
        examples: [["你为什么没来上课？", "nǐ wèishénme méi lái shàngkè?", "Pourquoi n'es-tu pas venu en cours ?"], ["因为我生病了，所以没来。", "yīnwèi wǒ shēngbìng le, suǒyǐ méi lái.", "Parce que j'étais malade, (donc) je ne suis pas venu."], ["因为下雨，所以我们在家。", "yīnwèi xià yǔ, suǒyǐ wǒmen zài jiā.", "Comme il pleut, nous restons à la maison."]],
      },
      {
        title: "虽然…但是… : bien que… (mais)…",
        text: "<b>虽然</b> suīrán (bien que) introduit la concession, <b>但是</b> dànshì (mais) l'opposition. Là encore, on garde les deux.",
        examples: [["虽然汉语很难，但是很有意思。", "suīrán Hànyǔ hěn nán, dànshì hěn yǒu yìsi.", "Bien que le chinois soit difficile, c'est très intéressant."], ["虽然他很累，但是还在工作。", "suīrán tā hěn lèi, dànshì hái zài gōngzuò.", "Bien qu'il soit fatigué, il travaille encore."]],
      },
      {
        title: "La santé et les sensations",
        examples: [["我觉得身体不太好。", "wǒ juéde shēntǐ bú tài hǎo.", "Je ne me sens pas très bien."], ["你生病了，要吃药。", "nǐ shēngbìng le, yào chī yào.", "Tu es malade, il faut prendre des médicaments."], ["我眼睛不舒服。", "wǒ yǎnjing bù shūfu.", "J'ai mal aux yeux."], ["最近工作很忙，我很累。", "zuìjìn gōngzuò hěn máng, wǒ hěn lèi.", "Ces derniers temps le travail est chargé, je suis fatigué."]],
      },
    ],
    mnemo: "En chinois, on annonce la couleur deux fois : « parce que… DONC… », « bien que… MAIS… ». Ce qui sonne lourd en français est naturel en chinois.",
    vocab: [["为什么", "wèishénme", "pourquoi"], ["因为", "yīnwèi", "parce que"], ["所以", "suǒyǐ", "donc"], ["虽然", "suīrán", "bien que"], ["但是", "dànshì", "mais"], ["觉得", "juéde", "trouver, penser"], ["累", "lèi", "fatigué"], ["忙", "máng", "occupé"], ["生病", "shēngbìng", "tomber malade"], ["身体", "shēntǐ", "corps, santé"], ["药", "yào", "médicament"], ["眼睛", "yǎnjing", "œil, yeux"], ["意思", "yìsi", "sens, intérêt"], ["有意思", "yǒu yìsi", "intéressant"]],
    quiz: [
      fill("你 ___ 不去？(pourquoi)", ["为什么", "wèishénme", "weishenme"], "为什么 = pourquoi."),
      mcq("因为下雨，___ 我不去公园。", ["但是", "所以", "虽然", "因为"], 1, "因为… 所以…"),
      mcq("虽然很贵，___ 我很喜欢。", ["所以", "但是", "因为", "就"], 1, "虽然… 但是…"),
      mcq("« Je trouve que c'est intéressant » :", ["我觉得很有意思。", "我觉得很意思。", "我有意思觉得。", "我是有意思。"], 0, "有意思 = intéressant."),
      fill("我生病了，要吃 ___。(médicament)", ["药", "yào", "yao"], "吃药 = prendre un médicament."),
      match("Associez", [["累|lèi", "fatigué"], ["忙|máng", "occupé"], ["身体|shēntǐ", "corps, santé"], ["眼睛|yǎnjing", "yeux"]]),
      mcq("觉得 juéde signifie :", ["dormir", "trouver, avoir l'impression", "savoir", "se réveiller"], 1, "我觉得… = je trouve que…"),
      tr("Traduisez : Je suis très occupé.", ["我很忙", "wǒ hěn máng", "wo hen mang"], "很 + adjectif."),
    ],
  },

  /* ------------------------------------------------------------ 8 */
  {
    id: "a2-li-cong", module: "vocab", title: "Distances et trajets : 离, 从…到, 往", emoji: "🧭",
    intro: "Dire si c'est loin, combien de temps prend un trajet et demander son chemin dans une ville chinoise.",
    sections: [
      {
        title: "A 离 B 远 / 近 : A est loin / près de B",
        text: "<b>离 lí</b> exprime la distance entre deux lieux (ou deux moments). On termine par <b>远 yuǎn</b> (loin) ou <b>近 jìn</b> (près).",
        examples: [["我家离学校很近。", "wǒ jiā lí xuéxiào hěn jìn.", "Ma maison est près de l'école."], ["机场离这儿远吗？", "jīchǎng lí zhèr yuǎn ma?", "L'aéroport est loin d'ici ?"], ["离考试还有三天。", "lí kǎoshì hái yǒu sān tiān.", "Il reste trois jours avant l'examen."]],
      },
      {
        title: "从 A 到 B : de A à B",
        examples: [["从我家到公司要二十分钟。", "cóng wǒ jiā dào gōngsī yào èrshí fēnzhōng.", "De chez moi à l'entreprise, il faut vingt minutes."], ["我从八点到十二点上课。", "wǒ cóng bā diǎn dào shí'èr diǎn shàngkè.", "J'ai cours de 8 h à midi."], ["你坐公共汽车去还是走路去？", "nǐ zuò gōnggòng qìchē qù háishi zǒulù qù?", "Tu y vas en bus ou à pied ?"]],
      },
      {
        title: "往 wǎng : vers — demander son chemin",
        examples: [["请问，宾馆怎么走？", "qǐngwèn, bīnguǎn zěnme zǒu?", "Excusez-moi, comment va-t-on à l'hôtel ?"], ["一直往前走，然后往左走。", "yìzhí wǎng qián zǒu, ránhòu wǎng zuǒ zǒu.", "Allez tout droit, puis tournez à gauche."], ["商店在银行旁边，医院在右边。", "shāngdiàn zài yínháng pángbiān, yīyuàn zài yòubian.", "Le magasin est à côté de la banque, l'hôpital est à droite."], ["请进！出门往右。", "qǐng jìn! chū mén wǎng yòu.", "Entrez ! En sortant, à droite."]],
      },
    ],
    mnemo: "离 lí : on mesure l'écart « LIbrement » entre deux points. 从 cóng (deux personnes 人人 qui se suivent) = à partir de.",
    vocab: [["离", "lí", "distance de, à … de"], ["远", "yuǎn", "loin"], ["近", "jìn", "près"], ["从", "cóng", "depuis, à partir de"], ["到", "dào", "jusqu'à, arriver"], ["往", "wǎng", "vers"], ["走", "zǒu", "marcher, partir"], ["路", "lù", "route, chemin"], ["左边", "zuǒbian", "gauche"], ["右边", "yòubian", "droite"], ["旁边", "pángbiān", "à côté"], ["机场", "jīchǎng", "aéroport"], ["公共汽车", "gōnggòng qìchē", "bus"], ["宾馆", "bīnguǎn", "hôtel"], ["进", "jìn", "entrer"], ["出", "chū", "sortir"], ["公司", "gōngsī", "entreprise"]],
    quiz: [
      mcq("« Ma maison est près de l'école » :", ["我家从学校很近。", "我家离学校很近。", "我家到学校很近。", "学校离很近我家。"], 1, "A 离 B 近."),
      fill("___ 北京到上海要五个小时。(de)", ["从", "cóng", "cong"], "从 A 到 B."),
      mcq("一直往前走 signifie :", ["tournez à droite", "allez tout droit", "revenez en arrière", "c'est à côté"], 1, "往前 = vers l'avant."),
      fill("银行在商店 ___ 。(à côté)", ["旁边", "pángbiān", "pangbian"], "旁边 = à côté."),
      mcq("Contraire de 远 yuǎn :", ["近 jìn", "进 jìn", "快 kuài", "长 cháng"], 0, "近 jìn = près (attention à 进 jìn, entrer)."),
      match("Associez", [["机场|jīchǎng", "aéroport"], ["宾馆|bīnguǎn", "hôtel"], ["左边|zuǒbian", "gauche"], ["右边|yòubian", "droite"]]),
      mcq("« Comment va-t-on à l'hôtel ? » :", ["宾馆在哪儿走？", "宾馆怎么走？", "宾馆什么走？", "怎么宾馆走？"], 1, "Lieu + 怎么走？"),
      tr("Traduisez : L'aéroport est loin d'ici ?", ["机场离这儿远吗", "机场离这里远吗", "jīchǎng lí zhèr yuǎn ma", "jichang li zher yuan ma", "jichang li zheli yuan ma"], "A 离 B 远吗？"),
    ],
  },

  /* ------------------------------------------------------------ 9 */
  {
    id: "a2-yao-le", module: "temps", title: "Bientôt, déjà, pas encore : 要…了, 已经…了, 就, 还", emoji: "⌛",
    intro: "Situer une action dans le temps : elle va arriver, elle est déjà faite, elle n'est pas encore faite. Avec le vocabulaire de l'école.",
    sections: [
      {
        title: "(快)要…了 : bientôt, sur le point de",
        text: "<b>要…了</b>, <b>快要…了</b>, <b>就要…了</b> = ça va bientôt arriver. Avec une date ou une heure précise, on utilise <b>就要…了</b> (pas 快要).",
        examples: [["快要下雨了。", "kuài yào xià yǔ le.", "Il va bientôt pleuvoir."], ["考试要开始了！", "kǎoshì yào kāishǐ le!", "L'examen va commencer !"], ["明天就要回国了。", "míngtiān jiù yào huí guó le.", "Demain je rentre déjà dans mon pays."]],
      },
      {
        title: "已经…了 : déjà — 还没…呢 : pas encore",
        examples: [["我已经吃完饭了。", "wǒ yǐjīng chī wán fàn le.", "J'ai déjà fini de manger."], ["他已经二十岁了。", "tā yǐjīng èrshí suì le.", "Il a déjà vingt ans."], ["作业你做完了吗？——还没做完呢。", "zuòyè nǐ zuò wán le ma? —— hái méi zuò wán ne.", "Tu as fini tes devoirs ? — Pas encore."]],
      },
      {
        title: "就 jiù : tôt, tout de suite — 还 hái : encore",
        text: "<b>就</b> souligne que c'est tôt ou rapide ; <b>还</b> que ça continue.",
        examples: [["他七点就来了。", "tā qī diǎn jiù lái le.", "Il est venu dès 7 h."], ["我马上就到。", "wǒ mǎshàng jiù dào.", "J'arrive tout de suite."], ["你还在教室吗？", "nǐ hái zài jiàoshì ma?", "Tu es encore dans la salle de classe ?"], ["这个题我没懂，你能再说一下吗？", "zhège tí wǒ méi dǒng, nǐ néng zài shuō yíxià ma?", "Je n'ai pas compris cette question, tu peux la redire ?"]],
      },
    ],
    mnemo: "要 = « il va », 了 = « ça y est » : 要…了 = « ça va y être » ! Et 已经 = « déjà » qui appelle toujours son 了 à la fin.",
    vocab: [["快要…了", "kuài yào… le", "bientôt, sur le point de"], ["已经", "yǐjīng", "déjà"], ["就", "jiù", "dès, tout de suite"], ["还", "hái", "encore"], ["开始", "kāishǐ", "commencer"], ["完", "wán", "finir (résultat)"], ["准备", "zhǔnbèi", "préparer"], ["考试", "kǎoshì", "examen"], ["课", "kè", "cours, leçon"], ["题", "tí", "question (d'exercice)"], ["问题", "wèntí", "question, problème"], ["教室", "jiàoshì", "salle de classe"], ["懂", "dǒng", "comprendre"], ["错", "cuò", "faux, erreur"], ["对", "duì", "juste, correct"], ["再", "zài", "à nouveau (futur)"]],
    quiz: [
      mcq("« Il va bientôt pleuvoir » :", ["快下雨了。", "快要下雨了。", "已经下雨了。", "还没下雨。"], 1, "快要…了 (快…了 est aussi possible à l'oral)."),
      mcq("Avec une heure précise : « Le train part à 8 h, bientôt » :", ["火车八点快要开了。", "火车八点就要开了。", "火车八点已经开。", "火车八点要开。"], 1, "Avec un temps précis : 就要…了."),
      fill("我 ___ 吃饭了。(déjà)", ["已经", "yǐjīng", "yijing"], "已经…了."),
      mcq("« Pas encore (fini) » :", ["还没做完呢。", "已经没做完。", "不做完了。", "还不做完了。"], 0, "还没 + verbe + 呢."),
      mcq("你说得对 signifie :", ["Tu as tort", "Tu as raison", "Parle plus fort", "Répète"], 1, "对 duì = juste, correct."),
      match("Associez", [["考试|kǎoshì", "examen"], ["教室|jiàoshì", "salle de classe"], ["准备|zhǔnbèi", "préparer"], ["懂|dǒng", "comprendre"]]),
      fill("请你 ___ 说一遍。(à nouveau)", ["再", "zài", "zai"], "再 = encore une fois (à venir)."),
      tr("Traduisez : L'examen va commencer.", ["考试要开始了", "考试快要开始了", "考试就要开始了", "kǎoshì yào kāishǐ le", "kaoshi yao kaishi le", "kaoshi kuai yao kaishi le", "kaoshi jiu yao kaishi le"], "要…了."),
    ],
  },

  /* ------------------------------------------------------------ 10 */
  {
    id: "a2-gei-rang", module: "gram", title: "Donner, aider, demander : 给, 让, 送, 告诉", emoji: "🎁",
    intro: "Les verbes et prépositions qui relient les personnes : téléphoner À quelqu'un, faire faire, offrir, présenter.",
    sections: [
      {
        title: "给 gěi : donner / à, pour (quelqu'un)",
        text: "Verbe : <b>给</b> + personne + objet = donner. Préposition : <b>给</b> + personne + verbe = faire quelque chose pour / à quelqu'un.",
        examples: [["妈妈给了我一本书。", "māma gěi le wǒ yì běn shū.", "Maman m'a donné un livre."], ["我晚上给你打电话。", "wǒ wǎnshang gěi nǐ dǎ diànhuà.", "Je t'appelle ce soir."], ["我给大家介绍一下，这是我朋友。", "wǒ gěi dàjiā jièshào yíxià, zhè shì wǒ péngyou.", "Je vous présente : voici mon ami."]],
      },
      {
        title: "让 ràng : faire faire, laisser",
        text: "A <b>让</b> B + verbe = A fait faire / laisse B faire quelque chose.",
        examples: [["老师让我们回答问题。", "lǎoshī ràng wǒmen huídá wèntí.", "Le professeur nous fait répondre aux questions."], ["妈妈不让我玩手机。", "māma bú ràng wǒ wán shǒujī.", "Maman ne me laisse pas jouer sur le téléphone."], ["让我想一下。", "ràng wǒ xiǎng yíxià.", "Laisse-moi réfléchir un instant."]],
      },
      {
        title: "送, 告诉, 帮助 et 一下",
        text: "<b>送</b> sòng = offrir ou raccompagner · <b>告诉</b> gàosu = dire, informer · <b>帮助</b> bāngzhù = aider · Verbe + <b>一下</b> yíxià = rapidement, un petit peu (adoucit une demande).",
        examples: [["我送你一个礼物。", "wǒ sòng nǐ yí ge lǐwù.", "Je t'offre un cadeau."], ["请告诉我你的手机号。", "qǐng gàosu wǒ nǐ de shǒujī hào.", "Dis-moi ton numéro de portable, s'il te plaît."], ["谢谢你的帮助！", "xièxie nǐ de bāngzhù!", "Merci pour ton aide !"], ["你知道他在哪儿吗？我找他有事情。", "nǐ zhīdào tā zài nǎr ma? wǒ zhǎo tā yǒu shìqing.", "Tu sais où il est ? Je le cherche, j'ai quelque chose à lui dire."]],
      },
    ],
    mnemo: "给 gěi = le « à » de « téléphoner À quelqu'un » : en chinois il se place AVANT le verbe : 给你打电话.",
    vocab: [["给", "gěi", "donner ; à, pour"], ["让", "ràng", "faire faire, laisser"], ["送", "sòng", "offrir, raccompagner"], ["告诉", "gàosu", "dire, informer"], ["帮助", "bāngzhù", "aider, aide"], ["介绍", "jièshào", "présenter"], ["问", "wèn", "demander"], ["回答", "huídá", "répondre"], ["找", "zhǎo", "chercher"], ["知道", "zhīdào", "savoir"], ["希望", "xīwàng", "espérer"], ["欢迎", "huānyíng", "bienvenue, accueillir"], ["一下", "yíxià", "un instant, un peu"], ["事情", "shìqing", "affaire, chose"], ["大家", "dàjiā", "tout le monde"], ["吧", "ba", "particule de suggestion"]],
    quiz: [
      mcq("« Je t'appelle ce soir » :", ["我晚上打电话你给。", "我晚上给你打电话。", "我晚上打电话你。", "我给晚上你打电话。"], 1, "给 + personne + verbe."),
      mcq("老师让我们回答问题 signifie :", ["Le professeur répond à nos questions.", "Le professeur nous fait répondre aux questions.", "Le professeur nous pose une question.", "Nous laissons le professeur répondre."], 1, "A 让 B + verbe."),
      fill("请 ___ 我你的名字。(dire, informer)", ["告诉", "gàosu", "gaosu"], "告诉 + personne + chose."),
      fill("我给大家介绍 ___ 。(un instant, adoucit la demande)", ["一下", "yíxià", "yixia"], "介绍一下."),
      mcq("« Je t'offre un cadeau » :", ["我送你一个礼物。", "我让你一个礼物。", "我告诉你一个礼物。", "我找你一个礼物。"], 0, "送 = offrir."),
      match("Associez", [["回答|huídá", "répondre"], ["知道|zhīdào", "savoir"], ["希望|xīwàng", "espérer"], ["欢迎|huānyíng", "bienvenue"]]),
      mcq("妈妈不让我玩手机 :", ["Maman ne joue pas sur son téléphone.", "Maman ne me laisse pas jouer sur le téléphone.", "Maman me donne son téléphone.", "Je ne laisse pas maman jouer."], 1, "不让 = ne pas laisser."),
      tr("Traduisez : Merci pour ton aide !", ["谢谢你的帮助", "xièxie nǐ de bāngzhù", "xiexie ni de bangzhu"], "你的帮助 = ton aide."),
    ],
  },

  /* ------------------------------------------------------------ 11 */
  {
    id: "a2-yanse", module: "vocab", title: "Couleurs, vêtements et prix : 件, 穿, 便宜", emoji: "👕",
    intro: "Acheter des vêtements, choisir une couleur, discuter le prix : la suite des achats du HSK 1.",
    sections: [
      {
        title: "Les couleurs et 颜色",
        text: "<b>颜色</b> yánsè = couleur. Avant un nom, on ajoute souvent <b>的</b> (红色的衣服) ; les couleurs d'une syllabe peuvent aussi se coller au nom (红茶).",
        examples: [["你喜欢什么颜色？", "nǐ xǐhuan shénme yánsè?", "Quelle couleur aimes-tu ?"], ["我喜欢红色和白色。", "wǒ xǐhuan hóngsè hé báisè.", "J'aime le rouge et le blanc."], ["那件黑色的衣服很漂亮。", "nà jiàn hēisè de yīfu hěn piàoliang.", "Ce vêtement noir-là est très joli."]],
      },
      {
        title: "件 jiàn et 穿 chuān",
        text: "<b>件</b> est le classificateur des vêtements du haut et des affaires (一件事情). <b>穿</b> = porter, mettre (un vêtement).",
        examples: [["我想买一件新衣服。", "wǒ xiǎng mǎi yí jiàn xīn yīfu.", "Je veux acheter un nouveau vêtement."], ["今天很冷，你多穿一点。", "jīntiān hěn lěng, nǐ duō chuān yìdiǎn.", "Il fait froid aujourd'hui, couvre-toi bien."], ["这件衣服我穿太大了。", "zhè jiàn yīfu wǒ chuān tài dà le.", "Ce vêtement est trop grand pour moi."]],
      },
      {
        title: "Discuter le prix",
        examples: [["这块手表多少钱？——两千块。", "zhè kuài shǒubiǎo duōshao qián? —— liǎng qiān kuài.", "Combien coûte cette montre ? — Deux mille yuans."], ["太贵了！便宜一点吧。", "tài guì le! piányi yìdiǎn ba.", "C'est trop cher ! Faites un peu moins cher."], ["这个商店卖的东西很便宜。", "zhège shāngdiàn mài de dōngxi hěn piányi.", "Ce magasin vend des choses bon marché."], ["一共一百零五块。", "yígòng yìbǎi líng wǔ kuài.", "Ça fait cent cinq yuans en tout."], ["这条裤子太长了。", "zhè tiáo kùzi tài cháng le.", "Ce pantalon est trop long."], ["我要买两支铅笔。", "wǒ yào mǎi liǎng zhī qiānbǐ.", "Je veux acheter deux crayons."]],
      },
    ],
    mnemo: "买 mǎi (3e ton) = acheter, 卖 mài (4e ton) = vendre : le caractère de vendre a un 十 en plus au-dessus… on « ajoute » de l'argent quand on vend !",
    vocab: [["颜色", "yánsè", "couleur"], ["红", "hóng", "rouge"], ["白", "bái", "blanc"], ["黑", "hēi", "noir"], ["件", "jiàn", "classificateur (vêtements, affaires)"], ["穿", "chuān", "porter, mettre"], ["新", "xīn", "nouveau"], ["贵", "guì", "cher"], ["便宜", "piányi", "bon marché"], ["卖", "mài", "vendre"], ["手表", "shǒubiǎo", "montre"], ["千", "qiān", "mille"], ["零", "líng", "zéro"], ["一共", "yígòng", "en tout"], ["长", "cháng", "long"], ["铅笔", "qiānbǐ", "crayon"], ["要", "yào", "vouloir, falloir"]],
    quiz: [
      mcq("Classificateur de 衣服 (vêtement) :", ["本", "件", "个", "杯"], 1, "一件衣服."),
      mcq("Contraire de 贵 guì :", ["便宜 piányi", "漂亮 piàoliang", "新 xīn", "大 dà"], 0, "便宜 = bon marché."),
      fill("你喜欢什么 ___？(couleur)", ["颜色", "yánsè", "yanse"], "颜色 = couleur."),
      mcq("买 mǎi et 卖 mài :", ["acheter / vendre", "vendre / acheter", "payer / rendre", "prix / argent"], 0, "买 3e ton = acheter ; 卖 4e ton = vendre."),
      mcq("2 000 yuans :", ["二千块", "两千块", "二十百块", "两百块"], 1, "Devant 千, on dit 两."),
      match("Associez", [["红|hóng", "rouge"], ["白|bái", "blanc"], ["黑|hēi", "noir"], ["手表|shǒubiǎo", "montre"]]),
      fill("今天很冷，你多 ___ 一点。(porter, mettre)", ["穿", "chuān", "chuan"], "穿衣服 = s'habiller."),
      tr("Traduisez : C'est trop cher !", ["太贵了", "tài guì le", "tai gui le"], "太…了."),
    ],
  },

  /* ------------------------------------------------------------ 12 */
  {
    id: "a2-jiaren", module: "vocab", title: "Frères, sœurs, mariage et anniversaires", emoji: "🎂",
    intro: "Le vocabulaire précis de la famille chinoise (aîné ou cadet ?), le nom de famille avec 姓 et les vœux d'anniversaire.",
    sections: [
      {
        title: "Aîné ou cadet : 4 mots différents",
        text: "Le chinois distingue toujours l'âge : <b>哥哥</b> gēge grand frère, <b>弟弟</b> dìdi petit frère, <b>姐姐</b> jiějie grande sœur, <b>妹妹</b> mèimei petite sœur.",
        examples: [["我有一个哥哥和两个妹妹。", "wǒ yǒu yí ge gēge hé liǎng ge mèimei.", "J'ai un grand frère et deux petites sœurs."], ["她是我姐姐，比我大三岁。", "tā shì wǒ jiějie, bǐ wǒ dà sān suì.", "C'est ma grande sœur, elle a trois ans de plus que moi."], ["你有孩子吗？——有，一个男孩子，一个女孩子。", "nǐ yǒu háizi ma? —— yǒu, yí ge nán háizi, yí ge nǚ háizi.", "Tu as des enfants ? — Oui, un garçon et une fille."]],
      },
      {
        title: "姓 xìng : le nom de famille",
        text: "Demande polie : <b>您贵姓？</b> nín guìxìng ? Réponse : <b>我姓…</b> Le nom de famille vient toujours en premier : 王明 = M. Wang, prénom Ming.",
        examples: [["您贵姓？——我姓李，叫李月。", "nín guìxìng? —— wǒ xìng Lǐ, jiào Lǐ Yuè.", "Quel est votre nom ? — Je m'appelle Li, Li Yue."], ["她丈夫姓王。", "tā zhàngfu xìng Wáng.", "Son mari s'appelle Wang (nom de famille)."], ["这是我妻子。", "zhè shì wǒ qīzi.", "Voici ma femme."]],
      },
      {
        title: "Les vœux",
        examples: [["生日快乐！", "shēngrì kuàilè!", "Joyeux anniversaire !"], ["你的生日是几月几号？", "nǐ de shēngrì shì jǐ yuè jǐ hào?", "C'est quand ton anniversaire ?"], ["新年快乐！——你也新年快乐！", "xīnnián kuàilè! —— nǐ yě xīnnián kuàilè!", "Bonne année ! — Bonne année à toi aussi !"], ["欢迎大家来我家！", "huānyíng dàjiā lái wǒ jiā!", "Bienvenue à tous chez moi !"]],
      },
    ],
    mnemo: "哥 gē = deux 可 empilés : le grand frère est « deux fois » plus grand. 妹 mèi contient 未 (« pas encore ») : la petite sœur n'a pas encore grandi.",
    vocab: [["哥哥", "gēge", "grand frère"], ["弟弟", "dìdi", "petit frère"], ["姐姐", "jiějie", "grande sœur"], ["妹妹", "mèimei", "petite sœur"], ["孩子", "háizi", "enfant"], ["男", "nán", "homme, masculin"], ["女", "nǚ", "femme, féminin"], ["丈夫", "zhàngfu", "mari"], ["妻子", "qīzi", "épouse"], ["姓", "xìng", "nom de famille, s'appeler (nom)"], ["生日", "shēngrì", "anniversaire"], ["快乐", "kuàilè", "joyeux, heureux"], ["您", "nín", "vous (poli)"], ["也", "yě", "aussi"]],
    quiz: [
      mcq("« Petite sœur » :", ["姐姐 jiějie", "妹妹 mèimei", "弟弟 dìdi", "哥哥 gēge"], 1, "妹妹 = petite sœur."),
      mcq("Demande polie du nom de famille :", ["你叫什么？", "您贵姓？", "你是谁？", "您姓什么名字？"], 1, "您贵姓？"),
      fill("我 ___ 王，叫王明。(nom de famille)", ["姓", "xìng", "xing"], "我姓…"),
      fill("生日 ___ ！(joyeux)", ["快乐", "kuàilè", "kuaile"], "生日快乐 !"),
      match("Associez", [["丈夫|zhàngfu", "mari"], ["妻子|qīzi", "épouse"], ["孩子|háizi", "enfant"], ["弟弟|dìdi", "petit frère"]]),
      mcq("Dans 王明, le nom de famille est :", ["明", "王", "les deux", "aucun"], 1, "Le nom de famille vient en premier."),
      mcq("男孩子 signifie :", ["une fille", "un garçon", "un homme âgé", "un mari"], 1, "男 = masculin."),
      tr("Traduisez : J'ai un grand frère.", ["我有一个哥哥", "wǒ yǒu yí ge gēge", "wo you yi ge gege", "我有哥哥"], "哥哥 = grand frère."),
    ],
  },

  /* ------------------------------------------------------------ 13 */
  {
    id: "a2-chifan", module: "vocab", title: "Au petit-déjeuner, au restaurant et la météo", emoji: "🥟",
    intro: "Commander des plats courants, dire ce qu'on aime manger le matin, et parler du temps : ensoleillé, couvert, neige.",
    sections: [
      {
        title: "Les plats et boissons du quotidien",
        examples: [["我早上喝牛奶，吃鸡蛋。", "wǒ zǎoshang hē niúnǎi, chī jīdàn.", "Le matin je bois du lait et je mange des œufs."], ["服务员，来一碗面条！", "fúwùyuán, lái yì wǎn miàntiáo!", "S'il vous plaît, un bol de nouilles !"], ["你喝咖啡还是喝茶？", "nǐ hē kāfēi háishi hē chá?", "Tu bois du café ou du thé ?"], ["这儿的羊肉和鱼都很好吃。", "zhèr de yángròu hé yú dōu hěn hǎochī.", "Ici, le mouton et le poisson sont tous les deux délicieux."], ["夏天我最喜欢吃西瓜。", "xiàtiān wǒ zuì xǐhuan chī xīguā.", "En été, ce que j'aime le plus, c'est la pastèque."]],
      },
      {
        title: "还是 háishi : ou (dans une question)",
        text: "Dans une <b>question</b> à choix, « ou » se dit <b>还是</b>. Dans une affirmation, on utilise 或者 (vu plus tard).",
        examples: [["你要米饭还是面条？", "nǐ yào mǐfàn háishi miàntiáo?", "Tu veux du riz ou des nouilles ?"]],
      },
      {
        title: "Le temps : 晴, 阴, 雪",
        examples: [["今天是晴天。", "jīntiān shì qíngtiān.", "Aujourd'hui il fait beau (ensoleillé)."], ["明天阴天，可能下雨。", "míngtiān yīntiān, kěnéng xià yǔ.", "Demain ce sera couvert, il pleuvra peut-être."], ["北京冬天下雪吗？", "Běijīng dōngtiān xià xuě ma?", "Il neige à Pékin en hiver ?"]],
      },
    ],
    mnemo: "牛奶 = « lait (奶) de vache (牛) », 羊肉 = « viande (肉) de mouton (羊) », 鸡蛋 = « œuf (蛋) de poule (鸡) » : le chinois se construit comme des Lego.",
    vocab: [["牛奶", "niúnǎi", "lait"], ["鸡蛋", "jīdàn", "œuf"], ["面条", "miàntiáo", "nouilles"], ["羊肉", "yángròu", "viande de mouton"], ["鱼", "yú", "poisson"], ["西瓜", "xīguā", "pastèque"], ["咖啡", "kāfēi", "café"], ["好吃", "hǎochī", "bon (à manger)"], ["服务员", "fúwùyuán", "serveur"], ["还是", "háishi", "ou (question)"], ["晴", "qíng", "ensoleillé"], ["阴", "yīn", "couvert, nuageux"], ["雪", "xuě", "neige"], ["可能", "kěnéng", "peut-être, possible"]],
    quiz: [
      mcq("« Tu veux du thé ou du café ? » :", ["你要茶或者咖啡吗？", "你要茶还是咖啡？", "你要茶和咖啡吗？", "你要茶都咖啡？"], 1, "Question à choix : 还是."),
      match("Associez", [["牛奶|niúnǎi", "lait"], ["鸡蛋|jīdàn", "œuf"], ["面条|miàntiáo", "nouilles"], ["西瓜|xīguā", "pastèque"]]),
      fill("这个菜很 ___ ！(délicieux)", ["好吃", "hǎochī", "haochi"], "好吃 = bon (à manger)."),
      mcq("阴天 signifie :", ["temps ensoleillé", "temps couvert", "il neige", "il fait chaud"], 1, "阴 yīn = couvert."),
      fill("明天 ___ 下雨。(peut-être)", ["可能", "kěnéng", "keneng"], "可能 = peut-être."),
      mcq("Pour appeler le serveur :", ["老师！", "服务员！", "医生！", "先生们！"], 1, "服务员 fúwùyuán."),
      mcq("下雪 signifie :", ["il pleut", "il neige", "il y a du vent", "il fait beau"], 1, "雪 xuě = neige."),
      tr("Traduisez : Aujourd'hui il fait beau.", ["今天是晴天", "今天晴天", "今天天气很好", "jīntiān shì qíngtiān", "jintian shi qingtian", "jintian qingtian", "jintian tianqi hen hao"], "晴天 = jour ensoleillé."),
    ],
  },

  /* ------------------------------------------------------------ 14 */
  {
    id: "a2-lvyou", module: "temps", title: "Voyages et expériences : 次, 第一, 别…了", emoji: "✈️",
    intro: "Raconter combien de fois on est allé quelque part, sa première fois, et donner des conseils de voyage.",
    sections: [
      {
        title: "Verbe + 过 + nombre + 次",
        text: "<b>次 cì</b> = fois. Il se place <b>après</b> le verbe (et après 过) : 去过两次 = y être allé deux fois.",
        examples: [["我去过中国三次。", "wǒ qù guo Zhōngguó sān cì.", "Je suis allé trois fois en Chine."], ["这是我第一次坐飞机。", "zhè shì wǒ dì-yī cì zuò fēijī.", "C'est la première fois que je prends l'avion."], ["去年我们去北京旅游了。", "qùnián wǒmen qù Běijīng lǚyóu le.", "L'an dernier, nous avons fait du tourisme à Pékin."]],
      },
      {
        title: "第 dì + nombre : ordinaux",
        text: "<b>第一</b> premier, <b>第二</b> deuxième… 第一次 = la première fois, 第三天 = le troisième jour.",
        examples: [["他是第一个到的。", "tā shì dì-yī ge dào de.", "C'est lui qui est arrivé le premier."], ["我住在第五层的房间。", "wǒ zhù zài dì-wǔ céng de fángjiān.", "Je loge dans une chambre au cinquième étage."]],
      },
      {
        title: "别…了 : ne… plus / arrête de — 可以 et 最",
        text: "<b>别</b> bié + verbe = ne… pas (interdiction douce) ; <b>别…了</b> = arrête de… <b>可以</b> = pouvoir (permission). <b>最</b> = le plus.",
        examples: [["别忘了带护照！", "bié wàng le dài hùzhào!", "N'oublie pas ton passeport !"], ["别玩手机了，我们要走了。", "bié wán shǒujī le, wǒmen yào zǒu le.", "Arrête de jouer sur ton téléphone, on va partir."], ["我可以在外面等你吗？", "wǒ kěyǐ zài wàimiàn děng nǐ ma?", "Je peux t'attendre dehors ?"], ["机票已经买了吗？", "jīpiào yǐjīng mǎi le ma?", "Les billets d'avion sont déjà achetés ?"], ["我最喜欢的城市是上海。", "wǒ zuì xǐhuan de chéngshì shì Shànghǎi.", "Ma ville préférée est Shanghai."]],
      },
    ],
    mnemo: "次 cì : la clé de la glace (冫) + 欠 (bâiller) → on bâille à la DEUXIÈME fois qu'on entend la même histoire !",
    vocab: [["次", "cì", "fois"], ["第一", "dì-yī", "premier"], ["旅游", "lǚyóu", "voyager, tourisme"], ["去年", "qùnián", "l'an dernier"], ["票", "piào", "billet, ticket"], ["房间", "fángjiān", "chambre, pièce"], ["别", "bié", "ne… pas (impératif)"], ["可以", "kěyǐ", "pouvoir (permission)"], ["最", "zuì", "le plus"], ["外", "wài", "dehors, extérieur"], ["飞机", "fēijī", "avion"], ["过", "guo", "particule d'expérience"], ["它", "tā", "il, elle (objet, animal)"], ["路上", "lùshang", "en route"]],
    quiz: [
      mcq("« Je suis allé trois fois en Chine » :", ["我三次去过中国。", "我去过中国三次。", "我去中国过三次。", "我去过三中国次。"], 1, "Verbe + 过 + lieu + nombre + 次."),
      fill("这是我 ___ 一次来北京。(ordinal)", ["第", "dì", "di"], "第一次 = la première fois."),
      mcq("« N'oublie pas ton passeport ! » :", ["不忘了护照！", "别忘了带护照！", "没忘护照！", "忘别了护照！"], 1, "别 + verbe = ne… pas (conseil)."),
      mcq("别玩手机了 signifie :", ["Joue sur ton téléphone", "Arrête de jouer sur ton téléphone", "Tu as perdu ton téléphone", "Prête-moi ton téléphone"], 1, "别…了 = arrête de…"),
      fill("我 ___ 喜欢的菜是饺子。(le plus)", ["最", "zuì", "zui"], "最 = le plus."),
      match("Associez", [["旅游|lǚyóu", "voyager"], ["去年|qùnián", "l'an dernier"], ["票|piào", "billet"], ["房间|fángjiān", "chambre"]]),
      mcq("我可以进来吗？demande :", ["si on peut entrer", "si on sait entrer", "si on veut entrer", "si on est entré"], 0, "可以 = permission."),
      tr("Traduisez : C'est la première fois que je prends l'avion.", ["这是我第一次坐飞机", "zhè shì wǒ dì-yī cì zuò fēijī", "zhe shi wo di yi ci zuo feiji", "zhe shi wo diyici zuo feiji", "我第一次坐飞机"], "第一次 + verbe."),
    ],
  },
];

/** Questions ajoutées à l'examen HSK 2 (à la suite des 8 d'origine) */
export const HSK2_EXAM_PLUS = [
  mcq("« Il est en train de dormir » :", ["他睡觉了。", "他正在睡觉呢。", "他睡觉过。", "他要睡觉。"], 1, "正在…呢."),
  mcq("« Elle court vite » :", ["她跑很快。", "她跑得很快。", "她很快跑得。", "她跑的快很。"], 1, "Verbe + 得 + adjectif."),
  mcq("因为太累了，___ 我想休息。", ["但是", "所以", "虽然", "还是"], 1, "因为… 所以…"),
  mcq("虽然下雨，___ 我们还是去了。", ["所以", "但是", "因为", "就"], 1, "虽然… 但是…"),
  fill("学校 ___ 我家很远。(distance)", ["离", "lí", "li"], "A 离 B 远."),
  mcq("« Le film va commencer » :", ["电影要开始了。", "电影已经开始。", "电影开始过。", "电影开始着。"], 0, "要…了."),
  fill("我 ___ 看完这本书了。(déjà)", ["已经", "yǐjīng", "yijing"], "已经…了."),
  mcq("« Je t'achète un livre » :", ["我买你给一本书。", "我给你买一本书。", "我给买你一本书。", "我买一本书你给。"], 1, "给 + personne + verbe."),
  mcq("Classificateur pour 衣服 :", ["个", "本", "件", "只"], 2, "一件衣服."),
  mcq("« Grande sœur » :", ["妹妹", "姐姐", "弟弟", "哥哥"], 1, "姐姐 jiějie."),
  mcq("« Tu veux des nouilles ou du riz ? » :", ["你要面条或者米饭吗？", "你要面条还是米饭？", "你要面条和米饭吗？", "你还是面条米饭？"], 1, "Question à choix : 还是."),
  tr("Traduisez : Je suis allé deux fois à Shanghai.", ["我去过上海两次", "我去过两次上海", "wǒ qù guo Shànghǎi liǎng cì", "wo qu guo shanghai liang ci", "wo quguo shanghai liang ci", "wo qu guo liang ci shanghai"], "Verbe + 过 + nombre + 次."),
];
