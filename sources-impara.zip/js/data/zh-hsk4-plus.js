/* =====================================================================
   Mandarin — compléments du palier HSK 4 (B2)
   ---------------------------------------------------------------------
   Calé sur le programme HSK 4 : connecteurs de concession et de
   condition (无论, 即使, 既然, 否则), compléments potentiels (看得懂,
   来不及), sens figurés des compléments de direction (想起来, 说下去),
   questions rhétoriques (难道, 不是…吗), surprise et attente (竟然,
   果然, 难怪, 原来), probabilité (恐怕, 估计, 说不定), connecteurs de
   discours (另外, 甚至, 于是, 因此), degré (极了, 得很, 稍微, 尤其),
   expressions orales, et vocabulaire du voyage, du numérique, de la
   société et des fêtes traditionnelles.
   Les leçons s'ajoutent APRÈS les 3 leçons d'origine du palier.
   ===================================================================== */

const mcq = (q, options, answer, explain = "") => ({ type: "mcq", q, options, answer, explain });
const fill = (q, answer, explain = "") => ({ type: "fill", q, answer, explain });
const match = (q, pairs, explain = "") => ({ type: "match", q, pairs, explain });
const tr = (q, answer, explain = "") => ({ type: "translate", q, answer, explain });

export const HSK4_PLUS = [
  /* ------------------------------------------------------------ 4 */
  {
    id: "b2-wulun", module: "gram", title: "Quoi qu'il arrive, même si : 无论, 即使, 既然, 否则", emoji: "🔗",
    intro: "Après 因为…所以 et 虽然…但是, voici les connecteurs du HSK 4 pour exprimer l'inconditionnel, la concession forte et la conséquence logique.",
    sections: [
      {
        title: "无论 / 不管… 都 : quoi que, quel que soit",
        text: "<b>无论 wúlùn</b> (écrit) ou <b>不管 bùguǎn</b> (oral) + mot interrogatif ou alternative (A 还是 B), puis <b>都 dōu</b> ou <b>也 yě</b>.",
        examples: [["无论多忙，他都每天锻炼。", "wúlùn duō máng, tā dōu měitiān duànliàn.", "Aussi occupé soit-il, il fait du sport tous les jours."], ["不管你去不去，我都去。", "bùguǎn nǐ qù bu qù, wǒ dōu qù.", "Que tu y ailles ou non, moi j'y vais."], ["无论谁来，都要先登记。", "wúlùn shéi lái, dōu yào xiān dēngjì.", "Qui que ce soit, il faut d'abord s'enregistrer."]],
      },
      {
        title: "即使… 也 : même si",
        text: "<b>即使 jíshǐ</b> introduit une hypothèse, souvent extrême ; la conséquence ne change pas : <b>也</b>. À l'oral : <b>就算 jiùsuàn… 也</b>.",
        examples: [["即使下雨，比赛也不会取消。", "jíshǐ xià yǔ, bǐsài yě bú huì qǔxiāo.", "Même s'il pleut, le match ne sera pas annulé."], ["就算你不说，我也知道。", "jiùsuàn nǐ bù shuō, wǒ yě zhīdào.", "Même si tu ne dis rien, je le sais."]],
      },
      {
        title: "既然… 就 : puisque ; 否则 : sinon",
        text: "<b>既然 jìrán</b> part d'un fait déjà admis pour en tirer une conclusion avec <b>就</b>. <b>否则 fǒuzé</b> (= 要不然) introduit la conséquence si on ne fait pas quelque chose.",
        examples: [["既然你不舒服，就早点儿回家吧。", "jìrán nǐ bù shūfu, jiù zǎo diǎnr huí jiā ba.", "Puisque tu ne te sens pas bien, rentre donc plus tôt."], ["快走吧，否则会迟到。", "kuài zǒu ba, fǒuzé huì chídào.", "Dépêchons-nous, sinon nous serons en retard."]],
      },
    ],
    mnemo: "无论 / 不管 et 都 ; 即使 et 也 ; 既然 et 就 : chaque connecteur a son partenaire dans la 2e partie, comme au HSK 3.",
    vocab: [["无论", "wúlùn", "quel que soit, quoi que"], ["不管", "bùguǎn", "peu importe (oral)"], ["即使", "jíshǐ", "même si"], ["就算", "jiùsuàn", "même si (oral)"], ["既然", "jìrán", "puisque"], ["否则", "fǒuzé", "sinon"], ["取消", "qǔxiāo", "annuler"], ["登记", "dēngjì", "s'enregistrer"], ["锻炼", "duànliàn", "faire de l'exercice"], ["迟到", "chídào", "être en retard"]],
    quiz: [
      fill("无论天气怎么样，我们 ___ 去。", ["都", "dōu", "dou"], "无论… 都."),
      mcq("___ 下大雪，他也要去上班。", ["因为", "即使", "既然", "所以"], 1, "即使… 也 = même si."),
      mcq("既然你已经决定了，___ 去做吧。", ["也", "都", "就", "才"], 2, "既然… 就."),
      fill("快吃吧，___ 菜就凉了。(sinon)", ["否则", "fǒuzé", "fouze", "要不然", "yàobùrán"], "否则 = sinon."),
      mcq("« Que tu viennes ou non, je pars » :", ["不管你来不来，我都走。", "因为你来不来，所以我走。", "即使你来不来，我就走。", "既然你来不来，我也走。"], 0, "不管 + alternative + 都."),
      match("Associez", [["无论|wúlùn", "quel que soit"], ["即使|jíshǐ", "même si"], ["既然|jìrán", "puisque"], ["否则|fǒuzé", "sinon"]]),
      tr("Traduisez : Même s'il pleut, j'irai.", ["即使下雨我也去", "即使下雨，我也去", "就算下雨我也去", "jíshǐ xià yǔ wǒ yě qù", "jishi xia yu wo ye qu"], "即使… 也."),
    ],
  },

  /* ------------------------------------------------------------ 5 */
  {
    id: "b2-kebuliao", module: "gram", title: "Pouvoir ou ne pas pouvoir : les compléments potentiels", emoji: "🎯",
    intro: "看得懂, 听不清楚, 来不及 : en glissant 得 ou 不 entre le verbe et son complément, on dit si le résultat est POSSIBLE ou non.",
    sections: [
      {
        title: "Verbe + 得 / 不 + résultat ou direction",
        text: "<b>听懂</b> (comprendre en écoutant) → <b>听得懂</b> (arriver à comprendre) / <b>听不懂</b> (ne pas arriver à comprendre). Fonctionne avec les compléments de résultat et de direction.",
        examples: [["老师说得太快，我听不懂。", "lǎoshī shuō de tài kuài, wǒ tīng bu dǒng.", "Le professeur parle trop vite, je n'arrive pas à comprendre."], ["这么多菜，我们吃得完吗？", "zhème duō cài, wǒmen chī de wán ma?", "Autant de plats, on va pouvoir tout finir ?"], ["门太小了，桌子搬不进去。", "mén tài xiǎo le, zhuōzi bān bu jìnqu.", "La porte est trop petite, on ne peut pas rentrer la table."]],
      },
      {
        title: "Les plus fréquents",
        text: "<b>来得及 / 来不及</b> (avoir / ne pas avoir le temps), <b>买不到</b> (introuvable), <b>找不到</b>, <b>受不了</b> (ne pas supporter), <b>V + 不了</b> (ne pas pouvoir du tout).",
        examples: [["快点儿，还来得及。", "kuài diǎnr, hái lái de jí.", "Vite, on a encore le temps."], ["票已经卖完了，买不到了。", "piào yǐjīng mài wán le, mǎi bu dào le.", "Les billets sont épuisés, impossible d'en trouver."], ["这么热的天气，我真受不了。", "zhème rè de tiānqì, wǒ zhēn shòu bu liǎo.", "Avec cette chaleur, je ne supporte vraiment pas."]],
      },
      {
        title: "Potentiel ou 能 ?",
        text: "<b>能</b> exprime une permission ou une capacité générale ; le complément potentiel insiste sur la possibilité concrète d'atteindre le résultat. Question : <b>看得见看不见？</b>",
        examples: [["你看得见黑板上的字吗？", "nǐ kàn de jiàn hēibǎn shang de zì ma?", "Tu arrives à voir ce qui est écrit au tableau ?"], ["我一个人拿不动这个箱子。", "wǒ yí ge rén ná bu dòng zhège xiāngzi.", "Je n'arrive pas à porter cette valise tout seul."]],
      },
    ],
    mnemo: "得 = le pont est ouvert, 不 = le pont est coupé : 看得懂 / 看不懂.",
    vocab: [["来得及", "lái de jí", "avoir le temps"], ["来不及", "lái bu jí", "ne pas avoir le temps"], ["受不了", "shòu bu liǎo", "ne pas supporter"], ["听不懂", "tīng bu dǒng", "ne pas comprendre (à l'oral)"], ["看得见", "kàn de jiàn", "arriver à voir"], ["拿不动", "ná bu dòng", "ne pas arriver à porter"], ["箱子", "xiāngzi", "valise, caisse"], ["黑板", "hēibǎn", "tableau noir"], ["搬", "bān", "déplacer, déménager"]],
    quiz: [
      mcq("« Je n'arrive pas à comprendre (à l'écrit) » :", ["我看懂不。", "我看不懂。", "我不看懂。", "我看得不懂。"], 1, "V + 不 + résultat."),
      fill("电影七点开始，现在六点半，还来 ___ 及。", ["得", "de"], "来得及 = on a le temps."),
      mcq("Il fait trop chaud, « je ne supporte pas » :", ["我受不了。", "我不受了。", "我受得了不。", "我没受。"], 0, "受不了."),
      mcq("你看得见吗？— 我 ___ 。(non)", ["看得见", "看不见", "不看见", "没看得见"], 1, "Réponse négative : 看不见."),
      fill("箱子太重了，我拿 ___ 动。", ["不", "bu", "bù"], "拿不动."),
      match("Associez", [["来不及|lái bu jí", "ne pas avoir le temps"], ["买不到|mǎi bu dào", "introuvable"], ["听得懂|tīng de dǒng", "arriver à comprendre"], ["受不了|shòu bu liǎo", "ne pas supporter"]]),
      tr("Traduisez : Je n'arrive pas à trouver mes clés.", ["我找不到我的钥匙", "我找不到钥匙", "wǒ zhǎo bu dào wǒ de yàoshi", "wo zhao bu dao wo de yaoshi", "wo zhao bu dao yaoshi"], "找不到."),
    ],
  },

  /* ------------------------------------------------------------ 6 */
  {
    id: "b2-quxiang", module: "gram", title: "想起来, 说下去, 看出来 : la direction au sens figuré", emoji: "↗️",
    intro: "起来, 下去, 出来, 下来 ne décrivent pas seulement un mouvement : ils expriment le début, la continuation, la découverte ou la fixation.",
    sections: [
      {
        title: "起来 : commencer, se souvenir, impression",
        text: "<b>V + 起来</b> : début d'une action (<i>笑起来</i>), souvenir (<i>想起来</i>), impression (<i>看起来 / 听起来</i> = avoir l'air).",
        examples: [["听到这个消息，大家都笑起来了。", "tīng dào zhège xiāoxi, dàjiā dōu xiào qǐlai le.", "En apprenant la nouvelle, tout le monde s'est mis à rire."], ["我想起来了，他叫李明！", "wǒ xiǎng qǐlai le, tā jiào Lǐ Míng!", "Ça me revient, il s'appelle Li Ming !"], ["这个菜看起来很好吃。", "zhège cài kàn qǐlai hěn hǎochī.", "Ce plat a l'air délicieux."]],
      },
      {
        title: "下去 : continuer ; 下来 : se fixer, s'arrêter",
        text: "<b>V + 下去</b> = continuer à (vers l'avenir). <b>V + 下来</b> = fixer quelque chose ou passer d'un mouvement à l'arrêt.",
        examples: [["别停，说下去！", "bié tíng, shuō xiàqu!", "Ne t'arrête pas, continue !"], ["学外语一定要坚持下去。", "xué wàiyǔ yídìng yào jiānchí xiàqu.", "Pour apprendre une langue, il faut absolument persévérer."], ["请把电话号码写下来。", "qǐng bǎ diànhuà hàomǎ xiě xiàlai.", "Notez le numéro de téléphone, s'il vous plaît."], ["车慢慢停下来了。", "chē mànmàn tíng xiàlai le.", "La voiture s'est arrêtée lentement."]],
      },
      {
        title: "出来 : faire apparaître, reconnaître",
        text: "<b>V + 出来</b> = faire émerger quelque chose : trouver une idée (<i>想出来</i>), reconnaître (<i>看出来 / 听出来</i>).",
        examples: [["我想出来一个好办法。", "wǒ xiǎng chūlai yí ge hǎo bànfǎ.", "J'ai trouvé une bonne solution."], ["你听得出来这是谁的声音吗？", "nǐ tīng de chūlai zhè shì shéi de shēngyīn ma?", "Tu arrives à reconnaître la voix de qui c'est ?"]],
      },
    ],
    mnemo: "想起来 = la mémoire « remonte » ; 想出来 = l'idée « sort » ; 说下去 = la parole « continue de descendre » vers la suite.",
    vocab: [["想起来", "xiǎng qǐlai", "se rappeler"], ["看起来", "kàn qǐlai", "avoir l'air"], ["想出来", "xiǎng chūlai", "trouver (une idée)"], ["坚持", "jiānchí", "persévérer"], ["消息", "xiāoxi", "nouvelle, information"], ["办法", "bànfǎ", "moyen, solution"], ["声音", "shēngyīn", "son, voix"], ["号码", "hàomǎ", "numéro"]],
    quiz: [
      mcq("« Ça me revient ! » :", ["我想出来了！", "我想起来了！", "我想下去了！", "我想下来了！"], 1, "想起来 = se souvenir."),
      mcq("« Il a l'air fatigué » :", ["他看起来很累。", "他看出来很累。", "他看下去很累。", "他看上很累。"], 0, "看起来 = avoir l'air."),
      fill("你的故事很有意思，请说 ___ 。(continuer)", ["下去", "xiàqu", "xiaqu"], "说下去."),
      fill("请把地址写 ___ 。(fixer par écrit)", ["下来", "xiàlai", "xialai"], "写下来."),
      mcq("« J'ai trouvé une idée » :", ["我想起来一个主意。", "我想出来一个主意。", "我想下去一个主意。", "我想上来一个主意。"], 1, "想出来."),
      match("Associez", [["笑起来|xiào qǐlai", "se mettre à rire"], ["坚持下去|jiānchí xiàqu", "persévérer"], ["停下来|tíng xiàlai", "s'arrêter"], ["听出来|tīng chūlai", "reconnaître (au son)"]]),
      tr("Traduisez : Ce plat a l'air délicieux.", ["这个菜看起来很好吃", "这道菜看起来很好吃", "zhège cài kàn qǐlai hěn hǎochī", "zhege cai kan qilai hen haochi"], "看起来."),
    ],
  },

  /* ------------------------------------------------------------ 7 */
  {
    id: "b2-fanwen", module: "gram", title: "Les questions rhétoriques : 难道…吗, 不是…吗", emoji: "❓",
    intro: "Une question qui n'attend pas de réponse : pour s'étonner, reprocher ou insister. Très fréquente à l'oral.",
    sections: [
      {
        title: "难道… 吗 ? : « ne me dis pas que… ? »",
        text: "<b>难道 nándào</b> exprime l'étonnement ou le reproche ; la phrase sous-entend le contraire de ce qu'elle dit.",
        examples: [["难道你不知道吗？", "nándào nǐ bù zhīdào ma?", "Ne me dis pas que tu ne le savais pas ?"], ["难道他忘了我们的约会？", "nándào tā wàng le wǒmen de yuēhuì?", "Il aurait oublié notre rendez-vous ?"]],
      },
      {
        title: "不是… 吗 ? : « est-ce que ce n'est pas… ? »",
        text: "<b>不是… 吗</b> rappelle un fait que l'interlocuteur devrait connaître : <i>tu n'avais pas dit que… ?</i>",
        examples: [["你不是说今天不来吗？", "nǐ bú shì shuō jīntiān bù lái ma?", "Tu n'avais pas dit que tu ne venais pas aujourd'hui ?"], ["这不是你的手机吗？", "zhè bú shì nǐ de shǒujī ma?", "Ce n'est pas ton téléphone, ça ?"]],
      },
      {
        title: "怎么能… 呢 / 何必 : reproche et inutilité",
        text: "<b>怎么能… 呢</b> = comment peut-on… ! (reproche). <b>何必 hébì</b> = à quoi bon, pas la peine de.",
        examples: [["你怎么能这样说呢？", "nǐ zěnme néng zhèyàng shuō ne?", "Comment peux-tu dire une chose pareille ?"], ["坐地铁很方便，何必打车呢？", "zuò dìtiě hěn fāngbiàn, hébì dǎ chē ne?", "Le métro est pratique, à quoi bon prendre un taxi ?"]],
      },
    ],
    mnemo: "难道 contient 难 (difficile) : « est-ce difficile à croire que… ? » — on n'y croit pas.",
    vocab: [["难道", "nándào", "ne me dis pas que… ?"], ["何必", "hébì", "à quoi bon"], ["约会", "yuēhuì", "rendez-vous"], ["忘", "wàng", "oublier"], ["这样", "zhèyàng", "ainsi, comme ça"], ["方便", "fāngbiàn", "pratique"], ["打车", "dǎ chē", "prendre un taxi"]],
    quiz: [
      fill("___ 你不认识他吗？(étonnement)", ["难道", "nándào", "nandao"], "难道… 吗."),
      mcq("你 ___ 说今天要加班吗？", ["不是", "难道是", "何必", "怎么"], 0, "不是… 吗 : tu n'avais pas dit que…"),
      mcq("« À quoi bon s'inquiéter ? » :", ["何必担心呢？", "难道担心吗？", "不是担心吗？", "怎么担心了？"], 0, "何必 = à quoi bon."),
      mcq("« 难道你忘了吗？ » signifie :", ["Tu as oublié, n'est-ce pas ?", "Ne me dis pas que tu as oublié ?", "Tu n'oublieras pas ?", "Pourquoi oublier ?"], 1, "Étonnement / reproche."),
      fill("你怎么能这么做 ___ ？", ["呢", "ne"], "怎么能… 呢."),
      tr("Traduisez : Ce n'est pas ton téléphone, ça ?", ["这不是你的手机吗", "zhè bú shì nǐ de shǒujī ma", "zhe bu shi ni de shouji ma"], "不是… 吗."),
    ],
  },

  /* ------------------------------------------------------------ 8 */
  {
    id: "b2-jingran", module: "gram", title: "Surprise et attente : 竟然, 果然, 难怪, 原来", emoji: "😲",
    intro: "Ces adverbes donnent l'émotion du récit : contre toute attente, comme prévu, pas étonnant que, en fait…",
    sections: [
      {
        title: "竟然 / 居然 : contre toute attente",
        text: "<b>竟然 jìngrán</b> (ou <b>居然 jūrán</b>) se place devant le verbe et marque la surprise.",
        examples: [["他学了三个月，竟然能说得这么好！", "tā xué le sān ge yuè, jìngrán néng shuō de zhème hǎo!", "Il n'a étudié que trois mois et il parle déjà si bien !"], ["这么简单的题，他居然做错了。", "zhème jiǎndān de tí, tā jūrán zuò cuò le.", "Une question aussi simple, et il s'est trompé !"]],
      },
      {
        title: "果然 : comme prévu ; 难怪 : pas étonnant que",
        text: "<b>果然 guǒrán</b> confirme une prévision. <b>难怪 nánguài</b> : on comprend enfin la raison d'un fait.",
        examples: [["天气预报说有雨，果然下雨了。", "tiānqì yùbào shuō yǒu yǔ, guǒrán xià yǔ le.", "La météo annonçait de la pluie, et il pleut, comme prévu."], ["他在中国住了十年，难怪中文这么好。", "tā zài Zhōngguó zhù le shí nián, nánguài Zhōngwén zhème hǎo.", "Il a vécu dix ans en Chine, pas étonnant qu'il parle si bien chinois."]],
      },
      {
        title: "原来 : en fait ; 以为 / 认为",
        text: "<b>原来 yuánlái</b> révèle la vraie situation. <b>以为 yǐwéi</b> = croire (à tort) ; <b>认为 rènwéi</b> = estimer, être d'avis que.",
        examples: [["原来你们是同学啊！", "yuánlái nǐmen shì tóngxué a!", "En fait, vous êtes camarades de classe !"], ["我以为你是日本人，原来你是韩国人。", "wǒ yǐwéi nǐ shì Rìběnrén, yuánlái nǐ shì Hánguórén.", "Je croyais que tu étais japonais, en fait tu es coréen."], ["我认为这个计划很好。", "wǒ rènwéi zhège jìhuà hěn hǎo.", "J'estime que ce projet est bon."]],
      },
    ],
    mnemo: "以为 = « je croyais, mais non » ; 原来 = « ah, en fait ! ». Ils vont souvent ensemble.",
    vocab: [["竟然", "jìngrán", "contre toute attente"], ["居然", "jūrán", "contre toute attente"], ["果然", "guǒrán", "comme prévu"], ["难怪", "nánguài", "pas étonnant que"], ["原来", "yuánlái", "en fait ; à l'origine"], ["以为", "yǐwéi", "croire (à tort)"], ["认为", "rènwéi", "estimer, penser que"], ["预报", "yùbào", "prévision"], ["简单", "jiǎndān", "simple"], ["计划", "jìhuà", "projet, plan"]],
    quiz: [
      mcq("我 ___ 他今天不来，没想到他来了。", ["认为", "以为", "原来", "果然"], 1, "以为 = croire à tort."),
      mcq("他每天练习，___ 考得很好。(comme prévu)", ["竟然", "果然", "难道", "何必"], 1, "果然 = comme prévu."),
      fill("外面下雪了，___ 这么冷。(pas étonnant)", ["难怪", "nánguài", "nanguai"], "难怪."),
      mcq("« Contre toute attente, il a gagné » :", ["他果然赢了。", "他竟然赢了。", "他难怪赢了。", "他以为赢了。"], 1, "竟然 = surprise."),
      fill("___ 你就是王老师！(en fait)", ["原来", "yuánlái", "yuanlai"], "原来 = en fait."),
      match("Associez", [["竟然|jìngrán", "contre toute attente"], ["果然|guǒrán", "comme prévu"], ["难怪|nánguài", "pas étonnant que"], ["以为|yǐwéi", "croire à tort"]]),
      tr("Traduisez : Je croyais que tu étais japonais.", ["我以为你是日本人", "wǒ yǐwéi nǐ shì Rìběnrén", "wo yiwei ni shi ribenren"], "以为."),
    ],
  },

  /* ------------------------------------------------------------ 9 */
  {
    id: "b2-kanlai", module: "expr", title: "Probable, peut-être, sûrement : 看来, 恐怕, 估计, 说不定", emoji: "🤔",
    intro: "Nuancer ce qu'on affirme : déduire, craindre, estimer, envisager. Indispensable pour ne pas parler de façon trop catégorique.",
    sections: [
      {
        title: "Déduire et estimer",
        text: "<b>看来 kànlái</b> = apparemment (déduction d'un indice). <b>估计 gūjì</b> = j'estime que, sûrement. <b>好像 hǎoxiàng</b> = on dirait que.",
        examples: [["他的灯还亮着，看来还没睡。", "tā de dēng hái liàng zhe, kànlái hái méi shuì.", "Sa lumière est encore allumée, apparemment il ne dort pas encore."], ["估计他十点以后才到。", "gūjì tā shí diǎn yǐhòu cái dào.", "Il n'arrivera sûrement pas avant dix heures."]],
      },
      {
        title: "Craindre et envisager",
        text: "<b>恐怕 kǒngpà</b> = je crains que (annonce poliment une mauvaise nouvelle). <b>说不定 shuōbudìng</b> = peut-être bien, qui sait. <b>不见得 bú jiàndé</b> = pas forcément.",
        examples: [["恐怕我明天去不了。", "kǒngpà wǒ míngtiān qù bu liǎo.", "Je crains de ne pas pouvoir y aller demain."], ["说不定他已经知道了。", "shuōbudìng tā yǐjīng zhīdào le.", "Il est bien possible qu'il le sache déjà."], ["贵的东西不见得好。", "guì de dōngxi bú jiàndé hǎo.", "Ce qui est cher n'est pas forcément bon."]],
      },
      {
        title: "Certain : 肯定, 一定",
        text: "<b>肯定 kěndìng</b> et <b>一定 yídìng</b> = sûrement, à coup sûr. Au négatif : <b>不一定</b> = pas forcément.",
        examples: [["他肯定会同意的。", "tā kěndìng huì tóngyì de.", "Il sera sûrement d'accord."], ["我不一定有时间。", "wǒ bù yídìng yǒu shíjiān.", "Je n'aurai pas forcément le temps."]],
      },
    ],
    mnemo: "恐怕 contient 怕 (avoir peur) : on « craint » de devoir annoncer quelque chose.",
    vocab: [["看来", "kànlái", "apparemment"], ["估计", "gūjì", "estimer, sûrement"], ["恐怕", "kǒngpà", "je crains que"], ["说不定", "shuōbudìng", "peut-être bien"], ["不见得", "bú jiàndé", "pas forcément"], ["肯定", "kěndìng", "sûrement, certain"], ["好像", "hǎoxiàng", "on dirait que"], ["同意", "tóngyì", "être d'accord"], ["亮", "liàng", "allumé, lumineux"]],
    quiz: [
      mcq("Annoncer poliment : « Je crains d'être en retard » :", ["恐怕我要迟到了。", "肯定我要迟到了。", "看来我迟到。", "难怪我迟到。"], 0, "恐怕 = je crains que."),
      fill("他没回消息，___ 他在开会。(apparemment)", ["看来", "kànlái", "kanlai"], "看来 = déduction."),
      mcq("« Pas forcément » :", ["一定", "不见得", "肯定", "看来"], 1, "不见得 / 不一定."),
      fill("别着急，___ 他马上就到。(peut-être bien)", ["说不定", "shuōbudìng", "shuobuding"], "说不定."),
      mcq("« Il sera sûrement d'accord » :", ["他恐怕同意。", "他肯定会同意的。", "他不见得同意。", "他说不定不同意。"], 1, "肯定 = sûrement."),
      match("Associez", [["估计|gūjì", "estimer"], ["恐怕|kǒngpà", "je crains que"], ["说不定|shuōbudìng", "peut-être bien"], ["肯定|kěndìng", "sûrement"]]),
    ],
  },

  /* ------------------------------------------------------------ 10 */
  {
    id: "b2-lianjie", module: "gram", title: "Structurer un texte : 另外, 甚至, 于是, 因此, 总之", emoji: "🧱",
    intro: "Pour écrire un paragraphe ou raconter une suite d'événements de façon fluide, ces connecteurs relient les phrases entre elles.",
    sections: [
      {
        title: "Ajouter et renchérir",
        text: "<b>另外 lìngwài</b> = par ailleurs. <b>并且 bìngqiě</b> = et en plus (écrit). <b>甚至 shènzhì</b> = et même. <b>何况 hékuàng</b> = à plus forte raison.",
        examples: [["这家饭馆很便宜，另外，服务也很好。", "zhè jiā fànguǎn hěn piányi, lìngwài, fúwù yě hěn hǎo.", "Ce restaurant est bon marché ; par ailleurs, le service est très bien."], ["他忙得甚至没有时间吃饭。", "tā máng de shènzhì méiyǒu shíjiān chī fàn.", "Il est tellement occupé qu'il n'a même pas le temps de manger."], ["中国人都觉得难，何况外国人呢？", "Zhōngguórén dōu juéde nán, hékuàng wàiguórén ne?", "Même les Chinois trouvent ça difficile, alors les étrangers…"]],
      },
      {
        title: "Enchaîner et conclure",
        text: "<b>于是 yúshì</b> = alors, du coup (récit). <b>因此 yīncǐ</b> = c'est pourquoi (écrit). <b>总之 zǒngzhī</b> = bref, en somme.",
        examples: [["外面下雨了，于是我们决定在家看电影。", "wàimiàn xià yǔ le, yúshì wǒmen juédìng zài jiā kàn diànyǐng.", "Il s'est mis à pleuvoir, alors nous avons décidé de regarder un film à la maison."], ["他工作很努力，因此得到了老板的表扬。", "tā gōngzuò hěn nǔlì, yīncǐ dédào le lǎobǎn de biǎoyáng.", "Il travaille dur, c'est pourquoi il a été félicité par son patron."], ["总之，这次旅行非常成功。", "zǒngzhī, zhè cì lǚxíng fēicháng chénggōng.", "Bref, ce voyage a été une grande réussite."]],
      },
      {
        title: "Opposer : 不过, 然而",
        text: "<b>不过 búguò</b> = mais, toutefois (oral courant). <b>然而 rán'ér</b> = cependant (écrit).",
        examples: [["这个手机不错，不过有点儿贵。", "zhège shǒujī búcuò, búguò yǒudiǎnr guì.", "Ce téléphone est bien, mais un peu cher."], ["大家都以为他会输，然而他赢了。", "dàjiā dōu yǐwéi tā huì shū, rán'ér tā yíng le.", "Tout le monde pensait qu'il perdrait ; cependant, il a gagné."]],
      },
    ],
    mnemo: "于是 = « et là… » dans une histoire ; 因此 = « c'est pourquoi » dans un texte argumenté.",
    vocab: [["另外", "lìngwài", "par ailleurs"], ["甚至", "shènzhì", "et même"], ["何况", "hékuàng", "à plus forte raison"], ["于是", "yúshì", "alors, du coup"], ["因此", "yīncǐ", "c'est pourquoi"], ["总之", "zǒngzhī", "bref"], ["不过", "búguò", "mais, toutefois"], ["然而", "rán'ér", "cependant"], ["表扬", "biǎoyáng", "féliciter"], ["服务", "fúwù", "service"]],
    quiz: [
      mcq("门开着，没有人，___ 我就进去了。(alors, récit)", ["于是", "何况", "另外", "甚至"], 0, "于是 dans un récit."),
      fill("他很累，___ 连话都不想说。(et même)", ["甚至", "shènzhì", "shenzhi"], "甚至."),
      mcq("« Bref » :", ["总之", "因此", "不过", "然而"], 0, "总之."),
      fill("这本书很有意思，___ ，也不贵。(par ailleurs)", ["另外", "lìngwài", "lingwai"], "另外."),
      mcq("Quel connecteur est le plus écrit ?", ["不过", "然而", "可是", "但是"], 1, "然而 = cependant (écrit)."),
      match("Associez", [["因此|yīncǐ", "c'est pourquoi"], ["何况|hékuàng", "à plus forte raison"], ["于是|yúshì", "alors"], ["不过|búguò", "toutefois"]]),
    ],
  },

  /* ------------------------------------------------------------ 11 */
  {
    id: "b2-chengdu", module: "gram", title: "Très, extrêmement, un peu : 极了, 得很, 稍微, 尤其", emoji: "📈",
    intro: "Varier les intensifs et les atténuateurs, et ne plus confondre 有点儿 et 一点儿.",
    sections: [
      {
        title: "Renforcer après l'adjectif",
        text: "<b>Adj + 极了 jíle</b> = extrêmement. <b>Adj + 得很</b> = très (oral). <b>Adj + 死了</b> = à mourir (familier). <b>Adj + 得不得了</b> = incroyablement.",
        examples: [["这儿的风景美极了！", "zhèr de fēngjǐng měi jíle!", "Le paysage ici est extrêmement beau !"], ["今天热死了。", "jīntiān rè sǐ le.", "Il fait une chaleur à mourir aujourd'hui."], ["他高兴得不得了。", "tā gāoxìng de bùdéliǎo.", "Il est incroyablement content."]],
      },
      {
        title: "Atténuer : 有点儿 ≠ 一点儿, 稍微",
        text: "<b>有点儿 + adj</b> (avant) = un peu, souvent négatif : <i>有点儿贵</i>. <b>adj + 一点儿</b> (après) = un peu plus, comparaison ou demande : <i>便宜一点儿</i>. <b>稍微 shāowēi</b> + V/adj + 一点儿 = légèrement.",
        examples: [["这件衣服有点儿大。", "zhè jiàn yīfu yǒudiǎnr dà.", "Ce vêtement est un peu grand."], ["能便宜一点儿吗？", "néng piányi yìdiǎnr ma?", "Vous pouvez faire un peu moins cher ?"], ["请稍微等一下。", "qǐng shāowēi děng yíxià.", "Patientez un petit instant, s'il vous plaît."]],
      },
      {
        title: "Mettre en relief : 尤其, 特别",
        text: "<b>尤其 yóuqí</b> = surtout, en particulier. <b>特别 tèbié</b> = particulièrement.",
        examples: [["我喜欢运动，尤其是游泳。", "wǒ xǐhuan yùndòng, yóuqí shì yóuyǒng.", "J'aime le sport, surtout la natation."], ["北京的冬天特别干燥。", "Běijīng de dōngtiān tèbié gānzào.", "L'hiver à Pékin est particulièrement sec."]],
      },
    ],
    mnemo: "有点儿 avant = « un peu trop » (on se plaint) ; 一点儿 après = « un peu plus » (on demande).",
    vocab: [["极了", "jíle", "extrêmement"], ["得很", "de hěn", "très"], ["死了", "sǐ le", "à mourir (familier)"], ["有点儿", "yǒudiǎnr", "un peu (trop)"], ["稍微", "shāowēi", "légèrement"], ["尤其", "yóuqí", "surtout"], ["特别", "tèbié", "particulièrement"], ["风景", "fēngjǐng", "paysage"], ["干燥", "gānzào", "sec"]],
    quiz: [
      mcq("« Ce plat est un peu salé » (on se plaint) :", ["这个菜咸一点儿。", "这个菜有点儿咸。", "这个菜一点儿咸。", "这个菜咸有点儿。"], 1, "有点儿 + adj."),
      mcq("Au marché : « Un peu moins cher ? » :", ["有点儿便宜吗？", "便宜一点儿吧？", "一点儿便宜吧？", "便宜有点儿吧？"], 1, "adj + 一点儿."),
      fill("今天的天气好 ___ 了！(extrêmement)", ["极", "jí", "ji"], "好极了."),
      fill("我喜欢中国菜，___ 是四川菜。(surtout)", ["尤其", "yóuqí", "youqi"], "尤其是."),
      mcq("« Attendez un petit instant » :", ["请稍微等一下。", "请有点儿等。", "请等极了。", "请一点儿等。"], 0, "稍微 + V + 一下."),
      tr("Traduisez : Ce vêtement est un peu grand.", ["这件衣服有点儿大", "这件衣服有点大", "zhè jiàn yīfu yǒudiǎnr dà", "zhe jian yifu youdianr da", "zhe jian yifu youdian da"], "有点儿 + adj."),
    ],
  },

  /* ------------------------------------------------------------ 12 */
  {
    id: "b2-lvxing", module: "vocab", title: "En voyage : réserver, annuler, réclamer", emoji: "🧳",
    intro: "Réserver un hôtel, changer un billet, signaler une valise perdue ou se plaindre poliment : le chinois des voyages au niveau HSK 4.",
    sections: [
      {
        title: "Réserver et changer",
        examples: [["预订", "yùdìng", "réserver"], ["取消", "qǔxiāo", "annuler"], ["改签", "gǎiqiān", "changer (un billet)"], ["退票", "tuì piào", "se faire rembourser un billet"], ["押金", "yājīn", "caution"], ["推迟", "tuīchí", "reporter, retarder"]],
      },
      {
        title: "Au comptoir",
        examples: [["我想预订一个双人间，住三个晚上。", "wǒ xiǎng yùdìng yí ge shuāngrénjiān, zhù sān ge wǎnshang.", "Je voudrais réserver une chambre double pour trois nuits."], ["航班推迟了两个小时。", "hángbān tuīchí le liǎng ge xiǎoshí.", "Le vol a été retardé de deux heures."], ["我的行李丢了，应该去哪儿登记？", "wǒ de xíngli diū le, yīnggāi qù nǎr dēngjì?", "Ma valise est perdue, où dois-je faire la déclaration ?"]],
      },
      {
        title: "Se plaindre poliment",
        text: "On commence par <b>不好意思</b> ou <b>麻烦你</b>, on décrit le problème avec <b>有点儿</b>, puis on demande <b>能不能…？</b>. <b>投诉 tóusù</b> = porter plainte (officiellement).",
        examples: [["不好意思，房间的空调有点儿问题。", "bù hǎoyìsi, fángjiān de kōngtiáo yǒudiǎnr wèntí.", "Excusez-moi, la climatisation de la chambre a un petit problème."], ["能不能给我换一个房间？", "néng bu néng gěi wǒ huàn yí ge fángjiān?", "Serait-il possible de me changer de chambre ?"]],
      },
    ],
    mnemo: "改签 (changer le billet) ≠ 退票 (rendre le billet) : en Chine, à la gare, on fait la queue au guichet 改签 / 退票.",
    vocab: [["预订", "yùdìng", "réserver"], ["取消", "qǔxiāo", "annuler"], ["退票", "tuì piào", "rendre un billet"], ["航班", "hángbān", "vol"], ["推迟", "tuīchí", "retarder"], ["行李", "xíngli", "bagages"], ["丢", "diū", "perdre"], ["押金", "yājīn", "caution"], ["空调", "kōngtiáo", "climatisation"], ["投诉", "tóusù", "porter plainte"]],
    quiz: [
      match("Associez", [["预订|yùdìng", "réserver"], ["取消|qǔxiāo", "annuler"], ["航班|hángbān", "vol"], ["行李|xíngli", "bagages"]]),
      fill("飞机 ___ 了一个小时。(retarder)", ["推迟", "tuīchí", "tuichi"], "推迟."),
      mcq("Pour rendre un billet de train :", ["退票", "买票", "改签", "检票"], 0, "退票 = se faire rembourser."),
      mcq("Demander poliment de changer de chambre :", ["给我换房间！", "能不能给我换一个房间？", "我要投诉你！", "房间不好。"], 1, "能不能…？ = poli."),
      fill("住酒店要先交 ___ 。(caution)", ["押金", "yājīn", "yajin"], "押金."),
      tr("Traduisez : Ma valise est perdue.", ["我的行李丢了", "我的箱子丢了", "wǒ de xíngli diū le", "wo de xingli diu le"], "丢了."),
    ],
  },

  /* ------------------------------------------------------------ 13 */
  {
    id: "b2-keji", module: "vocab", title: "La vie numérique : payer, commander, se connecter", emoji: "📱",
    intro: "En Chine, presque tout passe par le téléphone : paiement par QR code, achats en ligne, livraisons, VTC. Le vocabulaire du quotidien connecté.",
    sections: [
      {
        title: "Payer et acheter",
        examples: [["扫码", "sǎo mǎ", "scanner un QR code"], ["支付", "zhīfù", "payer"], ["网购", "wǎnggòu", "acheter en ligne"], ["快递", "kuàidì", "livraison express, colis"], ["外卖", "wàimài", "plats à emporter / livrés"], ["退货", "tuì huò", "retourner un article"]],
      },
      {
        title: "Téléphone et internet",
        examples: [["密码", "mìmǎ", "mot de passe"], ["下载", "xiàzài", "télécharger"], ["充电", "chōng diàn", "recharger"], ["信号", "xìnhào", "signal, réseau"], ["没电了", "méi diàn le", "plus de batterie"], ["上网", "shàng wǎng", "aller sur internet"]],
      },
      {
        title: "En situation",
        examples: [["可以扫码支付吗？", "kěyǐ sǎo mǎ zhīfù ma?", "Je peux payer en scannant le QR code ?"], ["我的手机没电了，哪儿可以充电？", "wǒ de shǒujī méi diàn le, nǎr kěyǐ chōng diàn?", "Mon téléphone n'a plus de batterie, où puis-je le recharger ?"], ["快递明天下午送到。", "kuàidì míngtiān xiàwǔ sòng dào.", "Le colis sera livré demain après-midi."], ["这里信号不好，我听不清楚。", "zhèlǐ xìnhào bù hǎo, wǒ tīng bu qīngchu.", "Il n'y a pas de réseau ici, je n'entends pas bien."]],
      },
    ],
    mnemo: "扫码 = « balayer le code » : on balaie le QR code avec l'appareil photo du téléphone.",
    vocab: [["扫码", "sǎo mǎ", "scanner un QR code"], ["支付", "zhīfù", "payer"], ["网购", "wǎnggòu", "achat en ligne"], ["快递", "kuàidì", "colis, livraison"], ["外卖", "wàimài", "livraison de repas"], ["密码", "mìmǎ", "mot de passe"], ["下载", "xiàzài", "télécharger"], ["充电", "chōng diàn", "recharger"], ["信号", "xìnhào", "réseau, signal"]],
    quiz: [
      match("Associez", [["密码|mìmǎ", "mot de passe"], ["下载|xiàzài", "télécharger"], ["快递|kuàidì", "colis"], ["外卖|wàimài", "repas livré"]]),
      mcq("« Je peux payer par QR code ? » :", ["可以扫码支付吗？", "可以下载支付吗？", "可以充电支付吗？", "可以上网支付吗？"], 0, "扫码支付."),
      fill("我的手机没 ___ 了。(batterie)", ["电", "diàn", "dian"], "没电了."),
      mcq("« Acheter en ligne » :", ["网购", "外卖", "退货", "信号"], 0, "网购."),
      fill("这里没有 ___ ，打不了电话。(réseau)", ["信号", "xìnhào", "xinhao"], "信号."),
      tr("Traduisez : le mot de passe", ["密码", "mìmǎ", "mima"], "密码."),
    ],
  },

  /* ------------------------------------------------------------ 14 */
  {
    id: "b2-shehui", module: "vocab", title: "Société et environnement : donner son avis", emoji: "🌏",
    intro: "Lire une brève, comprendre le journal télévisé, débattre de l'environnement ou de la ville : le vocabulaire d'actualité du HSK 4.",
    sections: [
      {
        title: "Environnement",
        examples: [["环境", "huánjìng", "environnement"], ["污染", "wūrǎn", "pollution, polluer"], ["保护", "bǎohù", "protéger"], ["节约", "jiéyuē", "économiser"], ["垃圾分类", "lājī fēnlèi", "tri des déchets"], ["空气", "kōngqì", "air"]],
      },
      {
        title: "Société et économie",
        examples: [["经济", "jīngjì", "économie"], ["发展", "fāzhǎn", "développement, se développer"], ["人口", "rénkǒu", "population"], ["社会", "shèhuì", "société"], ["新闻", "xīnwén", "informations, actualités"], ["压力", "yālì", "pression, stress"]],
      },
      {
        title: "Exprimer une opinion",
        text: "<b>我认为…</b> (j'estime que), <b>对…来说</b> (pour…), <b>一方面… 另一方面…</b> (d'un côté… de l'autre), <b>越来越</b> (de plus en plus).",
        examples: [["我认为保护环境是每个人的责任。", "wǒ rènwéi bǎohù huánjìng shì měi ge rén de zérèn.", "J'estime que protéger l'environnement est la responsabilité de chacun."], ["对年轻人来说，工作压力越来越大。", "duì niánqīngrén lái shuō, gōngzuò yālì yuè lái yuè dà.", "Pour les jeunes, la pression au travail est de plus en plus forte."], ["一方面经济发展了，另一方面污染也严重了。", "yì fāngmiàn jīngjì fāzhǎn le, lìng yì fāngmiàn wūrǎn yě yánzhòng le.", "D'un côté l'économie s'est développée, de l'autre la pollution s'est aggravée."]],
      },
    ],
    mnemo: "污染 : les deux caractères ont la clé de l'eau 氵 — la pollution commence souvent par l'eau.",
    vocab: [["环境", "huánjìng", "environnement"], ["污染", "wūrǎn", "pollution"], ["保护", "bǎohù", "protéger"], ["经济", "jīngjì", "économie"], ["发展", "fāzhǎn", "développement"], ["社会", "shèhuì", "société"], ["新闻", "xīnwén", "actualités"], ["压力", "yālì", "pression"], ["责任", "zérèn", "responsabilité"], ["严重", "yánzhòng", "grave"]],
    quiz: [
      match("Associez", [["环境|huánjìng", "environnement"], ["污染|wūrǎn", "pollution"], ["经济|jīngjì", "économie"], ["新闻|xīnwén", "actualités"]]),
      fill("我们应该 ___ 环境。(protéger)", ["保护", "bǎohù", "baohu"], "保护环境."),
      mcq("« Pour les étudiants » :", ["对学生来说", "学生对来说", "对学生说来", "为学生说"], 0, "对… 来说."),
      mcq("« Le tri des déchets » :", ["垃圾分类", "空气污染", "节约用水", "经济发展"], 0, "垃圾分类."),
      fill("工作压力 ___ 大。(de plus en plus)", ["越来越", "yuè lái yuè", "yuelaiyue", "yue lai yue"], "越来越 + adjectif."),
      tr("Traduisez : la pollution de l'air", ["空气污染", "kōngqì wūrǎn", "kongqi wuran"], "空气污染."),
    ],
  },

  /* ------------------------------------------------------------ 15 */
  {
    id: "b2-jieri", module: "expr", title: "Fêtes et traditions : 春节, 中秋, 端午", emoji: "🧧",
    intro: "Les grandes fêtes chinoises, leurs plats et les vœux qu'on y échange — un sujet incontournable de conversation et d'examen.",
    sections: [
      {
        title: "Le Nouvel An chinois 春节",
        text: "Fête du calendrier lunaire (fin janvier – février). On rentre en famille (le <b>春运</b>, plus grande migration annuelle du monde), on mange des <b>饺子</b> au nord, on donne des <b>红包</b> (enveloppes rouges) et on fait le <b>拜年</b> (visites de vœux).",
        examples: [["新年快乐！", "xīnnián kuàilè!", "Bonne année !"], ["恭喜发财！", "gōngxǐ fācái!", "Je vous souhaite la prospérité !"], ["过年的时候，孩子们会收到红包。", "guònián de shíhou, háizimen huì shōu dào hóngbāo.", "Au Nouvel An, les enfants reçoivent des enveloppes rouges."]],
      },
      {
        title: "Fête de la mi-automne 中秋节 et fête des Bateaux-Dragons 端午节",
        text: "<b>中秋节</b> (15e jour du 8e mois lunaire) : on admire la pleine lune et on mange des <b>月饼</b>. <b>端午节</b> (5e jour du 5e mois) : courses de bateaux-dragons et <b>粽子</b> (riz gluant en feuille de bambou).",
        examples: [["中秋节晚上，一家人一起赏月。", "Zhōngqiū Jié wǎnshang, yì jiā rén yìqǐ shǎng yuè.", "Le soir de la mi-automne, la famille admire la lune ensemble."], ["端午节要吃粽子。", "Duānwǔ Jié yào chī zòngzi.", "À la fête des Bateaux-Dragons, on mange des zongzi."]],
      },
      {
        title: "Tabous et symboles",
        text: "Le <b>rouge</b> porte chance ; le chiffre <b>8 八 bā</b> évoque 发 (faire fortune) ; le <b>4 四 sì</b> ressemble à 死 sǐ (la mort). On évite d'offrir une <b>horloge 钟 zhōng</b> (送钟 sonne comme 送终, « accompagner un mourant »).",
        examples: [["红色代表喜庆和好运。", "hóngsè dàibiǎo xǐqìng hé hǎoyùn.", "Le rouge représente la fête et la chance."]],
      },
    ],
    mnemo: "红包 = « paquet rouge » : rouge comme la chance, et on le tend à deux mains, comme une carte de visite.",
    vocab: [["春节", "Chūn Jié", "Nouvel An chinois"], ["红包", "hóngbāo", "enveloppe rouge"], ["拜年", "bài nián", "présenter ses vœux"], ["饺子", "jiǎozi", "raviolis"], ["中秋节", "Zhōngqiū Jié", "fête de la mi-automne"], ["月饼", "yuèbing", "gâteau de lune"], ["端午节", "Duānwǔ Jié", "fête des Bateaux-Dragons"], ["粽子", "zòngzi", "zongzi (riz gluant)"], ["恭喜发财", "gōngxǐ fācái", "vœux de prospérité"]],
    quiz: [
      mcq("Que mange-t-on à la fête de la mi-automne ?", ["饺子", "月饼", "粽子", "汤圆"], 1, "月饼 = gâteau de lune."),
      mcq("Pourquoi éviter d'offrir une horloge ?", ["C'est trop cher", "送钟 sonne comme 送终", "Le rouge porte malheur", "Le 8 est interdit"], 1, "送终 = accompagner un mourant."),
      fill("过年的时候，孩子们会收到 ___ 。(enveloppe rouge)", ["红包", "hóngbāo", "hongbao"], "红包."),
      match("Associez", [["春节|Chūn Jié", "Nouvel An"], ["端午节|Duānwǔ Jié", "Bateaux-Dragons"], ["粽子|zòngzi", "riz gluant"], ["拜年|bài nián", "présenter ses vœux"]]),
      mcq("Le chiffre porte-bonheur en Chine :", ["4", "7", "8", "13"], 2, "八 bā rappelle 发 fā (faire fortune)."),
      tr("Souhaitez la prospérité pour le Nouvel An", ["恭喜发财", "gōngxǐ fācái", "gongxi facai"], "恭喜发财 !"),
    ],
  },

  /* ------------------------------------------------------------ 16 */
  {
    id: "b2-kouyu", module: "expr", title: "Parler comme un natif : 算了, 没事儿, 随便…", emoji: "🗨️",
    intro: "Des expressions toutes faites qu'on entend dix fois par jour en Chine, et qui rendent votre chinois tout de suite plus naturel.",
    sections: [
      {
        title: "Réagir",
        examples: [["算了吧。", "suàn le ba.", "Laisse tomber. / Tant pis."], ["没事儿。", "méi shìr.", "Ce n'est rien. / Pas de souci."], ["真是的！", "zhēn shì de!", "Franchement ! (agacement)"], ["那倒是。", "nà dào shì.", "Ça, c'est vrai."], ["好不容易。", "hǎo bù róngyì.", "Avec beaucoup de mal (enfin)."]],
      },
      {
        title: "Laisser le choix, être modeste",
        examples: [["随便。", "suíbiàn.", "Comme tu veux. / N'importe."], ["都行。", "dōu xíng.", "Tout me va."], ["哪里哪里。", "nǎli nǎli.", "Oh, pas du tout (réponse modeste à un compliment)."], ["过奖了。", "guòjiǎng le.", "Vous me flattez."]],
      },
      {
        title: "En situation",
        examples: [["你想吃什么？— 随便，你决定吧。", "nǐ xiǎng chī shénme? — suíbiàn, nǐ juédìng ba.", "Tu veux manger quoi ? — Comme tu veux, décide."], ["你的中文说得真好！— 哪里哪里。", "nǐ de Zhōngwén shuō de zhēn hǎo! — nǎli nǎli.", "Tu parles vraiment bien chinois ! — Oh, pas du tout."], ["我好不容易才买到票。", "wǒ hǎo bù róngyì cái mǎi dào piào.", "J'ai eu un mal fou à trouver des billets."]],
      },
    ],
    mnemo: "Face à un compliment, un Chinois ne dit pas 谢谢 mais 哪里哪里 (« où ça, où ça ? ») : la modestie avant tout.",
    vocab: [["算了", "suàn le", "laisse tomber"], ["没事儿", "méi shìr", "ce n'est rien"], ["随便", "suíbiàn", "comme tu veux"], ["哪里哪里", "nǎli nǎli", "pas du tout (modestie)"], ["好不容易", "hǎo bù róngyì", "à grand-peine"], ["真是的", "zhēn shì de", "franchement !"], ["都行", "dōu xíng", "tout me va"], ["过奖", "guòjiǎng", "flatter (trop louer)"]],
    quiz: [
      mcq("On vous fait un compliment, vous répondez :", ["谢谢，我知道。", "哪里哪里。", "算了吧。", "真是的！"], 1, "哪里哪里 = modestie."),
      mcq("« Tu veux boire quoi ? » — « N'importe » :", ["随便。", "没事儿。", "算了。", "过奖了。"], 0, "随便."),
      fill("— 对不起！— 没 ___ 儿。", ["事", "shì", "shi"], "没事儿."),
      mcq("« 我好不容易才找到他 » signifie :", ["Je l'ai trouvé facilement.", "J'ai eu beaucoup de mal à le trouver.", "Je ne l'ai pas trouvé.", "Je ne veux pas le trouver."], 1, "好不容易 = à grand-peine (malgré le 不 !)."),
      match("Associez", [["算了|suàn le", "laisse tomber"], ["都行|dōu xíng", "tout me va"], ["真是的|zhēn shì de", "franchement !"], ["过奖了|guòjiǎng le", "vous me flattez"]]),
    ],
  },
];

export const HSK4_EXAM_PLUS = [
  mcq("无论多难，我 ___ 要试试。", ["就", "都", "才", "还是"], 1, "无论… 都."),
  mcq("« Je n'ai pas le temps » (de finir à temps) :", ["来不及", "来得及", "不来及", "没来及"], 0, "来不及."),
  fill("我想 ___ 了，他姓王。(se souvenir)", ["起来", "qǐlai", "qilai"], "想起来."),
  mcq("___ 你不知道吗？(étonnement)", ["难道", "何必", "果然", "于是"], 0, "难道… 吗."),
  mcq("我 ___ 他是老师，原来他是学生。", ["认为", "以为", "看来", "估计"], 1, "以为 = croire à tort."),
  fill("___ 我明天去不了。(je crains que)", ["恐怕", "kǒngpà", "kongpa"], "恐怕."),
  mcq("« Un peu cher » (on se plaint) :", ["贵一点儿", "有点儿贵", "一点儿贵", "贵有点儿"], 1, "有点儿 + adj."),
  mcq("Le vol est retardé :", ["航班取消了。", "航班推迟了。", "航班退票了。", "航班预订了。"], 1, "推迟 = retarder."),
  match("Associez", [["扫码|sǎo mǎ", "scanner un QR code"], ["环境|huánjìng", "environnement"], ["月饼|yuèbing", "gâteau de lune"], ["随便|suíbiàn", "comme tu veux"]]),
  tr("Traduisez : Même s'il pleut, j'irai.", ["即使下雨我也去", "即使下雨，我也去", "就算下雨我也去", "jíshǐ xià yǔ wǒ yě qù", "jishi xia yu wo ye qu"], "即使… 也."),
];
