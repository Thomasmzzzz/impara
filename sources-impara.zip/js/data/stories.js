/* =====================================================================
   stories.js — Histoires et dialogues (à lire et à écouter)
   ---------------------------------------------------------------------
   Chaque histoire se débloque après une leçon (after) et réutilise son
   vocabulaire. Une ligne : { who, t (texte), py (pinyin), fr }.
   Une question de compréhension : { q, options, answer }.
   Pour ajouter une histoire : copiez un bloc et changez « after ».
   Le contenu est réparti par langue (stories-it.js, stories-zh.js) :
   seule la langue apprise est téléchargée.
   ===================================================================== */
import { code } from "../core/lang.js";

const SOURCES = { it: () => import("./stories-it.js"), zh: () => import("./stories-zh.js") };
export const STORIES = { [code]: (await (SOURCES[code] || SOURCES.it)()).default };
