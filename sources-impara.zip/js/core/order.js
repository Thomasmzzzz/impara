/* =====================================================================
   order.js — « Remettez les mots dans l'ordre »
   Une phrase des leçons est découpée en mots (même découpage que les
   mots cliquables), mélangés : on la reconstruit en touchant les mots.
   ===================================================================== */

import { code } from "./lang.js";
import { shuffle, tri } from "./ui.js";
import { tokenize } from "./words.js";
import { levelWantsPinyin } from "./pinyin.js";

const zh = () => code === "zh";

/** Étiquettes d'une phrase : mots seulement (la ponctuation finale est retirée, les « l' » restent collés) */
export function tilesOf(text) {
  const toks = tokenize(String(text).replace(/\s*[.!?。！？…]+\s*$/u, "").trim());
  const tiles = [];
  toks.forEach((x) => {
    if (x.word) {
      // Italien : un mot élidé (« l' », « dell' ») se colle au mot suivant
      if (!zh() && tiles.length && /['’]$/.test(tiles[tiles.length - 1])) tiles[tiles.length - 1] += x.t;
      else tiles.push(x.t);
    } else if (/[,，、;；:：]/.test(x.t) && tiles.length) {
      tiles[tiles.length - 1] += x.t.trim(); // la virgule reste avec le mot qui la précède
    }
  });
  return tiles;
}

/** Question « ordre » pour une phrase { t, py, fr } (null si trop courte ou trop longue) */
export function orderQuestion({ t, py, fr }, ref, levelId = "") {
  // Pas de nombres seuls (« 九十九 = 99 ») : il faut une vraie phrase traduite en mots
  if ((String(fr).match(/\p{L}/gu) || []).length < 4) return null;
  const tiles = tilesOf(t);
  if (tiles.length < 3 || tiles.length > 9) return null;
  if (new Set(tiles).size === 1) return null;
  const sep = zh() ? "" : " ";
  return {
    ref,
    q: {
      type: "order", q: "Remettez les mots dans l'ordre", fr, tiles, say: t,
      answer: [tiles.join(sep)], explain: py ? `${t} · ${py}` : "", _py: levelWantsPinyin(levelId),
    },
  };
}

/** Phrases d'exemple d'une leçon (les répliques « A — B » sont séparées) */
export function lessonSentences(lesson) {
  const out = [];
  (lesson.sections || []).flatMap((s) => s.examples || []).map(tri).forEach(([t, py, fr]) => {
    const ts = String(t).split(/\s+—\s+/), ps = String(py).split(/\s+—\s+/), fs = String(fr).split(/\s+—\s+/);
    if (ts.length > 1 && ts.length === fs.length) ts.forEach((x, i) => out.push({ t: x, py: ps[i] || "", fr: fs[i] }));
    else out.push({ t, py, fr: String(fr).split(" — ")[0] });
  });
  return out;
}

/** n questions « ordre » sur une liste de phrases */
export function orderQuestions(sentences, n, refBase = "order", levelId = "") {
  const out = [];
  for (const s of shuffle(sentences)) {
    const q = orderQuestion(s, `${refBase}:gen:${out.length}`, s.levelId || levelId);
    if (q) out.push(q);
    if (out.length >= n) break;
  }
  return out;
}
