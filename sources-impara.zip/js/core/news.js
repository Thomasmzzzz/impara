/* Nouveautés non vues (pastille sur la roue ⚙️ et dans Paramètres) */
import { state, commit } from "./storage.js";
import { code } from "./lang.js";
import { CHANGELOG } from "../data/changelog.js";

const mine = () => CHANGELOG.filter((e) => !e.lang || e.lang === code);
/** Nombre de nouveautés pas encore vues (0 pour un tout nouvel utilisateur) */
export function unseenNews() {
  const seen = state.settings.newsSeen;
  if (!seen) return 0;
  return mine().filter((e) => e.at > seen).length;
}
export function markNewsSeen() {
  const top = CHANGELOG[0]?.at;
  if (top && state.settings.newsSeen !== top) commit((s) => { s.settings.newsSeen = top; }, { touch: false });
}
/** Premier lancement : on part de la dernière nouveauté (pas d'historique à « rattraper ») */
export function initNews() {
  if (!state.settings.newsSeen) {
    // Ceux qui utilisent déjà l'appli voient les nouveautés récentes (depuis le 3 novembre)
    const veteran = Object.keys(state.lessons || {}).length > 0;
    commit((s) => { s.settings.newsSeen = veteran ? "2026-11-03T00:00" : CHANGELOG[0]?.at || ""; }, { touch: false });
  }
}
