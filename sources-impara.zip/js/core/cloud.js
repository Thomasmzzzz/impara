/* =====================================================================
   cloud.js — Comptes utilisateurs et synchronisation (Supabase)
   ---------------------------------------------------------------------
   Principe « local d'abord » :
   - la copie locale (localStorage) reste la copie de travail : le site
     est instantané et fonctionne hors ligne ;
   - une fois connecté, chaque modification est envoyée au serveur
     (regroupée toutes les ~1,5 s) dans la table `progress`
     (une ligne par compte et par langue) ;
   - à la connexion, au chargement et au retour sur l'onglet, la copie
     du serveur est récupérée et FUSIONNÉE avec la copie locale
     (meilleurs scores, union du vocabulaire, etc.), donc on ne perd
     rien en passant d'un appareil à l'autre.
   - Une progression commencée en invité est rattachée au compte
     lors de la première connexion.
   ===================================================================== */

import { SUPABASE_URL, SUPABASE_ANON_KEY } from "../config.js";
import { state, subscribe, replaceState, defaultState } from "./storage.js";
import { code } from "./lang.js";

const TABLE = "progress";
const PUSH_DELAY = 1500;

export const isConfigured = () => !!(SUPABASE_URL && SUPABASE_ANON_KEY) || !!window.__IMPARA_SUPABASE_MOCK__;

/* ------------------------- État observable ------------------------- */
// status : off (non configuré) | guest (déconnecté) | syncing | synced | offline | error
const info = { status: "off", user: null, lastSync: null, message: "", recovery: false };
const listeners = new Set();
export const cloudInfo = () => info;
export const onCloud = (fn) => (listeners.add(fn), () => listeners.delete(fn));
const emit = (patch) => { Object.assign(info, patch); listeners.forEach((fn) => fn(info)); };

let sb = null;
let pushTimer = null, pushing = false, pushAgain = false, applyingRemote = false;

/* -------------------- Chargement du client ------------------------- */
async function client() {
  if (sb) return sb;
  if (window.__IMPARA_SUPABASE_MOCK__) return (sb = window.__IMPARA_SUPABASE_MOCK__); // tests automatisés
  const { createClient } = await import("https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm");
  sb = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: { flowType: "pkce", persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
  });
  return sb;
}

/** Traduit les erreurs courantes de Supabase */
export function frError(err) {
  const m = String(err?.message || err || "");
  if (/Failed to fetch|NetworkError|Load failed|fetch/i.test(m)) return "Serveur injoignable. Vérifiez votre connexion internet.";
  if (/Invalid login credentials/i.test(m)) return "E-mail ou mot de passe incorrect.";
  if (/already registered|already exists/i.test(m)) return "Un compte existe déjà avec cet e-mail : connectez-vous.";
  if (/Email not confirmed/i.test(m)) return "Confirmez d'abord votre adresse : cliquez sur le lien reçu par e-mail.";
  if (/Password should be at least|at least 6/i.test(m)) return "Le mot de passe doit contenir au moins 6 caractères.";
  if (/rate limit|too many/i.test(m)) return "Trop de tentatives. Patientez quelques minutes.";
  if (/invalid.*email|valid email/i.test(m)) return "Adresse e-mail invalide.";
  if (/same.*password|different from the old/i.test(m)) return "Choisissez un mot de passe différent de l'ancien.";
  return m || "Une erreur inattendue est survenue.";
}

const redirectURL = () => location.origin + location.pathname;

/* --------------------------- Fusion -------------------------------- */
/**
 * Fusionne deux sauvegardes d'un même utilisateur sans rien perdre.
 * @param {object} a copie locale  @param {object} b copie du serveur
 */
export function mergeStates(a, b) {
  const newer = (a.updatedAt || 0) >= (b.updatedAt || 0) ? a : b;
  const older = newer === a ? b : a;
  const out = structuredClone(newer);

  out.profile = newer.profile || older.profile;
  for (const key of ["lessons", "exams"]) {
    out[key] = { ...older[key], ...newer[key] };
    for (const id of Object.keys(older[key] || {})) {
      const x = older[key][id], y = newer[key]?.[id];
      if (!y) continue;
      out[key][id] = {
        ...y, best: Math.max(x.best, y.best), total: y.total || x.total,
        attempts: Math.max(x.attempts || 0, y.attempts || 0), passed: !!(x.passed || y.passed),
        date: (x.date || "") > (y.date || "") ? x.date : y.date,
      };
    }
  }
  out.vocab = { ...newer.vocab };
  for (const [k, w] of Object.entries(older.vocab || {})) {
    if (!out.vocab[k] || (w.added && w.added < out.vocab[k].added)) out.vocab[k] = w;
  }
  out.errors = { ...(newer.errors || {}) }; // la copie la plus récente fait foi
  out.mastered = Math.max(a.mastered || 0, b.mastered || 0);
  out.xp = Math.max(a.xp || 0, b.xp || 0);
  out.srs = { ...(older.srs || {}), ...(newer.srs || {}) };
  for (const [k, c] of Object.entries(older.srs || {})) if ((c.last || 0) > (out.srs[k]?.last || 0)) out.srs[k] = c;
  const ws = [a.weekly, b.weekly].filter((w) => w?.week).sort((p, q) => q.week.localeCompare(p.week) || q.xp - p.xp);
  out.weekly = ws[0] || out.weekly || { week: null, xp: 0 };
  const ds = [a.daily, b.daily].filter(Boolean).sort((p, q) => (q.date || "").localeCompare(p.date || "") || q.xp - p.xp);
  out.daily = ds[0] || out.daily;
  const ss = [a.streak, b.streak].filter(Boolean).sort((p, q) => (q.last || "").localeCompare(p.last || "") || q.count - p.count);
  out.streak = ss[0] || out.streak;
  const seen = new Set();
  out.history = [...(a.history || []), ...(b.history || [])]
    .sort((p, q) => q.date - p.date)
    .filter((h) => { const k = h.date + "|" + h.label; if (seen.has(k)) return false; seen.add(k); return true; })
    .slice(0, 20);
  out.updatedAt = Math.max(a.updatedAt || 0, b.updatedAt || 0);
  return out;
}

const stripLocal = (s) => { const c = structuredClone(s); delete c.owner; return c; };
const isEmpty = (s) => !s.profile && !Object.keys(s.lessons || {}).length && !s.xp;

/* --------------------------- Pull / Push --------------------------- */
async function pull() {
  if (!info.user) return;
  emit({ status: "syncing" });
  try {
    const { data, error } = await sb.from(TABLE).select("state, updated_at").eq("user_id", info.user.id).eq("lang", code).maybeSingle();
    if (error) throw error;
    const remote = data?.state || null;
    const local = structuredClone(state);
    const prevOwner = local.owner;
    let next;
    if (local.owner && local.owner !== info.user.id) {
      // Copie locale d'un AUTRE compte (ordinateur partagé) : on ne mélange jamais
      next = remote || { ...defaultState() };
    } else if (!remote) {
      next = structuredClone(local);      // premier envoi : la progression invitée est rattachée au compte
    } else if (isEmpty(local)) {
      next = structuredClone(remote);
    } else {
      next = mergeStates(local, remote);
    }
    // Nouvelle langue sur ce compte : on reprend le profil d'une autre langue
    if (!next.profile) {
      const other = await sb.from(TABLE).select("state").eq("user_id", info.user.id).neq("lang", code).limit(1);
      const prof = other.data?.[0]?.state?.profile;
      if (prof) next = { ...next, profile: prof };
    }
    next.owner = info.user.id;
    const changed = JSON.stringify(stripLocal(next)) !== JSON.stringify(stripLocal(local)) || prevOwner !== info.user.id;
    if (changed) {
      applyingRemote = true;
      replaceState(next, { touch: false });
      applyingRemote = false;
      window.dispatchEvent(new CustomEvent("impara:remote-update"));
    }
    // Envoie la version fusionnée si le serveur n'est pas à jour
    if (!remote || JSON.stringify(stripLocal(remote)) !== JSON.stringify(stripLocal(next))) await push();
    else emit({ status: "synced", lastSync: Date.now(), message: "" });
  } catch (e) {
    applyingRemote = false;
    emit({ status: navigator.onLine === false ? "offline" : "error", message: frError(e) });
  }
}

async function push() {
  if (!info.user || state.owner !== info.user.id) return;
  if (pushing) { pushAgain = true; return; }        // une seule écriture à la fois
  pushing = true;
  emit({ status: "syncing" });
  try {
    const { error } = await sb.from(TABLE).upsert(
      { user_id: info.user.id, lang: code, state: stripLocal(state), updated_at: new Date().toISOString() },
      { onConflict: "user_id,lang" },
    );
    if (error) throw error;
    emit({ status: "synced", lastSync: Date.now(), message: "" });
  } catch (e) {
    emit({ status: navigator.onLine === false ? "offline" : "error", message: frError(e) });
  } finally {
    pushing = false;
    if (pushAgain) { pushAgain = false; schedulePush(); }
  }
}

function schedulePush() {
  clearTimeout(pushTimer);
  pushTimer = setTimeout(push, PUSH_DELAY);
}

/* ---------------------------- Session ------------------------------ */
async function onSession(session) {
  const user = session?.user || null;
  if (!user) { emit({ status: "guest", user: null }); return; }
  const same = info.user?.id === user.id;
  emit({ user: { id: user.id, email: user.email } });
  if (!same) await pull();
}

/** Démarre le module (appelé une fois par app.js) */
export async function initCloud() {
  if (!isConfigured()) { emit({ status: "off" }); return; }
  emit({ status: "guest" });
  try {
    await client();
    const { data } = await sb.auth.getSession();
    sb.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY") emit({ recovery: true });
      if (event === "SIGNED_OUT") emit({ status: "guest", user: null });
      else if (session) setTimeout(() => onSession(session), 0);
    });
    await onSession(data?.session);
    // Nettoie l'adresse après un lien de confirmation (?code=…)
    if (location.search.includes("code=")) history.replaceState(null, "", location.pathname + location.hash);
  } catch (e) {
    emit({ status: "error", message: frError(e) });
  }

  // Chaque modification locale part vers le serveur
  subscribe(() => { if (!applyingRemote && info.user) schedulePush(); });
  // Retour sur l'onglet : récupère ce qui a été fait sur un autre appareil
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && info.user && !document.body.classList.contains("focus-mode")) pull();
  });
  window.addEventListener("online", () => info.user && pull());
  window.addEventListener("pagehide", () => { if (pushTimer && info.user) { clearTimeout(pushTimer); push(); } });
}

/* ---------------------- Actions de l'utilisateur ------------------- */
export async function signUp(email, password) {
  await client();
  const { data, error } = await sb.auth.signUp({ email, password, options: { emailRedirectTo: redirectURL() } });
  if (error) throw new Error(frError(error));
  if (!data.session) return { needsConfirmation: true };
  await onSession(data.session);
  return { needsConfirmation: false };
}

export async function signIn(email, password) {
  await client();
  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if (error) throw new Error(frError(error));
  await onSession(data.session);
}

export async function signOut() {
  clearTimeout(pushTimer);
  if (info.user) await push();                       // dernier envoi avant de partir
  await sb?.auth.signOut();
  // On efface la copie locale : la progression reste en sécurité sur le serveur
  replaceState(defaultState(), { touch: false });
  emit({ status: "guest", user: null, lastSync: null });
}

export async function resetPassword(email) {
  await client();
  const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: redirectURL() });
  if (error) throw new Error(frError(error));
}

export async function updatePassword(password) {
  const { error } = await sb.auth.updateUser({ password });
  if (error) throw new Error(frError(error));
  emit({ recovery: false });
}

export const syncNow = () => pull();

/** Client Supabase partagé (utilisé par l'espace social) */
export const getClient = () => client();
