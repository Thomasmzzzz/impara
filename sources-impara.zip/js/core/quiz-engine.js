/* =====================================================================
   quiz-engine.js — Moteur de quiz générique et réutilisable
   ---------------------------------------------------------------------
   Utilisé par : quiz de leçon, examen de palier, révision des erreurs.
   Chaque type de question est un petit « composant » qui expose :
     mount(area, q, onReady) -> { check(): { correct, given, expected, note } }
   Pour ajouter un type (ex. dictée audio), ajoutez une entrée à TYPES.
   ===================================================================== */

import { esc, shuffle, speak, pair, plain } from "./ui.js";
import { L } from "./lang.js";
import { ruby, wantPinyin } from "./pinyin.js";

/** Texte d'une question : avec pinyin au-dessus des caractères si demandé */
const tx = (q, s) => (q._py ? ruby(s) : esc(s));
const tile = (q, s) => (String(s).includes("|") || !q._py ? pair(s) : ruby(s));

/* ------------------- Animations de réponse ------------------------- */
import { sfx, haptic } from "./fx.js";
import { mascot } from "./mascot.js";
/** Bonne réponse : étoiles, « +XP », combo ; mauvaise : la carte tremble */
function celebrateAnswer(root, ok, { xp = 0, combo = 0, progress = 0 } = {}) {
  const card = root.querySelector(".quiz-card"), bar = root.querySelector(".bar span"), btn = root.querySelector(".quiz-action");
  const replay = (el, cls) => { if (!el) return; el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); };
  if (!ok) { replay(card, "shake"); haptic([40, 40, 40]); sfx("bad"); return; }
  haptic(18); sfx(combo >= 3 && combo % 3 === 0 ? "combo" : "good");
  replay(card, "pop");
  if (bar) { bar.style.width = `${progress * 100}%`; replay(bar.parentElement, "pulse"); }
  if (matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
  // Gerbe d'étoiles autour du bouton
  const r = (btn || card).getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top - 34;
  const layer = document.createElement("div");
  layer.className = "burst-layer";
  const glyphs = ["⭐", "✨", "🌟", "●", "●", "●"];
  for (let k = 0; k < 14; k++) {
    const s = document.createElement("span");
    const a = (Math.PI * 2 * k) / 14 + Math.random() * .4, d = 60 + Math.random() * 70;
    s.textContent = glyphs[k % glyphs.length];
    s.className = "burst-p" + (s.textContent === "●" ? " dot" : "");
    s.style.cssText = `left:${cx}px;top:${cy}px;--dx:${Math.cos(a) * d}px;--dy:${Math.sin(a) * d - 40}px;--rot:${Math.random() * 360}deg;animation-delay:${Math.random() * 60}ms`;
    layer.appendChild(s);
  }
  if (xp) { const f = document.createElement("b"); f.className = "xp-float"; f.textContent = `+${xp} XP`; f.style.cssText = `left:${cx}px;top:${cy - 10}px`; layer.appendChild(f); }
  if (combo >= 3) { const c = document.createElement("b"); c.className = "combo-float"; c.textContent = `🔥 ${combo} d'affilée !`; c.style.cssText = `left:${cx}px;top:${cy - 50}px`; layer.appendChild(c); }
  document.body.appendChild(layer);
  setTimeout(() => layer.remove(), 1400);
}

/* ---------------------- Normalisation du texte --------------------- */
export const normalize = (s) =>
  String(s).toLowerCase()
    .replace(/[’`´]/g, "'").replace(/'\s+/g, "'")
    .replace(/[.,!?;:«»"¿¡()，。！？、；：“”‘’（）—]/g, " ")
    .replace(/\s+/g, "").trim(); // espaces ignorés : « ni hao » = « nihao »
const stripAccents = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "");

/** Compare une saisie libre à la liste des réponses acceptées */
export function checkText(given, answers) {
  const g = normalize(given);
  if (answers.some((a) => normalize(a) === g)) return { correct: true };
  const loose = answers.find((a) => stripAccents(normalize(a)) === stripAccents(g));
  if (loose) return { correct: true, note: `${L.looseNote} : « ${loose} »` };
  return { correct: false };
}

/* ---------------------- Clavier de tons ---------------------------
   Tapez la syllabe (ex. « hao ») puis cliquez sur un ton : la marque
   est placée sur la bonne voyelle selon les règles du pinyin
   (a/e en priorité, « ou » → o, sinon la dernière voyelle).          */
const TONED = {
  a: "āáǎà", e: "ēéěè", i: "īíǐì", o: "ōóǒò", u: "ūúǔù", "ü": "ǖǘǚǜ",
};
const BASE = {};
Object.entries(TONED).forEach(([v, s]) => [...s].forEach((c) => (BASE[c] = v)));

export function applyTone(before, tone) {
  const m = before.match(/[a-zāáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜü]+$/i);
  if (!m) return before;
  let syl = [...m[0]].map((c) => BASE[c.toLowerCase()] ? (c === c.toUpperCase() && c !== c.toLowerCase() ? BASE[c.toLowerCase()].toUpperCase() : BASE[c.toLowerCase()]) : c).join("");
  if (tone === 0) return before.slice(0, -m[0].length) + syl; // ton neutre : on retire la marque
  const low = syl.toLowerCase();
  let idx = low.indexOf("a");
  if (idx < 0) idx = low.indexOf("e");
  if (idx < 0 && low.includes("ou")) idx = low.indexOf("o");
  if (idx < 0) { for (let k = low.length - 1; k >= 0; k--) if ("iouü".includes(low[k])) { idx = k; break; } }
  if (idx < 0) return before;
  const ch = TONED[low[idx]][tone - 1];
  const out = syl.slice(0, idx) + (syl[idx] !== low[idx] ? ch.toUpperCase() : ch) + syl.slice(idx + 1);
  return before.slice(0, -m[0].length) + out;
}

function toneBar(input) {
  const bar = document.createElement("div");
  bar.className = "accent-bar";
  bar.innerHTML = `
    <button type="button" tabindex="-1" data-t="1" title="1er ton">ā</button>
    <button type="button" tabindex="-1" data-t="2" title="2e ton">á</button>
    <button type="button" tabindex="-1" data-t="3" title="3e ton">ǎ</button>
    <button type="button" tabindex="-1" data-t="4" title="4e ton">à</button>
    <button type="button" tabindex="-1" data-t="0" title="Ton neutre">a</button>
    <button type="button" tabindex="-1" data-ins="ü" title="Insérer ü">ü</button>
    <span class="tone-hint">Tapez la syllabe puis le ton · ou écrivez directement en caractères</span>`;
  bar.onclick = (e) => {
    const b = e.target.closest("button"); if (!b) return;
    const { selectionStart: s, selectionEnd: en, value } = input;
    let before = value.slice(0, s);
    before = b.dataset.ins ? before + b.dataset.ins : applyTone(before, +b.dataset.t);
    input.value = before + value.slice(en);
    input.focus(); input.setSelectionRange(before.length, before.length);
    input.dispatchEvent(new Event("input"));
  };
  return bar;
}

/* ------------------ Clavier d'accents (italien) -------------------- */
function italianBar(input) {
  const bar = document.createElement("div");
  bar.className = "accent-bar";
  bar.innerHTML = ["à", "è", "é", "ì", "ò", "ù"].map((a) => `<button type="button" tabindex="-1">${a}</button>`).join("");
  bar.onclick = (e) => {
    if (e.target.tagName !== "BUTTON") return;
    const { selectionStart: s, selectionEnd: en, value } = input;
    input.value = value.slice(0, s) + e.target.textContent + value.slice(en);
    input.focus(); input.setSelectionRange(s + 1, s + 1);
    input.dispatchEvent(new Event("input"));
  };
  return bar;
}

/** Clavier adapté à la langue active */
const accentBar = (input) => (L.keyboard === "tones" ? toneBar(input) : italianBar(input));

/* --------------------------- Types --------------------------------- */
const TYPES = {
  /* Écoute : le mot est prononcé, on choisit la bonne réponse (🔊 rejoue, 🐢 lentement) */
  listen: {
    label: "Écoutez puis choisissez",
    mount(area, q, onReady) {
      area.innerHTML = `<div class="listen-bar">
          <button type="button" class="listen-btn" data-play aria-label="Réécouter">🔊<span>Écouter</span></button>
          <button type="button" class="listen-btn slow" data-play-slow aria-label="Écouter lentement">🐢<span>Lentement</span></button>
        </div><div class="listen-opts"></div>`;
      const play = (slow) => speak(q.say, { slow, force: true });
      area.querySelector("[data-play]").onclick = () => play(false);
      area.querySelector("[data-play-slow]").onclick = () => play(true);
      setTimeout(() => play(false), 250);
      const sub = area.querySelector(".listen-opts");
      const api = TYPES.mcq.mount(sub, q, onReady);
      area._keys = (e) => { if (e.key === " " && e.target === document.body) { e.preventDefault(); play(false); } else sub._keys?.(e); };
      return { check() { const r = api.check(); return { ...r, note: q.reveal ? `On entendait : ${q.reveal}` : r.note }; } };
    },
  },

  mcq: {
    label: "Choisissez la bonne réponse",
    mount(area, q, onReady) {
      const order = shuffle(q.options.map((_, i) => i));
      let picked = null;
      area.innerHTML = `<div class="options">${order
        .map((i, k) => `<button class="option" data-i="${i}"><kbd>${k + 1}</kbd><span>${tx(q, q.options[i])}</span></button>`)
        .join("")}</div>`;
      const btns = [...area.querySelectorAll(".option")];
      const pick = (b) => { btns.forEach((x) => x.classList.remove("selected")); b.classList.add("selected"); picked = +b.dataset.i; onReady(true); };
      btns.forEach((b) => (b.onclick = () => pick(b)));
      area._keys = (e) => { const n = +e.key; if (n >= 1 && n <= btns.length && !area._locked) pick(btns[n - 1]); };
      return {
        check() {
          area._locked = true;
          btns.forEach((b) => {
            b.disabled = true;
            if (+b.dataset.i === q.answer) b.classList.add("correct");
            else if (+b.dataset.i === picked) b.classList.add("wrong");
          });
          return { correct: picked === q.answer, given: q.options[picked], expected: q.options[q.answer] };
        },
      };
    },
  },

  fill: {
    label: "Complétez la phrase",
    mount(area, q, onReady) {
      const [before, after = ""] = q.q.split("___");
      area.innerHTML = `<p class="fill-sentence">${tx(q, before)}<input class="fill-input" autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="Réponse">${tx(q, after)}</p>`;
      const input = area.querySelector("input");
      area.appendChild(accentBar(input));
      input.oninput = () => onReady(input.value.trim().length > 0);
      setTimeout(() => input.focus(), 50);
      return {
        check() {
          input.disabled = true;
          const res = checkText(input.value, q.answer);
          input.classList.add(res.correct ? "correct" : "wrong");
          return { ...res, given: input.value, expected: q.answer[0] };
        },
      };
    },
    // la phrase est affichée dans la zone de réponse, pas dans le titre
    title: () => "Complétez avec le mot manquant",
  },

  translate: {
    get label() { return L.trLabel; },
    mount(area, q, onReady) {
      area.innerHTML = `<textarea class="tr-input" rows="2" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="${esc(L.trPlaceholder)}" aria-label="Traduction"></textarea>`;
      const input = area.querySelector("textarea");
      area.appendChild(accentBar(input));
      input.oninput = () => onReady(input.value.trim().length > 0);
      input.onkeydown = (e) => { if (e.key === "Enter") e.preventDefault(); };
      setTimeout(() => input.focus(), 50);
      return {
        check() {
          input.disabled = true;
          const res = checkText(input.value, q.answer);
          input.classList.add(res.correct ? "correct" : "wrong");
          return { ...res, given: input.value, expected: q.answer[0] };
        },
      };
    },
  },

  match: {
    label: "Associez les paires",
    mount(area, q, onReady) {
      const left = shuffle(q.pairs.map((p, i) => ({ t: p[0], i })));
      const right = shuffle(q.pairs.map((p, i) => ({ t: p[1], i })));
      let sel = null, found = 0, mistakes = 0;
      area.innerHTML = `<div class="match">
        <div class="match-col">${left.map((x) => `<button class="tile" data-side="L" data-i="${x.i}" data-say="${esc(x.t)}">${tile(q, x.t)}</button>`).join("")}</div>
        <div class="match-col">${right.map((x) => `<button class="tile" data-side="R" data-i="${x.i}">${tile(q, x.t)}</button>`).join("")}</div>
      </div>`;
      area.querySelectorAll(".tile").forEach((t) => (t.onclick = () => {
        if (t.classList.contains("done")) return;
        if (t.dataset.side === "L") speak(t.dataset.say);
        if (!sel || sel.dataset.side === t.dataset.side) {
          area.querySelectorAll(".tile.sel").forEach((x) => x.classList.remove("sel"));
          sel = t; t.classList.add("sel"); return;
        }
        if (sel.dataset.i === t.dataset.i) {
          [sel, t].forEach((x) => { x.classList.remove("sel"); x.classList.add("done"); x.disabled = true; });
          if (++found === q.pairs.length) onReady(true);
        } else {
          mistakes++;
          [sel, t].forEach((x) => { x.classList.remove("sel"); x.classList.add("shake"); setTimeout(() => x.classList.remove("shake"), 400); });
        }
        sel = null;
      }));
      return {
        check() {
          return {
            correct: mistakes === 0,
            given: mistakes ? `${mistakes} erreur(s) d'association` : "",
            expected: q.pairs.map((p) => `${plain(p[0])} = ${plain(p[1])}`).join(" · "),
            note: mistakes ? null : "Sans aucune erreur !",
          };
        },
      };
    },
  },
};

/* --------------------------- Lecteur ------------------------------- */
/**
 * Lance un quiz dans `root`.
 * @param {HTMLElement} root
 * @param {{ title:string, questions:{ref:string,q:object}[],
 *           onFinish:(results)=>void, onQuit:()=>void }} opts
 */
export function runQuiz(root, { title, questions, onFinish, onQuit, onAnswer, xpPerAnswer = 0 }) {
  let i = 0, phase = "answer", api = null, current = null, combo = 0;
  const results = [];

  root.innerHTML = `
    <section class="quiz" aria-live="polite">
      <header class="quiz-top">
        <button class="icon-btn quiz-quit" aria-label="Quitter le quiz">✕</button>
        <div class="bar"><span></span></div>
        <span class="quiz-count"></span>
      </header>
      <p class="quiz-title">${questions[0] && wantPinyin(questions[0].ref) ? ruby(title) : esc(title)}</p>
      <div class="quiz-card">
        <p class="q-label"></p>
        <h2 class="q-text"></h2>
        <div class="q-area"></div>
      </div>
      <footer class="quiz-foot">
        <div class="feedback" hidden></div>
        <button class="btn primary big quiz-action" disabled>Vérifier</button>
      </footer>
    </section>`;

  const el = (s) => root.querySelector(s);
  const action = el(".quiz-action"), feedback = el(".feedback"), area = el(".q-area");

  function show() {
    const { ref } = questions[i];
    const q = questions[i].q._py === undefined && wantPinyin(ref) ? { ...questions[i].q, _py: true } : questions[i].q;
    current = q;
    const type = TYPES[q.type];
    phase = "answer";
    el(".bar span").style.width = `${(i / questions.length) * 100}%`;
    el(".quiz-count").textContent = `${i + 1} / ${questions.length}`;
    el(".q-label").textContent = type.label;
    el(".q-text").innerHTML = tx(q, type.title ? type.title(q) : q.q);
    feedback.hidden = true; feedback.className = "feedback";
    root.querySelector(".quiz-foot").className = "quiz-foot";
    action.textContent = "Vérifier"; action.disabled = true;
    area._locked = false; area._keys = null;
    api = type.mount(area, q, (ready) => { if (phase === "answer") action.disabled = !ready; });
  }

  function check() {
    const { ref } = questions[i];
    const q = current;
    const res = api.check();
    results.push({ ref, correct: res.correct, given: res.given });
    onAnswer?.({ index: i, q, correct: res.correct, given: res.given, expected: res.expected });
    phase = "feedback";
    const foot = root.querySelector(".quiz-foot");
    foot.classList.add(res.correct ? "is-correct" : "is-wrong");
    feedback.hidden = false;
    combo = res.correct ? combo + 1 : 0;
    celebrateAnswer(root, res.correct, { xp: xpPerAnswer, combo, progress: (i + 1) / questions.length });
    feedback.innerHTML = `<span class="fb-mascot">${mascot(res.correct ? "happy" : "sad", { size: 58 })}</span><div class="fb-txt">` + (res.correct
      ? `<strong>✓ ${tx(q, L.cheers[i % L.cheers.length])}</strong>${res.note ? `<p>${tx(q, res.note)}</p>` : ""}${q.explain ? `<p class="muted">${tx(q, q.explain)}</p>` : ""}`
      : `<strong>✗ Pas tout à fait…</strong>
         <p>Bonne réponse : <b>${tx(q, res.expected)}</b></p>
         ${q.explain ? `<p class="explain">💡 ${tx(q, q.explain)}</p>` : ""}
         <p class="muted small">Cette question est ajoutée à votre cahier d'erreurs.</p>`) + `</div>`;
    action.textContent = i === questions.length - 1 ? "Voir mes résultats" : "Continuer";
    action.disabled = false;
    action.focus();
  }

  function next() {
    if (++i < questions.length) show();
    else { el(".bar span").style.width = "100%"; cleanup(); onFinish(results); }
  }

  action.onclick = () => (phase === "answer" ? check() : next());
  el(".quiz-quit").onclick = () => { cleanup(); onQuit(); };

  const onKey = (e) => {
    if (e.key === "Enter" && !action.disabled && e.target !== action) { e.preventDefault(); action.click(); }
    else area._keys?.(e);
  };
  document.addEventListener("keydown", onKey);
  const cleanup = () => document.removeEventListener("keydown", onKey);
  root._cleanup = cleanup;

  show();
}
