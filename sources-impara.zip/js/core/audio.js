/* =====================================================================
   audio.js — Voix naturelle enregistrée
   ---------------------------------------------------------------------
   Les phrases du cours ont été enregistrées une fois avec une voix
   neuronale (tools/audio). Elles sont regroupées dans quelques gros
   fichiers (audio/<langue>/p0.bin…) avec un index : pour jouer une
   phrase, on télécharge seulement ses octets (requête « Range »).
   Si une phrase n'est pas enregistrée (ou en cas de souci), l'appli
   utilise la voix de l'appareil comme avant.
   ===================================================================== */

import { code } from "./lang.js";
import { clipId } from "./speechkey.js";

const BASE = `./audio/${code}/`;
let INDEX = null, failed = false, loading = null;

/** Charge l'index des enregistrements (une fois) */
export function loadAudioIndex() {
  if (INDEX || failed) return Promise.resolve(INDEX);
  return (loading ||= fetch(`${BASE}index.json`, { cache: "no-cache" })
    .then((r) => (r.ok ? r.json() : null))
    .then((j) => { if (j?.clips) INDEX = j; else failed = true; return INDEX; })
    .catch(() => { failed = true; return null; }));
}
export const audioInfo = () => (INDEX ? { voice: INDEX.voice || "", count: Object.keys(INDEX.clips).length } : null);
export const hasClip = (t) => !!INDEX?.clips?.[clipId(t)];

/* ------------------------------ Lecture ------------------------------ */
let el = null;
const player = () => {
  if (!el) { el = new Audio(); el.preload = "auto"; el.preservesPitch = true; el.webkitPreservesPitch = true; }
  return el;
};
// iPhone : le son doit d'abord être « débloqué » par un geste de l'utilisateur
const SILENT = "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=";
let unlocked = false;
if (typeof document !== "undefined") {
  const unlock = () => {
    if (unlocked) return;
    unlocked = true;
    const a = player();
    a.src = SILENT;
    a.play().then(() => a.pause()).catch(() => { unlocked = false; });
  };
  document.addEventListener("pointerdown", unlock, { capture: true, passive: true });
  document.addEventListener("keydown", unlock, { capture: true });
}

const urls = new Map();     // id → URL du morceau (les 80 derniers)
const packs = new Map();    // n° de paquet → ArrayBuffer (si le serveur ignore « Range »)
async function clipUrl(id) {
  if (urls.has(id)) return urls.get(id);
  const [p, off, len] = INDEX.clips[id];
  const file = BASE + INDEX.packs[p];
  let blob;
  if (packs.has(p)) blob = new Blob([packs.get(p).slice(off, off + len)], { type: "audio/mpeg" });
  else {
    const res = await fetch(file, { headers: { Range: `bytes=${off}-${off + len - 1}` } });
    if (!res.ok) throw new Error("audio");
    if (res.status === 206) blob = new Blob([await res.arrayBuffer()], { type: "audio/mpeg" });
    else { const buf = await res.arrayBuffer(); packs.set(p, buf); blob = new Blob([buf.slice(off, off + len)], { type: "audio/mpeg" }); }
  }
  const url = URL.createObjectURL(blob);
  urls.set(id, url);
  if (urls.size > 80) { const [k, u] = urls.entries().next().value; URL.revokeObjectURL(u); urls.delete(k); }
  return url;
}

let token = 0;
/** Joue l'enregistrement d'une phrase ; résout false s'il n'existe pas ou n'a pas pu être lu */
export async function playClip(t, rate = 1) {
  if (!INDEX) return false;
  const id = clipId(t);
  if (!INDEX.clips[id]) return false;
  const my = ++token;
  try {
    const url = await clipUrl(id);
    if (my !== token) return true;              // une autre phrase a été demandée entre-temps
    const a = player();
    a.pause();
    a.src = url;
    a.defaultPlaybackRate = a.playbackRate = Math.max(0.5, Math.min(2, rate));
    await a.play();
    return true;
  } catch { return false; }
}
export function stopClip() { token++; try { el?.pause(); } catch {} }

// L'index est petit : on le charge peu après l'ouverture de l'appli
if (typeof window !== "undefined") setTimeout(() => loadAudioIndex(), 1200);
