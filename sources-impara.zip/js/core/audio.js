/* =====================================================================
   audio.js — Voix naturelle enregistrée
   ---------------------------------------------------------------------
   Les phrases du cours ont été enregistrées une fois avec une voix
   neuronale (tools/audio). Elles sont regroupées dans quelques gros
   fichiers (audio/<langue>/p0.bin…) avec un index : pour jouer une
   phrase, on télécharge seulement ses octets (requête « Range »).
   Si une phrase n'est pas enregistrée (ou en cas de souci), l'appli
   utilise la voix de l'appareil comme avant.
   ===================================================================== */

import { code } from "./lang.js";
import { clipId } from "./speechkey.js";
import { state } from "./storage.js";

/* Voix disponibles par langue : dossier audio/<dossier>/ (la première est la voix par défaut).
   Deux voix par langue : italien Sara / Nicola, mandarin Xiaoxiao / Yunxi. */
export const VOICES = {
  it: [{ id: "f", dir: "it", name: "Sara", sex: "f" }, { id: "m", dir: "it-m", name: "Nicola", sex: "m" }],
  zh: [{ id: "f", dir: "zh", name: "Xiaoxiao", sex: "f" }, { id: "m", dir: "zh-m", name: "Yunxi", sex: "m" }],
};
const list = () => VOICES[code] || [];
const INDEX = {}, failed = {}, loading = {};
/** Mandarin : tons corrigés (par défaut) ou enregistrements d'origine */
export const tonesFixed = () => code !== "zh" || state.settings?.toneFix !== false;
// clé d'index : la voix + la version (« ~0 » = version d'origine)
const kv = (v) => (tonesFixed() ? v : `${v}~0`);

/** Voix choisie dans les réglages (id) */
export const mainVoice = () => { const v = state.settings?.recVoice?.[code]; return list().some((x) => x.id === v) ? v : list()[0]?.id; };
/** L'autre voix (pour un 2e personnage), sinon la même */
export const otherVoice = () => list().find((x) => x.id !== mainVoice())?.id || mainVoice();
/** Voix d'un personnage : f / m (si la voix existe), « alt » = l'autre voix */
export function voiceFor(who) {
  if (who === "alt") return otherVoice();
  if (who === "f" || who === "m") { const v = list().find((x) => x.sex === who); if (v) return v.id; }
  return mainVoice();
}

/** Charge l'index des enregistrements d'une voix (une fois) */
export function loadAudioIndex(v = mainVoice()) {
  const meta = list().find((x) => x.id === v), k = kv(v);
  if (!meta || INDEX[k] || failed[k]) return Promise.resolve(INDEX[k] || null);
  return (loading[k] ||= fetch(`./audio/${meta.dir}/${tonesFixed() ? "index.json" : "index-v0.json"}`, { cache: "no-cache" })
    .then((r) => (r.ok ? r.json() : null))
    .then((j) => { if (j?.clips) INDEX[k] = { ...j, base: `./audio/${meta.dir}/` }; else failed[k] = true; return INDEX[k] || null; })
    .catch(() => { failed[k] = true; return null; }));
}
export const audioInfo = (v = mainVoice()) => (INDEX[kv(v)] ? { voice: INDEX[kv(v)].voice || "", count: Object.keys(INDEX[kv(v)].clips).length } : null);
/** Voix qui a enregistré cette phrase (la voix demandée en priorité), ou null */
export function clipVoice(t, v = mainVoice()) {
  const id = clipId(t);
  if (INDEX[kv(v)]?.clips?.[id]) return v;
  if (!INDEX[kv(v)] && !failed[kv(v)]) loadAudioIndex(v);
  const o = list().find((x) => x.id !== v && INDEX[kv(x.id)]?.clips?.[id]);
  return o ? o.id : null;
}
export const hasClip = (t, v) => !!clipVoice(t, v);

/* ------------------------------ Lecture ------------------------------ */
let el = null;
const player = () => {
  if (!el) { el = new Audio(); el.preload = "auto"; el.preservesPitch = true; el.webkitPreservesPitch = true; }
  return el;
};
// iPhone : le son doit d'abord être « débloqué » par un geste de l'utilisateur
const SILENT = "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=";
let unlocked = false;
if (typeof document !== "undefined") {
  const unlock = () => {
    if (unlocked) return;
    const a = player();
    // Une phrase est déjà en cours : le son est débloqué, surtout ne pas l'interrompre
    if (!a.paused) { unlocked = true; return; }
    unlocked = true;
    a.src = SILENT;
    a.play().then(() => { if (a.src === SILENT) a.pause(); }).catch(() => { if (a.src === SILENT) unlocked = false; });
  };
  document.addEventListener("click", unlock, { capture: true, passive: true });
  document.addEventListener("touchend", unlock, { capture: true, passive: true });
  document.addEventListener("keydown", unlock, { capture: true });
}

const urls = new Map();     // voix:id → URL du morceau (les 80 derniers)
const packs = new Map();    // voix:n° de paquet → ArrayBuffer (si le serveur ignore « Range »)
async function clipUrl(v, cid) {
  const ix = INDEX[kv(v)], id = cid, key = `${kv(v)}:${cid}`;
  if (urls.has(key)) return urls.get(key);
  const [p0, off, len] = ix.clips[id], p = `${kv(v)}:${p0}`;
  const file = ix.base + ix.packs[p0];
  let blob;
  if (packs.has(p)) blob = new Blob([packs.get(p).slice(off, off + len)], { type: "audio/mpeg" });
  else {
    const res = await fetch(file, { headers: { Range: `bytes=${off}-${off + len - 1}` } });
    if (!res.ok) throw new Error("audio");
    if (res.status === 206) blob = new Blob([await res.arrayBuffer()], { type: "audio/mpeg" });
    else { const buf = await res.arrayBuffer(); packs.set(p, buf); blob = new Blob([buf.slice(off, off + len)], { type: "audio/mpeg" }); }
  }
  const url = URL.createObjectURL(blob);
  urls.set(key, url);
  if (urls.size > 80) { const [k, u] = urls.entries().next().value; URL.revokeObjectURL(u); urls.delete(k); }
  return url;
}

/* Volume de la voix (Paramètres › Son), de 0 à 1.
   L'iPhone ignore « audio.volume » : on passe alors par un gain Web Audio. */
export const voiceVolume = () => Math.max(0, Math.min(1, (state.settings?.volume ?? 100) / 100));
const IOS = typeof navigator !== "undefined" && (/iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1));
let actx = null, gain = null;
function applyVolume(a) {
  const v = voiceVolume();
  try { a.volume = v; } catch {}
  if (!IOS) return;
  if (!gain && v >= 0.999) return;                      // volume normal : lecture directe, sans Web Audio
  try {
    if (!gain) {
      actx = new (window.AudioContext || window.webkitAudioContext)();
      gain = actx.createGain();
      actx.createMediaElementSource(a).connect(gain).connect(actx.destination);
    }
    if (actx.state === "suspended") actx.resume();
    gain.gain.value = v;
  } catch {}
}

let token = 0;
/** Joue l'enregistrement d'une phrase ; résout false s'il n'existe pas ou n'a pas pu être lu */
export async function playClip(t, rate = 1, voice) {
  const v = clipVoice(t, voice);
  if (!v) return false;
  const id = clipId(t);
  const my = ++token;
  try {
    const url = await clipUrl(v, id);
    if (my !== token) return true;              // une autre phrase a été demandée entre-temps
    const a = player();
    a.pause();
    a.src = url;
    a.defaultPlaybackRate = a.playbackRate = Math.max(0.5, Math.min(2, rate));
    applyVolume(a);
    await a.play();
    unlocked = true;
    return true;
  } catch { return false; }
}
export function stopClip() { token++; try { el?.pause(); } catch {} }
/** Promesse résolue quand l'enregistrement en cours se termine (ou est interrompu) */
export function clipEnd(maxMs = 30000) {
  return new Promise((res) => {
    const a = player();
    if (a.paused && a.currentTime === 0) return res();
    let done = false; const fin = () => { if (done) return; done = true; a.removeEventListener("ended", fin); a.removeEventListener("pause", fin); clearTimeout(t); res(); };
    const t = setTimeout(fin, maxMs);
    a.addEventListener("ended", fin); a.addEventListener("pause", fin);
  });
}

// L'index est petit : on le charge peu après l'ouverture de l'appli
if (typeof window !== "undefined") setTimeout(() => list().forEach((x) => loadAudioIndex(x.id)), 1200);
