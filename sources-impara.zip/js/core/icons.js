/* =====================================================================
   icons.js — Jeu d'icônes de l'interface (dessins vectoriels Lucide,
   licence ISC) : même rendu sur iPhone, Android et ordinateur, à la
   place des emojis du système.
   icon("map")  → <svg …> qui prend la couleur du texte (currentColor)
   ===================================================================== */
import {
  Map, Dumbbell, ChartColumn, Users, Settings, Flame, Lock, Crown, GraduationCap, Trophy,
  Shield, ShieldCheck, BookOpen, Puzzle, Hourglass, Hash, MessageCircle, Brush, CaseSensitive,
  Mic, Headphones, Keyboard, AudioWaveform, PenTool, RotateCcw, Layers, Notebook, CalendarCheck,
  Target, Play, Check, BookOpenText, Sparkles, Route, Star, Swords, Zap, Sprout, SmilePlus,
} from "lucide";

const SET = {
  map: Map, train: Dumbbell, chart: ChartColumn, users: Users, settings: Settings, flame: Flame,
  lock: Lock, crown: Crown, grad: GraduationCap, trophy: Trophy, shield: Shield, "shield-check": ShieldCheck,
  book: BookOpen, puzzle: Puzzle, hourglass: Hourglass, hash: Hash, chat: MessageCircle, brush: Brush,
  letters: CaseSensitive, mic: Mic, headphones: Headphones, keyboard: Keyboard, wave: AudioWaveform,
  pen: PenTool, redo: RotateCcw, layers: Layers, notebook: Notebook, calendar: CalendarCheck,
  target: Target, play: Play, check: Check, story: BookOpenText, sparkles: Sparkles, route: Route, star: Star,
  swords: Swords, zap: Zap, sprout: Sprout, "smile-plus": SmilePlus,
};

const attrs = (o) => Object.entries(o).map(([k, v]) => `${k}="${String(v).replace(/"/g, "&quot;")}"`).join(" ");

/** SVG d'une icône ; options : size (px), cls, stroke (épaisseur), fill */
export function icon(name, { size = 24, cls = "", stroke = 2.25, fill = "none" } = {}) {
  const node = SET[name];
  if (!node) return "";
  const kids = node.map(([tag, a]) => `<${tag} ${attrs(a)}/>`).join("");
  return `<svg class="ico ico-${name} ${cls}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="${fill}" stroke="currentColor" stroke-width="${stroke}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${kids}</svg>`;
}

/** Icône d'un module de leçon (Bases, Grammaire…) */
export const MODULE_ICONS = { bases: "letters", vocab: "book", gram: "puzzle", conj: "hourglass", temps: "hourglass", nombres: "hash", expr: "chat", hanzi: "brush" };
export const moduleIcon = (mod, opts) => icon(MODULE_ICONS[mod] || "star", opts);

/** Remplit tous les [data-ico] présents dans la page (en-tête, barre d'onglets) */
export function hydrateIcons(root = document) {
  root.querySelectorAll("[data-ico]").forEach((el) => {
    if (el.dataset.icoDone) return;
    el.innerHTML = icon(el.dataset.ico, { size: +(el.dataset.icoSize || 24), fill: el.dataset.icoFill || "none" });
    el.dataset.icoDone = "1";
  });
}
