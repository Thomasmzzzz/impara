/* =====================================================================
   icons.js — Jeu d'icônes de l'interface (dessins vectoriels Lucide,
   licence ISC) : même rendu sur iPhone, Android et ordinateur, à la
   place des emojis du système.
   icon("map")  → <svg …> qui prend la couleur du texte (currentColor)
   ===================================================================== */
import {
  Map, Dumbbell, ChartColumn, Users, Settings, Flame, Lock, Crown, GraduationCap, Trophy,
  Shield, ShieldCheck, BookOpen, Puzzle, Hourglass, Hash, MessageCircle, Brush, CaseSensitive,
  Mic, Headphones, Keyboard, AudioWaveform, PenTool, RotateCcw, Layers, Notebook, CalendarCheck,
  Target, Play, Check, BookOpenText, Sparkles, Route, Star, Swords, Zap, Sprout, SmilePlus,
  Newspaper, UserPlus, ChevronRight, Timer, Medal, Clock, ChevronLeft, SendHorizontal, Skull, Crosshair, Repeat, Compass,
  ArrowLeftRight, Award, BadgeCheck, Bell, BookMarked, Brain, CalendarDays, CircleCheck, CircleX, ClipboardList, Cloud, CloudOff, Dices, Download, Ear, Eye, FileText, Flag, Gauge, Gift, Globe, Hand, Heart, Inbox, Info, Languages, Lightbulb, ListChecks, LogOut, Mail, Megaphone, Moon, Palette, PartyPopper, Pencil, Plus, RefreshCw, Rocket, Search, Share2, Shuffle, Smartphone, Snail, Spade, StickyNote, Sun, ThumbsUp, Ticket, Trash2, TriangleAlert, Unlock, User, Volume2, WifiOff, X,
} from "lucide";

const SET = {
  map: Map, train: Dumbbell, chart: ChartColumn, users: Users, settings: Settings, flame: Flame,
  lock: Lock, crown: Crown, grad: GraduationCap, trophy: Trophy, shield: Shield, "shield-check": ShieldCheck,
  book: BookOpen, puzzle: Puzzle, hourglass: Hourglass, hash: Hash, chat: MessageCircle, brush: Brush,
  letters: CaseSensitive, mic: Mic, headphones: Headphones, keyboard: Keyboard, wave: AudioWaveform,
  pen: PenTool, redo: RotateCcw, layers: Layers, notebook: Notebook, calendar: CalendarCheck,
  target: Target, play: Play, check: Check, story: BookOpenText, sparkles: Sparkles, route: Route, star: Star,
  swords: Swords, zap: Zap, sprout: Sprout, "smile-plus": SmilePlus,
  news: Newspaper, "user-plus": UserPlus, chevron: ChevronRight, timer: Timer, medal: Medal, clock: Clock, back: ChevronLeft, send: SendHorizontal,
  skull: Skull, crosshair: Crosshair, repeat: Repeat, compass: Compass,
  volume: Volume2, snail: Snail, flag: Flag, x: X, search: Search, bell: Bell, palette: Palette, megaphone: Megaphone, phone: Smartphone, shuffle: Shuffle, list: ListChecks, clipboard: ClipboardList, party: PartyPopper, alert: TriangleAlert, cloud: Cloud, "cloud-off": CloudOff, user: User, eye: Eye, award: Award, swap: ArrowLeftRight, info: Info, gift: Gift, sun: Sun, moon: Moon, download: Download, logout: LogOut, mail: Mail, heart: Heart, thumbs: ThumbsUp, pencil: Pencil, trash: Trash2, share: Share2, bookmark: BookMarked, languages: Languages, gauge: Gauge, "check-circle": CircleCheck, "x-circle": CircleX, "badge-check": BadgeCheck, "wifi-off": WifiOff, "calendar-days": CalendarDays, bulb: Lightbulb, rocket: Rocket, inbox: Inbox, ear: Ear, refresh: RefreshCw, plus: Plus, dices: Dices, ticket: Ticket, globe: Globe, brain: Brain, file: FileText, spade: Spade, unlock: Unlock, hand: Hand, sticky: StickyNote,
};

const attrs = (o) => Object.entries(o).map(([k, v]) => `${k}="${String(v).replace(/"/g, "&quot;")}"`).join(" ");

/** SVG d'une icône ; options : size (px), cls, stroke (épaisseur), fill */
export function icon(name, { size = 24, cls = "", stroke = 2.25, fill = "none" } = {}) {
  const node = SET[name];
  if (!node) return "";
  const kids = node.map(([tag, a]) => `<${tag} ${attrs(a)}/>`).join("");
  return `<svg class="ico ico-${name} ${cls}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="${fill}" stroke="currentColor" stroke-width="${stroke}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${kids}</svg>`;
}

/** Icône d'un module de leçon (Bases, Grammaire…) */
export const MODULE_ICONS = { bases: "letters", vocab: "book", gram: "puzzle", conj: "hourglass", temps: "hourglass", nombres: "hash", expr: "chat", hanzi: "brush" };
export const moduleIcon = (mod, opts) => icon(MODULE_ICONS[mod] || "star", opts);

/** Remplit tous les [data-ico] présents dans la page (en-tête, barre d'onglets) */
export function hydrateIcons(root = document) {
  root.querySelectorAll("[data-ico]").forEach((el) => {
    if (el.dataset.icoDone) return;
    el.innerHTML = icon(el.dataset.ico, { size: +(el.dataset.icoSize || 24), fill: el.dataset.icoFill || "none" });
    el.dataset.icoDone = "1";
  });
}

/* ---------------------------------------------------------------------
   Emojis de l'interface → icônes dessinées (même style partout).
   Les emojis « de contenu » (avatars, illustrations des leçons et des
   histoires, réactions, messages, mascotte) ne sont pas touchés.
   --------------------------------------------------------------------- */
const EMOJI_ICONS = {
  "🔊": ["volume"], "🐢": ["snail"], "⚑": ["flag", "ei-red"], "🃏": ["spade", "ei-gold"], "📒": ["notebook", "ei-gold"],
  "🧭": ["compass", "ei-blue"], "🔥": ["flame", "ei-orange"], "⚡": ["zap", "ei-gold"], "🎯": ["target", "ei-red"], "🔒": ["lock", "ei-muted"],
  "🎉": ["party", "ei-violet"], "✅": ["check-circle", "ei-green"], "🔁": ["repeat", "ei-blue"], "🏆": ["trophy", "ei-gold"], "⚔️": ["swords", "ei-red"], "⚔": ["swords", "ei-red"],
  "☁️": ["cloud", "ei-blue"], "☁": ["cloud", "ei-blue"], "⏱️": ["timer", "ei-blue"], "⏱": ["timer", "ei-blue"], "💀": ["skull", "ei-muted"], "👥": ["users", "ei-blue"],
  "🎧": ["headphones", "ei-violet"], "⚙️": ["settings", "ei-muted"], "⚙": ["settings", "ei-muted"], "📈": ["chart", "ei-green"], "⏳": ["hourglass", "ei-muted"],
  "🔔": ["bell", "ei-gold"], "💬": ["chat", "ei-blue"], "⚠️": ["alert", "ei-orange"], "⚠": ["alert", "ei-orange"], "✨": ["sparkles", "ei-gold"], "🎓": ["grad", "ei-violet"],
  "📋": ["clipboard", "ei-blue"], "👑": ["crown", "ei-gold"], "📅": ["calendar", "ei-blue"], "🎤": ["mic", "ei-red"], "🔀": ["shuffle", "ei-blue"], "🎨": ["palette", "ei-violet"],
  "🎲": ["dices", "ei-violet"], "📴": ["wifi-off", "ei-muted"], "📝": ["pencil", "ei-blue"], "🔄": ["refresh", "ei-blue"], "🏅": ["medal", "ei-gold"], "📚": ["book", "ei-green"],
  "📖": ["story", "ei-green"], "💡": ["bulb", "ei-gold"], "🛡️": ["shield", "ei-blue"], "🛡": ["shield", "ei-blue"], "📣": ["megaphone", "ei-orange"], "👤": ["user", "ei-muted"],
  "📤": ["share", "ei-blue"], "🆕": ["sparkles", "ei-green"], "🚀": ["rocket", "ei-violet"], "📭": ["inbox", "ei-muted"], "📲": ["phone", "ei-blue"], "📱": ["phone", "ei-blue"],
  "🗣️": ["chat", "ei-blue"], "🔤": ["letters", "ei-blue"], "✍️": ["pencil", "ei-blue"], "🐞": ["alert", "ei-red"], "🌱": ["sprout", "ei-green"], "💪": ["zap", "ei-orange"],
  "📊": ["chart", "ei-blue"], "🔍": ["search", "ei-muted"], "🔎": ["search", "ei-muted"], "📆": ["calendar-days", "ei-blue"], "🎙️": ["mic", "ei-red"], "🎙": ["mic", "ei-red"],
  "📩": ["mail", "ei-blue"], "✉️": ["mail", "ei-blue"], "🗑️": ["trash", "ei-red"], "🗑": ["trash", "ei-red"], "✏️": ["pencil", "ei-blue"], "🌙": ["moon", "ei-violet"], "☀️": ["sun", "ei-gold"],
  "🙈": ["eye", "ei-muted"], "👁️": ["eye", "ei-muted"], "👁": ["eye", "ei-muted"], "🔑": ["unlock", "ei-gold"], "🧩": ["puzzle", "ei-violet"], "🔢": ["hash", "ei-blue"], "🎁": ["gift", "ei-red"], "👋": ["hand", "ei-gold"], "👍": ["thumbs", "ei-blue"], "🤷": ["info", "ei-blue"], "💯": ["award", "ei-gold"],
};
const EMOJI_RE = new RegExp(Object.keys(EMOJI_ICONS).sort((a, b) => b.length - a.length).map((e) => e.replace(/[️]/g, "️?")).join("|"), "gu");
// Zones où les emojis font partie du contenu
const KEEP = ".no-ico, input, textarea, svg, script, style, [contenteditable], .rx, .rx-row, .rx-pick, .cf-rx, .cf-menu-rx, .cf-msg, .cf-msgs, .avatar-grid, .avatar-opt, .hdr-avatar, .res-me, .m-bubble, .big-emoji, .story-emoji, .lesson-emoji, .streak-screen, .feed-body, [class*=avatar], [class*='-av'], .mascot, .modal-body .rp-recap, .sl-bubble, .story-line, .dlg-line";
/** Remplace les emojis d'interface par des icônes dans un élément (et ses enfants) */
export function iconize(root) {
  if (!root || root.nodeType !== 1 && root.nodeType !== 3) return;
  const nodes = [];
  if (root.nodeType === 3) nodes.push(root);
  else {
    if (root.closest?.(KEEP)) return;
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (EMOJI_RE.test(n.nodeValue) && (EMOJI_RE.lastIndex = 0, true) && !n.parentElement?.closest(KEEP) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT),
    });
    for (let n; (n = w.nextNode());) nodes.push(n);
  }
  for (const n of nodes) {
    const p = n.parentElement;
    if (!p || p.closest(KEEP)) continue;
    const s = n.nodeValue; EMOJI_RE.lastIndex = 0;
    if (!EMOJI_RE.test(s)) continue;
    EMOJI_RE.lastIndex = 0;
    const html = esc(s).replace(EMOJI_RE, (m) => {
      const [name, cls = ""] = EMOJI_ICONS[m] || EMOJI_ICONS[m + "️"] || EMOJI_ICONS[m.replace("️", "")] || [];
      return name ? `<span class="ei ${cls}" role="img" aria-label="">${icon(name, { size: 18, stroke: 2.25 })}</span>` : m;
    });
    const t = document.createElement("template"); t.innerHTML = html;
    n.replaceWith(t.content);
  }
}
const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
/** Surveille la page : chaque nouvel élément affiché est converti */
export function watchIcons(root = document.body) {
  if (typeof MutationObserver === "undefined") return;
  iconize(root);
  new MutationObserver((muts) => {
    for (const m of muts) {
      if (m.type === "characterData") { iconize(m.target); continue; }
      m.addedNodes.forEach((n) => { if (n.nodeType === 1 && n.classList?.contains("ei")) return; iconize(n); });
    }
  }).observe(root, { childList: true, subtree: true, characterData: true });
}
