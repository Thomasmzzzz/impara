/* =====================================================================
   words.js — Mots cliquables (exemples des leçons, histoires)
   ---------------------------------------------------------------------
   - Dictionnaire : tous les mots des leçons + ceux du carnet ;
   - découpage d'une phrase en mots (italien : par mots, articles élidés
     compris ; mandarin : le plus long mot connu, caractère par caractère) ;
   - toucher un mot ouvre une fiche : sens, pinyin, 🔊, « + carnet » et,
     en mandarin, les clés de chaque caractère (好 = 女 + 子).
   ===================================================================== */

import { state, commit } from "./storage.js";
import { code, L } from "./lang.js";
import { esc, speak, toast, tri } from "./ui.js";
import { ALL_LESSONS, getLesson } from "../data/curriculum.js";
import { charReading } from "./pinyin.js";

const zh = () => code === "zh";
const HAN = /[㐀-鿿]/;
const ARTICLE = /^(il|lo|la|i|gli|le|un|una|uno|l'|un'|dell'|all')\s*/i;
const low = (s) => String(s).toLowerCase().replace(/’/g, "'").trim();

/* ---------------------------- Dictionnaire ---------------------------- */
let DICT = null, DICT_LANG = null, MAXLEN = 1;
export function dictionary() {
  if (DICT && DICT_LANG === code) return DICT;
  DICT = new Map(); DICT_LANG = code; MAXLEN = 1;
  const add = (key, e) => { const k = low(key); if (!k || DICT.has(k)) return; DICT.set(k, e); MAXLEN = Math.max(MAXLEN, zh() ? [...k].length : k.split(" ").length); };
  const entry = (w, py, fr, levelId, lessonId) => {
    const e = { zh: w, py: py || "", fr: String(fr).split(" — ")[0], levelId, lessonId };
    // « bello / bella », « il libro » : chaque forme, avec ou sans article
    String(w).split(/\s*\/\s*|\s*,\s*/).forEach((v) => { add(v, e); if (!zh()) add(v.replace(ARTICLE, ""), e); });
  };
  ALL_LESSONS.forEach((l) => (l.vocab || []).map(tri).forEach(([w, py, fr]) => entry(w, py, fr, l.levelId, l.id)));
  Object.values(state.vocab || {}).forEach((w) => entry(w.zh, w.py, w.fr, w.levelId, w.lessonId));
  if (zh()) MAXLEN = Math.min(MAXLEN, 6);
  return DICT;
}
export const lookup = (w) => dictionary().get(low(w)) || (!zh() ? dictionary().get(low(w).replace(ARTICLE, "")) : null) || null;

/* ------------------------------ Découpage ----------------------------- */
/**
 * Découpe une phrase : [{ t: texte, k: clé du dictionnaire | null, word: bool }]
 * Mandarin : le plus long mot connu (6 caractères au plus), sinon caractère seul.
 */
export function tokenize(text) {
  const s = String(text ?? ""), out = [];
  const D = dictionary();
  if (zh()) {
    let i = 0;
    const chars = [...s];
    while (i < chars.length) {
      if (!HAN.test(chars[i])) { let j = i; while (j < chars.length && !HAN.test(chars[j])) j++; out.push({ t: chars.slice(i, j).join(""), k: null, word: false }); i = j; continue; }
      let n = Math.min(MAXLEN, chars.length - i), hit = null;
      for (; n > 1; n--) { const w = chars.slice(i, i + n).join(""); if (chars.slice(i, i + n).every((c) => HAN.test(c)) && D.has(w)) { hit = w; break; } }
      const w = hit || chars[i];
      out.push({ t: w, k: w, word: true });
      i += [...w].length;
    }
    return out;
  }
  // Italien : mots (avec apostrophe d'élision collée au mot qui suit), espaces et ponctuation
  const parts = s.match(/[\p{L}\p{M}]+['’]?|[^\p{L}\p{M}]+/gu) || [];
  for (let i = 0; i < parts.length; i++) {
    const p = parts[i];
    if (!/\p{L}/u.test(p)) { out.push({ t: p, k: null, word: false }); continue; }
    // Expressions de plusieurs mots (« per favore », « a presto ») : la plus longue connue
    let hit = null, span = 1;
    for (let n = Math.min(MAXLEN, 4); n > 1; n--) {
      const seq = parts.slice(i, i + n * 2 - 1);
      if (seq.length < n * 2 - 1 || !seq.every((x, k) => (k % 2 ? /^\s+$/.test(x) : /\p{L}/u.test(x)))) continue;
      const w = seq.join("");
      if (D.has(low(w))) { hit = w; span = n * 2 - 1; break; }
    }
    if (hit) { out.push({ t: hit, k: low(hit), word: true }); i += span - 1; continue; }
    const k = low(p).replace(/'$/, "'");
    out.push({ t: p, k: D.has(k) || D.has(k.replace(ARTICLE, "")) ? k : null, word: true });
  }
  return out;
}

/** HTML d'une phrase dont les mots connus (et tous les caractères chinois) sont cliquables */
export function wordsHtml(text) {
  return tokenize(text).map((x) => (x.word && (x.k || zh()) ? `<span class="wd" data-wd="${esc(x.k || x.t)}" role="button" tabindex="0">${esc(x.t)}</span>` : esc(x.t))).join("");
}

/* ------------------------------ Fiche mot ----------------------------- */
let KEYS = null;
const loadKeys = () => (KEYS ||= import("../data/zh-keys.js").catch(() => ({ CHARS: {}, COMPS: {}, MEAN: {} })));

function keysHtml(word, K) {
  const blocks = [...new Set([...word].filter((c) => HAN.test(c)))].map((c) => {
    const d = K.CHARS[c];
    if (!d) return "";
    const [parts, phon, story] = d;
    const chip = (x, i) => { const [py, fr] = K.COMPS[x] || ["", ""];
      return `<span class="key-chip ${i === phon ? "phon" : ""}"><b>${esc(x)}</b>${py ? `<i>${esc(py)}</i>` : ""}${fr ? `<small>${esc(fr)}</small>` : ""}${i === phon ? `<em>son</em>` : ""}</span>`; };
    const auto = phon >= 0
      ? `${parts.filter((_, i) => i !== phon).map((x) => `${x} (${K.COMPS[x]?.[1] || "?"})`).join(" + ")} donne le sens, ${parts[phon]} ${K.COMPS[parts[phon]]?.[0] || ""} donne le son.`
      : parts.map((x) => `${x} ${K.COMPS[x]?.[1] ? `(${K.COMPS[x][1]})` : ""}`).join(" + ") + ` → ${c}${K.MEAN[c] ? ` (${K.MEAN[c]})` : ""}`;
    return `<div class="key-block"><div class="key-row"><span class="key-ch">${esc(c)}</span><span class="key-eq">=</span>${parts.map(chip).join(`<span class="key-plus">+</span>`)}</div>
      <p class="key-story">${esc(story || auto)}</p></div>`;
  }).filter(Boolean);
  return blocks.length ? `<div class="wd-keys"><p class="wd-sub">🔑 Les clés ${blocks.length > 1 ? "des caractères" : "du caractère"}</p>${blocks.join("")}</div>` : "";
}

let pop = null;
function closePop() { pop?.remove(); pop = null; document.querySelectorAll(".wd.on").forEach((x) => x.classList.remove("on")); }

export async function openWord(key, anchor = null) {
  closePop();
  const e = lookup(key);
  const w = e?.zh || key;
  const py = e?.py || (zh() ? [...w].map((c) => (HAN.test(c) ? charReading(c) || "" : "")).filter(Boolean).join(" ") : "");
  const inCarnet = !!state.vocab?.[e?.zh || w];
  const lesson = e?.lessonId ? getLesson(e.lessonId) : null;
  anchor?.classList.add("on");
  pop = document.createElement("div");
  pop.className = "wd-pop";
  pop.setAttribute("role", "dialog");
  pop.innerHTML = `<div class="wd-card">
    <button class="wd-x" aria-label="Fermer">✕</button>
    <div class="wd-head"><button class="wd-say" aria-label="Écouter">🔊</button>
      <div><p class="wd-w ${L.wordClass}">${esc(w)}</p>${py ? `<p class="wd-py">${esc(py)}</p>` : ""}</div></div>
    <p class="wd-fr">${e ? esc(e.fr) : `<span class="muted">Ce mot n'est pas encore dans vos leçons.</span>`}</p>
    ${lesson ? `<p class="wd-from muted small">Leçon : ${esc(lesson.title)}</p>` : ""}
    ${zh() && /[\u3400-\u9fff]/.test(w) ? `<div class="wd-strokes" data-strokes title="Touchez un caractère pour revoir ses traits"></div>` : ""}
    ${zh() ? `<div data-keys></div>` : ""}
    ${e ? `<button class="btn ${inCarnet ? "ghost" : "primary"} wd-add" ${inCarnet ? "disabled" : ""}>${inCarnet ? "✓ Déjà dans le carnet" : "＋ Ajouter au carnet"}</button>` : ""}
  </div>`;
  document.body.appendChild(pop);
  requestAnimationFrame(() => pop?.classList.add("show"));
  speak(w, { force: true });
  pop.querySelector(".wd-say").onclick = () => speak(w, { force: true });
  pop.querySelector(".wd-x").onclick = closePop;
  pop.querySelector(".wd-add")?.addEventListener("click", (ev) => {
    commit((s) => { if (!s.vocab[e.zh]) s.vocab[e.zh] = { zh: e.zh, py: e.py, fr: e.fr, levelId: e.levelId, lessonId: e.lessonId, added: Date.now(), from: "lecture" }; });
    ev.currentTarget.textContent = "✓ Ajouté au carnet"; ev.currentTarget.disabled = true; ev.currentTarget.className = "btn ghost wd-add";
    toast("Mot ajouté au carnet 📒", "ok");
  });
  if (zh()) {
    import("./hanzi.js").then((m) => m.strokeAnim(pop?.querySelector("[data-strokes]"), w)).catch(() => {});
    const K = await loadKeys();
    const z = pop?.querySelector("[data-keys]");
    if (z) z.innerHTML = keysHtml(w, K);
  }
}

// Un seul écouteur pour toute l'appli
if (typeof document !== "undefined") {
  document.addEventListener("click", (ev) => {
    const t = ev.target.closest?.(".wd[data-wd]");
    if (t) { ev.preventDefault(); ev.stopPropagation(); openWord(t.dataset.wd, t); return; }
    if (pop && !ev.target.closest(".wd-card")) closePop();
  }, true);
  document.addEventListener("keydown", (ev) => {
    if (ev.key === "Escape") closePop();
    if ((ev.key === "Enter" || ev.key === " ") && ev.target.matches?.(".wd[data-wd]")) { ev.preventDefault(); openWord(ev.target.dataset.wd, ev.target); }
  });
  window.addEventListener("hashchange", closePop);
}

/** Clés d'un caractère (pour la page de tracé) */
export async function keysFor(ch) { const K = await loadKeys(); return keysHtml(ch, K); }
