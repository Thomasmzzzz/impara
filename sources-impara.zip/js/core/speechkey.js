/* =====================================================================
   speechkey.js — Texte réellement prononcé et identifiant d'enregistrement
   Module sans dépendance, partagé par l'appli (lecture) et par l'outil
   qui prépare les enregistrements (tools/audio) : les deux doivent
   calculer exactement la même clé pour une même phrase.
   ===================================================================== */

/** Le texte lu à voix haute : partie avant « | », sans ✓✗, filtré selon la langue */
export function speechText(raw, filter = null) {
  let t = String(raw ?? "").split("|")[0].replace(/[✓✗]/g, "");
  if (filter) t = t.replace(filter, "");
  return t.trim();
}

/** Identifiant court d'une phrase (FNV-1a 32 bits, en base 36) */
export function clipId(t) {
  let h = 0x811c9dc5;
  for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
  return h.toString(36);
}

/** Filtre de lecture de chaque langue (identique à lang.js) */
export const SPEAK_FILTER = { it: null, zh: /[^㐀-鿿豈-﫿，。！？、]/g };
