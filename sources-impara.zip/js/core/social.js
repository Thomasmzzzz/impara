/* =====================================================================
   social.js — Amis, messages et défis (Supabase)
   ---------------------------------------------------------------------
   - Nom d'utilisateur unique (table `profiles`).
   - Demandes d'ami : envoyées par nom d'utilisateur, acceptées par
     l'autre personne ; une fois amis, chacun voit la progression de
     l'autre (table `user_stats`, un résumé par langue).
   - Messages privés entre amis, reçus en temps réel.
   - Défis : l'un lance, l'autre accepte, puis chacun répond à des
     questions de SA langue ; le meilleur score gagne (puis le temps).
   Le schéma et les règles de sécurité sont dans supabase/social.sql.
   ===================================================================== */

import { state, subscribe } from "./storage.js";
import { code, LANGS } from "./lang.js";
import { cloudInfo, onCloud, getClient, isConfigured } from "./cloud.js";
import * as P from "./progress.js";
import { lvlLabel } from "../data/curriculum.js";

export const USERNAME_RE = /^[a-z0-9_]{3,20}$/;

/* --------------------------- État partagé -------------------------- */
const S = {
  ready: false,          // données chargées au moins une fois
  me: null,              // { id, username, pseudo, avatar } ou null (pas encore de nom d'utilisateur)
  profiles: {},          // { [id]: profil }
  friendships: [],       // lignes brutes
  stats: {},             // { [userId]: { [lang]: résumé } }
  challenges: [],
  unread: {},            // { [friendId]: nombre }
};
export const social = () => S;
const listeners = new Set();
export const onSocial = (fn) => (listeners.add(fn), () => listeners.delete(fn));
const emit = (what = "all", detail) => listeners.forEach((fn) => fn(what, detail));

const uid = () => cloudInfo().user?.id || null;
export const isAvailable = () => isConfigured() && !!uid();

/* ------------------------------ Erreurs ---------------------------- */
const ERRORS = {
  not_found: "Aucun utilisateur ne porte ce nom.",
  self: "C'est votre propre nom d'utilisateur 🙂",
  already_friends: "Vous êtes déjà amis.",
  already_sent: "Demande déjà envoyée : elle attend sa réponse.",
  no_profile: "Choisissez d'abord votre nom d'utilisateur.",
  not_friends: "Vous devez être amis pour faire cela.",
  challenge_not_playable: "Ce défi n'est pas (ou plus) jouable.",
  already_played: "Vous avez déjà joué ce défi.",
};
export function socialError(e) {
  const m = String(e?.message || e || "");
  for (const [k, v] of Object.entries(ERRORS)) if (m.includes(k)) return v;
  if (/duplicate key|unique/i.test(m)) return "Ce nom d'utilisateur est déjà pris.";
  if (/Failed to fetch|NetworkError|Load failed/i.test(m)) return "Serveur injoignable. Vérifiez votre connexion.";
  return m || "Une erreur est survenue.";
}
const check = ({ data, error }) => { if (error) throw error; return data; };

/* ------------------------------ Chargement ------------------------- */
let loading = null;
export function refresh() {
  if (!isAvailable()) return Promise.resolve();
  if (loading) return loading;
  loading = (async () => {
    const sb = await getClient();
    const me = uid();
    const [mine, fr, ch, unread] = await Promise.all([
      sb.from("profiles").select("*").eq("id", me).maybeSingle().then(check),
      sb.from("friendships").select("*").then(check),
      sb.from("challenges").select("*").order("created_at", { ascending: false }).limit(60).then(check),
      sb.from("messages").select("sender").eq("recipient", me).is("read_at", null).then(check),
    ]);
    S.me = mine;
    S.friendships = fr;
    S.challenges = ch;
    S.unread = {};
    unread.forEach((m) => (S.unread[m.sender] = (S.unread[m.sender] || 0) + 1));

    const ids = [...new Set(fr.flatMap((f) => [f.requester, f.addressee]).concat(ch.flatMap((c) => [c.challenger, c.opponent])))].filter((x) => x !== me);
    if (mine) S.profiles[me] = mine;
    if (ids.length) {
      const [profs, stats] = await Promise.all([
        sb.from("profiles").select("id, username, pseudo, avatar, color").in("id", ids).then(check),
        sb.from("user_stats").select("user_id, lang, summary, updated_at").in("user_id", [...ids, me]).then(check),
      ]);
      profs.forEach((p) => (S.profiles[p.id] = p));
      S.stats = {};
      stats.forEach((r) => ((S.stats[r.user_id] ||= {})[r.lang] = { ...r.summary, updated_at: r.updated_at }));
    } else {
      const stats = await sb.from("user_stats").select("user_id, lang, summary, updated_at").eq("user_id", me).then(check);
      S.stats = {};
      stats.forEach((r) => ((S.stats[r.user_id] ||= {})[r.lang] = { ...r.summary, updated_at: r.updated_at }));
    }
    S.ready = true;
    emit("all");
  })().finally(() => (loading = null));
  return loading;
}

/* --------------------------- Vues dérivées ------------------------- */
const other = (f, me = uid()) => (f.requester === me ? f.addressee : f.requester);
export function friends() {
  return S.friendships.filter((f) => f.status === "accepted")
    .map((f) => ({ ...S.profiles[other(f)], friendshipId: f.id, since: f.created_at }))
    .filter((p) => p.id)
    .sort((a, b) => (S.unread[b.id] || 0) - (S.unread[a.id] || 0) || (a.pseudo || a.username).localeCompare(b.pseudo || b.username));
}
export const incoming = () => S.friendships.filter((f) => f.status === "pending" && f.addressee === uid()).map((f) => ({ ...f, from: S.profiles[f.requester] }));
export const outgoing = () => S.friendships.filter((f) => f.status === "pending" && f.requester === uid()).map((f) => ({ ...f, to: S.profiles[f.addressee] }));
export const friendByUsername = (u) => friends().find((f) => f.username === u);
export const profileOf = (id) => S.profiles[id];
export const statsOf = (id) => S.stats[id] || {};

/** Point de vue de l'utilisateur sur un défi */
export function view(c) {
  const me = uid();
  const iAmChallenger = c.challenger === me;
  const side = iAmChallenger ? "challenger" : "opponent", oside = iAmChallenger ? "opponent" : "challenger";
  const mine = c[`${side}_score`] != null ? { score: c[`${side}_score`], total: c[`${side}_total`], ms: c[`${side}_ms`], lang: c[`${side}_lang`] } : null;
  const theirs = c[`${oside}_score`] != null ? { score: c[`${oside}_score`], total: c[`${oside}_total`], ms: c[`${oside}_ms`], lang: c[`${oside}_lang`] } : null;
  let stage;
  if (c.status === "declined") stage = "declined";
  else if (c.status === "cancelled") stage = "cancelled";
  else if (c.status === "pending") stage = iAmChallenger ? "waiting_accept" : "to_accept";
  else if (!mine) stage = "to_play";
  else if (!theirs) stage = "waiting_play";
  else stage = "done";
  let outcome = null;
  if (stage === "done") {
    const a = mine.score / mine.total, b = theirs.score / theirs.total;
    outcome = a > b ? "win" : a < b ? "lose" : mine.ms < theirs.ms ? "win" : mine.ms > theirs.ms ? "lose" : "draw";
  }
  return { ...c, iAmChallenger, friend: S.profiles[iAmChallenger ? c.opponent : c.challenger], mine, theirs, stage, outcome };
}
export const challengesWith = (friendId) => S.challenges.filter((c) => c.challenger === friendId || c.opponent === friendId).map(view);
export const allChallenges = () => S.challenges.map(view);

/** Nombre d'actions en attente (pastille de l'onglet Amis) */
export function badgeCount() {
  if (!isAvailable() || !S.ready) return 0;
  const unread = Object.values(S.unread).reduce((a, b) => a + b, 0);
  const todo = allChallenges().filter((c) => c.stage === "to_accept" || c.stage === "to_play").length;
  return incoming().length + unread + todo;
}

/* ------------------------------ Actions ---------------------------- */
async function rpc(name, args) { const sb = await getClient(); return check(await sb.rpc(name, args)); }

export async function createProfile(username) {
  const u = username.trim().toLowerCase();
  if (!USERNAME_RE.test(u)) throw new Error("3 à 20 caractères : lettres minuscules, chiffres ou _ (sans espace ni accent).");
  const sb = await getClient();
  try {
    check(await sb.from("profiles").insert({ id: uid(), username: u, pseudo: state.profile?.pseudo || u, avatar: state.profile?.avatar || "👤" }));
  } catch (e) { throw new Error(socialError(e)); }
  await refresh();
  pushStats(true);
}

export async function addFriend(username) {
  const r = await rpc("send_friend_request", { p_username: username.trim().toLowerCase().replace(/^@/, "") }).catch((e) => { throw new Error(socialError(e)); });
  if (r !== "sent" && r !== "accepted") throw new Error(socialError(r));
  await refresh();
  return r;
}
export async function acceptFriend(id) { await rpc("accept_friend_request", { p_id: id }); await refresh(); }
export async function removeFriendship(id) {
  const sb = await getClient();
  check(await sb.from("friendships").delete().eq("id", id));
  await refresh();
}

export async function loadMessages(friendId, limit = 80) {
  const sb = await getClient();
  const me = uid();
  const rows = check(await sb.from("messages").select("*")
    .or(`and(sender.eq.${me},recipient.eq.${friendId}),and(sender.eq.${friendId},recipient.eq.${me})`)
    .order("created_at", { ascending: false }).limit(limit));
  return rows.reverse();
}
export async function sendMessage(friendId, body) {
  const text = body.trim().slice(0, 1000);
  if (!text) return null;
  const sb = await getClient();
  try { return check(await sb.from("messages").insert({ sender: uid(), recipient: friendId, body: text }).select().single()); }
  catch (e) { throw new Error(socialError(e)); }
}
export async function markRead(friendId) {
  if (!S.unread[friendId]) return;
  delete S.unread[friendId];
  emit("unread");
  await rpc("mark_messages_read", { p_friend: friendId }).catch(() => {});
}

export async function createChallenge(friendId, n = 10) {
  const id = await rpc("create_challenge", { p_opponent: friendId, p_n: n }).catch((e) => { throw new Error(socialError(e)); });
  await refresh();
  return id;
}
export async function respondChallenge(id, accept) { await rpc("respond_challenge", { p_id: id, p_accept: accept }).catch((e) => { throw new Error(socialError(e)); }); await refresh(); }
export async function cancelChallenge(id) { await rpc("cancel_challenge", { p_id: id }).catch((e) => { throw new Error(socialError(e)); }); await refresh(); }
export async function submitChallenge(id, { score, total, ms }) {
  await rpc("submit_challenge", { p_id: id, p_lang: code, p_score: score, p_total: total, p_ms: Math.round(ms) })
    .catch((e) => { throw new Error(socialError(e)); });
  await refresh();
}
export async function getChallenge(id) {
  const sb = await getClient();
  const c = check(await sb.from("challenges").select("*").eq("id", id).maybeSingle());
  if (c) { const i = S.challenges.findIndex((x) => x.id === id); if (i >= 0) S.challenges[i] = c; else S.challenges.unshift(c); }
  return c ? view(c) : null;
}

/* ------------------- Résumé de progression partagé ----------------- */
export function mySummary() {
  const g = P.globalProgress(), lvl = P.currentLevel();
  return {
    xp: state.xp, streak: P.streakCount(), level: lvlLabel(lvl), levelName: lvl.name,
    pct: g.pct, done: g.done, total: g.total,
    lessons: Object.values(state.lessons).filter((l) => l.passed).length,
    words: Object.keys(state.vocab).length,
    week: P.weekKey(), weekXp: P.weeklyXp(),
    days: P.last7Days(),
    // Rappel de série (notification du soir) : jour local de la dernière activité et fuseau horaire
    lastDay: state.streak.last || null, streakRaw: state.streak.count || 0,
    tz: (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC"; } catch { return "UTC"; } })(),
    remind: state.settings.streakReminder !== false,
  };
}
let lastSent = "", statsTimer = null;
export async function pushStats(force = false) {
  if (!isAvailable() || !S.me || !state.profile) return;
  const sum = mySummary(), key = JSON.stringify(sum);
  if (!force && key === lastSent) return;
  lastSent = key;
  const sb = await getClient();
  const { error } = await sb.from("user_stats").upsert({ user_id: uid(), lang: code, summary: sum, updated_at: new Date().toISOString() });
  if (error) { lastSent = ""; return; }
  (S.stats[uid()] ||= {})[code] = { ...sum, updated_at: new Date().toISOString() };
  // Historique du classement : XP de la semaine en cours
  if (sum.weekXp > 0) await sb.from("weekly_xp").upsert({ user_id: uid(), week: sum.week, lang: code, xp: sum.weekXp, updated_at: new Date().toISOString() });
  // Pseudo / avatar modifiés dans le profil : on les recopie
  const color = state.profile?.color || null;
  if (state.profile && (S.me.pseudo !== state.profile.pseudo || S.me.avatar !== state.profile.avatar || (S.me.color || null) !== color)) {
    const { error: e2 } = await sb.from("profiles").update({ pseudo: state.profile.pseudo, avatar: state.profile.avatar, color }).eq("id", uid());
    if (!e2) { S.me.pseudo = state.profile.pseudo; S.me.avatar = state.profile.avatar; S.me.color = color; }
  }
}

/* --------------------------- Temps réel ---------------------------- */
let channel = null, poll = null, startedFor = null;

async function start() {
  const me = uid();
  if (!me || startedFor === me) return;
  stop();
  startedFor = me;
  await refresh().catch(() => {});
  pushStats(true);
  const sb = await getClient();
  if (sb.channel) {
    channel = sb.channel(`social-${me}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `recipient=eq.${me}` }, (p) => {
        const m = p.new;
        S.unread[m.sender] = (S.unread[m.sender] || 0) + 1;
        emit("message", m);
        if (!S.profiles[m.sender]) refresh();
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "challenges" }, () => refresh())
      .on("postgres_changes", { event: "*", schema: "public", table: "friendships" }, () => refresh())
      .on("postgres_changes", { event: "*", schema: "public", table: "user_stats" }, (p) => {
        // Progression d'un ami mise à jour : classement et fiches rafraîchis tout de suite
        const r = p.new;
        if (r?.user_id && r.user_id !== uid()) { (S.stats[r.user_id] ||= {})[r.lang] = { ...r.summary, updated_at: r.updated_at }; emit("all"); }
      })
      .subscribe();
  }
  // Filet de sécurité si le temps réel est coupé (réseau mobile…)
  poll = setInterval(() => { if (document.visibilityState === "visible") refresh().catch(() => {}); }, 30000);
}
function stop() {
  if (channel) { getClient().then((sb) => sb.removeChannel?.(channel)); channel = null; }
  clearInterval(poll); poll = null; startedFor = null;
  Object.assign(S, { ready: false, me: null, profiles: {}, friendships: [], stats: {}, challenges: [], unread: {} });
  emit("all");
}

export function initSocial() {
  if (!isConfigured()) return;
  onCloud((i) => { if (i.user) start(); else if (startedFor) stop(); });
  if (uid()) start();
  subscribe(() => { clearTimeout(statsTimer); statsTimer = setTimeout(() => pushStats(), 4000); });
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible" && uid()) refresh().catch(() => {}); });
}

/** Classement de la semaine : moi + mes amis, XP gagnés depuis lundi (toutes langues) */
export function leaderboard() {
  const week = P.weekKey();
  const total = (id, override) => Object.entries({ ...statsOf(id), ...(override || {}) })
    .reduce((n, [, s]) => n + (s?.week === week ? s.weekXp || 0 : 0), 0);
  const all = (id, override) => Object.values({ ...statsOf(id), ...(override || {}) }).reduce((n, s) => n + (s?.xp || 0), 0);
  const mine = { [code]: mySummary() };
  const me = S.me ? [{ ...S.me, isMe: true, xp: total(S.me.id, mine), allXp: all(S.me.id, mine) }] : [];
  return [...me, ...friends().map((f) => ({ ...f, xp: total(f.id), allXp: all(f.id) }))].sort((a, b) => b.xp - a.xp || b.allXp - a.allXp);
}

/** Lundi (UTC) d'une semaine « 2026-W45 » */
export function weekStart(week) {
  const [y, w] = week.split("-W").map(Number);
  const jan4 = new Date(Date.UTC(y, 0, 4));
  const monday = new Date(jan4); monday.setUTCDate(jan4.getUTCDate() - ((jan4.getUTCDay() || 7) - 1) + (w - 1) * 7);
  return monday;
}

/**
 * Historique du classement : pour chaque semaine passée, le total d'XP de
 * moi et de mes amis (toutes langues), du meilleur au moins bon.
 * @returns {Promise<{week:string, start:Date, ranking:{id, xp, isMe, profile}[]}[]>}
 */
export async function weeklyHistory(limit = 12) {
  if (!isAvailable()) return [];
  const sb = await getClient();
  const ids = [uid(), ...friends().map((f) => f.id)];
  const current = P.weekKey();
  const { data, error } = await sb.from("weekly_xp").select("user_id, week, xp").in("user_id", ids).lt("week", current).order("week", { ascending: false }).limit(1000);
  if (error) throw error;
  const byWeek = new Map();
  for (const r of data || []) {
    const m = byWeek.get(r.week) || new Map();
    m.set(r.user_id, (m.get(r.user_id) || 0) + r.xp);
    byWeek.set(r.week, m);
  }
  return [...byWeek.entries()].sort((a, b) => b[0].localeCompare(a[0])).slice(0, limit).map(([week, m]) => ({
    week, start: weekStart(week),
    ranking: [...m.entries()].map(([id, xp]) => ({ id, xp, isMe: id === uid(), profile: id === uid() ? S.me : S.profiles[id] }))
      .filter((r) => r.profile && r.xp > 0).sort((a, b) => b.xp - a.xp),
  })).filter((w) => w.ranking.length);
}

/** Bilan des défis contre un ami (ou contre tout le monde) */
export function record(friendId = null) {
  const list = allChallenges().filter((c) => c.stage === "done" && (!friendId || c.friend?.id === friendId));
  return { win: list.filter((c) => c.outcome === "win").length, lose: list.filter((c) => c.outcome === "lose").length, draw: list.filter((c) => c.outcome === "draw").length, total: list.length };
}

export const langLabel = (c) => LANGS[c]?.label || c;
