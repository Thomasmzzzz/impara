/* =====================================================================
   pinyin.js — Pinyin au-dessus des caractères dans les quiz
   ---------------------------------------------------------------------
   Les lectures viennent de data/zh-pinyin.js (généré à partir du cours :
   chaque suite de caractères avec sa lecture en contexte).
   Réglage « Pinyin dans les quiz » (profil) :
   - auto     : affiché pour HSK 1 et HSK 2 (défaut) ;
   - always   : toujours ; never : jamais.
   ===================================================================== */

import MAP from "../data/zh-pinyin.js";
import { state } from "./storage.js";
import { code } from "./lang.js";
import { getLesson } from "../data/curriculum.js";
import { esc } from "./ui.js";

const AUTO_LEVELS = ["A1", "A2"]; // HSK 1 et HSK 2
export const PINYIN_MODES = [["auto", "HSK 1-2"], ["always", "Toujours"], ["never", "Jamais"]];

/** Faut-il afficher le pinyin pour cette question (référence « leçon:i » ou « exam-A1:i ») ? */
export function wantPinyin(ref = "") {
  if (code !== "zh") return false;
  const mode = state.settings.pinyinQuiz || "auto";
  if (mode === "never") return false;
  if (mode === "always") return true;
  const src = String(ref).split(":")[0];
  const level = src.startsWith("exam-") ? src.slice(5) : getLesson(src)?.levelId;
  return AUTO_LEVELS.includes(level);
}

const HAN_RUN = /[㐀-鿿]+/g;
const TONED = /[āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ]/;

/** Texte → HTML échappé, avec le pinyin en petit au-dessus de chaque caractère */
export function ruby(text) {
  const s = String(text ?? "");
  let out = "", last = 0;
  for (const m of s.matchAll(HAN_RUN)) {
    const run = m[0], end = m.index + run.length;
    out += esc(s.slice(last, m.index));
    // Déjà suivi de son pinyin dans le texte (ex. « 你好 nǐ hǎo ») : on ne double pas
    const after = s.slice(end, end + 14);
    const already = /^\s*[(（]?[a-zü']+/i.test(after) && TONED.test(after.split(/[,.;:!?)）»]/)[0]);
    const syl = MAP[run]?.split(" ");
    out += !already && syl && syl.length === run.length
      ? [...run].map((c, i) => `<ruby>${esc(c)}<rt>${esc(syl[i])}</rt></ruby>`).join("")
      : esc(run);
    last = end;
  }
  return out + esc(s.slice(last));
}
