/* =====================================================================
   pinyin.js — Pinyin au-dessus des caractères dans les quiz
   ---------------------------------------------------------------------
   Les lectures viennent de data/zh-pinyin.js (généré à partir du cours :
   chaque suite de caractères avec sa lecture en contexte).
   Réglage « Pinyin dans les quiz » (profil) :
   - auto     : affiché pour HSK 1 et HSK 2 (défaut) ;
   - always   : toujours ; never : jamais.
   ===================================================================== */

import { state } from "./storage.js";
import { code } from "./lang.js";
import { getLesson } from "../data/curriculum.js";
import { esc } from "./ui.js";

// Dictionnaire des lectures : téléchargé seulement pour le mandarin
const MAP = code === "zh" ? (await import("../data/zh-pinyin.js")).default : {};
export { MAP as PINYIN_MAP };

const AUTO_LEVELS = ["A1", "A2"]; // HSK 1 et HSK 2
export const PINYIN_MODES = [["auto", "HSK 1-2"], ["always", "Toujours"], ["never", "Jamais"]];

/** Faut-il afficher le pinyin pour ce palier (« A1 », « A2 »…) ? */
export function levelWantsPinyin(levelId) {
  if (code !== "zh") return false;
  const mode = state.settings.pinyinQuiz || "auto";
  if (mode === "never") return false;
  if (mode === "always") return true;
  return AUTO_LEVELS.includes(levelId);
}

/** Idem pour une question (référence « leçon:i » ou « exam-A1:i ») */
export function wantPinyin(ref = "") {
  const src = String(ref).split(":")[0];
  return levelWantsPinyin(src.startsWith("exam-") ? src.slice(5) : getLesson(src)?.levelId);
}

const HAN_RUN = /[㐀-鿿]+/g;
const TONED = /[āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ]/;

/** Le texte qui suit commence-t-il déjà par du pinyin (ex. « 你好 nǐ hǎo ») ? */
const bare = (s) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-zü]/g, "");
const followedByPinyin = (after, syl) => {
  if (/^\s*[(（]?[a-zü']+/i.test(after) && TONED.test(after.slice(0, 16).split(/[,.;:!?)）»=—]/)[0])) return true;
  // Pinyin sans accent (ton neutre, ex. « 的 de ») : on compare les lettres
  if (!syl) return false;
  const want = bare(syl.join("")), next = bare(after.slice(0, want.length * 2 + 6));
  return /^\s*[(（]?[a-zü]/i.test(after) && want.length > 0 && next.startsWith(want);
};

function annotate(s, escape, lookahead = "") {
  let out = "", last = 0;
  for (const m of s.matchAll(HAN_RUN)) {
    const run = m[0], end = m.index + run.length;
    out += escape(s.slice(last, m.index));
    // Lecture du groupe entier, sinon caractère par caractère (ex. phrase coupée par « ___ »)
    let syl = MAP[run]?.split(" ");
    if (!syl || syl.length !== run.length) { const each = [...run].map((c) => MAP[c]); syl = each.every(Boolean) ? each : null; }
    out += syl && syl.length === run.length && !followedByPinyin(s.slice(end) + lookahead, syl)
      ? [...run].map((c, i) => `<ruby>${esc(c)}<rt>${esc(syl[i])}</rt></ruby>`).join("")
      : escape(run);
    last = end;
  }
  return out + escape(s.slice(last));
}

/** Texte brut → HTML échappé, avec le pinyin en petit au-dessus de chaque caractère */
export const ruby = (text) => annotate(String(text ?? ""), esc);

/** Même chose pour un fragment HTML du cours (balises <b>, <i>… conservées) */
export function rubyHtml(html) {
  const parts = String(html ?? "").split(/(<[^>]+>)/);
  return parts.map((p, i) => {
    if (p.startsWith("<")) return p;
    const after = parts.slice(i + 1).join("").replace(/<[^>]+>/g, "").slice(0, 20);
    return annotate(p, (x) => x, after);
  }).join("");
}

/** Raccourcis pour les vues : n'annote que si le palier le demande */
export const pyText = (levelId, text) => (levelWantsPinyin(levelId) ? ruby(text) : esc(text));
export const pyHtml = (levelId, html) => (levelWantsPinyin(levelId) ? rubyHtml(html) : html);
