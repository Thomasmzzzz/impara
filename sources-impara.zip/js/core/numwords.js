/* =====================================================================
   numwords.js — Nombres, heures, dates et prix en toutes lettres
   (italien et mandarin). Module sans dépendance : utilisé par l'exercice
   « Nombres » et par l'outil qui prépare les enregistrements audio.
   ===================================================================== */

/* ------------------------------ Italien ------------------------------ */
const U = ["zero", "uno", "due", "tre", "quattro", "cinque", "sei", "sette", "otto", "nove", "dieci", "undici", "dodici", "tredici", "quattordici", "quindici", "sedici", "diciassette", "diciotto", "diciannove"];
const T = ["", "", "venti", "trenta", "quaranta", "cinquanta", "sessanta", "settanta", "ottanta", "novanta"];
function it100(n) {
  if (n < 20) return U[n];
  const t = T[Math.floor(n / 10)], u = n % 10;
  if (!u) return t;
  if (u === 1 || u === 8) return t.slice(0, -1) + U[u]; // ventuno, ventotto
  return t + (u === 3 ? "tré" : U[u]);                   // ventitré
}
function it1000(n) {
  const h = Math.floor(n / 100), r = n % 100;
  const hs = h === 0 ? "" : h === 1 ? "cento" : U[h] + "cento";
  if (!r) return hs || "zero";
  let rs = it100(r);
  if (r === 3 && h) rs = "tré";
  if (hs && /^o/.test(rs)) return hs.slice(0, -1) + rs; // centotto, duecentottanta
  return hs + rs;
}
export function itNum(n) {
  if (n < 1000) return it1000(n);
  const k = Math.floor(n / 1000), r = n % 1000;
  return (k === 1 ? "mille" : it1000(k) + "mila") + (r ? it1000(r) : "");
}
export const itHourWord = (h) => (h === 1 ? "l'una" : `le ${itNum(h)}`);
export const itMonths = ["gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto", "settembre", "ottobre", "novembre", "dicembre"];

/* ------------------------------ Mandarin ----------------------------- */
export const D = "零一二三四五六七八九";
const PY = { 零: "líng", 一: "yī", 二: "èr", 两: "liǎng", 三: "sān", 四: "sì", 五: "wǔ", 六: "liù", 七: "qī", 八: "bā", 九: "jiǔ", 十: "shí", 百: "bǎi", 千: "qiān", 万: "wàn", 点: "diǎn", 分: "fēn", 半: "bàn", 刻: "kè", 月: "yuè", 号: "hào", 块: "kuài", 差: "chà" };
export function zhNum(n) {
  if (n < 10) return D[n];
  if (n < 20) return "十" + (n % 10 ? D[n % 10] : "");
  const units = [[10000, "万"], [1000, "千"], [100, "百"], [10, "十"], [1, ""]];
  let out = "", zero = false, started = false;
  for (const [v, u] of units) {
    const d = Math.floor(n / v) % 10;
    if (!d) { if (started) zero = true; continue; }
    if (zero) { out += "零"; zero = false; }
    // « deux » se dit 两 devant 百, 千, 万 (sauf en début de dizaine)
    out += (d === 2 && v >= 100 ? "两" : D[d]) + u;
    started = true;
  }
  return out;
}
export const zhPy = (s) => [...s].map((c) => PY[c] || c).join(" ").replace(/\s+([,，])/g, "$1");
export const zhHour = (h) => (h === 2 ? "两" : zhNum(h));


/* ------------------- Phrases dites (une seule source) ------------------- */
export const MINUTES = [0, 5, 10, 15, 20, 30, 40, 45, 50];
export const CENTS = [0, 10, 20, 50, 80, 90];
export const DAYS = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

export function sayTime(lang, h, m) {
  const nh = (h % 12) + 1;
  if (lang === "zh") {
    return m === 0 ? `${zhHour(h)}点` : m === 15 ? `${zhHour(h)}点一刻` : m === 30 ? `${zhHour(h)}点半` : m === 45 ? `${zhHour(h)}点三刻`
      : m === 5 ? `${zhHour(h)}点零五分` : `${zhHour(h)}点${zhNum(m)}分`;
  }
  const H = (x) => (x === 1 ? "È l'una" : `Sono ${itHourWord(x)}`);
  return m === 0 ? H(h) : m === 15 ? `${H(h)} e un quarto` : m === 30 ? `${H(h)} e mezza` : m === 45 ? `${H(nh)} meno un quarto`
    : m === 40 ? `${H(nh)} meno venti` : m === 50 ? `${H(nh)} meno dieci` : `${H(h)} e ${itNum(m)}`;
}
export function sayDate(lang, mo, d) {
  if (lang === "zh") return `${zhNum(mo + 1)}月${zhNum(d)}号`;
  return d === 1 ? `il primo ${itMonths[mo]}` : (d === 8 || d === 11) ? `l'${itNum(d)} ${itMonths[mo]}` : `il ${itNum(d)} ${itMonths[mo]}`;
}
export function sayPrice(lang, e, c) {
  if (lang === "zh") { const j = Math.floor(c / 10); return `${e === 2 ? "两" : zhNum(e)}块${j ? D[j] : ""}`; }
  return `${e === 1 ? "un" : itNum(e)} euro${c ? ` e ${itNum(c)}` : ""}`;
}
export const sayNum = (lang, n) => (lang === "zh" ? zhNum(n) : itNum(n));

/** Grands nombres proposés à l'écoute (liste fixe, pour qu'ils soient tous enregistrés) */
export const BIG = (() => {
  let s = 12345;
  const r = () => (s = (s * 1103515245 + 12345) % 2147483648) / 2147483648;
  const out = new Set([110, 115, 200, 250, 300, 500, 999, 1000, 1001, 1500, 2000, 2026, 5000, 9999]);
  while (out.size < 220) out.add(101 + Math.floor(r() * 899));
  while (out.size < 400) out.add(1000 + Math.floor(r() * 9000));
  return [...out].sort((a, b) => a - b);
})();

/** Tout ce que l'exercice peut faire dire (pour les enregistrements) */
export function allSpoken(lang) {
  const out = new Set();
  for (let n = 0; n <= 100; n++) out.add(sayNum(lang, n));
  BIG.forEach((n) => out.add(sayNum(lang, n)));
  for (let h = 1; h <= 12; h++) MINUTES.forEach((m) => out.add(sayTime(lang, h, m)));
  DAYS.forEach((max, mo) => { for (let d = 1; d <= max; d++) out.add(sayDate(lang, mo, d)); });
  for (let e = 1; e <= 99; e++) CENTS.forEach((c) => out.add(sayPrice(lang, e, c)));
  return [...out];
}
