/* =====================================================================
   mascot.js — Les mascottes d'Impara (dessins SVG originaux)
   - Italien  : Volpina, une petite renarde
   - Mandarin : Bao (宝), un petit panda
   Humeurs : idle · happy · cheer · sad · think
   ===================================================================== */
import { code } from "./lang.js";

export const MASCOTS = {
  it: { name: "Volpina", kind: "fox" },
  zh: { name: "Bao", kind: "panda" },
};
export const mascotName = () => (MASCOTS[code] || MASCOTS.it).name;

/* ------------------------------ Visage ------------------------------ */
function eyes(mood, ink, y = 60, dx = 15) {
  const L = 60 - dx, R = 60 + dx;
  if (mood === "happy" || mood === "cheer")
    return `<g class="m-eyes" fill="none" stroke="${ink}" stroke-width="4" stroke-linecap="round">
      <path d="M${L - 6},${y + 2} Q${L},${y - 6} ${L + 6},${y + 2}"/><path d="M${R - 6},${y + 2} Q${R},${y - 6} ${R + 6},${y + 2}"/></g>`;
  if (mood === "sad")
    return `<g class="m-eyes"><ellipse cx="${L}" cy="${y + 2}" rx="5" ry="5.5" fill="${ink}"/><ellipse cx="${R}" cy="${y + 2}" rx="5" ry="5.5" fill="${ink}"/>
      <path d="M${L - 8},${y - 5} L${L + 5},${y - 10}" stroke="${ink}" stroke-width="3" stroke-linecap="round"/><path d="M${R + 8},${y - 5} L${R - 5},${y - 10}" stroke="${ink}" stroke-width="3" stroke-linecap="round"/>
      <path d="M${R + 3},${y + 8} q3,6 0,9 q-3,-3 0,-9z" fill="#7cc4f2"/></g>`;
  const look = mood === "think" ? -3 : 0;
  return `<g class="m-eyes"><ellipse cx="${L}" cy="${y}" rx="5.5" ry="6.5" fill="${ink}"/><ellipse cx="${R}" cy="${y}" rx="5.5" ry="6.5" fill="${ink}"/>
    <circle cx="${L + 1.8}" cy="${y - 2.5 + look}" r="2" fill="#fff"/><circle cx="${R + 1.8}" cy="${y - 2.5 + look}" r="2" fill="#fff"/></g>`;
}
function mouth(mood, ink, y = 82) {
  if (mood === "sad") return `<path d="M52,${y + 4} Q60,${y - 3} 68,${y + 4}" fill="none" stroke="${ink}" stroke-width="3" stroke-linecap="round"/>`;
  if (mood === "think") return `<ellipse cx="62" cy="${y + 1}" rx="3.5" ry="3" fill="${ink}"/>`;
  if (mood === "happy" || mood === "cheer")
    return `<path d="M50,${y - 1} Q60,${y + 13} 70,${y - 1} Z" fill="${ink}"/><path d="M55,${y + 5} Q60,${y + 10} 65,${y + 5} Z" fill="#ff7b8a"/>`;
  return `<path d="M53,${y} Q60,${y + 6} 67,${y}" fill="none" stroke="${ink}" stroke-width="3" stroke-linecap="round"/>`;
}
const paws = (color, mood) => mood === "cheer"
  ? `<g class="m-paws"><ellipse cx="18" cy="70" rx="9" ry="12" fill="${color}" transform="rotate(-25 18 70)"/><ellipse cx="102" cy="70" rx="9" ry="12" fill="${color}" transform="rotate(25 102 70)"/>
     <text x="8" y="26" font-size="14">✨</text><text x="98" y="22" font-size="12">✨</text></g>` : "";

/* ------------------------------ Renarde ----------------------------- */
function fox(mood) {
  const ink = "#2b1d14";
  return `
  ${paws("#f08a2c", mood)}
  <g class="m-head">
    <path d="M22,48 L30,10 L52,34 Z" fill="#f08a2c"/><path d="M29,38 L33,19 L45,33 Z" fill="#3a2418"/>
    <path d="M98,48 L90,10 L68,34 Z" fill="#f08a2c"/><path d="M91,38 L87,19 L75,33 Z" fill="#3a2418"/>
    <ellipse cx="60" cy="66" rx="42" ry="38" fill="#f5913a"/>
    <path d="M18,66 Q34,104 60,104 Q86,104 102,66 Q86,76 72,72 Q60,86 48,72 Q34,76 18,66 Z" fill="#fff6ec"/>
    <ellipse cx="34" cy="80" rx="7" ry="4.5" fill="#ffb3a7" opacity=".7"/><ellipse cx="86" cy="80" rx="7" ry="4.5" fill="#ffb3a7" opacity=".7"/>
    ${eyes(mood, ink)}
    <ellipse cx="60" cy="74" rx="6" ry="4.5" fill="${ink}"/>
    ${mouth(mood, ink, 84)}
  </g>`;
}

/* ------------------------------- Panda ------------------------------ */
function panda(mood) {
  const ink = "#1f2328";
  return `
  ${paws("#2a2e33", mood)}
  <g class="m-head">
    <circle cx="28" cy="30" r="15" fill="#2a2e33"/><circle cx="92" cy="30" r="15" fill="#2a2e33"/>
    <circle cx="28" cy="30" r="7" fill="#4a4f56"/><circle cx="92" cy="30" r="7" fill="#4a4f56"/>
    <ellipse cx="60" cy="64" rx="44" ry="40" fill="#ffffff" stroke="#e3e6ea" stroke-width="2"/>
    <ellipse cx="43" cy="61" rx="12" ry="15" fill="#2a2e33" transform="rotate(25 43 61)"/>
    <ellipse cx="77" cy="61" rx="12" ry="15" fill="#2a2e33" transform="rotate(-25 77 61)"/>
    ${eyes(mood, "#ffffff", 60, 16).replace(/fill="#fff"/g, `fill="${ink}"`)}
    <ellipse cx="38" cy="82" rx="7" ry="4.5" fill="#ffb3c2" opacity=".75"/><ellipse cx="82" cy="82" rx="7" ry="4.5" fill="#ffb3c2" opacity=".75"/>
    <ellipse cx="60" cy="76" rx="6" ry="4.5" fill="${ink}"/>
    ${mouth(mood, ink, 86)}
    <path d="M52,16 q8,-10 16,0" fill="none" stroke="#3aa35c" stroke-width="3" stroke-linecap="round"/><ellipse cx="66" cy="12" rx="6" ry="3" fill="#3aa35c" transform="rotate(-20 66 12)"/>
  </g>`;
}

/**
 * SVG de la mascotte de la langue active.
 * @param {"idle"|"happy"|"cheer"|"sad"|"think"} mood
 */
export function mascot(mood = "idle", { size = 96, cls = "", lang = code } = {}) {
  const kind = (MASCOTS[lang] || MASCOTS.it).kind;
  return `<svg class="mascot m-${mood} ${cls}" width="${size}" height="${size}" viewBox="0 0 120 120" role="img" aria-label="${(MASCOTS[lang] || MASCOTS.it).name}">${kind === "panda" ? panda(mood) : fox(mood)}</svg>`;
}

/* ---------------------------- Répliques ----------------------------- */
const LINES = {
  welcome: { it: ["Ciao ! On continue ?", "Pronto ? Andiamo !", "Un petit pas chaque jour 🇮🇹"], zh: ["你好！On continue ?", "加油 jiāyóu ! Allez !", "Un caractère après l'autre 🐼"] },
  good: { it: ["Bravissimo !", "Perfetto !", "Ottimo !"], zh: ["太棒了 ! Super !", "对了 ! C'est ça !", "很好 !"] },
  bad: { it: ["Pas grave, on réessaie !", "Coraggio !", "Ça viendra 💪"], zh: ["没关系 ! Pas grave !", "加油 ! Courage !", "Ça viendra 💪"] },
  win: { it: ["Che bravo ! Je suis fière de toi !", "Leçon dans la poche !", "Fantastico !"], zh: ["太好了 ! Je suis fier de toi !", "Leçon réussie !", "厉害 lìhai ! Impressionnant !"] },
  fail: { it: ["Presque ! On la refait ensemble ?", "Relis la leçon, tu vas y arriver !"], zh: ["差一点 ! Presque !", "On révise et on recommence !"] },
  streak: { it: ["Ta série brûle 🔥", "Ne la laisse pas s'éteindre !"], zh: ["Ta série brûle 🔥", "Reviens demain, je t'attends !"] },
};
export const line = (key) => { const l = LINES[key]?.[code] || LINES[key]?.it || [""]; return l[Math.floor(Math.random() * l.length)]; };
