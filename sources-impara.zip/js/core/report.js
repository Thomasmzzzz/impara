/* =====================================================================
   report.js — « Signaler un problème »
   Un petit bouton ⚑ dans les quiz, défis, entraînements, histoires,
   dialogues, dictées et exercices de prononciation. Il ouvre une fenêtre
   où l'on choisit le type de problème (traduction, formulation,
   prononciation, réponse refusée à tort, bug) et ajoute un commentaire.
   Le signalement part avec son contexte (question, réponse attendue,
   réponse donnée, phrase lue, voix utilisée) dans la table Supabase
   « reports » (supabase/reports.sql). Sans connexion, il est gardé et
   renvoyé plus tard.
   ===================================================================== */

import { state } from "./storage.js";
import { code, L } from "./lang.js";
import { esc, modal, toast } from "./ui.js";
import { isConfigured, getClient, cloudInfo } from "./cloud.js";
import { mainVoice, tonesFixed } from "./audio.js";
import { clipId, speechText } from "./speechkey.js";

export const KINDS = [
  ["traduction", "🔤", "Mauvaise traduction"],
  ["formulation", "✍️", "Phrase incorrecte ou mal formulée"],
  ["prononciation", "🔊", "Mauvaise prononciation"],
  ["reponse", "✅", "Ma réponse aurait dû être acceptée"],
  ["bug", "🐞", "Bug d'affichage ou autre"],
];

/** Bouton à placer dans l'en-tête d'un exercice */
export const reportButton = (cls = "") =>
  `<button type="button" class="rp-btn ${cls}" data-report aria-label="Signaler un problème" title="Signaler un problème">⚑</button>`;

// Contexte courant fourni par l'exercice affiché (question en cours…)
let ctxFn = null;
/** L'exercice indique ce qui est affiché : () => ({ place, question, expected, given, audio, … }) */
export function setReportContext(fn) { ctxFn = fn; }

const strip = (s) => String(s ?? "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim().slice(0, 400);

function gather() {
  let c = {};
  try { c = ctxFn?.() || {}; } catch {}
  const audio = c.audio ? speechText(c.audio, L.speakFilter) : "";
  return {
    place: strip(c.place || location.hash.slice(1) || "accueil").slice(0, 200),
    context: {
      question: strip(c.question), expected: strip(c.expected), given: strip(c.given),
      audio: strip(audio), clip: audio ? clipId(audio) : "", ref: strip(c.ref),
      extra: c.extra ? strip(typeof c.extra === "string" ? c.extra : JSON.stringify(c.extra)) : "",
      voice: state.settings.recordedVoice === false ? "appareil" : `${mainVoice() || ""}${tonesFixed() ? "" : "~origine"}`,
      hash: location.hash.slice(0, 80), ua: navigator.userAgent.slice(0, 160), at: new Date().toISOString(),
    },
  };
}

/* ------------------------- Envoi (et file d'attente) ------------------------- */
const QUEUE = "impara.reports.queue";
const readQ = () => { try { return JSON.parse(localStorage.getItem(QUEUE) || "[]"); } catch { return []; } };
const writeQ = (q) => { try { localStorage.setItem(QUEUE, JSON.stringify(q.slice(-30))); } catch {} };

async function send(row) {
  if (!isConfigured()) throw new Error("offline");
  const sb = await getClient();
  const uid = cloudInfo().user?.id || null;
  const { error } = await sb.from("reports").insert({ ...row, user_id: uid });
  if (error) throw error;
}
async function flushQueue() {
  const q = readQ();
  if (!q.length || !navigator.onLine) return;
  const left = [];
  for (const r of q) { try { await send(r); } catch { left.push(r); } }
  writeQ(left);
}
if (typeof window !== "undefined") {
  window.addEventListener("online", () => flushQueue());
  setTimeout(() => flushQueue(), 5000);
}

/* ------------------------------- Fenêtre ------------------------------- */
export async function openReport(preset = null) {
  const g = gather();
  const c = g.context;
  const recap = [
    c.question && `<p><small>Question</small>${esc(c.question)}</p>`,
    c.expected && `<p><small>Réponse attendue</small>${esc(c.expected)}</p>`,
    c.given && `<p><small>Votre réponse</small>${esc(c.given)}</p>`,
    !c.question && c.audio && `<p><small>Phrase</small>${esc(c.audio)}</p>`,
  ].filter(Boolean).join("");
  let kind = preset || "", comment = "";
  const v = await modal({
    title: "⚑ Signaler un problème",
    body: `${recap ? `<div class="rp-recap">${recap}</div>` : ""}
      <div class="rp-kinds" role="radiogroup" aria-label="Type de problème">${KINDS.map(([k, ico, l]) =>
        `<button type="button" class="rp-kind ${k === kind ? "on" : ""}" data-kind="${k}" role="radio" aria-checked="${k === kind}"><span>${ico}</span>${l}</button>`).join("")}</div>
      <textarea class="rp-comment" rows="3" maxlength="1000" placeholder="Précisez si besoin (ex. : la bonne traduction serait…)"></textarea>
      <p class="rp-note">Merci ! Le signalement est envoyé avec la question affichée pour pouvoir la corriger.</p>`,
    actions: [{ label: "Annuler", value: "" }, { label: "Envoyer", value: "send", kind: "primary" }],
    onOpen: (root) => {
      const btns = [...root.querySelectorAll("[data-kind]")], sendBtn = root.querySelector('[data-value="send"]');
      const sync = () => { sendBtn.disabled = !kind; };
      btns.forEach((b) => (b.onclick = () => {
        kind = b.dataset.kind;
        btns.forEach((x) => { x.classList.toggle("on", x === b); x.setAttribute("aria-checked", x === b); });
        sync();
      }));
      const ta = root.querySelector(".rp-comment");
      ta.addEventListener("input", () => (comment = ta.value));
      sync();
    },
  });
  if (v !== "send" || !kind) return;
  const row = { kind, comment: comment.trim().slice(0, 1000) || null, lang: code, place: g.place, context: c };
  try { await send(row); toast("Merci, c'est signalé ✓", "ok"); }
  catch (e) {
    if (/too_many/.test(String(e?.message))) { toast("Trop de signalements en ce moment, réessayez plus tard.", "warn"); return; }
    writeQ([...readQ(), row]);
    toast("Signalement gardé : il partira dès que la connexion revient ✓", "ok");
  }
}

// Un seul écouteur pour tous les boutons ⚑ de l'appli
if (typeof document !== "undefined") {
  document.addEventListener("click", (e) => {
    const b = e.target.closest?.("[data-report]");
    if (!b) return;
    e.preventDefault(); e.stopPropagation();
    openReport(b.dataset.report || null);
  });
}
