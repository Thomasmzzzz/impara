/* =====================================================================
   pwa.js — Application installable + notifications push
   ---------------------------------------------------------------------
   - Enregistre le service worker (sw.js) : icône sur l'écran d'accueil,
     ouverture en plein écran, fonctionnement hors ligne.
   - Bouton « Installer » (Android / ordinateur) ; mode d'emploi sur iPhone.
   - Notifications : abonnement Web Push enregistré dans Supabase
     (table push_subscriptions) ; l'envoi est fait par la fonction serveur
     `notify` (voir supabase/push.sql et supabase/functions/notify).
   ===================================================================== */

import { SUPABASE_URL, SUPABASE_ANON_KEY } from "../config.js";
import { getClient, cloudInfo, isConfigured } from "./cloud.js";

let deferred = null;
const listeners = new Set();
export const onPwa = (fn) => (listeners.add(fn), () => listeners.delete(fn));
const emit = () => [...listeners].forEach((fn) => fn());

export const isStandalone = () => matchMedia("(display-mode: standalone)").matches || navigator.standalone === true;
export const isIOS = () => /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
export const canPrompt = () => !!deferred;
export const swSupported = () => "serviceWorker" in navigator && location.protocol === "https:";

export function initPwa() {
  if (swSupported()) navigator.serviceWorker.register("sw.js").catch(() => {});
  addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); deferred = e; emit(); });
  addEventListener("appinstalled", () => { deferred = null; emit(); });
}

/** Ouvre la fenêtre d'installation du navigateur ; renvoie true si acceptée */
export async function promptInstall() {
  if (!deferred) return false;
  deferred.prompt();
  const { outcome } = await deferred.userChoice.catch(() => ({ outcome: "dismissed" }));
  deferred = null; emit();
  return outcome === "accepted";
}

/* --------------------------- Notifications --------------------------- */
export const pushSupported = () => swSupported() && "PushManager" in window && "Notification" in window;
/** Sur iPhone, les notifications ne marchent que dans l'application installée */
export const pushNeedsInstall = () => isIOS() && !isStandalone();

const b64ToBytes = (s) => {
  const pad = "=".repeat((4 - (s.length % 4)) % 4);
  const raw = atob((s + pad).replace(/-/g, "+").replace(/_/g, "/"));
  return Uint8Array.from(raw, (c) => c.charCodeAt(0));
};

async function vapidKey() {
  const res = await fetch(`${SUPABASE_URL}/functions/v1/notify`, {
    method: "POST",
    headers: { "Content-Type": "application/json", apikey: SUPABASE_ANON_KEY },
    body: JSON.stringify({ action: "vapid" }),
  });
  if (!res.ok) throw new Error("Service de notifications indisponible pour le moment.");
  const { publicKey } = await res.json();
  if (!publicKey) throw new Error("Service de notifications indisponible pour le moment.");
  return publicKey;
}

async function currentSub() {
  if (!pushSupported()) return null;
  const reg = await navigator.serviceWorker.getRegistration();
  return reg ? reg.pushManager.getSubscription() : null;
}

/** État affiché dans le profil : unsupported | needs-install | needs-login | denied | on | off */
export async function pushState() {
  if (!isConfigured() || !pushSupported()) return pushNeedsInstall() ? "needs-install" : "unsupported";
  if (pushNeedsInstall()) return "needs-install";
  if (!cloudInfo().user) return "needs-login";
  if (Notification.permission === "denied") return "denied";
  return (await currentSub()) && Notification.permission === "granted" ? "on" : "off";
}

export async function enablePush() {
  if (!cloudInfo().user) throw new Error("Connectez-vous d'abord à votre compte.");
  const perm = await Notification.requestPermission();
  if (perm !== "granted") throw new Error("Notifications refusées. Vous pouvez les autoriser dans les réglages du navigateur.");
  const reg = await navigator.serviceWorker.ready;
  let sub = await reg.pushManager.getSubscription();
  if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToBytes(await vapidKey()) });
  const j = sub.toJSON();
  const sb = await getClient();
  const { error } = await sb.rpc("save_push_subscription", { p_endpoint: j.endpoint, p_p256dh: j.keys.p256dh, p_auth: j.keys.auth });
  if (error) throw new Error(error.message);
}

export async function disablePush() {
  const sub = await currentSub();
  if (!sub) return;
  const sb = await getClient();
  await sb.rpc("remove_push_subscription", { p_endpoint: sub.endpoint }).catch(() => {});
  await sub.unsubscribe().catch(() => {});
}
