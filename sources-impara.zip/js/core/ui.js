/* =====================================================================
   ui.js — Utilitaires d'interface partagés
   ===================================================================== */

import { state } from "./storage.js";
import { L } from "./lang.js";

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/** Échappe le texte saisi par l'utilisateur avant injection HTML */
export const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/** Mélange de Fisher-Yates (copie) */
export function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}

/* ------------------------- Synthèse vocale ------------------------- */
let voice = null;
function pickVoice() {
  try {
    const voices = speechSynthesis.getVoices();
    voice = voices.find((v) => v.lang?.toLowerCase().replace("_", "-") === L.speech.toLowerCase())
      || voices.find((v) => v.lang?.toLowerCase().startsWith(L.voice)) || null;
  } catch { /* non supporté */ }
}
try { pickVoice(); speechSynthesis.onvoiceschanged = pickVoice; } catch {}

/** Vitesses de lecture proposées (multiplicateur de la vitesse de base de la langue) */
export const VOICE_SPEEDS = [[1, "Normale"], [0.8, "Posée"], [0.65, "Lente"]];
const SLOW_FACTOR = 0.55; // bouton 🐢 : nettement plus lent que la vitesse choisie

/**
 * Prononce un texte dans la langue étudiée (en mandarin, seuls les caractères sont lus).
 * @param {{slow?: boolean}} opts  slow : lecture ralentie (bouton 🐢)
 */
export function speak(text, { slow = false, force = false } = {}) {
  if (!state.settings.tts && !force) return; // les exercices d'écoute jouent toujours le son
  let t = String(text).split("|")[0].replace(/[✓✗]/g, "");
  if (L.speakFilter) t = t.replace(L.speakFilter, "");
  t = t.trim();
  if (!t) return;
  try {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(t);
    u.lang = L.speech;
    const base = L.rate * (state.settings.voiceSpeed || 1);
    u.rate = slow ? Math.max(0.35, base * SLOW_FACTOR) : base;
    if (voice) u.voice = voice;
    speechSynthesis.speak(u);
  } catch { toast("Audio indisponible sur ce navigateur", "warn"); }
}
export const speakBtn = (text) =>
  `<span class="speak-pair"><button class="speak" data-speak="${esc(text)}" aria-label="Écouter « ${esc(text)} »" title="Écouter">🔊</button>` +
  `<button class="speak slow" data-speak="${esc(text)}" data-slow aria-label="Écouter lentement « ${esc(text)} »" title="Écouter lentement">🐢</button></span>`;

/* ------------------------------ Toasts ----------------------------- */
export function toast(msg, type = "info") {
  const root = $("#toast-root");
  const el = document.createElement("div");
  el.className = `toast toast-${type}`;
  el.textContent = msg;
  root.appendChild(el);
  requestAnimationFrame(() => el.classList.add("show"));
  setTimeout(() => { el.classList.remove("show"); setTimeout(() => el.remove(), 300); }, 2600);
}

/* ------------------------------ Modale ----------------------------- */
/**
 * Boîte de dialogue intégrée (remplace confirm/alert, bloqués dans certains contextes).
 * @returns {Promise<string|null>} valeur du bouton cliqué
 */
export function modal({ title, body = "", actions = [{ label: "OK", value: "ok", kind: "primary" }], dismissable = true }) {
  return new Promise((resolve) => {
    const root = $("#modal-root");
    root.innerHTML = `
      <div class="modal-backdrop" data-close>
        <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
          <h2 id="modal-title">${title}</h2>
          <div class="modal-body">${body}</div>
          <div class="modal-actions">
            ${actions.map((a) => `<button class="btn ${a.kind || "ghost"}" data-value="${a.value}">${a.label}</button>`).join("")}
          </div>
        </div>
      </div>`;
    const close = (v) => { root.innerHTML = ""; resolve(v); };
    root.querySelectorAll("[data-value]").forEach((b) => (b.onclick = () => close(b.dataset.value)));
    if (dismissable) root.querySelector("[data-close]").onclick = (e) => { if (e.target.dataset.close !== undefined) close(null); };
    root.querySelector(".modal .btn.primary, .modal .btn")?.focus();
  });
}

/* --------------------------- Confettis ----------------------------- */
export function celebrate() {
  const colors = L.confetti;
  const box = document.createElement("div");
  box.className = "confetti";
  for (let i = 0; i < 60; i++) {
    const p = document.createElement("i");
    p.style.left = Math.random() * 100 + "%";
    p.style.background = colors[i % colors.length];
    p.style.animationDelay = Math.random() * 0.4 + "s";
    p.style.transform = `rotate(${Math.random() * 360}deg)`;
    box.appendChild(p);
  }
  document.body.appendChild(box);
  setTimeout(() => box.remove(), 2600);
}

/** Anneau de progression SVG */
export function ring(pct, size = 120, stroke = 10, label = `${pct}%`) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r;
  return `<svg class="ring" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" role="img" aria-label="${pct} %">
    <circle cx="${size / 2}" cy="${size / 2}" r="${r}" stroke-width="${stroke}" class="ring-bg"/>
    <circle cx="${size / 2}" cy="${size / 2}" r="${r}" stroke-width="${stroke}" class="ring-fg"
      stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - pct / 100)}" transform="rotate(-90 ${size / 2} ${size / 2})"/>
    <text x="50%" y="50%" dominant-baseline="central" text-anchor="middle" class="ring-label">${label}</text>
  </svg>`;
}

export const AVATARS = L.avatars;

/** Uniformise exemples et vocabulaire : [mot, fr] → [mot, "", fr] ; [mot, pinyin, fr] inchangé */
export const tri = (x) => (x.length === 3 ? x : [x[0], "", x[1]]);

/** Affiche "汉字|pinyin" en deux lignes (caractères + pinyin) */
export const pair = (s) => {
  const [a, b] = String(s).split("|");
  return b ? `<span class="zh">${esc(a)}</span><small class="py">${esc(b)}</small>` : esc(a);
};
/** Version texte brut de "汉字|pinyin" */
export const plain = (s) => String(s).replace("|", " ");
