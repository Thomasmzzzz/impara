/* =====================================================================
   ui.js — Utilitaires d'interface partagés
   ===================================================================== */

import { state, commit } from "./storage.js";
import { L, LANGS } from "./lang.js";
import { sfx, haptic } from "./fx.js";
import { speechText } from "./speechkey.js";
import { hasClip, playClip, stopClip, voiceFor } from "./audio.js";

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/** Échappe le texte saisi par l'utilisateur avant injection HTML */
export const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/** Mélange de Fisher-Yates (copie) */
export function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}

/* ------------------------- Synthèse vocale ------------------------- */
// Choix de la voix : on classe les voix de l'appareil pour prendre la plus
// naturelle (voix « Natural » d'Edge, « Premium » / « améliorée » d'Apple,
// voix Google…), en écartant le cantonais (zh-HK) pour le mandarin.
// L'utilisateur peut aussi en imposer une dans les réglages.
let voice = null;
const QUALITY = [
  [/natural|neural|wavenet|online/i, 60, "Naturelle"],
  [/premium/i, 55, "Premium"],
  [/enhanced|améliorée|amélioré|verbessert|mejorada|migliorata/i, 50, "Améliorée"],
  [/siri/i, 45, "Siri"],
  [/google/i, 35, "Google"],
];
const NICE = { it: /alice|federica|emma|paola|luca|elsa|isabella|diego|giuseppe/i, zh: /tingting|ting-ting|lili|lilian|yaoyao|xiaoxiao|xiaoyi|yunxi|yunyang|huihui|kangkang|meijia/i };
function voiceInfo(v) {
  const lang = (v.lang || "").toLowerCase().replace("_", "-");
  let score = 0, tag = "Standard";
  for (const [re, pts, label] of QUALITY) if (re.test(v.name)) { score += pts; tag = label; break; }
  if (lang === L.speech.toLowerCase()) score += 20;
  if (NICE[L.code]?.test(v.name)) score += 10;
  if (v.localService === false) score += 5;
  if (/espeak|compact|eloquence/i.test(v.name)) score -= 40;
  if (L.code === "zh") {
    if (/zh-hk|yue|cantonese|粤|粵/i.test(lang + " " + v.name)) score -= 1000; // cantonais : pas du mandarin
    else if (/zh-tw|taiwan/i.test(lang + " " + v.name)) score -= 8;
  }
  return { v, name: v.name, lang: v.lang, score, tag };
}
/** Voix de l'appareil pour la langue apprise, de la plus naturelle à la plus robotique */
export function listVoices() {
  try {
    return speechSynthesis.getVoices()
      .filter((v) => (v.lang || "").toLowerCase().replace("_", "-").startsWith(L.voice))
      .map(voiceInfo).filter((x) => x.score > -500)
      .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name))
      // iPhone : la même voix peut apparaître deux fois (deux identifiants internes)
      .filter((x, i, arr) => arr.findIndex((y) => y.name === x.name && y.lang === x.lang) === i);
  } catch { return []; }
}
const chosenName = () => state.settings?.voiceName?.[L.code] || "";
function pickVoice() {
  const list = listVoices();
  voice = (chosenName() && list.find((x) => x.name === chosenName())?.v) || list[0]?.v || null;
  voiceListeners.forEach((f) => f());
}
const voiceListeners = new Set();
/** Prévenir quand la liste des voix change (elle arrive après le chargement sur Chrome) */
export const onVoices = (f) => { voiceListeners.add(f); return () => voiceListeners.delete(f); };
export const currentVoice = () => voice;
/** Impose une voix ("" = automatique : la meilleure disponible) */
export function setVoice(name) {
  commit((s) => { s.settings.voiceName = { ...(s.settings.voiceName || {}), [L.code]: name || "" }; });
  pickVoice();
}
try { pickVoice(); speechSynthesis.onvoiceschanged = pickVoice; } catch {}

/** Vitesses de lecture proposées (multiplicateur de la vitesse de base de la langue) */
export const VOICE_SPEEDS = [[1, "Normale"], [0.8, "Posée"], [0.65, "Lente"]];
const SLOW_FACTOR = 0.55; // bouton 🐢 : nettement plus lent que la vitesse choisie

/**
 * Prononce un texte dans la langue étudiée (en mandarin, seuls les caractères sont lus).
 * @param {{slow?: boolean, voice?: string}} opts  slow : lecture ralentie (bouton 🐢) ;
 *   voice : « f » / « m » (voix d'un personnage) ou « alt » (l'autre voix enregistrée)
 */
export function speak(text, { slow = false, force = false, rate = null, lang = null, factor = 1, device = false, voice = null } = {}) {
  if (!state.settings.tts && !force) return; // les exercices d'écoute jouent toujours le son
  const t = speechText(text, L.speakFilter);
  if (!t) return;
  const other = lang && lang !== L.code && LANGS[lang];   // mot d'une autre langue (carte partagée par un ami)
  stopClip();
  try { speechSynthesis.cancel(); } catch {}
  // Voix naturelle enregistrée si la phrase l'est (sinon, voix de l'appareil)
  const v = voiceFor(voice);
  if (!other && !device && state.settings.recordedVoice !== false && hasClip(t, v)) {
    const pr = (state.settings.voiceSpeed || 1) * (slow ? SLOW_FACTOR : 1) * (rate ? rate / L.rate : factor);
    playClip(t, pr, v).then((ok) => { if (!ok) ttsSpeak(t, { slow, rate, other, factor }); });
    return;
  }
  ttsSpeak(t, { slow, rate, other, factor });
}
/** Arrête toute lecture en cours (enregistrement ou voix de l'appareil) */
export function stopSpeaking() { stopClip(); try { speechSynthesis.cancel(); } catch {} }
function ttsSpeak(t, { slow, rate, other, factor }) {
  try {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(t);
    u.lang = other ? other.speech : L.speech;
    const base = L.rate * (state.settings.voiceSpeed || 1);
    u.rate = slow ? Math.max(0.35, base * SLOW_FACTOR) : rate || base * factor;
    if (voice && !other) { u.voice = voice; u.lang = voice.lang || u.lang; }
    speechSynthesis.speak(u);
  } catch { toast("Audio indisponible sur ce navigateur", "warn"); }
}
export const speakBtn = (text) =>
  `<span class="speak-pair"><button class="speak" data-speak="${esc(text)}" aria-label="Écouter « ${esc(text)} »" title="Écouter">🔊</button>` +
  `<button class="speak slow" data-speak="${esc(text)}" data-slow aria-label="Écouter lentement « ${esc(text)} »" title="Écouter lentement">🐢</button></span>`;

/* ------------------------------ Toasts ----------------------------- */
export function toast(msg, type = "info", { href = "", ms = 2600 } = {}) {
  const root = $("#toast-root");
  const el = document.createElement("div");
  el.className = `toast toast-${type}${href ? " toast-link" : ""}`;
  el.textContent = msg;
  if (href) { el.setAttribute("role", "link"); el.onclick = () => { location.hash = href; el.remove(); }; }
  root.appendChild(el);
  requestAnimationFrame(() => el.classList.add("show"));
  setTimeout(() => { el.classList.remove("show"); setTimeout(() => el.remove(), 300); }, ms);
}

/* ------------------------------ Modale ----------------------------- */
/**
 * Boîte de dialogue intégrée (remplace confirm/alert, bloqués dans certains contextes).
 * @returns {Promise<string|null>} valeur du bouton cliqué
 */
export function modal({ title, body = "", actions = [{ label: "OK", value: "ok", kind: "primary" }], dismissable = true, onOpen = null }) {
  return new Promise((resolve) => {
    const root = $("#modal-root");
    root.innerHTML = `
      <div class="modal-backdrop" data-close>
        <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
          <h2 id="modal-title">${title}</h2>
          <div class="modal-body">${body}</div>
          <div class="modal-actions">
            ${actions.map((a) => `<button class="btn ${a.kind || "ghost"}" data-value="${a.value}">${a.label}</button>`).join("")}
          </div>
        </div>
      </div>`;
    document.documentElement.classList.add("modal-open"); // la page derrière ne défile plus
    const close = (v) => { root.innerHTML = ""; document.documentElement.classList.remove("modal-open"); resolve(v); };
    root.querySelectorAll("[data-value]").forEach((b) => (b.onclick = () => close(b.dataset.value)));
    if (dismissable) root.querySelector("[data-close]").onclick = (e) => { if (e.target.dataset.close !== undefined) close(null); };
    root.querySelector(".modal .btn.primary, .modal .btn")?.focus();
    onOpen?.(root);
  });
}

/* --------------------------- Confettis ----------------------------- */
export function celebrate({ sound = "win" } = {}) {
  if (sound) sfx(sound);
  haptic([30, 50, 30, 50, 80]);
  const colors = L.confetti;
  const box = document.createElement("div");
  box.className = "confetti";
  for (let i = 0; i < 60; i++) {
    const p = document.createElement("i");
    p.style.left = Math.random() * 100 + "%";
    p.style.background = colors[i % colors.length];
    p.style.animationDelay = Math.random() * 0.4 + "s";
    p.style.transform = `rotate(${Math.random() * 360}deg)`;
    box.appendChild(p);
  }
  document.body.appendChild(box);
  setTimeout(() => box.remove(), 2600);
}

/** Anneau de progression SVG */
export function ring(pct, size = 120, stroke = 10, label = `${pct}%`) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r;
  return `<svg class="ring" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" role="img" aria-label="${pct} %">
    <circle cx="${size / 2}" cy="${size / 2}" r="${r}" stroke-width="${stroke}" class="ring-bg"/>
    <circle cx="${size / 2}" cy="${size / 2}" r="${r}" stroke-width="${stroke}" class="ring-fg"
      stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - pct / 100)}" transform="rotate(-90 ${size / 2} ${size / 2})"/>
    <text x="50%" y="50%" dominant-baseline="central" text-anchor="middle" class="ring-label">${label}</text>
  </svg>`;
}

export const AVATARS = L.avatars;

/** Uniformise exemples et vocabulaire : [mot, fr] → [mot, "", fr] ; [mot, pinyin, fr] inchangé */
export const tri = (x) => (x.length === 3 ? x : [x[0], "", x[1]]);
/**
 * Exemple de leçon → répliques séparées. « Di dove sei? — Sono francese. » devient deux phrases,
 * chacune avec SA traduction (avant, la phrase entière gardait la traduction de la 1re réplique
 * seulement : impossible de deviner « francese »). Le tiret peut être collé (« 他是谁？— … »).
 */
export function splitDialog(ex) {
  const [t, py, fr] = tri(ex), sep = /\s*—+\s*/;
  const ts = String(t).split(sep), ps = String(py || "").split(sep), fs = String(fr).split(sep);
  // une réplique se termine par une ponctuation (sinon c'est une expression du type 竹篮打水——一场空)
  const turns = ts.slice(0, -1).every((x) => /[.!?…。！？]$/.test(x.trim()));
  if (ts.length > 1 && turns && ts.length === fs.length) return ts.map((x, i) => [x.trim(), (ps.length === ts.length ? ps[i] : "").trim(), fs[i].trim()]);
  return [[t, py, fr]];
}

/** Affiche "汉字|pinyin" en deux lignes (caractères + pinyin) */
export const pair = (s) => {
  const [a, b] = String(s).split("|");
  return b ? `<span class="zh">${esc(a)}</span><small class="py">${esc(b)}</small>` : esc(a);
};
/** Version texte brut de "汉字|pinyin" */
export const plain = (s) => String(s).replace("|", " ");
