/* =====================================================================
   fx.js — Effets sonores (synthétisés, aucun fichier audio) et vibrations
   Réglages : state.settings.sfx (sons) et state.settings.haptics (vibrations).
   Les vibrations ne fonctionnent que sur Android (l'iPhone ne les autorise
   pas aux sites web).
   ===================================================================== */
import { state } from "./storage.js";

let ctx = null;
function audio() {
  try {
    ctx ||= new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === "suspended") ctx.resume();
    return ctx;
  } catch { return null; }
}

function tone(c, freq, start, dur, { type = "sine", vol = 0.16, to = null } = {}) {
  const o = c.createOscillator(), g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, start);
  if (to) o.frequency.exponentialRampToValueAtTime(to, start + dur);
  g.gain.setValueAtTime(0.0001, start);
  g.gain.exponentialRampToValueAtTime(vol, start + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
  o.connect(g).connect(c.destination);
  o.start(start); o.stop(start + dur + 0.02);
}

const SOUNDS = {
  good: (c, t) => { tone(c, 880, t, 0.12, { type: "triangle" }); tone(c, 1318.5, t + 0.08, 0.22, { type: "triangle" }); },
  bad: (c, t) => { tone(c, 196, t, 0.22, { type: "sawtooth", vol: 0.06, to: 140 }); tone(c, 155, t + 0.12, 0.25, { type: "sawtooth", vol: 0.05, to: 110 }); },
  combo: (c, t) => [784, 988, 1175, 1568].forEach((f, k) => tone(c, f, t + k * 0.06, 0.16, { type: "triangle", vol: 0.12 })),
  win: (c, t) => [523.3, 659.3, 784, 1046.5].forEach((f, k) => tone(c, f, t + k * 0.11, k === 3 ? 0.5 : 0.18, { type: "triangle", vol: 0.15 })),
  fanfare: (c, t) => {
    [[523.3, 0], [523.3, .12], [523.3, .24], [659.3, .36], [784, .6], [659.3, .78], [784, .9], [1046.5, 1.08]].forEach(([f, d], k) =>
      tone(c, f, t + d, k === 7 ? 0.8 : 0.16, { type: "square", vol: 0.07 }));
    [261.6, 329.6, 392].forEach((f) => tone(c, f, t + 1.08, 0.8, { type: "triangle", vol: 0.08 }));
  },
  streak: (c, t) => { tone(c, 300, t, 0.5, { type: "sine", vol: 0.1, to: 900 }); [1046.5, 1318.5].forEach((f, k) => tone(c, f, t + 0.45 + k * 0.1, 0.3, { type: "triangle", vol: 0.12 })); },
  tap: (c, t) => tone(c, 660, t, 0.05, { type: "sine", vol: 0.05 }),
};

/** Joue un effet : good · bad · combo · win · fanfare · streak · tap */
export function sfx(name) {
  if (state.settings?.sfx === false) return;
  const c = audio(); if (!c || !SOUNDS[name]) return;
  try { SOUNDS[name](c, c.currentTime + 0.01); } catch {}
}

/** Vibration (motif en millisecondes) */
export function haptic(pattern) {
  if (state.settings?.haptics === false) return;
  try { navigator.vibrate?.(pattern); } catch {}
}
