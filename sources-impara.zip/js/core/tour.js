/* =====================================================================
   tour.js — Bulles d'aide (visite guidée) au premier lancement.
   Chaque étape met en lumière un élément de la page avec une bulle
   d'explication ; « Suivant » passe à l'étape d'après.
   ===================================================================== */
import { state, commit } from "./storage.js";

const visible = (el) => { if (!el) return false; const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== "hidden"; };

/**
 * @param {{sel:string|string[], title:string, text:string}[]} steps
 * @param {string} key  clé enregistrée dans state.settings.tours une fois la visite terminée
 */
export function runTour(steps, key) {
  if (state.settings.tours?.[key]) return;
  const list = steps.map((s) => ({ ...s, el: [].concat(s.sel).map((q) => [...document.querySelectorAll(q)].find(visible)).find(Boolean) })).filter((s) => s.el);
  if (!list.length) return;
  let i = 0;
  const root = document.createElement("div");
  root.className = "tour";
  root.innerHTML = `<div class="tour-hole"></div><div class="tour-bubble" role="dialog" aria-live="polite"><p class="tour-step"></p><h3></h3><p class="tour-text"></p>
    <div class="tour-actions"><button type="button" class="btn ghost small" data-skip>Passer</button><button type="button" class="btn primary small" data-next>Suivant</button></div></div>`;
  document.body.appendChild(root);
  const hole = root.querySelector(".tour-hole"), bubble = root.querySelector(".tour-bubble");
  const finish = () => {
    root.remove(); removeEventListener("resize", place); removeEventListener("scroll", place, true);
    commit((s) => { s.settings.tours = { ...(s.settings.tours || {}), [key]: Date.now() }; });
  };
  function place() {
    const s = list[i], r = s.el.getBoundingClientRect(), pad = 8;
    Object.assign(hole.style, { left: `${r.left - pad}px`, top: `${r.top - pad}px`, width: `${r.width + pad * 2}px`, height: `${r.height + pad * 2}px` });
    const bw = Math.min(320, innerWidth - 24), below = r.bottom + 14 + 170 < innerHeight;
    bubble.style.width = `${bw}px`;
    bubble.style.left = `${Math.max(12, Math.min(innerWidth - bw - 12, r.left + r.width / 2 - bw / 2))}px`;
    bubble.style.top = below ? `${r.bottom + 14}px` : "";
    bubble.style.bottom = below ? "" : `${innerHeight - r.top + 14}px`;
    bubble.classList.toggle("up", !below);
  }
  function show() {
    const s = list[i];
    s.el.scrollIntoView({ block: "center", behavior: "instant" in document.documentElement.style ? "instant" : "auto" });
    root.querySelector(".tour-step").textContent = `${i + 1} / ${list.length}`;
    root.querySelector("h3").textContent = s.title;
    root.querySelector(".tour-text").textContent = s.text;
    root.querySelector("[data-next]").textContent = i === list.length - 1 ? "C'est parti !" : "Suivant";
    requestAnimationFrame(place);
    root.querySelector("[data-next]").focus();
  }
  root.querySelector("[data-next]").onclick = () => { if (++i < list.length) show(); else finish(); };
  root.querySelector("[data-skip]").onclick = finish;
  addEventListener("resize", place); addEventListener("scroll", place, true);
  show();
}
