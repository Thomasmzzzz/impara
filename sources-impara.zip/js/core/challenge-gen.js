/* =====================================================================
   challenge-gen.js — Questions des défis entre amis
   ---------------------------------------------------------------------
   Les défis ne reprennent PAS les questions du cours : ils sont générés
   à partir des mots que le joueur a réellement appris (son carnet =
   mots des leçons réussies), avec des formulations variées :
   sens d'un mot, mot à partir du sens, écoute, vrai/faux, association,
   écriture, phrase à compléter, et en mandarin pinyin ⇄ caractères.
   Un défi n'est jouable qu'avec assez de mots appris (MIN_WORDS).
   ===================================================================== */

import { state } from "./storage.js";
import { code, L } from "./lang.js";
import { shuffle, tri } from "./ui.js";
import { levelWantsPinyin } from "./pinyin.js";
import { ALL_LESSONS } from "../data/curriculum.js";

export const MIN_WORDS = 12;

/** Mots appris dans la langue active (un par entrée du carnet) */
export function learnedWords() {
  return Object.values(state.vocab).filter((w) => w.zh && w.fr).map((w) => ({ ...w, py: w.py || "" }));
}
/** Mots nécessaires pour un défi de n questions : au moins n (et jamais moins de MIN_WORDS) */
export const wordsNeeded = (n = 10) => Math.max(MIN_WORDS, n);
export const canChallenge = (n = 5) => learnedWords().length >= wordsNeeded(n);
export const missingWords = (n = 5) => Math.max(0, wordsNeeded(n) - learnedWords().length);
export const CHALLENGE_SIZES = [[5, "Éclair", "≈ 1 min"], [10, "Classique", "≈ 2 min"], [15, "Marathon", "≈ 4 min"], [25, "Expert", "≈ 6 min"], [50, "Ultime", "≈ 12 min"]];

const zh = () => code === "zh";
const pick = (arr, n) => shuffle(arr).slice(0, n);
const strip = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "");
const cleanFr = (fr) => String(fr).split(" — ")[0];

/** Autres mots du carnet, pour fabriquer les mauvaises réponses */
function distractors(w, pool, n, key) {
  const seen = new Set([key(w)]);
  const out = [];
  for (const x of shuffle(pool)) {
    const k = key(x);
    if (!seen.has(k)) { seen.add(k); out.push(x); }
    if (out.length === n) break;
  }
  return out;
}

const mcq = (q, right, wrongs, extra = {}) => {
  const options = shuffle([right, ...wrongs]);
  return { type: "mcq", q, options, answer: options.indexOf(right), ...extra };
};

/* --------------------------- Variantes de tons ----------------------- */
const TONES = { a: "āáǎà", e: "ēéěè", i: "īíǐì", o: "ōóǒò", u: "ūúǔù", "ü": "ǖǘǚǜ" };
/** « nǐ hǎo » → [« ní hǎo », « nǐ hào », …] : même lettres, autres tons */
function toneVariants(py) {
  const chars = [...py];
  const marked = chars.map((c, i) => [c, i]).filter(([c]) => Object.values(TONES).some((t) => t.includes(c)));
  const out = new Set();
  for (const [c, i] of shuffle(marked)) {
    const base = Object.keys(TONES).find((v) => TONES[v].includes(c));
    for (const t of TONES[base]) if (t !== c) { const v = [...chars]; v[i] = t; out.add(v.join("")); }
    if (out.size >= 6) break;
  }
  return [...out];
}

/* --------------------------- Phrases d'exemple ----------------------- */
/** Exemples des leçons RÉUSSIES contenant le mot (pour « complétez la phrase ») */
function exampleFor(w, extra = []) {
  const done = [...ALL_LESSONS.filter((l) => state.lessons[l.id]?.passed), ...extra];
  const all = done.flatMap((l) => (l.sections || []).flatMap((s) => s.examples || [])).map(tri);
  const it = !zh();
  const has = ([s]) => (it ? new RegExp(`(^|[^\\p{L}])${w.zh.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^\\p{L}]|$)`, "iu").test(s) : s.includes(w.zh)) && s !== w.zh;
  // La phrase doit garder du contexte une fois le mot retiré (pas juste « ___ ! »)
  const context = ([s]) => s.replace(it ? new RegExp(w.zh, "i") : w.zh, "").replace(/[\s\p{P}]/gu, "").length >= 2;
  const ex = shuffle(all.filter((e) => has(e) && context(e)))[0];
  if (!ex) return null;
  const [sentence, , fr] = ex;
  const idx = it ? sentence.toLowerCase().indexOf(w.zh.toLowerCase()) : sentence.indexOf(w.zh);
  return { text: sentence.slice(0, idx) + "___" + sentence.slice(idx + w.zh.length), fr: cleanFr(fr) };
}

/* ----------------------------- Générateurs --------------------------- */
const word = (w) => w.zh;
const answersFor = (w) => [w.zh, ...(w.py ? [w.py, strip(w.py), w.py.replace(/\s+/g, "")] : [])];

function makers(w, pool, withPy, extra = []) {
  const fr = cleanFr(w.fr);
  const other = (n, key) => distractors(w, pool, n, key);
  const lang = L.label.toLowerCase();
  const list = [
    // 1. Sens du mot
    () => mcq(zh() ? `Que signifie ${w.zh} ?` : `Que signifie « ${w.zh} » ?`, fr, other(3, (x) => cleanFr(x.fr)).map((x) => cleanFr(x.fr))),
    // 2. Le mot à partir du sens
    () => mcq(`Comment dit-on « ${fr} » en ${lang} ?`, w.zh, other(3, word).map(word)),
    // 3. Écoute : quel mot ?
    () => { const o = shuffle([w, ...other(3, word)]); return { type: "listen", say: w.zh, q: "Quel mot entendez-vous ?", options: o.map(word), answer: o.indexOf(w), reveal: `${w.zh}${w.py ? " (" + w.py + ")" : ""} — ${fr}` }; },
    // 4. Écoute : quel sens ?
    () => { const o = shuffle([w, ...other(3, (x) => cleanFr(x.fr))]); return { type: "listen", say: w.zh, q: "Que veut dire le mot entendu ?", options: o.map((x) => cleanFr(x.fr)), answer: o.indexOf(w), reveal: `${w.zh}${w.py ? " (" + w.py + ")" : ""} — ${fr}` }; },
    // 5. Vrai ou faux
    () => {
      const truth = Math.random() < 0.5, x = truth ? w : other(1, (y) => cleanFr(y.fr))[0] || w;
      return { type: "mcq", q: zh() ? `${w.zh} veut dire « ${cleanFr(x.fr)} » : vrai ou faux ?` : `« ${w.zh} » veut dire « ${cleanFr(x.fr)} » : vrai ou faux ?`,
        options: ["✓ Vrai", "✗ Faux"], answer: truth || x === w ? 0 : 1, explain: `${w.zh}${w.py ? " " + w.py : ""} = ${fr}` };
    },
    // 6. Associer 4 mots et leur sens
    () => { const g = [w, ...other(3, (x) => cleanFr(x.fr))]; return { type: "match", q: "Associez chaque mot à son sens", pairs: g.map((x) => [x.py ? `${x.zh}|${x.py}` : x.zh, cleanFr(x.fr)]) }; },
    // 7. Écrire le mot
    () => ({ type: "translate", q: zh() ? `Écrivez « ${fr} » en pinyin (ou en caractères)` : `Écrivez « ${fr} » en ${lang}`, answer: answersFor(w), explain: `${w.zh}${w.py ? " " + w.py : ""}` }),
  ];
  // 8. Phrase à compléter (exemple d'une leçon réussie)
  const ex = exampleFor(w, extra);
  if (ex) list.push(() => ({ type: "fill", q: `${ex.text} (${ex.fr})`, answer: answersFor(w), explain: `${w.zh}${w.py ? " " + w.py : ""} = ${fr}` }));
  // Mandarin : pinyin ⇄ caractères (seulement quand le pinyin n'est pas déjà affiché)
  if (zh() && w.py && !withPy) {
    list.push(() => {
      const wrong = [...new Set([...toneVariants(w.py), ...other(4, (x) => x.py).map((x) => x.py)])].filter((p) => p && p !== w.py);
      return mcq(`Quel est le pinyin de ${w.zh} ?`, w.py, pick(wrong, 3), { explain: `${w.zh} ${w.py} = ${fr}` });
    });
    list.push(() => mcq(`Quels caractères se lisent « ${w.py} » ?`, w.zh, other(3, word).map(word), { explain: `${w.zh} ${w.py} = ${fr}` }));
  }
  if (zh() && w.py && withPy) {
    // Avec pinyin affiché : les tons à l'oreille
    list.push(() => {
      const wrong = [...new Set(toneVariants(w.py))].filter((p) => p !== w.py);
      if (wrong.length < 3) return null;
      const o = shuffle([w.py, ...pick(wrong, 3)]);
      return { type: "listen", say: w.zh, q: "Quels tons entendez-vous ?", options: o, answer: o.indexOf(w.py), reveal: `${w.zh} ${w.py} — ${fr}` };
    });
  }
  return list;
}

/**
 * Construit n questions variées à partir des mots appris.
 * @returns {{ref:string, q:object}[]} vide si pas assez de mots
 */
export function buildChallengeQuestions(n = 10) {
  const pool = learnedWords();
  if (pool.length < MIN_WORDS) return [];
  const words = [];
  while (words.length < n) words.push(...shuffle(pool));
  const used = [];
  return words.slice(0, n).map((w, i) => {
    const withPy = levelWantsPinyin(w.levelId);
    const fns = shuffle(makers(w, pool, withPy));
    // On évite deux formulations identiques d'affilée
    let q = null, kind = -1;
    for (const [k, f] of fns.entries()) {
      const cand = f();
      if (!cand) continue;
      const sig = cand.type + cand.q.slice(0, 12);
      if (used[used.length - 1] === sig && k < fns.length - 1) continue;
      q = cand; kind = sig; break;
    }
    used.push(kind);
    return { ref: `defi:${i}:${w.zh}`, q: { ...q, _py: withPy } };
  });
}

/**
 * Questions générées pour un quiz de leçon : uniquement sur les mots de
 * la leçon, avec le reste du vocabulaire connu pour les mauvaises réponses.
 * @returns {{ref:string, q:object}[]}
 */
export function buildLessonQuestions(lesson, n) {
  const own = lesson.vocab.map(tri).map(([zhw, py, fr]) => ({ zh: zhw, py: py || "", fr, levelId: lesson.levelId }));
  const seen = new Set(own.map((w) => w.zh));
  const pool = [...own];
  for (const w of [...learnedWords(), ...ALL_LESSONS.filter((l) => l.levelId === lesson.levelId).flatMap((l) => l.vocab.map(tri).map(([a, b, c]) => ({ zh: a, py: b || "", fr: c })))]) {
    if (!seen.has(w.zh)) { seen.add(w.zh); pool.push(w); }
  }
  if (own.length < 2 || pool.length < 4) return [];
  const withPy = levelWantsPinyin(lesson.levelId);
  const out = [], used = new Set();
  const order = [...shuffle(own), ...shuffle(own), ...shuffle(own)]; // un mot peut revenir sous une autre forme
  for (const w of order) {
    if (out.length >= n) break;
    for (const f of shuffle(makers(w, pool, withPy, [lesson]))) {
      const cand = f();
      if (!cand) continue;
      const sig = cand.type + cand.q.slice(0, 12);
      if (used.has(sig)) continue;
      used.add(sig);
      out.push({ ref: `${lesson.id}:gen:${out.length}`, q: { ...cand, _py: withPy } });
      break;
    }
  }
  return out;
}
